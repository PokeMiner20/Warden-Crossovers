class PBStuff
  BITEMOVE     = [:BITE,:CRUNCH,:THUNDERFANG,:FIREFANG,:ICEFANG,:POISONFANG,:HYPERFANG,:PSYCHICFANGS,:FISHIOUSREND,:ORN_VISEGRIP,:ORN_STRAFE,:ORN_DRAGONGNAW,:ORN_NECROPHAGY,:ORN_FLYTRAP,:ORN_FROSTBITE,:ORN_VENOMDRAIN,:ORN_MINDDRAIN,:ORN_AQUAFANG,:ORN_SLURP,:ORN_SUCKBLOOD]
  BULLETMOVE   = [:ACIDSPRAY,:AURASPHERE,:BARRAGE,:BULLETSEED,:EGGBOMB,:ELECTROBALL,:ENERGYBALL,:FOCUSBLAST,:GYROBALL,:ICEBALL,:MAGNETBOMB,:MISTBALL,:MUDBOMB,:OCTAZOOKA,:ROCKWRECKER,:SEARINGSHOT,:SEEDBOMB,:SHADOWBALL,:SLUDGEBOMB,:WEATHERBALL,:ZAPCANNON,:BEAKBLAST,:PYROBALL,:ORN_LOVEBURST,:ORN_CHAKRABLAST,:ORN_CHIORB,:ORN_FIREBALL,:ORN_CATAPULT,:ORN_HELLBULLET,:ORN_TIMEBOMB,:ORN_CORALBOMB,:ORN_ALKALINEBOMB,:ORN_BOMBARDMENT,:ORN_SHRAPNEL,:ORN_CLUSTERROCKETS,:ORN_SONICBLAST,:ORN_MUDBLAST,:ORN_DIRTYBOMB,:ORN_MANABLAST]
  NOCOPYMOVE   = [:ASSIST,:COPYCAT,:MEFIRST,:METRONOME,:MIMIC,:MIRRORMOVE,:NATUREPOWER,:SHELLTRAP,:SKETCH,:SLEEPTALK,:STRUGGLE,:BEAKBLAST,:FOCUSPUNCH,:TRANSFORM,:BELCH,:CHATTER,:KINGSSHIELD,:BANEFULBUNKER,:BESTOW,:COUNTER,:COVET,:DESTINYBOND,:DETECT,:ENDURE,:FEINT,:FOLLOWME,:HELPINGHAND,:MATBLOCK,:MIRRORCOAT,:PROTECT,:RAGEPOWDER,:SNATCH,:SPIKYSHIELD,:SPOTLIGHT,:SWITCHEROO,:THIEF,:TRICK,:ORN_GOLDRUSH,:ORN_RAYOFLIGHT,:ORN_GRABANDGO]
  DANCEMOVE    = [:QUIVERDANCE,:DRAGONDANCE,:FIERYDANCE,:FEATHERDANCE,:PETALDANCE,:SWORDSDANCE,:TEETERDANCE,:LUNARDANCE,:REVELATIONDANCE,:ORN_DEATHWALTZ,:ORN_MACABREDANCE,:ORN_LOVELOOP,:ORN_WEAPONMASTERY]
  POWDERMOVES  = [:COTTONSPORE,:SLEEPPOWDER,:STUNSPORE,:SPORE,:RAGEPOWDER,:POISONPOWDER,:POWDER,:MAGICPOWDER,:ORN_STARDUST]
  PULSEMOVES   = [:AURASPHERE,:DRAGONPULS,:DARKPULSE,:WATERPULSE,:ORIGINPULSE,:ORN_ETHEREALBURST,:ORN_MYSTICPULSE,:ORN_SHADOWRAY,:ORN_GAIAPULSE,:ORN_RAINBOWBEAM,:ORN_PRIMALWAVE,:ORN_PULSE,:ORN_MAGNETICCANNON,:ORN_AERIALPULSE,:ORN_WRAITHPULSE]
  UNFREEZEMOVE = [:FLAMEWHEEL,:SACREDFIRE,:FLAREBLITZ,:FUSIONFLARE,:SCALD,:STEAMERUPTION,:BURNUP,:PYROBALL,:SCORCHINGSANDS,:ORN_SOLARFLARE,:ORN_SOLARMETEOR,:ORN_CHIDORI,:ORN_ANCIENTFIRE,:ORN_CRIMSONGATE,:ORN_FIREBALL,:ORN_FLAMEVOLLEY,:ORN_FLARESWEEP,:ORN_HEATSIPHON,:ORN_INFERNALBLADE,:ORN_MELTINGHORN,:ORN_SIZZLE,:ORN_BURNINGOFUDA,:ORN_LIGHTSABER,:ORN_SPARKLE,:ORN_PYROKINESIS,:ORN_STONESURGE,:ORN_RASENGAN]
  SLICINGMOVES = [:SACREDSWORD,:AERIALACE,:SOLARBLADE,:LEAFBLADE,:CUT,:SMARTSTRIKE,:BEHEMOTHBLADE,:RAZORSHELL,:FURYCUTTER,:XSCISSOR,:NIGHTSLASH,:AIRCUTTER,:AIRSLASH,:SHADOWCLAW,:RAZORLEAF,:SLASH,:CROSSPOISON,:PSYCHOCUT,:ORN_DEATHREAP,:ORN_WYVERNSLASH,:ORN_EXCALIBUR,:ORN_EDGESTRIKE,:ORN_INFERNALBLADE,:ORN_GRIMREAPER,:ORN_COUPDEGRACE,:ORN_LIGHTSABER,:ORN_LUMINOUSBLADE,:ORN_SHINYPLUMES,:ORN_SLICINGTAIL,:ORN_DIAMONDBLADE,:ORN_SMARTBLADE,:ORN_SWORDSTRIKE,:ORN_SWEEPINGTALON,:ORN_ICICLESTRIKE]
  WINDMOVE     = [:HEATWAVE,:HURRICANE,:TAILWIND,:PETALBLIZZARD,:BLIZZARD,:ICYWIND,:RAZORWIND,:WHIRLWIND,:SANDSTORM,:SILVERWIND,:TWISTER,:FAIRYWIND,:AIRCUTTER,:AEROBLAST,:GUST,:OMINOUSWIND,:ORN_DRAGONGALE,:ORN_SWEEPINGWIND,:ORN_BOREASBREATH,:ORN_DEATHVORTEX,:ORN_GALEHOLD,:ORN_TORNADO,:ORN_TURBULENCE,:ORN_TYPHOON,:ORN_ICEVORTEX,:ORN_ASTRALWIND,:ORN_TEMPESTFLARE,:ORN_AERIALPULSE,:ORN_DRACOTEMPEST,:ORN_PETALTEMPEST,:ORN_DUSTDEVILS,:ORN_NUMBINGWIND,:ORN_MIASMA]
end

EVOSTONES = [:FIRESTONE,:THUNDERSTONE,:WATERSTONE,:LEAFSTONE,:MOONSTONE,:SUNSTONE,:DUSKSTONE,:DAWNSTONE,:SHINYSTONE,:LINKSTONE,:ICESTONE,:SWEETAPPLE,:TARTAPPLE,:CHIPPEDPOT,:CRACKEDPOT,:NIGHTMAREFUEL,:XENWASTE,:GALARICACUFF,:GALARICAWREATH,:BLACKAUGURITE,:PEATBLOCK,:ORN_FIRESTONE,:ORN_THUNDERSTONE,:ORN_WATERSTONE,:ORN_LEAFSTONE,:ORN_MOONSTONE,:ORN_SUNSTONE,:ORN_DUSKSTONE,:ORN_DAWNSTONE,:ORN_SHINYSTONE,:ORN_ICESTONE,:ORN_LINKSTONE,:ORN_HUMMINGSTONE,:ORN_SANDSTONE,:ORN_WINDSTONE,:ORN_IRONSTONE,:ORN_NOXIOUSSTONE,:ORN_POWERSTONE,:ORN_SWARMSTONE,:ORN_GEMSTONE,:ORN_ROYALSTONE]
GEMS = [:FIREGEM,:WATERGEM,:ELECTRICGEM,:GRASSGEM,:ICEGEM,:FIGHTINGGEM,:POISONGEM,:GROUNDGEM,:FLYINGGEM,:PSYCHICGEM,:BUGGEM,:ROCKGEM,:GHOSTGEM,:DRAGONGEM,:DARKGEM,:STEELGEM,:NORMALGEM,:FAIRYGEM]
ItemHandlers::UseOnPokemon.copy(:FIRESTONE,:ORN_FIRESTONE,:ORN_THUNDERSTONE,:ORN_WATERSTONE,:ORN_LEAFSTONE,:ORN_MOONSTONE,:ORN_SUNSTONE,:ORN_DUSKSTONE,:ORN_DAWNSTONE,:ORN_SHINYSTONE,:ORN_ICESTONE,:ORN_LINKSTONE,:ORN_HUMMINGSTONE,:ORN_SANDSTONE,:ORN_WINDSTONE,:ORN_IRONSTONE,:ORN_NOXIOUSSTONE,:ORN_POWERSTONE,:ORN_SWARMSTONE,:ORN_GEMSTONE,:ORN_ROYALSTONE)

class PokeBattle_Battler # Body Armor Code
  def pbEffectsOnDealingDamage(move, user, target, damage, innards)
    movetypes = [move.pbType(user), *move.getSecondaryType(user)]
    # Gen 9 Mod - Store that target was hit for calculating Rage Fist damage.
    if target.damagestate.calcdamage > 0 && !target.damagestate.substitute
      @battle.addBattlerHit(target)
    end
    return if target.nil?
    return if move.basedamage == 0

    # Make the target flinch
    # needs to be checked before mummy/wandering spirit stench is check before ability change
    if target.damagestate.calcdamage > 0 && !target.damagestate.substitute
      # Gen 9 Mod - Added Covert Cloak
      if (target.ability != :SHIELDDUST || target.moldbroken) && !target.hasWorkingItem(:COVERTCLOAK)
        if (user.hasWorkingItem(:KINGSROCK) || user.hasWorkingItem(:RAZORFANG)) && !move.canFlinch?
          if @battle.pbRandom(10) == 0
            target.effects[:Flinch] = true
          end
        elsif user.ability == :STENCH && !move.canFlinch?
          if @battle.pbRandom(10) == 0 || ([:WASTELAND, :MURKWATERSURFACE, :BACKALLEY, :CITY].include?(@battle.FE) && @battle.pbRandom(10) < 2)
            target.effects[:Flinch] = true
          end
        end
      end
    end
    # Gen 9 Mod - Added Punching Glove
    if target.damagestate.calcdamage > 0 && !target.damagestate.substitute && !move.zmove && move.contactMove? && user.ability != :LONGREACH && !(user.hasWorkingItem(:PUNCHINGGLOVE) && move.punchMove?)
      eschance = 3
      eschance = 6 if @battle.FE == :CORRUPTED
      if user.ability == :POISONTOUCH && @battle.pbRandom(10) < eschance && target.pbCanPoison?(false)
        target.pbPoison(user)
        @battle.pbDisplay(_INTL("{1}'s {2} poisoned {3}!", user.pbThis, getAbilityName(user.ability), target.pbThis(true)))
      end
      # Gen 9 Mod - Added Toxic Chain
      if user.ability == :TOXICCHAIN && @battle.pbRandom(10) < eschance && target.pbCanPoison?(false)
        target.pbPoison(user, true)
        @battle.pbDisplay(_INTL("{1}'s {2} badly poisoned {3}!", user.pbThis, getAbilityName(user.ability), target.pbThis(true)))
      end
      if user.ability == :CORROSION && @battle.FE == :WASTELAND
        if @battle.pbRandom(10) == 0
          case @battle.pbRandom(4)
            when 0 then target.pbBurn(user)       if target.pbCanBurn?(false)
            when 1 then target.pbPoison(user)     if target.pbCanPoison?(false)
            when 2 then target.pbParalyze(user)   if target.pbCanParalyze?(false)
            when 3 then target.pbFreeze           if target.pbCanFreeze?(false)
          end
        end
      end
      if !user.hasWorkingItem(:PROTECTIVEPADS)
        if target.effects[:BeakBlast] && user.ability != :MAGICGUARD && !(user.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM) && user.pbCanBurn?(false)
          user.pbBurn(target)
          @battle.pbDisplay(_INTL("{1} was burned by the heat!", user.pbThis))
        end
        if target.ability == :AFTERMATH && !user.isFainted? && target.hp <= 0 && !@battle.pbCheckGlobalAbility(:DAMP) && user.ability != :MAGICGUARD && !(user.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
          PBDebug.log("[#{user.pbThis} hurt by Aftermath]")
          @battle.scene.pbDamageAnimation(user, 0)
          if @battle.FE == :CORROSIVEMIST
            user.pbReduceHP((user.totalhp / 2.0).floor)
            @battle.pbDisplay(_INTL("{1} was caught in the toxic aftermath!", user.pbThis))
          else
            user.pbReduceHP((user.totalhp / 4.0).floor)
            @battle.pbDisplay(_INTL("{1} was caught in the aftermath!", user.pbThis))
          end
        end
        if [:IRONBARBS, :ROUGHSKIN].include?(target.ability) && !user.isFainted? && user.ability != :MAGICGUARD && !(user.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
          @battle.scene.pbDamageAnimation(user, 0)
          user.pbReduceHP((user.totalhp / 8.0).floor)
          @battle.pbDisplay(_INTL("{1}'s {2} hurt {3}!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
        end
        if target.hasWorkingItem(:ROCKYHELMET, true) && !user.isFainted? && user.ability != :MAGICGUARD && !(user.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
          @battle.scene.pbDamageAnimation(user, 0)
          user.pbReduceHP((user.totalhp / 6.0).floor)
          @battle.pbDisplay(_INTL("{1} was hurt by the {2}!", user.pbThis, getItemName(target.item)))
        end
        eschance = 3
        eschance = 6 if [:FOREST, :WASTELAND, :BEWITCHED].include?(@battle.FE)
        # Effect Spore
        if !user.hasType?(:GRASS) && user.ability != :OVERCOAT && target.ability == :EFFECTSPORE && @battle.pbRandom(10) < eschance
          rnd = @battle.pbRandom(3)
          if rnd == 0 && user.pbCanPoison?(false)
            user.pbPoison(target)
            @battle.pbDisplay(_INTL("{1}'s {2} poisoned {3}!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
          elsif rnd == 1 && user.pbCanSleep?(false)
            user.pbSleep
            @battle.pbDisplay(_INTL("{1}'s {2} made {3} sleep!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
          elsif rnd == 2 && user.pbCanParalyze?(false)
            user.pbParalyze(target)
            @battle.pbDisplay(_INTL("{1}'s {2} paralyzed {3}! It may be unable to move!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
          end
        end
        if target.ability == :FLAMEBODY && @battle.pbRandom(10) < 3 && user.pbCanBurn?(false) && @battle.FE != :FROZENDIMENSION
          user.pbBurn(target)
          @battle.pbDisplay(_INTL("{1}'s {2} burned {3}!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
        end
        eschance = 3
        eschance = 6 if @battle.FE == :WASTELAND || @battle.FE == :CORRUPTED
        if target.ability == :POISONPOINT && @battle.pbRandom(10) < eschance && user.pbCanPoison?(false)
          user.pbPoison(target)
          @battle.pbDisplay(_INTL("{1}'s {2} poisoned {3}!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
        end
        eschance = 3
        eschance = 6 if @battle.FE == :SHORTCIRCUIT || (Rejuv && @battle.FE == :ELECTERRAIN)
        if target.ability == :STATIC && @battle.pbRandom(10) < eschance && user.pbCanParalyze?(false)
          user.pbParalyze(target)
          @battle.pbDisplay(_INTL("{1}'s {2} paralyzed {3}! It may be unable to move!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
        end
        if target.ability == :CUTECHARM && @battle.pbRandom(10) < 3
          if user.ability != :OBLIVIOUS &&
             ((user.gender == 1 && target.gender == 0) || (user.gender == 0 && target.gender == 1)) && user.effects[:Attract] < 0 && !user.isFainted?
            user.effects[:Attract] = target.index
            @battle.pbDisplay(_INTL("{1}'s {2} infatuated {3}!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
            if user.hasWorkingItem(:DESTINYKNOT) && target.ability != :OBLIVIOUS && target.effects[:Attract] < 0
              target.effects[:Attract] = user.index
              @battle.pbDisplay(_INTL("{1}'s {2} infatuated {3}!", user.pbThis, getItemName(user.item), target.pbThis(true)))
            end
          end
        end
        if target.ability == :PERISHBODY && user.effects[:PerishSong] == 0 && target.effects[:PerishSong] == 0 && @battle.FE != :HOLY
          if @battle.FE == :INFERNAL
            @battle.pbDisplay(_INTL("Both Pokémon will faint in one turn!"))
            user.effects[:PerishSong] = 2
            user.effects[:PerishSongUser] = target.index
            target.effects[:PerishSong] = 2
            target.effects[:PerishSongUser] = target.index
          else
            @battle.pbDisplay(_INTL("Both Pokémon will faint in three turns!"))
            user.effects[:PerishSong] = 4
            user.effects[:PerishSongUser] = target.index
            target.effects[:PerishSong] = 4
            target.effects[:PerishSongUser] = target.index
          end
          if @battle.FE == :DIMENSIONAL || @battle.FE == :HAUNTED || @battle.FE == :INFERNAL
            target.effects[:MeanLook] = user.index
            @battle.pbDisplay(_INTL("{1} can't escape now!", target.pbThis))
          end
        end
        if target.ability == :GOOEY
          if user.ability == :CONTRARY
            if @battle.FE == :SWAMP || @battle.FE == :MURKWATERSURFACE
              user.pbReduceStat(PBStats::SPEED, 2, statmessage: false, ignoreContrary: true)
              @battle.pbDisplay(_INTL("{1}'s {2} sharply boosted {3}'s Speed!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
            else
              user.pbReduceStat(PBStats::SPEED, 1, statmessage: false, ignoreContrary: true)
              @battle.pbDisplay(_INTL("{1}'s {2} boosted {3}'s Speed!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
            end
          elsif [:WHITESMOKE, :CLEARBODY, :FULLMETALBODY].include?(user.ability)
            @battle.pbDisplay(_INTL("{1}'s {2} prevents stat loss!", user.pbThis, getAbilityName(user.ability)))
          elsif @battle.FE == :SWAMP || @battle.FE == :MURKWATERSURFACE
            user.pbReduceStat(PBStats::SPEED, 2, statmessage: false, ignoreContrary: true)
            @battle.pbDisplay(_INTL("{1}'s {2} harshly lowered {3}'s Speed!", target.pbThis, getAbilityName(target.ability), user.pbThis(true))) if user.ability != :MIRRORARMOR
          else
            user.pbReduceStat(PBStats::SPEED, 1, statmessage: false, ignoreContrary: true)
            @battle.pbDisplay(_INTL("{1}'s {2} lowered {3}'s Speed!", target.pbThis, getAbilityName(target.ability), user.pbThis(true))) if user.ability != :MIRRORARMOR
          end
          if @battle.FE == :WASTELAND && user.pbCanPoison?(false)
            user.pbPoison(target)
            @battle.pbDisplay(_INTL("{1}'s {2} poisoned {3}!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
          end
        end
        if target.ability == :TANGLINGHAIR
          if user.ability == :CONTRARY
            user.pbReduceStat(PBStats::SPEED, 1, statmessage: false, ignoreContrary: true)
            @battle.pbDisplay(_INTL("{1}'s {2} boosted {3}'s Speed!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
          elsif user.ability == :WHITESMOKE || user.ability == :CLEARBODY || user.ability == :FULLMETALBODY
            @battle.pbDisplay(_INTL("{1}'s {2} prevents stat loss!", user.pbThis, getAbilityName(user.ability)))
          else
            user.pbReduceStat(PBStats::SPEED, 1, statmessage: false, ignoreContrary: true)
            @battle.pbDisplay(_INTL("{1}'s {2} lowered {3}'s Speed!", target.pbThis, getAbilityName(target.ability), user.pbThis(true))) if user.ability != :MIRRORARMOR
          end
        end
        if target.hasWorkingItem(:STICKYBARB, true) && user.item.nil? && !user.isFainted?
          user.item = target.item
          target.item = nil
          if !@battle.opponent && !@battle.pbIsOpposing?(user.index)
            if user.pokemon.itemInitial.nil? && target.pokemon.itemInitial == user.item
              user.pokemon.itemInitial = user.item
              target.pokemon.itemInitial = nil
            end
          end
          @battle.pbDisplay(_INTL("{1}'s {2} was transferred to {3}!", target.pbThis, getItemName(user.item), user.pbThis(true)))
        end
        if target.ability == :MUMMY && !user.isFainted?
          if user.ability != :MUMMY && !PBStuff::FIXEDABILITIES.include?(user.ability)
            neutralgas = true if user.ability == :NEUTRALIZINGGAS
            user.ability = :MUMMY
            user.effects[:GorillaLock] = nil
            @battle.pbDisplay(_INTL("{1} was mummified by {2}!", user.pbThis, target.pbThis(true)))
            @battle.neutralizingGasDisable(user.index) if neutralgas
          end
        end
        if target.ability == :WANDERINGSPIRIT && !user.isFainted? # && !@user.isBoss
          if ![:WANDERINGSPIRIT, :NEUTRALIZINGGAS].include?(user.ability) && !PBStuff::FIXEDABILITIES.include?(user.ability)
            tmp = user.ability
            user.ability = target.ability
            target.ability = tmp
            user.effects[:GorillaLock] = nil
            @battle.pbDisplay(_INTL("{1} swapped its {2} Ability with its target!", target.pbThis, getAbilityName(target.ability)))
            user.pbAbilitiesOnSwitchIn(true)
            target.pbAbilitiesOnSwitchIn(true)
          end
        end
        # Gen 9 Mod - Added Lingering Aroma
        if target.ability == :LINGERINGAROMA && !user.isFainted?
          if user.ability != :LINGERINGAROMA && !PBStuff::FIXEDABILITIES.include?(user.ability) && !user.hasWorkingItem(:ABILITYSHIELD) # Gen 9 Mod - Added Ability Shield
            neutralgas = true if user.ability == :NEUTRALIZINGGAS
            user.ability = :LINGERINGAROMA
            user.effects[:GorillaLock] = nil
            @battle.pbDisplay(_INTL("A lingering aroma clings to {1}!", user.pbThis))
            @battle.neutralizingGasDisable(user.index) if neutralgas
          end
        end
      end
    end
    if target.damagestate.calcdamage > 0
      if @battle.FE == :GLITCH # Glitch Field Hyper Beam Reset
        if user.hp > 0 && target.hp <= 0
          user.effects[:HyperBeam] = 0
        end
      end
      pbRecoilCalc(move, user, target, damage, innards)
      # Bastiodon Crest
      if target.crested == :BASTIODON && !target.damagestate.disguise &&
         user.ability != :MAGICGUARD && !(user.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
        user.pbReduceHP([1, (damage / 2).floor].max)
        target.pbRecoverHP([1, (damage / 2).floor].max) if !target.isFainted?
        @battle.pbDisplay(_INTL("{1}'s crest causes {2} to take recoil damage and {3} to recover!", target.pbThis, user.pbThis(true), target.pbThis))
      end
      if target.ability == :INNARDSOUT && !user.isFainted? &&
         target.hp <= 0 && user.ability != :MAGICGUARD && !(user.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
        PBDebug.log("[#{user.pbThis} hurt by Innards Out]")
        @battle.scene.pbDamageAnimation(user, 0)
        user.pbReduceHP(innards)
        @battle.pbDisplay(_INTL("{2}'s innards hurt {1}!", user.pbThis, target.pbThis))
      end
      if !target.damagestate.substitute
        if target.effects[:ShellTrap] && move.pbIsPhysical?(movetypes[0]) && user.pbOwnSide != target.pbOwnSide && !(user.ability == :SHEERFORCE && move.effect > 0)
          target.effects[:ShellTrap] = false
        end
        if (target.ability == :CURSEDBODY && @battle.FE != :HOLY && (@battle.pbRandom(10) < 3 || (target.isFainted? && @battle.FE == :HAUNTED))) || target.crested == :BEHEEYEM
          if user.effects[:Disable] <= 0 && move.pp > 0 && !user.isFainted?
            user.effects[:Disable] = 4
            user.effects[:DisableMove] = move.move
            @battle.pbDisplay(_INTL("{1}'s {2} disabled {3}!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
          end
        end
        if target.ability == :GULPMISSILE && target.species == :CRAMORANT && !user.isFainted? && target.form != 0
          @battle.scene.pbDamageAnimation(user, 0)
          if user.ability != :MAGICGUARD && !(user.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
            if @battle.FE == :UNDERWATER
              eff = PBTypes.twoTypeEff(:WATER, user.type1, user.type2)
              user.pbReduceHP((user.totalhp * eff / 16.0).floor)
            else
              user.pbReduceHP((user.totalhp / 4.0).floor)
            end
          end
          if target.form == 1 # Gulping Form
            if user.pbReduceStat(PBStats::DEFENSE, 1, abilitymessage: false, statdropper: target)
              if user.ability == :CONTRARY
                @battle.pbDisplay(_INTL("{1}'s {2} raised {3}'s Defense!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
              else
                @battle.pbDisplay(_INTL("{1}'s {2} lowered {3}'s Defense!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
              end
            end
          elsif target.form == 2 # Gorging Form
            if user.pbCanParalyze?(false)
              user.pbParalyze(target)
              @battle.pbDisplay(_INTL("{1}'s {2} paralyzed {3}! It may be unable to move!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
            end
          end
          @battle.pbDisplay(_INTL("{1}'s {2} hurt {3}!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
          target.form = 0
          target.pbUpdate(false)
          @battle.scene.pbChangePokemon(target, target.pokemon)
          @battle.pbDisplay(_INTL("{1} returned to normal!", target.pbThis))
        end
        if target.effects[:Illusion] != nil
          target.effects[:Illusion] = nil
          @battle.pbAnimation(:TRANSFORM, target, target) if !target.isFainted?
          @battle.scene.pbChangePokemon(target, target.pokemon)
          @battle.pbDisplay(_INTL("{1}'s {2} was broken!", target.pbThis, getAbilityName(:ILLUSION)))
        end
        if target.ability == :JUSTIFIED && movetypes.include?(:DARK)
          if target.pbCanIncreaseStatStage?(PBStats::ATTACK)
            stat = @battle.FE == :HOLY ? 2 : 1
            target.pbIncreaseStatBasic(PBStats::ATTACK, stat)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s {2} raised its Attack!", target.pbThis, getAbilityName(target.ability)))
          end
        end
        if target.ability == :RATTLED && [:BUG, :DARK, :GHOST].intersect?(movetypes)
          if target.pbCanIncreaseStatStage?(PBStats::SPEED)
            target.pbIncreaseStatBasic(PBStats::SPEED, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s {2} raised its Speed!", target.pbThis, getAbilityName(target.ability)))
          end
        end
        if target.ability == :WEAKARMOR && move.pbIsPhysical?(movetypes[0])
          if target.pbCanReduceStatStage?(PBStats::DEFENSE, false, true)
            target.pbReduceStatBasic(PBStats::DEFENSE, 1)
            @battle.pbCommonAnimation("StatDown", target, nil)
            @battle.pbDisplay(_INTL("{1}'s {2} lowered its Defense!", target.pbThis, getAbilityName(target.ability)))
          end
          if target.pbCanIncreaseStatStage?(PBStats::SPEED)
            target.pbIncreaseStatBasic(PBStats::SPEED, 2)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s {2} sharply raised its Speed!", target.pbThis, getAbilityName(target.ability)))
          end
        end
        # Gen 9 Mod - Added Toxic Debris.
        if target.ability == (:TOXICDEBRIS) && target.pbOpposingSide.effects[:ToxicSpikes] < 2 && move.pbIsPhysical?(movetypes) && !(@battle.FE == :WATERS || @battle.FE == :MURKWATERS)
           target.pbOpposingSide.effects[:ToxicSpikes] += 1
          if !@battle.pbIsOpposing?(target.index)
             @battle.pbDisplay(_INTL("Poison spikes were scattered all around the foe's team's feet!"))
          else
             @battle.pbDisplay(_INTL("Poison spikes were scattered all around your team's feet!"))
          end
        end
        if target.ability == :STAMINA
          if target.pbCanIncreaseStatStage?(PBStats::DEFENSE)
            target.pbIncreaseStatBasic(PBStats::DEFENSE, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s {2} raised its Defense!", target.pbThis, getAbilityName(target.ability)))
          end
        end
        if target.crested == :NOCTOWL
          if target.pbCanIncreaseStatStage?(PBStats::SPDEF)
            target.pbIncreaseStatBasic(PBStats::SPDEF, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s Crest raised its Special Defense!", target.pbThis))
          end
        end
        if target.ability == :WATERCOMPACTION && movetypes.include?(:WATER)
          if @battle.FE != :ASHENBEACH
            if target.pbCanIncreaseStatStage?(PBStats::DEFENSE)
              target.pbIncreaseStatBasic(PBStats::DEFENSE, 2)
              @battle.pbCommonAnimation("StatUp", target, nil)
              @battle.pbDisplay(_INTL("{1}'s Water Compaction sharply raised its Defense!", target.pbThis, getAbilityName(target.ability)))
            end
          else
            boost = false
            if target.pbCanIncreaseStatStage?(PBStats::DEFENSE)
              target.pbIncreaseStatBasic(PBStats::DEFENSE, 2)
              @battle.pbCommonAnimation("StatUp", target, nil) if !boost
              boost = true
            end
            if target.pbCanIncreaseStatStage?(PBStats::SPDEF)
              target.pbIncreaseStatBasic(PBStats::SPDEF, 2)
              @battle.pbCommonAnimation("StatUp", target, nil) if !boost
              boost = true
            end
            @battle.pbDisplay(_INTL("{1}'s {2} sharply raised its Defense and Special Defense!", target.pbThis, getAbilityName(target.ability))) if boost
          end
        end
        # Cotton Down
        if target.ability == :COTTONDOWN
          @battle.pbDisplay(_INTL("{1}'s {2} scatters cotton around!", target.pbThis, getAbilityName(target.ability)))
          for i in @battle.battlers
            next if i == target
            statdrop = 1
            statdrop = 2 if @battle.FE == :BEWITCHED || @battle.FE == :GRASSY
            if i.pbReduceStat(PBStats::SPEED, statdrop, abilitymessage: false)
              @battle.pbDisplay(_INTL("The cotton reduces {1}'s Speed!", i.pbThis)) if i.ability != :MIRRORARMOR
            end
          end
        end
        # Sand Spit
        if target.ability == :SANDSPIT
          if !(@battle.state.effects[:HeavyRain] || @battle.state.effects[:HarshSunlight] ||
             @battle.weather == :STRONGWINDS || @battle.weather == :SANDSTORM || [:NEWWORLD, :UNDERWATER, :DIMENSIONAL].include?(@battle.FE))
            @battle.pbAnimation(:SANDSTORM, self, nil)
            @battle.weather = :SANDSTORM
            @battle.weatherduration = 5
            @battle.weatherduration = 8 if target.hasWorkingItem(:SMOOTHROCK) || [:DESERT, :ASHENBEACH, :SKY].include?(@battle.FE)
            @battle.pbCommonAnimation("Sandstorm")
            @battle.pbDisplay(_INTL("A sandstorm brewed!"))
            if [:DESERT, :ASHENBEACH].include?(@battle.FE) && user.pbCanReduceStatStage?(PBStats::ACCURACY)
              user.pbReduceStatBasic(PBStats::ACCURACY, 1)
              @battle.pbCommonAnimation("StatDown", user, nil)
              @battle.pbDisplay(_INTL("{1}'s accuracy fell!", user.pbThis))
            end
          end
        end
        # Steam Engine
        if target.ability == :STEAMENGINE && [:WATER, :FIRE].intersect?(movetypes)
          if target.pbCanIncreaseStatStage?(PBStats::SPEED)
            target.pbIncreaseStatBasic(PBStats::SPEED, 6)
            @battle.pbCommonAnimation("StatUp", target)
            @battle.pbDisplay(_INTL("{1}'s {2} drastically raised its Speed!", target.pbThis, getAbilityName(target.ability)))
          end
        end
        if target.hasWorkingItem(:ABSORBBULB) && movetypes.include?(:WATER)
          if target.pbIncreaseStat(PBStats::SPATK, 1, statmessage: false, statsource: target)
            if target.ability == :CONTRARY && !target.moldbroken
              @battle.pbDisplay(_INTL("{1}'s {2} lowered its Special Attack!", target.pbThis, getItemName(target.item)))
            else
              @battle.pbDisplay(_INTL("{1}'s {2} raised its Special Attack!", target.pbThis, getItemName(target.item)))
            end
            target.pbDisposeItem(false)
          end
        end
        if (target.hasWorkingItem(:SNOWBALL) && movetypes.include?(:ICE)) || (target.hasWorkingItem(:CELLBATTERY) && movetypes.include?(:ELECTRIC))
          if target.pbIncreaseStat(PBStats::ATTACK, 1, statmessage: false, statsource: target)
            if target.ability == :CONTRARY && !target.moldbroken
              @battle.pbDisplay(_INTL("{1}'s {2} lowered its Attack!", target.pbThis, getItemName(target.item)))
            else
              @battle.pbDisplay(_INTL("{1}'s {2} raised its Attack!", target.pbThis, getItemName(target.item)))
            end
            target.pbDisposeItem(false)
          end
        end
        if target.hasWorkingItem(:LUMINOUSMOSS) && movetypes.include?(:WATER)
          if target.pbIncreaseStat(PBStats::SPDEF, 1, statmessage: false, statsource: target)
            if target.ability == :CONTRARY && !target.moldbroken
              @battle.pbDisplay(_INTL("{1}'s {2} lowered its Special Defense!", target.pbThis, getItemName(target.item)))
            else
              @battle.pbDisplay(_INTL("{1}'s {2} raised its Special Defense!", target.pbThis, getItemName(target.item)))
            end
            target.pbDisposeItem(false)
          end
        end
        if !([:UNNERVE, :ASONECHILLING, :ASONEGRIM].include?(user.ability) || [:UNNERVE, :ASONECHILLING, :ASONEGRIM].include?(user.pbPartner.ability))
          if target.hasWorkingItem(:KEEBERRY) && move.pbIsPhysical?(movetypes[0]) && user.ability != :SHEERFORCE
            if target.pbCanIncreaseStatStage?(PBStats::DEFENSE)
              @battle.pbCommonAnimation("Nom", target)
              target.pbIncreaseStat(PBStats::DEFENSE, 1, statmessage: false, statsource: target)
              if target.ability == :CONTRARY && !target.moldbroken
                @battle.pbDisplay(_INTL("{1}'s {2} lowered its Defense!", target.pbThis, getItemName(target.item)))
              else
                @battle.pbDisplay(_INTL("{1}'s {2} raised its Defense!", target.pbThis, getItemName(target.item)))
              end
              target.pbDisposeItem(true)
            end
          end

          if target.hasWorkingItem(:MARANGABERRY) && move.pbIsSpecial?(movetypes[0]) && user.ability != :SHEERFORCE
            if target.pbCanIncreaseStatStage?(PBStats::SPDEF)
              @battle.pbCommonAnimation("Nom", target)
              target.pbIncreaseStat(PBStats::SPDEF, 1, statmessage: false, statsource: target)
              if target.ability == :CONTRARY && !target.moldbroken
                @battle.pbDisplay(_INTL("{1}'s {2} lowered its Special Defense!", target.pbThis, getItemName(target.item)))
              else
                @battle.pbDisplay(_INTL("{1}'s {2} raised its Special Defense!", target.pbThis, getItemName(target.item)))
              end
              target.pbDisposeItem(true)
            end
          end

          if target.hasWorkingItem(:JABOCABERRY, true) && !user.isFainted? && move.pbIsPhysical?(movetypes[0])
            @battle.pbCommonAnimation("Nom", target)
            @battle.scene.pbDamageAnimation(user, 0)
            user.pbReduceHP((user.totalhp / 8.0).floor)
            @battle.pbDisplay(_INTL("{1} was hurt by the {2}!", user.pbThis, getItemName(target.item)))
            target.pbDisposeItem(true)
          end
          if target.hasWorkingItem(:ROWAPBERRY, true) && !user.isFainted? && move.pbIsSpecial?(movetypes[0])
            @battle.pbCommonAnimation("Nom", target)
            @battle.scene.pbDamageAnimation(user, 0)
            user.pbReduceHP((user.totalhp / 8.0).floor)
            @battle.pbDisplay(_INTL("{1} was hurt by the {2}!", user.pbThis, getItemName(target.item)))
            target.pbDisposeItem(true)
          end
        end
        if target.hasWorkingItem(:WEAKNESSPOLICY) && target.damagestate.typemod > 4
          if target.pbIncreaseStat(PBStats::ATTACK, 2, statmessage: false, statsource: target)
            if target.ability == :CONTRARY && !target.moldbroken
              @battle.pbDisplay(_INTL("{1}'s {2} harshly lowered its Attack!", target.pbThis, getItemName(:WEAKNESSPOLICY)))
            else
              @battle.pbDisplay(_INTL("{1}'s {2} sharply raised its Attack!", target.pbThis, getItemName(:WEAKNESSPOLICY)))
            end
            target.pbDisposeItem(false)
          end
          if target.pbIncreaseStat(PBStats::SPATK, 2, statmessage: false, statsource: target)
            if target.ability == :CONTRARY && !target.moldbroken
              @battle.pbDisplay(_INTL("{1}'s {2} harshly lowered its Special Attack!", target.pbThis, getItemName(:WEAKNESSPOLICY)))
            else
              @battle.pbDisplay(_INTL("{1}'s {2} sharply raised its Special Attack!", target.pbThis, getItemName(:WEAKNESSPOLICY)))
            end
            target.pbDisposeItem(false)
          end
        end
        if target.ability == :ANGERPOINT
          if target.pbCanIncreaseStatStage?(PBStats::ATTACK) && target.damagestate.critical
            target.stages[PBStats::ATTACK] = 6
            @battle.pbCommonAnimation("StatUp", target)
            @battle.pbDisplay(_INTL("{1}'s {2} maxed its Attack!", target.pbThis, getAbilityName(target.ability)))
          end
        end
        if target.effects[:Rage] && target.pbIsOpposing?(user.index)
          # TODO: Apparently triggers if opposing Pokémon uses Future Sight after a Future Sight attack
          if target.pbCanIncreaseStatStage?(PBStats::ATTACK)
            target.pbIncreaseStatBasic(PBStats::ATTACK, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s rage is building!", target.pbThis))
          end
        end
      end
      # Gen 9 Mod - Thermal Exchange
      if !target.damagestate.substitute
        if target.ability == (:THERMALEXCHANGE) && (movetypes == :FIRE)
          if target.pbCanIncreaseStatStage?(PBStats::ATTACK)
            target.pbIncreaseStatBasic(PBStats::ATTACK, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s {2} raised its Attack!", target.pbThis, getAbilityName(target.ability)))
          end
        end
      end
      # Gen 9 Mod - Wind Power
      if target.ability == (:WINDPOWER) && move.windMove?
        # Gen 9 Mod - Charge lasts until the user uses an electric move.
        if target.effects[:Charge] == false
          target.effects[:Charge] = true
          @battle.pbCommonAnimation("Charge", target, nil)
        end
        @battle.pbDisplay(_INTL("Being hit by {1} charged {2} with power!",move.name, target.pbThis))
      end
      # Gen 9 Mod - Electromorphosis
      # Gen 9 Mod - Charge lasts until the user uses an electric move.
      if target.ability == (:ELECTROMORPHOSIS)
        if target.effects[:Charge] == false
          target.effects[:Charge] = true
          @battle.pbCommonAnimation("Charge", target, nil)
        end
        @battle.pbDisplay(_INTL("Being hit by {1} charged {2} with power!", move.name, target.pbThis))
      end
      # Gen 9 Mod - Seed Sower
      if target.ability == (:SEEDSOWER)
        if ((@battle.canChangeFE?(:GRASSY)) || @battle.canChangeFE?([:GRASSY,:DRAGONSDEN])) && !(@battle.state.effects[:GRASSY] > 0)
          if @battle.FE == :FROZENDIMENSION
            @battle.pbDisplay(_INTL("The frozen dimension remains unchanged."))
          else
            duration = 5
            duration = 8 if self.hasWorkingItem(:AMPLIFIELDROCK)
            @battle.pbAnimation(:GRASSYTERRAIN, self, nil)
            @battle.setField(:GRASSY, duration)
            @battle.pbDisplay(_INTL("The terrain became grassy!"))
          end
        end
      end
      if target.hasWorkingItem(:AIRBALLOON, true)
        target.pbDisposeItem(false, true, false)
        @battle.pbDisplay(_INTL("{1}'s Air Balloon popped!", target.pbThis))
      end
    end
    if !target.effects[:ItemRemoval].nil?
      if target.item
        if target.ability == :STICKYHOLD && !target.moldbroken
          abilityname = getAbilityName(target.ability)
          @battle.pbDisplay(_INTL("{1}'s {2} made {3} ineffective!", target.pbThis, abilityname, basemove.name))
        elsif target.effects[:ItemRemoval] == :Remove && !@battle.pbIsUnlosableItem(target, target.item)
          target.effects[:ChoiceBand] = nil
          # Knocking of the item
          itemname = getItemName(target.item)
          target.item = nil
          target.pokemon.corrosiveGas = false
          @battle.pbDisplay(_INTL("{1} knocked off {2}'s {3}!", user.pbThis, target.pbThis(true), itemname))
        elsif target.effects[:ItemRemoval] == :Steal && !@battle.pbIsUnlosableItem(target, target.item) && !@battle.pbIsUnlosableItem(user, target.item) && user.item.nil?
          itemname = getItemName(target.item)
          user.item = target.item
          target.item = nil
          if target.pokemon.corrosiveGas
            target.pokemon.corrosiveGas = false
            user.pokemon.corrosiveGas = true
          end
          target.effects[:ChoiceBand] = nil
          # In a wild battle
          if !@battle.opponent && user.pokemon.itemInitial.nil? && target != user.pbPartner && target.pokemon.itemInitial == user.item && !target.isbossmon && !user.isbossmon
            user.pokemon.itemInitial = user.item
            user.pokemon.itemReallyInitialHonestlyIMeanItThisTime = user.item
            target.pokemon.itemInitial = nil
          end
          if @move == :THIEF
            @battle.pbCommonAnimation("Thief", user, target)
          else
            @battle.pbCommonAnimation("Covet", user, target)
          end
          @battle.pbDisplay(_INTL("{1} stole {2}'s {3}!", user.pbThis, target.pbThis(true), itemname))
        end
      end
      target.effects[:ItemRemoval] = nil
    end
  end

  def pbRecoilCalc(move, user, target, damage, innards)
    if move.recoil > 0 && !target.damagestate.disguise && user.item != :ORN_BODYARMOR &&
       user.ability != :ROCKHEAD && user.crested != :RAMPARDOS && user.ability != :MAGICGUARD &&
       !(move.move == :WILDCHARGE && @battle.FE == :ELECTERRAIN) && !(user.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
      recoilmultiplier = move.recoil
      recoilmultiplier = 0.25 if move.move == :WAVECRASH && (@battle.FE == :WATERSURFACE || @battle.FE == :UNDERWATER)
      recoildamage = [1, (damage * recoilmultiplier).floor].max
      user.pbReduceHP(recoildamage)
      @battle.pbDisplay(_INTL("{1} is damaged by the recoil!", user.pbThis))
    end
  end
end

class PokeBattle_Move
  alias warden_pbTypeModMessages pbTypeModMessages
  alias warden_pbReduceHPDamage pbReduceHPDamage
  alias warden_pbAccuracyCheck pbAccuracyCheck
  alias warden_pbType pbType
  # Warden Abilities #
  def pbTypeModMessages(type, attacker, opponent)
    secondtype = getSecondaryType(attacker)
    if opponent.ability == :ORN_CACOPHONY && !opponent.moldbroken && (type == :SOUND || (!secondtype.nil? && secondtype.include?(:SOUND)))
      if opponent.pbCanIncreaseStatStage?(PBStats::SPATK)
        opponent.pbIncreaseStatBasic(PBStats::SPATK, 1)
        @battle.pbCommonAnimation("StatUp", opponent, nil)
        @battle.pbDisplay(_INTL("{1}'s {2} raised its Special Attack!", opponent.pbThis, getAbilityName(opponent.ability)))
      else
        @battle.pbDisplay(_INTL("{1}'s {2} made {3} ineffective!", opponent.pbThis, getAbilityName(opponent.ability), self.name))
      end
      return 0
    elsif opponent.ability == :ORN_COMETSTORM && !opponent.moldbroken && (type == :ROCK || (!secondtype.nil? && secondtype.include?(:ROCK)))
      if opponent.pbCanIncreaseStatStage?(PBStats::SPATK)
        opponent.pbIncreaseStatBasic(PBStats::SPATK, 1)
        @battle.pbCommonAnimation("StatUp", opponent, nil)
        @battle.pbDisplay(_INTL("{1}'s {2} raised its Special Attack!", opponent.pbThis, getAbilityName(opponent.ability)))
      else
        @battle.pbDisplay(_INTL("{1}'s {2} made {3} ineffective!", opponent.pbThis, getAbilityName(opponent.ability), self.name))
      end
      if opponent.pbCanIncreaseStatStage?(PBStats::SPEED)
        opponent.pbIncreaseStatBasic(PBStats::SPEED, 1)
        @battle.pbCommonAnimation("StatUp", opponent, nil)
        @battle.pbDisplay(_INTL("{1}'s {2} raised its Speed!", opponent.pbThis, getAbilityName(opponent.ability)))
      else
        @battle.pbDisplay(_INTL("{1}'s {2} made {3} ineffective!", opponent.pbThis, getAbilityName(opponent.ability), self.name))
      end
      return 0
    else
      return warden_pbTypeModMessages(type, attacker, opponent)
    end
  end

  def pbAccuracyCheck(attacker, opponent, precheckedacc: nil)
    return true if attacker.ability == :ORN_SHARPSHOOTER && !@move.contactMove?
    accstage = attacker.stages[PBStats::ACCURACY]
    accstage = 0 if opponent.ability == :UNAWARE && !opponent.moldbroken
    evastage = opponent.stages[PBStats::EVASION]
    evastage = 0 if opponent.effects[:Foresight] || opponent.effects[:MiracleEye] || @function == 0xA9 || ([:UNAWARE, :KEENEYE, :MINDSEYE].include?(attacker.ability) && !opponent.moldbroken) # Gen 9 Mod - Added Mind's Eye
    accstage -= evastage
    accstage = accstage.clamp(-6, 6)
    accuracy = accstage >= 0 ? (accstage + 3) * 100.0 / 3 : 300.0 / (3 - accstage)
    if attacker.ability == :HUSTLE && @basedamage > 0 && pbIsSpecial?(pbType(attacker))
      accuracy *= 0.8
      return @battle.pbRandom(100) < (baseaccuracy * accuracy / 100.0).floor
    elsif attacker.ability == :ORN_PRECISION
      accuracy *= 1.3
      return @battle.pbRandom(100) < (baseaccuracy * accuracy / 100.0).floor
    end
    return warden_pbAccuracyCheck(attacker, opponent, precheckedacc: nil)
  end

  def pbType(attacker, type = @type)
    old_type = type
    if !PBStuff::ZMOVES.include?(@move)
      case attacker.ability
        when :ORN_BLACKLIGHT then type = :DARK   if type == :LIGHT
        when :ORN_WHITEOUT   then type = :LIGHT  if type == :DARK
        when :ORN_DARKMATTER then type = :COSMIC if type == :NORMAL
      end
    end
    return type if old_type != type
    return warden_pbType(attacker, type = @type)
  end

  def pbReduceHPDamage(damage, attacker, opponent)
    ward_abils = [:ORN_ETHEREAL,:ORN_TELEFACE,:ORN_DESTRUCTIVECORE]
    if ward_abils.include?(opponent.ability)
      if opponent.effects[:Ethereal] && (!attacker || attacker.index != opponent.index) && contactMove?
          opponent.effects[:Substitute] <= 0 && opponent.damagestate.typemod != 0 && !opponent.moldbroken
        @battle.pbDisplay(_INTL("The attack phased through {1}'s Ethereal form.", opponent.name))
        opponent.effects[:Ethereal] = false
        damage = 0
        @battle.pbDisplay(_INTL("{1} became corporeal.", opponent.name))
      end
      if opponent.effects[:Teleface] && (!attacker || attacker.index != opponent.index) && opponent.effects[:Substitute] <= 0 && opponent.damagestate.typemod != 0 && !opponent.moldbroken && move.pbIsPhysical?
        @battle.pbDisplay(_INTL("{1}'s TV was busted!", opponent.name))
        opponent.effects[:Teleface] = false
        damage = 0
	  end
	  return damage
    else
      return warden_pbReduceHPDamage(damage, attacker, opponent)
    end
  end
end

class PokeBattle_Battle
  alias warden_pbEndOfRoundPhase pbEndOfRoundPhase

  def pbEndOfRoundPhase
    priority = pbPriority
    for i in priority
      # Pure Heart
      if i.ability == :ORN_PUREHEART
        i.pbRecoverHP((i.totalhp / 16.0).floor, true)
        pbDisplay(_INTL("{1}'s Pure Heart restored its health!", i.pbThis))
      elsif i.ability == :ORN_CLAYFORM && pbWeather == :SANDSTORM
        i.pbRecoverHP((i.totalhp / 8.0).floor, true)
        pbDisplay(_INTL("{1}'s Clay Form restored its health!", i.pbThis))
      elsif i.ability == :ORN_SYNTHESIZE && pbWeather == :SUNNYDAY
        i.pbRecoverHP((i.totalhp / 8.0).floor, true)
        pbDisplay(_INTL("{1}'s Synthesize restored its health!", i.pbThis))
      end
      if @battle.state.effects[:ELECTERRAIN] > 0 || @battle.FE == :ELECTERRAIN
        for facemon in @battlers
          if facemon.species == :ORN_EISCUE && facemon.form == 1   # Eiscue
            facemon.pbRegenTele
            pbDisplayPaused(_INTL("{1} transformed!", facemon.name))
          end
        end
      end
    end
	warden_pbEndOfRoundPhase
  end

end

class PokeBattle_Battler
  alias warden_pbProcessMoveAgainstTarget pbProcessMoveAgainstTarget
  alias warden_pbEffectsOnDealingDamage pbEffectsOnDealingDamage
  alias warden_pbCanReduceStatStage? pbCanReduceStatStage?
  alias warden_pbAbilitiesOnSwitchIn pbAbilitiesOnSwitchIn
  alias warden_pbCheckFormRoundEnd pbCheckFormRoundEnd
  alias warden_pbSuccessCheck pbSuccessCheck
  alias warden_pbInitEffects pbInitEffects
  alias warden_pbCanStatus? pbCanStatus?
  alias warden_pbCheckForm pbCheckForm

  def pbInitEffects(batonpass, fakebattler=false)
    warden_pbInitEffects(batonpass, fakebattler=false)
    @effects[:Ethereal] = (self.ability == :ORN_ETHEREAL)
    @effects[:Teleface] = (self.ability == :ORN_TELEFACE && self.species==:ORN_EISCUE && self.form==0)
  end

  def pbSuccessCheck(basemove, user, target, flags, accuracy = true, precheckedacc: nil)
    return true if user.ability == :ORN_SHARPSHOOTER && !basemove.contactMove?
    return warden_pbSuccessCheck(basemove, user, target, flags, accuracy, precheckedacc: nil)
  end

  def pbAbilitiesOnSwitchIn(onactive)
    return if @hp <= 0
    # Dishearten
    warden_pbAbilitiesOnSwitchIn(onactive)
    if self.ability == :ORN_DISHEARTEN && onactive
      for i in 0...4
        next if !pbIsOpposing?(i) || @battle.battlers[i].isFainted?
        @battle.battlers[i].pbReduceSpecialAttackStatStageDishearten(self)
      end
    elsif self.ability == :ORN_DISARRAY && onactive
      if @battle.trickroom == 0
        @battle.trickroom = 5
        if [:CHESS, :NEWWORLD, :PSYTERRAIN].include?(@battle.FE) || self.hasWorkingItem(:AMPLIFIELDROCK) || (Rejuv && @battle.FE == :STARLIGHT)
          @battle.trickroom = 8
        end
        if @battle.FE == :DIMENSIONAL
          rnd = @battle.pbRandom(6)
          @battle.trickroom = 3 + rnd
        end
        @battle.pbDisplay(_INTL("{1} twisted the dimensions!", self.pbThis))
      else
        @battle.trickroom = 0
        @battle.pbDisplay(_INTL("The twisted dimensions returned to normal!", self.pbThis))
      end
      for i in @battle.battlers
        if i.hasWorkingItem(:ROOMSERVICE)
          if i.pbReduceStat(PBStats::SPEED, 1, abilitymessage: false, statdropper: i)
            if i.ability == :CONTRARY && !i.moldbroken
              @battle.pbDisplay(_INTL("The Room Service raised #{i.pbThis}'s Speed!"))
            else
              @battle.pbDisplay(_INTL("The Room Service lowered #{i.pbThis}'s Speed!"))
            end
            i.pbDisposeItem(false)
          end
        end
      end
	elsif self.ability == :TELEFACE && self.form == 1 && self.species == :ORN_EISCUE && onactive
      if @battle.state.effects[:ELECTERRAIN] > 0 || @battle.FE == :ELECTERRAIN
        self.pbRegenTele
        @battle.pbDisplay(_INTL("{1} transformed!",self.pbThis))
      end
	end
  end

  def pbEffectsOnDealingDamage(move, user, target, damage, innards)
    return if target.nil?
    return if move.basedamage == 0
    if target.damagestate.calcdamage > 0
      if !target.damagestate.substitute && !move.zmove
        if target.ability == :ORN_VITALITY
          if target.pbCanIncreaseStatStage?(PBStats::SPDEF)
            target.pbIncreaseStatBasic(PBStats::SPDEF, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s {2} raised its Special Defense!", target.pbThis, getAbilityName(target.ability)))
          end
        elsif move.contactMove? && PBStuff::BITEMOVE.include?(move)
          if user.ability == :ORN_LEECHINGFANGS
            changehp=(target.totalhp/8).floor # Changed by DemICE 06-Oct-2023 Reworking Leeching Fangs to absorb 1/8 of opponent's total hp.
            changehp*=1.3 if user.hasActiveItem?(:BIGROOT)
            if target.ability == :LIQUIDOOZE
              changehp*=2 if (@battle.FE == :WASTELAND || @battle.FE == :MURKWATERSURFACE || @battle.FE == :CORRUPTED)
              user.pbReduceHP(changehp, true)
              @battle.pbDisplay(_INTL("{1} sucked up the liquid ooze!", user.pbThis))
            else
              user.pbRecoverHP(changehp, true)
              @battle.pbDisplay(_INTL("{1} drained HP with {2}!",user.pbThis,user.abilityName))
            end
          end
        elsif target.ability == :ORN_HIVEBODY && move.contactMove?
          chance = 50
		  if @battle.pbRandom(100) >= chance
            user.effects[:MultiTurn] = 5 + @battle.pbRandom(2)
            user.effects[:MultiTurn] = 8 if target.hasWorkingItem(:GRIPCLAW)
            user.effects[:MultiTurnAttack] = :INFESTATION
            user.effects[:MultiTurnUser] = target.index
            @battle.pbDisplay(_INTL("{1} has been infested!", user.pbThis))
          end
        elsif target.ability == :ORN_MAELSTROM && move.contactMove?
          chance = 50
		  if @battle.pbRandom(100) >= chance
            user.effects[:MultiTurn] = 5 + @battle.pbRandom(2)
            user.effects[:MultiTurn] = 8 if target.hasWorkingItem(:GRIPCLAW)
            user.effects[:MultiTurnAttack] = :WHIRLPOOL
            user.effects[:MultiTurnUser] = target.index
            @battle.pbDisplay(_INTL("{1} became trapped in the vortex!", user.pbThis))
          end
        elsif target.ability == :ORN_SCORCHSCALE && move.priority > 0
          user.pbBurn(target) if user.pbCanBurn?(false) && @battle.FE != :FROZENDIMENSION
          @battle.pbDisplay(_INTL("{1}'s {2} burned {3}!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
		end
      end
    end
    warden_pbEffectsOnDealingDamage(move, user, target, damage, innards)
  end

  def pbCanReduceStatStage?(stat, showMessages = false, selfreduce = false, ignoreContrary: false)
    return false if isFainted? && !(Rejuv && isbossmon && @shieldCount > 0)
    if !selfreduce
     abilityname = getAbilityName(self.ability)
	 if stat == PBStats::DEFENSE && self.ability == :ORN_UNBREAKABLE && !self.moldbroken
        @battle.pbDisplay(_INTL("{1}'s {2} prevents Defense loss!", pbThis, abilityname)) if showMessages
        return false
      elsif stat == PBStats::SPATK && self.ability == :ORN_INTUITION && !self.moldbroken
        @battle.pbDisplay(_INTL("{1}'s {2} prevents Special Attack loss!", pbThis, abilityname)) if showMessages
        return false
      elsif [PBStats::DEFENSE,PBStats::SPDEF].include?(stat) && self.ability == :ORN_IMPENETRABLE && !self.moldbroken
        @battle.pbDisplay(_INTL("{1}'s {2} prevents Defense loss!", pbThis, abilityname)) if showMessages && stat == PBStats::DEFENSE
        @battle.pbDisplay(_INTL("{1}'s {2} prevents Special Defense loss!", pbThis, abilityname)) if showMessages && stat == PBStats::SPDEF
        return false
      elsif ([self.ability,pbPartner.ability].include?(:ORN_NEBULACLOUD) && hasType?(:COSMIC) && !self.moldbroken)
        cloud_user = (pbPartner.ability == :ORN_NEBULACLOUD) ? pbPartner.pbThis : pbThis
        @battle.pbDisplay(_INTL("{1}'s {2} prevents Stat loss!", cloud_user, abilityname)) if showMessages
        return false
      else
        return warden_pbCanReduceStatStage?(stat, showMessages, selfreduce, ignoreContrary: false)
      end
    else
      return warden_pbCanReduceStatStage?(stat, showMessages, selfreduce, ignoreContrary: false)
    end
  end
  
  def pbProcessMoveAgainstTarget(basemove, user, target, numhits, flags = { totaldamage: 0 }, nocheck = false, alltargets = nil, showanimation = true, precheckedacc: nil)
    if target
      aboveHalfHp = target.hp > (target.totalhp / 2.0).floor
    end
    if !target.isFainted? && aboveHalfHp && target.hp <= (target.totalhp / 2.0).floor && damage > 0
      if target.ability == :ORN_FORTIFICATION
        if !pbTooHigh?(PBStats::DEFENSE)
          target.pbIncreaseStatBasic(PBStats::DEFENSE, 1)
          @battle.pbCommonAnimation("StatUp", target, nil)
          @battle.pbDisplay(_INTL("{1}'s Fortifiction boosted its Defense!", target.pbThis))
        end
        if !pbTooHigh?(PBStats::SPDEF)
          target.pbIncreaseStatBasic(PBStats::SPDEF, 1)
          @battle.pbCommonAnimation("StatUp", target, nil)
          @battle.pbDisplay(_INTL("{1}'s Fortifiction boosted its Special Defense!", target.pbThis))
        end
      elsif target.ability == :ORN_TERMINATOR
        if !pbTooHigh?(PBStats::ATTACK)
          target.pbIncreaseStatBasic(PBStats::ATTACK, 1)
          @battle.pbCommonAnimation("StatUp", target, nil)
          @battle.pbDisplay(_INTL("{1}'s Terminator boosted its Attack!", target.pbThis))
        end
      elsif target.ability == :ORN_VENGEFUL
        if !pbTooHigh?(PBStats::ATTACK)
          target.pbIncreaseStatBasic(PBStats::ATTACK, 1)
          @battle.pbCommonAnimation("StatUp", target, nil)
          @battle.pbDisplay(_INTL("{1}'s Vengeful boosted its Attack!", target.pbThis))
        end
        if !pbTooHigh?(PBStats::SPEED)
          target.pbIncreaseStatBasic(PBStats::SPEED, 1)
          @battle.pbCommonAnimation("StatUp", target, nil)
          @battle.pbDisplay(_INTL("{1}'s Vengeful boosted its Speed!", target.pbThis))
        end
      end
    end
    if user.ability == :ORN_REAPER && target.isFainted?
      user.pbRecoverHP(user.totalhp / 5)
      @battle.pbCommonAnimation("StatUp", target, nil)
      @battle.pbDisplay(_INTL("{1} restored health by defeating the foe!", user.pbThis))
    end
    return warden_pbProcessMoveAgainstTarget(basemove, user, target, numhits, flags, nocheck, alltargets, showanimation, precheckedacc: nil)
  end

  def pbCanStatus?(showMessages, ignorestatus = false, moldbroken = self.moldbroken, ownStatus = false)
    failure = :none
	failure = :ORN_NEBULACLOUD if ((@ability == :ORN_NEBULACLOUD || pbPartner.ability == :ORN_NEBULACLOUD)) && hasType?(:COSMIC) && !moldbroken
    if failure != :none
      if showMessages
        case failure
          when :ORN_NEBULACLOUD then @battle.pbDisplay(_INTL("{1} is protected by Nebula Cloud!", pbThis))
        end
      end
	  return false
    else
      return warden_pbCanStatus?(showMessages, ignorestatus, moldbroken, ownStatus)
    end
  end

  def pbCheckForm(basemove = nil)
    transformed = false
    if (self.pokemon && self.pokemon.species == :ORN_TOGEDEMARU) && !self.isFainted?
      if self.ability == :ORN_DESTRUCTIVECORE && @hp<=((@totalhp/2.0).floor)
        if self.form == 0
          self.form = 1; transformed=true
        end
      end
    end
	if transformed
	end
	warden_pbCheckForm(basemove = nil)
  end

  def pbCheckFormRoundEnd
    # Warden Mons
    if self.species == :ORN_WISHIWASHI && !self.isFainted?
      if self.ability == :ORN_DARKSWARM && !@effects[:Transform]
        schoolHP = (self.totalhp / 4.0).floor
        if (self.hp > schoolHP && self.level > 19)
          if self.form != 1
            self.form = 1
            pbUpdate(true)
            @battle.scene.pbChangePokemon(self, @pokemon)
            @battle.pbDisplay(_INTL("{1} formed a swarm!", pbThis))
          end
        else
          if self.form != 0
            self.form = 0
            pbUpdate(true)
            @battle.scene.pbChangePokemon(self, @pokemon)
            @battle.pbDisplay(_INTL("{1} stopped swarming!", pbThis))
          end
        end
      end
    end
    if self.species == :ORN_UNOWN && !self.isFainted?
      if self.ability == :ORN_SYMPHONY && !@effects[:Transform]
        schoolHP = (self.totalhp / 4.0).floor
        if (self.hp > schoolHP && self.level > 19)
          if self.form != 1
            self.form = 1
            pbUpdate(true)
            @battle.scene.pbChangePokemon(self, @pokemon)
            @battle.pbDisplay(_INTL("{1} formed a symphony!", pbThis))
          end
        else
          if self.form != 0
            self.form = 0
            pbUpdate(true)
            @battle.scene.pbChangePokemon(self, @pokemon)
            @battle.pbDisplay(_INTL("{1} stopped coordinating!", pbThis))
          end
        end
      end
    end
    warden_pbCheckFormRoundEnd
  end
  
  # New Definitions
  def pbReduceSpecialAttackStatStageDishearten(opponent)
    # Ways intimidate doesn't work
    return false if isFainted? && !(Rejuv && isbossmon && @shieldCount > 0)
    return false if @effects[:Substitute] > 0

    if [:CLEARBODY, :WHITESMOKE, :HYPERCUTTER, :FULLMETALBODY].include?(self.ability) || (Gen > 7 && [:INNERFOCUS, :OBLIVIOUS, :OWNTEMPO, :SCRAPPY].include?(self.ability))
      abilityname = getAbilityName(self.ability)
      oppabilityname = getAbilityName(opponent.ability)
      @battle.pbDisplay(_INTL("{1}'s {2} prevented {3}'s {4} from working!", pbThis, abilityname, opponent.pbThis(true), oppabilityname))
      if hasWorkingItem(:ADRENALINEORB) && pbCanIncreaseStatStage?(PBStats::SPEED, false) && self.stages[PBStats::SPATK] > -6
        triggerAdrenalineOrb
      end
      return false
    end
    if pbOwnSide.effects[:Mist] > 0
      @battle.pbDisplay(_INTL("{1} is protected by Mist!", pbThis))
      if hasWorkingItem(:ADRENALINEORB) && pbCanIncreaseStatStage?(PBStats::SPEED, false) && self.stages[PBStats::SPATK] > -6
        triggerAdrenalineOrb
      end
      return false
    end
    # Gen 9 Mod - Clear Amulet prevents stat drop from intimidate
    if hasWorkingItem(:CLEARAMULET)
      itemname = getItemName(self.item)
      oppabilityname = getAbilityName(opponent.ability)
      @battle.pbDisplay(_INTL("{1}'s {2} prevented {3}'s {4} from working!", pbThis, itemname, opponent.pbThis(true), oppabilityname))
      return false
    end
    # Gen 9 Mod - Guard Dog raises attack on Intimidate
    if (self.ability == :GUARDDOG)
      @battle.pbDisplay(_INTL("{1} got angry!",pbThis))
      pbIncreaseStat(PBStats::SPATK, 1)
      if hasWorkingItem(:ADRENALINEORB) && pbCanIncreaseStatStage?(PBStats::SPEED, false) && self.stages[PBStats::SPATK] > -6
        triggerAdrenalineOrb
      end
      return false
    end

    # reduce stat only if you can
    if @battle.FE == :CROWD && pbCanReduceStatStage?(PBStats::DEFENSE, false)
      pbReduceStat(PBStats::DEFENSE, 1, statmessage: false, statdropper: opponent, defiant_proc: false)
      oppabilityname = getAbilityName(opponent.ability)
      @battle.pbDisplay(_INTL("{1}'s {2} cuts {3}'s Defense!", opponent.pbThis, oppabilityname, pbThis(true))) if self.ability != :CONTRARY
      @battle.pbDisplay(_INTL("{1}'s {2} boosts {3}'s Defense!", opponent.pbThis, oppabilityname, pbThis(true))) if self.ability == :CONTRARY
      # Defiant/Competitive
      if self.ability == :DEFIANT
        increment = 2
        increment = 3 if @battle.FE == :BACKALLEY
        pbIncreaseStat(PBStats::SPATK, increment, statmessage: false)
        if @battle.FE == :BACKALLEY
          @battle.pbDisplay(_INTL("Defiant dramatically raised {1}'s Special Attck!", pbThis))
        else
          @battle.pbDisplay(_INTL("Defiant sharply raised {1}'s Special Attck!", pbThis))
        end
      end
      if self.ability == :COMPETITIVE && !(Rejuv && @battle.FE == :CHESS)
        increment = 2
        increment = 3 if @battle.FE == :CITY
        pbIncreaseStat(PBStats::ATTACK, increment, statmessage: false)
        if @battle.FE == :CITY
          @battle.pbDisplay(_INTL("Competitive dramatically raised {1}'s Attack!", pbThis))
        else
          @battle.pbDisplay(_INTL("Competitive sharply raised {1}'s Attack!", pbThis))
        end
      end
    end
    if pbReduceStat(PBStats::SPATK, 1, statmessage: false, statdropper: opponent, defiant_proc: false)
      # Battle message
      oppabilityname = getAbilityName(opponent.ability)
      @battle.pbDisplay(_INTL("{1}'s {2} cuts {3}'s Special Attck!", opponent.pbThis, oppabilityname, pbThis(true))) if !(self.ability == :CONTRARY)
      @battle.pbDisplay(_INTL("{1}'s {2} boosts {3}'s Special Attck!", opponent.pbThis, oppabilityname, pbThis(true))) if (self.ability == :CONTRARY)

      if self.ability == :RATTLED && Gen > 7
        pbIncreaseStat(PBStats::SPEED, 1, statmessage: false)
        @battle.pbDisplay(_INTL("{1}'s Rattled raised its Speed!", pbThis))
      end

      # Defiant/Competitive
      if self.ability == :DEFIANT
        increment = 2
        increment = 3 if @battle.FE == :BACKALLEY
        pbIncreaseStat(PBStats::SPATK, increment, statmessage: false)
        if @battle.FE == :BACKALLEY
          @battle.pbDisplay(_INTL("Defiant dramatically raised {1}'s Special Attck!", pbThis))
        else
          @battle.pbDisplay(_INTL("Defiant sharply raised {1}'s Special Attck!", pbThis))
        end
      end
      if self.ability == :COMPETITIVE && !(Rejuv && @battle.FE == :CHESS)
        increment = 2
        increment = 3 if @battle.FE == :CITY
        pbIncreaseStat(PBStats::ATTACK, increment, statmessage: false)
        if @battle.FE == :CITY
          @battle.pbDisplay(_INTL("Competitive dramatically raised {1}'s Attack!", pbThis))
        else
          @battle.pbDisplay(_INTL("Competitive sharply raised {1}'s Attack!", pbThis))
        end
      end

      # Item triggers
      if hasWorkingItem(:ADRENALINEORB) && pbCanIncreaseStatStage?(PBStats::SPEED, false)
        triggerAdrenalineOrb
      end
      if hasWorkingItem(:WHITEHERB)
        reducedstats = false
        for i in 1..7
          if self.stages[i] < 0
            self.stages[i] = 0
            reducedstats = true
          end
        end
        if reducedstats
          itemname = self.item.nil? ? "" : getItemName(self.item)
          @battle.pbDisplay(_INTL("{1}'s {2} restored its status!", pbThis, itemname))
          pbDisposeItem(false)
        end
      end

      return true
    end
    return false
  end

  def pbRegenTele
    self.form=0
    @effects[:Teleface] = true
    pbUpdate(true)
    @battle.scene.pbChangePokemon(self,@pokemon)
  end

  def pbResetForm
    return if !@pokemon
    if !@effects[:Transform]
      if (@pokemon.species == :AEGISLASH && self.form < 2) || [:CASTFORM, :CHERRIM, :WISHIWASHI, :DITTO, :MEW, :MORPEKO, :CRAMORANT, :ORN_WISHIWASHI, :ORN_UNOWN].include?(@pokemon.species) 
      elsif [:DARMANITAN, :MINIOR, :ORN_TOGEDEMARU].include?(@pokemon.species)
        self.form=@startform
      end
    end
    pbUpdate(true)
  end
end

# Superclass for moves which apply an effect to every Pokemon on the field.
class PokeBattle_AllTargetMove < PokeBattle_Move
  def priorityBlockedForAllTargetMoves?(attacker)
    # Priority blocking abilities by the opponent prevent certain moves from going through on ALL Pokemon if used via Prankster
    @battle.battlers.each do |battler|
      if battler != attacker && battler != attacker.pbPartner
        prior_block = ([:ORN_NOBILITY,:QUEENLYMAJESTY,:DAZZLING].include?(battler.ability) || (@battle.FE == :STARLIGHT && battler.ability == :MIRRORARMOR)) ? true : false
        if !battler.moldbroken && prior_block
          if priorityCheck(attacker) > 0 && @battle.choices[attacker.index][2] == self # && !flags[:instructed]
            @battle.pbDisplay(_INTL("{1} cannot use {2}!", attacker.pbThis, self.name))
            return true
          end
        end
      end
    end
    return false
  end
end

## Manual Overwrites because method cannot be Aliased ##
class PokeBattle_Battler
  # For Charisma
  def pbUseMove(choice, flags = { danced: false, totaldamage: 0, specialusage: false, specialZ: false })
    if @battle.recorded == true
      $game_variables[:BattleDataArray].last().pokemonTrackMove(choice, self, @battle.battlers)
    end
    danced = flags[:danced]
      # TODO: lastMoveUsed is not to be updated on nested calls
    flags[:totaldamage] = 0 if !flags[:totaldamage]
      # hasMovedThisRound by itself isn't enough for, say, Fake Out + Instruct.
    @isFirstMoveOfRound = !self.hasMovedThisRound?
      # Start using the move
    pbBeginTurn(choice)
      # Force the use of certain moves if they're already being used
    if @effects[:TwoTurnAttack] != 0 || @effects[:HyperBeam] > 0 || @effects[:Outrage] > 0 || @effects[:Rollout] > 0 || @effects[:Uproar] > 0 || @effects[:Bide] > 0
      PBDebug.log("[Continuing move]") if $INTERNAL
      choice[2] = PokeBattle_Move.pbFromPBMove(@battle, PBMove.new(@currentMove), self) if @currentMove != 0
      flags[:specialusage] = true
    elsif @effects[:Encore] > 0 && !choice[2].zmove && choice[2] != @battle.struggle
      if @battle.pbCanShowCommands?(@index)
        PBDebug.log("[Using Encore move]") if $INTERNAL
        if choice[1] != @effects[:EncoreIndex]   # Was Encored mid-round
          choice[1] = @effects[:EncoreIndex]
          choice[2] = @moves[@effects[:EncoreIndex]]
          if choice[2].move == :ACUPRESSURE
            choice[3] = self.index
          else
            choice[3] = -1   # No target chosen
          end
        end
      end
    end
    basemove = choice[2]
    return if !basemove

    if !flags[:specialusage]
        # TODO: Quick Claw message
    end
    PBDebug.log("  #{self.name} used   #{basemove.name}") if $INTERNAL
    return false if self.effects[:SkyDrop] || self.effects[:Commander]   # Gen 9 Mod - Tatsugiri can't use move if in Dondozo's mouth

    if !pbTryUseMove(choice, basemove, flags)
      if self.vanished
        @battle.scene.pbUnVanishSprite(self)
        droprelease = self.effects[:SkyDroppee]
        if droprelease != nil
          oppmon = droprelease
          oppmon.effects[:SkyDrop] = false
          @effects[:SkyDroppee] = nil
          @battle.scene.pbUnVanishSprite(oppmon)
          @battle.pbDisplay(_INTL("{1} is freed from the Sky Drop effect!", oppmon.pbThis))
        end
      end
        # Commented out because the cases we tested (Encore / Disable / Sketch / Mimic / Spite / Instruct)
        # all work after a sleep turn using the last used move.
        # self.lastMoveUsed = -1
      if !flags[:specialusage]
          # self.lastMoveUsedSketch = -1 if self.effects[:TwoTurnAttack] == 0
          # self.lastRegularMoveUsed = -1
        self.lastRoundMoved = @battle.turncount
      end
      self.effects[:Metronome] = 0
      pbCancelMoves
      @battle.pbGainEXP
      pbEndTurn(choice)
      @battle.pbJudgeSwitch
      return
    end
    if !flags[:specialusage]
      @battle.ai.addMoveToMemory(self, basemove) if !choice[2].zmove
      ppmove = choice[2].zmove ? self.moves[choice[1]] : basemove
      if !pbReducePP(ppmove) && !choice[2].zmove
        @battle.pbDisplay(_INTL("{1} used\r\n{2}!", pbThis, basemove.getMoveUseName))
        @battle.pbDisplay(_INTL("But there was no PP left for the move!"))
        self.lastMoveUsed = -1
        if !flags[:specialusage]
          self.lastMoveUsedSketch = -1 if self.effects[:TwoTurnAttack] == 0
          self.lastRegularMoveUsed = -1
          self.lastRoundMoved = @battle.turncount
        end
        pbEndTurn(choice)
        @battle.pbJudgeSwitch
        return
      end
    end
    @battle.pbUseZMove(self.index, choice, self.item, flags[:specialZ]) if choice[2].zmove && (!flags[:specialusage] || flags[:specialZ])
    if basemove.function != 0x92   # Echoed Voice
      self.effects[:EchoedVoice] = 0
    end
    if basemove.function != 0x91   # Fury Cutter
      self.effects[:FuryCutter] = 0
    end
    if @effects[:Powder] && basemove.type == :FIRE
      @battle.pbDisplay(_INTL("The powder around {1} exploded!", pbThis))
      @battle.pbCommonAnimation("Powder", self, nil)
      pbReduceHP((@totalhp / 4.0).floor)
      pbFaint if @hp < 1
      return false
    end
      # Remember that user chose a two-turn move
    if basemove.pbTwoTurnAttack(self)
        # Beginning use of two-turn attack
      @effects[:TwoTurnAttack] = basemove.move
      @currentMove = basemove.move
    else
      @effects[:TwoTurnAttack] = 0   # Cancel use of two-turn attack
      @effects[:SkyDroppee] = nil if basemove.move != :SKYDROP
    end
      # "X used Y!" message
    case basemove.pbDisplayUseMessage(self, choice)
      when 2     # Continuing Bide
        if !flags[:specialusage]
          self.lastRoundMoved = @battle.turncount
        end
        return
      when 1     # Starting Bide
        if $cache.moves[basemove.move]
          self.lastMoveUsed = basemove.move
          @lastMoveChoice = choice.clone
          if !flags[:specialusage]
            self.lastMoveUsedSketch = basemove.move if self.effects[:TwoTurnAttack] == 0
            self.lastRegularMoveUsed = basemove.move
            if self.effects[:ChoiceBand] == nil && (self.hasWorkingItem(:CHOICEBAND) || self.hasWorkingItem(:CHOICESPECS) || self.hasWorkingItem(:CHOICESCARF))
              self.effects[:ChoiceBand] = basemove.move
            end
            if self.effects[:GorillaLock] == nil && self.ability == :GORILLATACTICS
              self.effects[:GorillaLock] = basemove.move
            end
            self.movesUsed.push(basemove.move)   # For Last Resort
            self.lastRoundMoved = @battle.turncount
          else
            self.lastRegularMoveUsed = -1 if basemove.move == :STRUGGLE
          end
          @battle.lastMoveUsed = basemove.move
          @battle.lastMoveUser = self.index
        end
        return
      when -1   # Was hurt while readying Focus Punch, fails use
        if $cache.moves[basemove.move]
          self.lastMoveUsed = basemove.move
          @lastMoveChoice = choice.clone
          if !flags[:specialusage]
            self.lastMoveUsedSketch = basemove.move if self.effects[:TwoTurnAttack] == 0
            self.lastRegularMoveUsed = basemove.move
            self.movesUsed.push(basemove.move)   # For Last Resort
            self.lastRoundMoved = @battle.turncount
          else
            self.lastRegularMoveUsed = -1 if basemove.move == :STRUGGLE
          end
          @battle.lastMoveUsed = basemove.move
          @battle.lastMoveUser = self.index
        end
        return
    end
      # Find the user and target(s)
    targets = []
    pbFindUser(choice, targets)
    user = self
      # Status Z-move effects
    pbZStatus(basemove.move, user) if choice[2].zmove && choice[2].category == :status && PBStuff::TYPETOZCRYSTAL[basemove.type] == user.item
      # moldbreaker
      # Gen 9 Mod - Added Mycelium Might
    if (user.ability == :MOLDBREAKER || user.ability == :TERAVOLT || user.ability == :TURBOBLAZE) || (user.ability == :MYCELIUMMIGHT && basemove.basedamage == 0 && user.effects[:TwoTurnAttack] == 0) ||
       basemove.function == 0x166 || basemove.function == 0x176 || basemove.function == 0x200   # Solgaluna/crozma signatures
      for i in 0..3
          # Gen 9 Mod - Added Ability Shield
        if !@battle.battlers[i].hasWorkingItem(:ABILITYSHIELD)
          @battle.battlers[i].moldbroken = true
        else
          @battle.battlers[i].moldbroken = false
        end
      end
    else
      for i in 0..3
        @battle.battlers[i].moldbroken = false
      end
    end
    if user.ability == :CORROSION
      for battlers in targets
        battlers.corroded = true
      end
    else
      for battlers in targets
        battlers.corroded = false
      end
    end
      # Battle Arena only - assume failure
      # Check whether Selfdestruct works
    if !basemove.pbOnStartUse(user)   # Only Selfdestruct can return false here
      if $cache.moves[basemove.move]
        user.lastMoveUsed = basemove.move
        @lastMoveChoice = choice.clone
        if !flags[:specialusage]
          user.lastMoveUsedSketch = basemove.move if user.effects[:TwoTurnAttack] == 0
          user.lastRegularMoveUsed = basemove.move
          user.movesUsed.push(basemove.move)   # For Last Resort
          user.lastRoundMoved = @battle.turncount
        else
          self.lastRegularMoveUsed = -1 if basemove.move == :STRUGGLE
        end
        @battle.lastMoveUsed = basemove.move
        @battle.lastMoveUser = user.index
      end
        # Might pbEndTurn need to be called here?
      return
    end
      # Record move as having been used
    if $cache.moves[basemove.move]
      user.lastMoveUsed = basemove.move
      @lastMoveChoice = choice.clone
      user.lastRoundMoved = @battle.turncount
      if !flags[:specialusage]
        user.lastMoveUsedSketch = basemove.move
        user.lastRegularMoveUsed = basemove.move
        if user.effects[:ChoiceBand] == nil && (user.hasWorkingItem(:CHOICEBAND) || user.hasWorkingItem(:CHOICESPECS) || user.hasWorkingItem(:CHOICESCARF))
          user.effects[:ChoiceBand] = basemove.move
        end
        if user.effects[:GorillaLock] == nil && user.ability == :GORILLATACTICS
          user.effects[:GorillaLock] = basemove.move
        end
        if !basemove.zmove
          user.movesUsed.push(basemove.move)   # For Last Resort
          user.effects[:Metronome] = 0 if basemove.move != user.movesUsed[-2]
        end
      else
        self.lastRegularMoveUsed = -1 if basemove.move == :STRUGGLE
      end
      @battle.lastMoveUsed = basemove.move
      @battle.lastMoveUser = user.index
      if basemove.zmove
        user.lastMoveUsed = -1
        user.lastMoveUsedSketch = -1
        user.lastRegularMoveUsed = -1
        @battle.lastMoveUsed = -1
      end
    end
    targetchoices = pbTarget(basemove)
      # Try to use move against user if there aren't any targets
    if targets.length == 0 && @effects[:TwoTurnAttack] == 0
      user = pbChangeUser(basemove, user)
      cancelcheck = false
      if basemove.typeFieldBoost(basemove.pbType(user), user, nil) == 0
        @battle.pbDisplay(_INTL(basemove.typeFieldMessage(basemove.pbType(user)))) if !basemove.fieldmessageshown_type
        basemove.fieldmessageshown_type = true
        user.pbCancelMoves
        cancelcheck = true
      end
      if basemove.moveFieldBoost == 0
        @battle.pbDisplay(_INTL(basemove.moveFieldMessage)) if !basemove.fieldmessageshown
        basemove.fieldmessageshown = true
        user.pbCancelMoves
        cancelcheck = true
      end
      if !cancelcheck
        if [:SingleNonUser, :RandomOpposing, :AllOpposing, :AllNonUsers, :Partner, :UserOrPartner, :SingleOpposing, :OppositeOpposing, :DragonDarts].include?(targetchoices)
          @battle.pbDisplay(_INTL("But there was no target..."))
          @effects[:Rollout] = 0 if @effects[:Rollout] > 0
          if PBStuff::TWOTURNMOVE.include?(basemove.move)   # Sprites for two turn moves
            @battle.scene.pbUnVanishSprite(user)
          end
        else
          PBDebug.logonerr {
            basemove.pbEffect(user, nil)
          }
        end
        unless !basemove
          pbDancerMoveCheck(basemove.move) unless danced
        end
      end
    else
        # We have targets
      dragondarthit = nil
      if targetchoices == :DragonDarts && targets.length > 1
        originaltargets = targets.clone
        for target in originaltargets
          if !basemove.pbAccuracyCheck(user, target)
            if targets.length > 1
              targets.delete(target)
              @battle.pbDisplay(_INTL("{1}'s attack missed!", user.pbThis))
            else
              dragondarthit = false
            end
            user.missAcc = true
          end
        end
        dragondarthit = true if dragondarthit.nil?
      end
      movesucceeded = false
      showanimation = true
      disguisebustcheck = false
      alltargets = []
      basemove.fieldmessageshown = false
      basemove.fieldmessageshown_type = false
      if @effects[:TwoTurnAttack] != 0 && targets.length == 0
        numhits = basemove.pbNumHits(user)
        pbProcessMoveAgainstTarget(basemove, user, nil, numhits, flags, false, alltargets, showanimation)
      end

      if targets.length > 0 && targetchoices == :AllOpposing
          # Add target's partner to list of targets
        pbAddTarget(targets, targets[0].pbPartner)
      end
      for i in 0...targets.length
        alltargets.push(targets[i].index)
      end

      killtracker = []
        # For each target in turn
      i = 0
      loop do
        break if i >= targets.length

          # Get next target
        userandtarget = [user, targets[i]]
        success = pbChangeTarget(basemove, userandtarget, targets)
        user = userandtarget[0]
        target = userandtarget[1]
        if target.effects[:MagicBounced] || target.isFainted?
          success = false
        end
        if !success
          i += 1
          next
        end
        numhits = basemove.pbNumHits(user)
          # Ledian and Cinccino crests
        if targetchoices != :AllOpposing && numhits < 2
          case user.crested
            when :LEDIAN
              numhits = 4 if basemove.punchMove?
            when :CINCCINO
              hitchances = [2, 2, 3, 3, 4, 5]
              ret = hitchances[@battle.pbRandom(hitchances.length)]
              ret = 5 if user.ability == :SKILLLINK
              numhits = ret if !basemove.pbIsMultiHit
          end
        end
          # Parental bond
        if numhits == 1 && user.ability == :PARENTALBOND && !choice[2].zmove
          counter1 = 0
          counter2 = 0
          for k in @battle.battlers
            next if k.isFainted?

            counter1 += 1
          end
          for j in @battle.battlers
            next unless user.pbIsOpposing?(j.index)
            next if j.isFainted?

            counter2 += 1
          end
          user.effects[:ParentalBond] = true unless (targetchoices == :AllNonUsers && counter1 != 2) || (targetchoices == :AllOpposing && counter2 != 1)
          numhits = 2 unless (targetchoices == :AllNonUsers && counter1 != 2) || (targetchoices == :AllOpposing && counter2 != 1)
        else
          user.effects[:ParentalBond] = false
        end
        if numhits == 1 && basemove.contactMove? && user.crested == :TYPHLOSION && !choice[2].zmove
          counter1 = 0
          counter2 = 0
          for k in @battle.battlers
            next if k.isFainted?

            counter1 += 1
          end
          for j in @battle.battlers
            next unless user.pbIsOpposing?(j.index)
            next if j.isFainted?

            counter2 += 1
          end
          user.effects[:TyphBond] = true unless (targetchoices == :AllNonUsers && counter1 != 2) || (targetchoices == :AllOpposing && counter2 != 1)
          numhits = 2 unless (targetchoices == :AllNonUsers && counter1 != 2) || (targetchoices == :AllOpposing && counter2 != 1)
        else
          user.effects[:TyphBond] = false
        end
          # Reset damage state, set Focus Band/Focus Sash to available
        target.damagestate.reset
        if target.hasWorkingItem(:FOCUSBAND) && @battle.pbRandom(10) == 0
          target.damagestate.focusband = true
        end
        if target.hasWorkingItem(:FOCUSSASH)
          target.damagestate.focussash = true
        end
        if target.crested == :RAMPARDOS && target.pokemon.rampCrestUsed == false
          target.damagestate.rampcrest = true
        end
        target.lastMoveTaken = basemove.move
          # Use move against the current target
        hitcheck, killflag = pbProcessMoveAgainstTarget(basemove, user, target, numhits, flags, false, alltargets, showanimation, precheckedacc: dragondarthit)
        hitcheck = 0 if hitcheck == nil
        killtracker.push(target) if killflag
        disguisebustcheck = true if target.damagestate.disguise
        showanimation = false unless (hitcheck <= 0 && disguisebustcheck == false && @effects[:TwoTurnAttack] == 0 && (basemove.pbIsSpecial?(basemove.type) || basemove.pbIsPhysical?(basemove.type)))
        movesucceeded = true if (hitcheck && hitcheck > 0) || disguisebustcheck
          # Probopass Crest
        if user.crested == :PROBOPASS
          if basemove.basedamage > 0 && basemove.move != :PROBOPOG
            @battle.pbDisplay(_INTL("{1}'s mini noses followed up on the attack!", user.pbThis))
            if basemove.target == :AllOpposing || basemove.target == :AllNonUsers
              movetarget = target
              movetarget = user.pbCrossOpposing if user.pbPartner == target
              movetarget = movetarget.pbPartner if movetarget.isFainted?
            else
              movetarget = target
              movetarget = movetarget.pbPartner if movetarget.isFainted?
            end
            if movetarget.isFainted?
              @battle.pbDisplay(_INTL("But there was no target left!", user.pbThis))
            else
              user.pbUseMoveSimple(:PROBOPOG, -1, movetarget.index)
            end
          end
        end
        i += 1
      end
      basemove.fieldmessageshown = false
      basemove.fieldmessageshown_type = false

        # Activation Timing: after the move fully resolves
        # On Kill effects
      for target in killtracker
        if user.hp > 0 && target.hp <= 0 && flags[:totaldamage] > 0
          if user.ability == :EXECUTION
            user.pbRecoverHP(self.totalhp / 8, true)
            @battle.pbDisplay(_INTL("{1}'s Execution healed some of its wounds!", user.pbThis))
          end
          if !@battle.pbAllFainted?(@battle.pbParty(target.index))
            if [:GRIMNEIGH, :ASONEGRIM].include?(user.ability)
              if !user.pbTooHigh?(PBStats::SPATK)
                @battle.pbCommonAnimation("StatUp", self, nil)
                user.pbIncreaseStatBasic(PBStats::SPATK, 1)
                abilityname = user.ability == :ASONEGRIM ? "Grim Neigh" : getAbilityName(user.ability)
                @battle.pbDisplay(_INTL("{1}'s {2} raised its Special Attack!", user.pbThis, abilityname))
              end
            end
            if [:MOXIE, :CHILLINGNEIGH, :ASONECHILLING].include?(user.ability)
             if !user.pbTooHigh?(PBStats::ATTACK)
                @battle.pbCommonAnimation("StatUp", self, nil)
                user.pbIncreaseStatBasic(PBStats::ATTACK, 1)
                abilityname = user.ability == :ASONECHILLING ? "Chilling Neigh" : getAbilityName(user.ability)
                @battle.pbDisplay(_INTL("{1}'s {2} raised its Attack!", user.pbThis, abilityname))
              end
            elsif [:CHARISMA].include?(user.ability)
             if !user.pbTooHigh?(PBStats::SPATK)
                @battle.pbCommonAnimation("StatUp", self, nil)
                user.pbIncreaseStatBasic(PBStats::SPATK, 1)
                abilityname = user.ability == :ASONECHILLING ? "Chilling Neigh" : getAbilityName(user.ability)
                @battle.pbDisplay(_INTL("{1}'s {2} raised its Special Attack!", user.pbThis, abilityname))
              end
            end
            if user.ability == :BEASTBOOST
              aBoost = user.attack
              dBoost = user.defense
              saBoost = user.spatk
              sdBoost = user.spdef
              spdBoost = user.speed
              boostStat = [aBoost, dBoost, saBoost, sdBoost, spdBoost].max
              statindex = [aBoost, dBoost, saBoost, sdBoost, spdBoost].index(boostStat) + 1
              statmod = @battle.FE == :DIMENSIONAL ? 2 : 1
              if !user.pbTooHigh?(statindex)
                @battle.pbCommonAnimation("StatUp", self, nil)
                user.pbIncreaseStatBasic(statindex, statmod)
                @battle.pbDisplay(_INTL("{1}'s Beast Boost raised its {2}!", user.pbThis, pbGetStatName(statindex)))
              end
            end
            if @battle.FE == :COLOSSEUM
              aBoost = target.attack
              dBoost = target.defense
              saBoost = target.spatk
              sdBoost = target.spdef
              spdBoost = target.speed
              boostStat = [aBoost, dBoost, saBoost, sdBoost, spdBoost].max
              statindex = [aBoost, dBoost, saBoost, sdBoost, spdBoost].index(boostStat) + 1
              if !user.pbTooHigh?(statindex)
                user.pbIncreaseStat(statindex, 1, statmessage: false)
                if user.ability == :CONTRARY
                  @battle.pbDisplay(_INTL("The cheering audience lowered {1}'s {2}!", user.pbThis, pbGetStatName(statindex)))
                else
                  @battle.pbDisplay(_INTL("The cheering audience raised {1}'s {2}!", user.pbThis, pbGetStatName(statindex)))
                end
              end
            end
            if @battle.FE == :BACKALLEY && basemove.move == :PURSUIT
              if !user.pbTooHigh?(PBStats::SPEED)
                @battle.pbCommonAnimation("StatUp", self, nil)
                user.pbIncreaseStatBasic(PBStats::SPEED, 1)
                @battle.pbDisplay(_INTL("{1}'s Pursuit raised its Speed!", user.pbThis))
              end
            end
            if user.species == :GRENINJA && user.ability == :BATTLEBOND && !@battle_bond_flags.include?(user.pokemon)
              unless LegacyBattleBond
                battleBondActive = false
                if !user.pbTooHigh?(PBStats::ATTACK)
                  @battle.pbCommonAnimation("StatUp", self, nil)
                  user.pbIncreaseStatBasic(PBStats::ATTACK, 1)
                  @battle.pbDisplay(_INTL("{1}'s {2} raised its Attack!", user.pbThis, getAbilityName(user.ability)))
                  battleBondActive = true
                end
                if !user.pbTooHigh?(PBStats::SPATK)
                  @battle.pbCommonAnimation("StatUp", self, nil)
                  user.pbIncreaseStatBasic(PBStats::SPATK, 1)
                  @battle.pbDisplay(_INTL("{1}'s {2} raised its Special Attack!", user.pbThis, getAbilityName(user.ability)))
                  battleBondActive = true
                end
                if !user.pbTooHigh?(PBStats::SPEED)
                  @battle.pbCommonAnimation("StatUp", self, nil)
                  user.pbIncreaseStatBasic(PBStats::SPEED, 1)
                  @battle.pbDisplay(_INTL("{1}'s {2} raised its Speed!", user.pbThis, getAbilityName(user.ability)))
                  battleBondActive = true
                end
                @battle_bond_flags.push(user.pokemon) if battleBondActive
              else
                if !user.effects[:Transform]
                  @battle.pbDisplay(_INTL("{1} became fully charged due to its bond with its Trainer!", user.pbThis))
                  @battle.pbCommonAnimation("MegaEvolution", user, nil)
                  user.form = 1
                  user.pbUpdate(true)
                  @battle.scene.pbChangePokemon(user, user.pokemon) if user.effects[:Substitute] == 0
                  @battle.pbDisplay(_INTL("{1} transformed into Ash-Greninja!", user.pbThis))
                  @battle_bond_flags.push(user.pokemon)
                end
              end
            end
          end
        end
      end
        # Swalot Crest
      if user.crested == :SWALOT
        if basemove.move == :BELCH
          move = :SPITUP
          movename = getMoveName(move)
          @battle.pbDisplay(_INTL("{1} used {2}!", user.pbThis, movename))
          movetarget = targets[0]
          movetarget = movetarget.pbPartner if movetarget.isFainted?
          if movetarget.isFainted?
            @battle.pbDisplay(_INTL("But there was no target left!", user.pbThis))
          else
            user.pbUseMoveSimple(move, -1, movetarget.index)
          end
        end
        if ![:STOCKPILE, :SPITUP, :SWALLOW].include?(basemove.move) && user.effects[:Stockpile] < 3
          user.effects[:Stockpile] += 1
          @battle.pbDisplay(_INTL("{1} stockpiled {2}!", user.pbThis, user.effects[:Stockpile]))
          if user.pbIncreaseStat(PBStats::DEFENSE, 1, abilitymessage: false, statsource: user)
            user.effects[:StockpileDef] += 1
          end
          if user.pbIncreaseStat(PBStats::SPDEF, 1, abilitymessage: false, statsource: user)
            user.effects[:StockpileSpDef] += 1
          end
        end
      end

      if user.missAcc
        if user.hasWorkingItem(:BLUNDERPOLICY)
          if user.pbIncreaseStat(PBStats::SPEED, 2, abilitymessage: false, statsource: user)
            if user.ability == :CONTRARY
              @battle.pbDisplay(_INTL("The Blunder Policy harshly lowered   #{user.pbThis}'s Speed!"))
            else
              @battle.pbDisplay(_INTL("The Blunder Policy sharply raised   #{user.pbThis}'s Speed!"))
            end
            user.pbDisposeItem(false)
          end
        end
        if @battle.ProgressiveFieldCheck(PBFields::CONCERT)
          @battle.reduceField
        end
      end

        # Throat Spray
      if user.hasWorkingItem(:THROATSPRAY) && basemove.isSoundBased? && user.hp > 0
        if user.pbIncreaseStat(PBStats::SPATK, 1, abilitymessage: false, statsource: user)
          if user.ability == :CONTRARY
            @battle.pbDisplay(_INTL("The Throat Spray lowered   #{user.pbThis}'s Special Attack!"))
          else
            @battle.pbDisplay(_INTL("The Throat Spray raised   #{user.pbThis}'s Special Attack!"))
          end
          user.pbDisposeItem(false)
        end
      end

        # Metronome item
      if (user.hasWorkingItem(:METRONOME) || @battle.FE == :CONCERT4) && movesucceeded
        user.effects[:Metronome] += 1
      else
        user.effects[:Metronome] = 0
      end

        # Magic Bounce
      for i in targets
        if !i.effects[:BouncedMove].nil?   # lía
          move = i.effects[:BouncedMove].move
          i.effects[:BouncedMove] = nil
          @battle.pbDisplay(_INTL("{1} bounced the {2} back!", i.pbThis, basemove.name))
          if @battle.FE == :MIRROR
            if i.pbCanIncreaseStatStage?(PBStats::EVASION)
              i.pbIncreaseStatBasic(PBStats::EVASION, 1)
              @battle.pbCommonAnimation("StatUp", i, nil)
              @battle.pbDisplay(_INTL("{1}'s Magic Bounce increased its evasion!", i.pbThis, basemove.name))
            end
          end
            # pbUseMoveSimple(moveid,index=-1,target=-1,danced=false)
          i.pbUseMoveSimple(move, -1, user.index, false)
          i.effects[:MagicBounced] = false
        end
      end

        # Misc Field Effects 2
      if @battle.FE == :DIMENSIONAL
        combust = user.totalhp
        if combust != 0
          if (basemove.move == :DIG || basemove.move == :DIVE ||
            basemove.move == :FLY || basemove.move == :BOUNCE) &&
             user.effects[:TwoTurnAttack] != 0
            combust -= 1 if user.ability == :STURDY
            @battle.pbDisplay(_INTL("The corrupted field damaged {1}!", user.pbThis)) if combust != 0
            user.pbReduceHP(combust) if combust != 0
            user.pbFaint if user.isFainted?
          end
        end
      end

        # Goth Crest
      if user.crested == :GOTHITELLE && user.hasType?(:DARK) && flags[:totaldamage] > 0 && @effects[:HealBlock] == 0
        hpgain = flags[:totaldamage] / 4.0
        hpgain = user.pbRecoverHP([hpgain.floor, 1].max, true)
        if hpgain > 0
          @battle.pbDisplay(_INTL("{1} restored some HP using the Gothitelle Crest!", user.pbThis))
        end
      end

        # Sheer Force affected items
      if !(user.ability == :SHEERFORCE && (basemove.effect > 0 || [0x908].include?(basemove.function)))   # Gen 9 Mod - Electro Shot needs to be affected by Sheer Force.

          # Shell Bell
        if (user.hasWorkingItem(:SHELLBELL) || (user.crested == :TORTERRA && !user.isFainted?)) && flags[:totaldamage] > 0 && @effects[:HealBlock] == 0
          hpgain = @battle.FE == :ASHENBEACH ? flags[:totaldamage] / 4.0 : flags[:totaldamage] / 8.0
          hpgain = user.pbRecoverHP([hpgain.floor, 1].max, true)
          if hpgain > 0
            @battle.pbDisplay(_INTL("{1} restored a little HP using its Shell Bell!", user.pbThis))
          end
        end

          # Life Orb
        if user.hasWorkingItem(:LIFEORB) && movesucceeded && user.ability != :MAGICGUARD && !(user.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
          hploss = user.pbReduceHP([(user.totalhp / 10.0).floor, 1].max, true)
          if hploss > 0
            @battle.pbDisplay(_INTL("{1} lost some of its HP!", user.pbThis))
          end
        end

        user.pbFaint if user.isFainted?   # no return
      end

      for i in alltargets
        target = @battle.battlers[i]
        if target.effects[:ItemRemoval] == :Pickpocket
          if target.item.nil? && !user.item.nil? && user.effects[:Substitute] == 0 && user.ability != :STICKYHOLD &&
           !battle.pbIsUnlosableItem(user, user.item) && !battle.pbIsUnlosableItem(target, user.item)
            target.item = user.item
            user.item = nil
            if user.pokemon.corrosiveGas
              user.pokemon.corrosiveGas = false
              target.pokemon.corrosiveGas = true
            end
            if @battle.pbIsWild? && target.pokemon.itemInitial.nil? && user.pokemon.itemInitial == target.item && !user.isbossmon && !target.isbossmon   # In a wild battle
              target.pokemon.itemInitial = target.item
              target.pokemon.itemReallyInitialHonestlyIMeanItThisTime = target.item
              user.pokemon.itemInitial = nil
            end
            @battle.pbCommonAnimation("Thief", target, user)
            @battle.pbDisplay(_INTL("{1} pickpocketed {2}'s {3}!", target.pbThis, user.pbThis(true), getItemName(target.item)))
          end
          target.effects[:ItemRemoval] = nil
        end
      end

        # Mold Breaker reset
      for i in 0..3
        @battle.battlers[i].moldbroken = false
        @battle.battlers[i].corroded = false
      end

        # Dancer
      unless !basemove
        pbDancerMoveCheck(basemove.move) unless danced
      end
      if danced
        if user.effects[:Outrage] > 0
          user.effects[:Outrage] = 0
        end
      end
        # Switch moves
      for i in @battle.battlers
        if i.userSwitch
          i.userSwitch = false
            # remove gem when switching out before hitting pbEndTurn
          if i.takegem
            i.pbDisposeItem(false, true, true, true)
            i.takegem = false
          end
          @battle.pbDisplay(_INTL("{1} went back to {2}!", i.pbThis, @battle.pbGetOwner(i.index).name))
          newpoke = 0
          newpoke = @battle.pbSwitchInBetween(i.index, true, false)
          @battle.pbMessagesOnReplace(i.index, newpoke)
          i.vanished = false
          i.pbResetForm
          @battle.pbReplace(i.index, newpoke, false)
          @battle.pbOnActiveOne(i)
          i.pbAbilitiesOnSwitchIn(true)
        end
        if i.forcedSwitch
            # remove gem when forced switching out mid attack
          if i.takegem
            i.pbDisposeItem(false, true, true, true)
            i.takegem = false
          end
          i.forcedSwitch = false
          party = @battle.pbParty(i.index)
          j = -1
          until j != -1
            j = @battle.pbRandom(party.length)
            if !((i.isFainted? || j != i.pokemonIndex) && (pbPartner.isFainted? || j != i.pbPartner.pokemonIndex) && party[j] && !party[j].isEgg? && party[j].hp > 0)
              j = -1
            end
            if !@battle.pbCanSwitchLax?(i.index, j, false)
              j = -1
            end
            if Rejuv and party[j].isbossmon
              j = -1
            end
          end
          newpoke = j
          i.vanished = false
          i.pbResetForm
          @battle.pbReplace(i.index, newpoke, false)
          @battle.pbDisplay(_INTL("{1} was dragged out!", i.pbThis))
          @battle.pbOnActiveOne(i)
          i.pbAbilitiesOnSwitchIn(true)
          i.forcedSwitchEarlier = true
        end
      end
    end
    if basemove.function == 0xE0   # Self-Destruct / Explosion
      user.effects[:DelayFaint] = false
      user.hp = 0
      user.pbFaint
    end
    @battle.fieldEffectAfterMove(basemove, user)
    @battle.pbGainEXP
      # Check if move order should be switched for shell trap

      # Remember trainer has used z-move
    if basemove.zmove
      side = @battle.pbIsOpposing?(self.index) ? 1 : 0
      owner = @battle.pbGetOwnerIndex(self.index)
      @battle.zMove[side][owner] = -2 if @battle.zMove[side][owner] != -1
    end
      # End of move usage
    pbEndTurn(choice)
    @battle.pbJudgeSwitch
    return
  end
  # Warden Ability Redirect
  def pbChangeTarget(basemove, userandtarget, targets)
    priority = @battle.pbPriority
    changeeffect = 0
    user = userandtarget[0]
    target = userandtarget[1]
    targetchoices = pbTarget(basemove)
    unless (basemove.function == 0x179) || user.ability == :STALWART || user.ability == :PROPELLERTAIL
      movetypes = [basemove.pbType(user), *basemove.getSecondaryType(user)]

      # LightningRod here, considers Hidden Power as Normal
      if targets.length == 1 && movetypes.include?(:ELECTRIC) && target.ability != :LIGHTNINGROD
        for i in priority # use Pokémon earliest in priority
          next if i.index == user.index || i.isFainted?

          if i.ability == :LIGHTNINGROD && !i.moldbroken
            target = i # X's LightningRod took the attack!
            changeeffect = 1
            break
          end
        end
      end

      # Storm Drain here, considers Hidden Power as Normal
      if targets.length == 1 && movetypes.include?(:WATER) && target.ability != :STORMDRAIN
        for i in priority # use Pokémon earliest in priority
          next if i.index == user.index || i.isFainted?

          if i.ability == :STORMDRAIN && !i.moldbroken
            target = i # X's Storm Drain took the attack!
            changeeffect = 2
            break
          end
        end
      end

      # Cacophony here, considers Hidden Power as Normal
      if targets.length == 1 && movetypes.include?(:SOUND) && target.ability != :ORN_CACOPHONY
        for i in priority # use Pokémon earliest in priority
          next if i.index == user.index || i.isFainted?

          if i.ability == :ORN_CACOPHONY && !i.moldbroken
            target = i # X's Storm Drain took the attack!
            changeeffect = 2
            break
          end
        end
      end

      # Change target to user of Follow Me (overrides Magic Coat
      # because check for Magic Coat below uses this target)
      if [:SingleNonUser, :SingleOpposing, :RandomOpposing, :OppositeOpposing, :DragonDarts].include?(targetchoices)
        for i in priority # use Pokémon latest in priority
          next if !pbIsOpposing?(i.index) || i.isFainted?

          if i.effects[:FollowMe] || i.effects[:RagePowder]
            unless (i.effects[:RagePowder] && (self.ability == :OVERCOAT || self.hasType?(:GRASS) || self.hasWorkingItem(:SAFETYGOGGLES))) # change target to this
              target = i
              changeeffect = 0
            end
          end
        end
      end
    end
    # TODO: Pressure here is incorrect if Magic Coat redirects target
    if target.ability == (:PRESSURE)
      pressuredmove = (basemove.zmove && !user.zmoves.nil? && user.zmoves.include?(basemove)) ? user.moves[user.zmoves.index(basemove)] : basemove
      pbReducePP(pressuredmove) # Reduce PP
      if @battle.FE == :DIMENSIONAL || @battle.FE == :DEEPEARTH
        pbReducePP(pressuredmove)
      end
    end
    # Change user to user of Snatch
    if !basemove.zmove && basemove.canSnatch?
      for i in priority
        if i.effects[:Snatch]
          @battle.pbDisplay(_INTL("{1} Snatched {2}'s move!",i.pbThis,user.pbThis(true)))
          i.effects[:Snatch]=false
          target=user
          user=i
          # Snatch's PP is reduced if old user has Pressure
          userchoice=@battle.choices[user.index][1]
          if target.ability == (:PRESSURE) && userchoice>=0
            pressuremove=user.moves[userchoice]
            pbSetPP(pressuremove,pressuremove.pp-1) if pressuremove.pp>0
            if @battle.FE == :DIMENSIONAL || @battle.FE == :DEEPEARTH
              pressuremove=user.moves[userchoice]
              pbSetPP(pressuremove,pressuremove.pp-1) if pressuremove.pp>0
            end
          end
        end
      end
    end

    statusMoveProtection = false
    if basemove.canProtect?
      statusMoveProtection = (target.pbOwnSide.effects[:QuickGuard] && basemove.priorityCheck(user) > 0) ||
                             (target.pbOwnSide.effects[:WideGuard] && [:AllOpposing, :AllNonUsers].include?(basemove.target)) ||
                             [:Protect, :BanefulBunker, :SpikyShield].include?(target.effects[:Protect]) ||
                             (target.effects[:Protect] == :KingsShield && [:FAIRYTALE, :CHESS].include?(@battle.FE)) ||
                             (target.effects[:Protect] == :Obstruct && [:DIMENSIONAL, :CHESS].include?(@battle.FE))
    end
    statusMoveProtection = true if target.pbOwnSide.effects[:CraftyShield]
    statusMoveProtection = false if target.effects[:ProtectNegation]

    userandtarget[0]=user
    userandtarget[1]=target
    if target.ability == (:SOUNDPROOF) && basemove.isSoundBased? &&
       basemove.function!=0x19 &&   # Heal Bell handled elsewhere
       basemove.function!=0xE5 &&   # Perish Song handled elsewhere
       !(target.moldbroken)
      @battle.pbDisplay(_INTL("{1}'s {2} blocks {3}!",target.pbThis,
         getAbilityName(target.ability),basemove.name))
      return false
    end
    if basemove.canMagicCoat? && target.effects[:MagicCoat] && !statusMoveProtection
      # switch user and target
      changeeffect=3
      target.effects[:MagicCoat]=false
      user, target = target, user

      # Magic Coat's PP is reduced if old user has Pressure
      userchoice = @battle.choices[user.index][1]
      if target.ability == :PRESSURE && userchoice >= 0
        pressuremove = user.moves[userchoice]
        pbSetPP(pressuremove, pressuremove.pp - 1) if pressuremove.pp > 0
        if @battle.FE == :DIMENSIONAL || @battle.FE == :DEEPEARTH
          pressuremove = user.moves[userchoice]
          pbSetPP(pressuremove, pressuremove.pp - 1) if pressuremove.pp > 0
        end
      end
    end
    if !user.effects[:MagicBounced] && basemove.canMagicCoat? && target.ability == :MAGICBOUNCE && !target.moldbroken &&
       !PBStuff::TWOTURNMOVE.include?(target.effects[:TwoTurnAttack]) && changeeffect != 3 && !statusMoveProtection
      target.effects[:MagicBounced] = true
      target.effects[:BouncedMove] = basemove
    end
    if changeeffect == 1
      @battle.pbDisplay(_INTL("{1}'s Lightning Rod took the move!", target.pbThis))
    elsif changeeffect == 2
      @battle.pbDisplay(_INTL("{1}'s Storm Drain took the move!", target.pbThis))
    elsif changeeffect == 3
      # Target refers to the move's old user
      @battle.pbDisplay(_INTL("{1}'s {2} was bounced back by Magic Coat!", user.pbThis, basemove.name))
    end
    userandtarget[0] = user
    userandtarget[1] = target
    return true
  end
end

class PokeBattle_Battle
  def pbPriority(ignorequickclaw = true, megacalc = false)
    return @priority if @usepriority && !megacalc # use stored priority if round isn't over yet (best ged rid of this in gen 8)

    @priority.clear
    priorityarray = []
    quickclawarray = [0, 0, 0, 0]
    # -Move priority take precedence(stored as priorityarray[i][0])
    # -Then Items  (stored as priorityarray[i][1])
    # -Then speed (stored as priorityarray[i][2]) (trick room is applied by just making speed negative.)
    # -The last element is just the battler index (which is otherwise lost when sorting)
    for i in 0..3
      priorityarray[i] = [0, 0, 0, i] # initializes the array and stores the battler index

      # Move priority
      pri = 0
      if @choices[i][0] == :switch || @battle.switchedOut[i] # If switching or has switched
        pri = 12
      end
      if @choices[i][0] == :item # Used item
        pri = 11
      end
      if @choices[i][0] == :move # Is a move
        pri = @choices[i][2].priority # Base move priority
        pri -= 1 if @battle.FE == :DEEPEARTH && @choices[i][2].move == :COREENFORCER
        pri += 1 if [:ORN_POUNCE,:ORN_LEADERSHIP].include?(battlers[i].ability) && battlers[i].turncount == 1
        pri += 1 if @field.effect == :CHESS && @battlers[i].pokemon && @battlers[i].pokemon.piece == :KING
        pri += 1 if @battlers[i].ability == :PRANKSTER && @choices[i][2].basedamage == 0 && @battlers[i].effects[:TwoTurnAttack] == 0 # Is status move
        pri += 1 if @battlers[i].ability == :GALEWINGS && @choices[i][2].type == :FLYING && (@battlers[i].hp == @battlers[i].totalhp || ((@field.effect == :MOUNTAIN || @field.effect == :SNOWYMOUNTAIN) && pbWeather == :STRONGWINDS))
        pri += 1 if @choices[i][2].move == :GRASSYGLIDE && (@field.effect == :GRASSY || @battle.state.effects[:GRASSY] > 0)
        pri += 1 if @choices[i][2].move == :QUASH && @field.effect == :DIMENSIONAL
        pri += 1 if @choices[i][2].basedamage != 0 && @battlers[i].crested == :FERALIGATR && @battlers[i].turncount == 1 # Feraligatr Crest
        pri += 3 if @battlers[i].ability == :TRIAGE && PBStuff::HEALFUNCTIONS.include?(@choices[i][2].function)
        pri = -2 if @battlers[i].ability == :MYCELIUMMIGHT && @choices[i][2].basedamage == 0 && @battlers[i].effects[:TwoTurnAttack] == 0 # Is status move # Gen 9 Mod - Added Mycelium Might
      end
      priorityarray[i][0] = pri

      # Item/stall priority (all items overwrite stall priority)
      priorityarray[i][1] = -1 if @battlers[i].ability == :STALL
      if !ignorequickclaw && @choices[i][0] == :move # Is a move
        if @battlers[i].ability == :QUICKDRAW && pbRandom(100) < 30
          priorityarray[i][1] = 1
          quickclawarray[i] = :QUICKDRAW
        elsif @battlers[i].itemWorks? && @battlers[i].item == :QUICKCLAW && pbRandom(100) < 20
          priorityarray[i][1] = 1
          quickclawarray[i] = :QUICKCLAW
        elsif @battlers[i].custap
          priorityarray[i][1] = 1
          quickclawarray[i] = :CUSTAPBERRY
        end
      end
      priorityarray[i][1] = -2 if (@battlers[i].itemWorks? && (@battlers[i].item == :LAGGINGTAIL || @battlers[i].item == :FULLINCENSE))

      # speed priority
      priorityarray[i][2] = @battlers[i].pbSpeed if @trickroom == 0
      priorityarray[i][2] = -@battlers[i].pbSpeed if @trickroom > 0

    end
    priorityarray.sort!

    # Speed ties. Only works correctly if two pokemon speed tie
    for i in 0..2
      for j in (i + 1)..3
        if priorityarray[i][0] == priorityarray[j][0] && priorityarray[i][1] == priorityarray[j][1] && priorityarray[i][2] == priorityarray[j][2]
          if pbRandom(2) == pbTieBreak
            priorityarray[i], priorityarray[j] = priorityarray[j], priorityarray[i]
          end
        end
      end
    end
    priorityarray.reverse!

    # Quick claw battle message
    for i in 0..3
      battler = @battlers[priorityarray[i][3]]
      @priority[i] = battler
      if (battler.ability == :QUICKDRAW) && quickclawarray[priorityarray[i][3]] == :QUICKDRAW
        if priorityarray[i][1] == 1 && !ignorequickclaw
          battler.effects[:QuickDrawSnipe] if @battle.FE == :COLOSSEUM
          pbDisplayBrief(_INTL("{1}'s Quick Draw let it move first!", battler.pbThis))
        end
      elsif (battler.itemWorks? && battler.item == :QUICKCLAW) && quickclawarray[priorityarray[i][3]] == :QUICKCLAW
        pbDisplayBrief(_INTL("{1}'s Quick Claw let it move first!", battler.pbThis)) if priorityarray[i][1] == 1 && !ignorequickclaw
      end
    end

    @usepriority = true
    return @priority
  end
end
