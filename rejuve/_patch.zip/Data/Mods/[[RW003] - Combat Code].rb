# Superclass for moves which apply an effect to every Pokemon on the field.
class PokeBattle_AllTargetMove < PokeBattle_Move
  def priorityBlockedForAllTargetMoves?(attacker)
    # Priority blocking abilities by the opponent prevent certain moves from going through on ALL Pokemon if used via Prankster
    @battle.battlers.each do |battler|
      if battler != attacker && battler != attacker.pbPartner
        prior_block = ([:ORN_NOBILITY,:QUEENLYMAJESTY,:DAZZLING].include?(battler.ability) || (@battle.FE == :STARLIGHT && battler.ability == :MIRRORARMOR)) ? true : false
        if !battler.moldbroken && prior_block
          if priorityCheck(attacker) > 0 && @battle.choices[attacker.index][2] == self # && !flags[:instructed]
            @battle.pbDisplay(_INTL("{1} cannot use {2}!", attacker.pbThis, self.name))
            return true
          end
        end
      end
    end
    return false
  end
end

## Manual Overwrites because method cannot be Aliased ##
class PokeBattle_Move
  def pbType(attacker, type = @type)
    case @battle.FE
      when :ASHENBEACH        then type = :FIGHTING   if @move == :STRENGTH
      when :GLITCH            then type = :NORMAL     if Glitchtypes.include?(type)
      when :MURKWATERSURFACE  then type = :WATER      if [:MUDSLAP, :MUDBOMB, :MUDBARRAGE, :MUDSHOT, :THOUSANDWAVES].include?(@move)
      when :FAIRYTALE         then type = :STEEL      if [:SACREDSWORD, :CUT, :SLASH, :SECRETSWORD].include?(@move)
      when :STARLIGHT         then type = :FAIRY      if !Rejuv && [:SOLARBEAM, :SOLARBLADE].include?(@move)
      when :DIMENSIONAL       then type = :DARK       if @move == :RAGE
      when :FROZENDIMENSION   then type = :DARK       if @move == :RAGE
      when :DRAGONSDEN        then type = :ROCK       if Rejuv && [:ROCKCLIMB, :STRENGTH].include?(@move)
      when :DEEPEARTH         then type = :GROUND     if @move == :TOPSYTURVY
    end
    if !PBStuff::ZMOVES.include?(@move)
      case attacker.ability
        when :ORN_BLACKLIGHT then type = :DARK   if type == :LIGHT
        when :ORN_WHITEOUT   then type = :LIGHT  if type == :DARK
        when :ORN_DARKMATTER then type = :COSMIC if type == :NORMAL
        when :NORMALIZE   then type = :NORMAL
        when :PIXILATE    then type = :FAIRY    if type == :NORMAL && @battle.FE != :GLITCH
        when :AERILATE    then type = :FLYING   if type == :NORMAL
        when :GALVANIZE   then type = :ELECTRIC if type == :NORMAL
        when :REFRIGERATE then type = :ICE      if type == :NORMAL
        when :DUSKILATE   then type = :DARK     if type == :NORMAL && @battle.FE != :GLITCH
        when :LIQUIDVOICE then type = @battle.FE == :ICY ? :ICE : :WATER if isSoundBased?
      end
    end
    case attacker.crested
      when :SIMISEAR  then type = :WATER    if type == :NORMAL
      when :SIMIPOUR  then type = :GRASS    if type == :NORMAL
      when :SIMISAGE  then type = :FIRE     if type == :NORMAL
      when :LUXRAY    then type = :ELECTRIC if type == :NORMAL
      when :SAWSBUCK
        case attacker.form
          when 0  then type = :WATER  if type == :NORMAL
          when 1  then type = :FIRE   if type == :NORMAL
          when 2  then type = :GROUND if type == :NORMAL
          when 3  then type = :ICE    if type == :NORMAL
        end
    end
    if attacker.effects[:Electrify] || (type == :NORMAL && @battle.state.effects[:IonDeluge])
      type = :ELECTRIC
    end
    return type
  end

  def pbCalcDamage(attacker, opponent, hitnum: 0)
    opponent.damagestate.critical = false
    opponent.damagestate.typemod = 0
    opponent.damagestate.calcdamage = 0
    basedmg = @basedamage # From PBS file
    basedmg = [attacker.happiness, 250].min if attacker.crested == :LUVDISC && basedmg != 0
    basedmg = pbBaseDamage(basedmg, attacker, opponent) # Some function codes alter base power
    return 0 if basedmg == 0

    basedmg = basedmg * 0.3 if attacker.crested == :CINCCINO && !pbIsMultiHit

    damage = 1.0 # variable for overall damage, defined early due to spread damaage modifiers, only used later
    # Multi-targeting attacks
    if pbTargetsAll?(attacker) || attacker.midwayThroughMove
      if attacker.pokemon.piece == :KNIGHT && battle.FE == :CHESS && attacker.pbTarget(self) == :AllOpposing
        @battle.pbDisplay(_INTL("The knight forked the opponents!")) if !attacker.midwayThroughMove
        damage *= 1.25
      else
        damage *= 0.75
      end
      attacker.midwayThroughMove = true
    end

    # Prevent third dart in case first dart killed an opponent in doubles.
    attacker.midwayThroughMove = true if attacker.pbTarget(self) == :DragonDarts

    # Type effectiveness
    type = pbType(attacker)
    typemod = pbTypeModMessages(type, attacker, opponent)
    opponent.damagestate.typemod = typemod
    if typemod == 0
      opponent.damagestate.calcdamage = 0
      opponent.damagestate.critical = false
      return 0
    end

    critchance = pbCritRate?(attacker, opponent)
    if critchance >= 0
      ratios = [24, 8, 2, 1]
      opponent.damagestate.critical = @battle.pbRandom(ratios[critchance]) == 0
    end
    ##### Calcuate base power of move #####

    basemult = 1.0
    # classic prep stuff
    attitemworks = attacker.itemWorks?(true)
    #oppitemworks = opponent.itemWorks?(true)
    case attacker.ability
      when :TECHNICIAN
        if basedmg <= 60
          basemult *= 1.5
        elsif (@battle.FE == :FACTORY || @battle.ProgressiveFieldCheck(PBFields::CONCERT)) && basedmg <= 80
          basemult *= 1.5
        end
      when :STRONGJAW     then basemult *= 1.5 if PBStuff::BITEMOVE.include?(@move)
      when :SHARPNESS     then basemult *= 1.5 if sharpMove?
      when :TRUESHOT      then basemult *= 1.3 if PBStuff::BULLETMOVE.include?(@move)
      when :TOUGHCLAWS    then basemult *= 1.3 if contactMove?
      when :IRONFIST
        if @battle.FE == :CROWD
          basemult *= 1.2 if punchMove?
        else
          basemult *= 1.2 if punchMove?
        end
      when :RECKLESS      then basemult *= 1.2 if @recoil > 0 || [0x130, 0x10B, 0x506].include?(@function) # Shadow End, High Jump Kick, Axe Kick
      when :FLAREBOOST    then basemult *= 1.5 if (attacker.status == :BURN || @battle.FE == :BURNING || @battle.FE == :VOLCANIC || @battle.FE == :INFERNAL) && pbIsSpecial?(type) && @battle.FE != :FROZENDIMENSION
      when :TOXICBOOST
        if (attacker.status == :POISON || @battle.FE == :CORROSIVE || @battle.FE == :CORROSIVEMIST || @battle.FE == :WASTELAND || @battle.FE == :MURKWATERSURFACE) && pbIsPhysical?(type)
          if @battle.FE == :CORRUPTED
            basemult *= 2.0
          else
            basemult *= 1.5
          end
        end
      when :PUNKROCK
        if isSoundBased?
          case @battle.FE
            when :BIGTOP then basemult *= 1.5
            when :CAVE then basemult *= 1.5
            else
              basemult *= 1.3
          end
        end
      when :RIVALRY       then basemult *= attacker.gender == opponent.gender ? 1.25 : 0.75 if attacker.gender != 2
      when :MEGALAUNCHER  then basemult *= 1.5 if [:AURASPHERE, :DRAGONPULSE, :DARKPULSE, :WATERPULSE, :ORIGINPULSE, :TERRAINPULSE].include?(@move)
      when :SANDFORCE     then basemult *= 1.3 if (@battle.pbWeather == :SANDSTORM || @battle.FE == :DESERT || @battle.FE == :ASHENBEACH) && (type == :ROCK || type == :GROUND || type == :STEEL)
      when :ANALYTIC      then basemult *= 1.3 if (@battle.battlers.find_all { |battler| battler && battler.hp > 0 && !battler.hasMovedThisRound? && !@battle.switchedOut[battler.index] }).length == 0
      when :SHEERFORCE    then basemult *= 1.3 if effect > 0 || [0x908].include?(@function) # Gen 9 Mod - Electro Shot needs to be affected by Sheer Force.
      when :AERILATE
        if @type == :NORMAL && type == :FLYING
          case @battle.FE
            when :MOUNTAIN, :SNOWYMOUNTAIN, :SKY then basemult *= 1.5
            else
              basemult *= 1.2
          end
        end
      when :GALVANIZE
        if @type == :NORMAL && type == :ELECTRIC
          case @battle.FE
            when :ELECTERRAIN, :FACTORY then basemult *= 1.5
            when :SHORTCIRCUIT then basemult *= 2
            else
              if @battle.state.effects[:ELECTERRAIN] > 0
                basemult *= 1.5
              else
                basemult *= 1.2
              end
          end
        end
      when :REFRIGERATE
        if @type == :NORMAL && type == :ICE
          case @battle.FE
            when :ICY, :SNOWYMOUNTAIN, :FROZENDIMENSION then basemult *= 1.5
            else
              basemult *= 1.2
          end
        end
      when :PIXILATE
        if @type == :NORMAL && (type == :FAIRY || (type == :NORMAL && @battle.FE == :GLITCH))
          case @battle.FE
            when :MISTY then basemult *= 1.5
            else
              if @battle.state.effects[:MISTY] > 0
                basemult *= 1.5
              else
                basemult *= 1.2
              end
          end
        end
      when :DUSKILATE     then basemult *= 1.2 if @type == :NORMAL && (type == :DARK || (type == :NORMAL && @battle.FE == :GLITCH))
      when :NORMALIZE     then basemult *= 1.2 if !@zmove
      when :TRANSISTOR    then basemult *= 1.5 if type == :ELECTRIC
      when :DRAGONSMAW    then basemult *= 1.5 if type == :DRAGON
      when :STEELWORKER   then basemult *= @battle.FE == :FACTORY ? 2.0 : 1.5 if type == :STEEL
      when :SOLARIDOL     then basemult *= 1.5 if type == :FIRE
      when :LUNARIDOL     then basemult *= 1.5 if type == :ICE
      when :TERAVOLT      then basemult *= 1.5 if (Rejuv && @battle.FE == :ELECTERRAIN && type == :ELECTRIC)
      when :INEXORABLE    then basemult *= 1.3 if type == :DRAGON && (!opponent.hasMovedThisRound? || @battle.switchedOut[opponent.index])
    end
    case opponent.ability
      when :HEATPROOF     then basemult *= 0.5 if !opponent.moldbroken && type == :FIRE
      when :DRYSKIN       then basemult *= 1.25 if !opponent.moldbroken && type == :FIRE
      when :TRANSISTOR    then basemult *= 0.5 if (@battle.FE == :ELECTERRAIN && type == :GROUND) && !opponent.moldbroken
    end
    if attitemworks
      if $cache.items[attacker.item].checkFlag?(:typeboost) == type
        if $cache.items[attacker.item].checkFlag?(:gem)
          basemult *= 1.3
          @battle.pbDisplay(_INTL("The {1} strengthened {2}'s power!", getItemName(attacker.item), self.name)) unless attacker.takegem
          attacker.takegem = true
        else
          basemult *= 1.2
        end
      else
        case attacker.item
          when :MUSCLEBAND then basemult *= 1.1 if pbIsPhysical?(type)
          when :WISEGLASSES then basemult *= 1.1 if pbIsSpecial?(type)
          when :LUSTROUSORB then basemult *= 1.2 if attacker.pokemon.species == :PALKIA && (type == :DRAGON || type == :WATER)
          when :ADAMANTORB then basemult *= 1.2 if attacker.pokemon.species == :DIALGA && (type == :DRAGON || type == :STEEL)
          when :GRISEOUSORB then basemult *= 1.2 if attacker.pokemon.species == :GIRATINA && (type == :DRAGON || type == :GHOST)
          when :SOULDEW then basemult *= 1.2 if (attacker.pokemon.species == :LATIAS || attacker.pokemon.species == :LATIOS) && (type == :DRAGON || type == :PSYCHIC)
          # Gen 9 Mod - Ogerpon's Masks give it a 1.2x boost to all damaging moves it uses.
          when :WELLSPRINGMASK, :HEARTHFLAMEMASK, :CORNERSTONEMASK then basemult *= 1.2 if (attacker.pokemon.species == :OGERPON)
        end
      end
    end
    basemult = pbBaseDamageMultiplier(basemult, attacker, opponent)
    # standard crest damage multipliers
    case attacker.crested
      when :FERALIGATR then basemult *= 1.5 if PBStuff::BITEMOVE.include?(@move)
      when :CLAYDOL then basemult *= 1.5 if isBeamMove?
      when :DRUDDIGON then basemult *= 1.3 if type == :DRAGON || type == :FIRE
      when :BOLTUND then basemult *= 1.5 if PBStuff::BITEMOVE.include?(@move) && (!opponent.hasMovedThisRound? || @battle.switchedOut[opponent.index])
      when :FEAROW then basemult *= 1.5 if PBStuff::STABBINGMOVE.include?(@move)
      when :DUSKNOIR then basemult *= 1.5 if basedmg <= 60 || ((@battle.FE == :FACTORY || @battle.ProgressiveFieldCheck(PBFields::CONCERT)) && basedmg <= 80)
      when :CRABOMINABLE then basemult *= 1.5 if attacker.lastHPLost > 0
      when :AMPHAROS then basemult *= attacker.hasType?(type) ? 1.2 : 1.5 if attacker.moves[0] == self
      when :LUXRAY then basemult *= 1.2 if @type == :NORMAL && type == :ELECTRIC
      when :SAWSBUCK
        case attacker.form
          when 0 then basemult *= 1.2 if @type == :NORMAL && type == :WATER
          when 1 then basemult *= 1.2 if @type == :NORMAL && type == :FIRE
          when 2 then basemult *= 1.2 if @type == :NORMAL && type == :GROUND
          when 3 then basemult *= 1.2 if @type == :NORMAL && type == :ICE
        end
    end
    #type mods
    case type
      when :FIRE then basemult *= 0.33 if @battle.state.effects[:WaterSport] > 0
      when :ELECTRIC
        basemult *= 0.33 if @battle.state.effects[:MudSport] > 0
        # Gen 9 Mod - Charge lasts until the user uses an electric move.
        basemult *= 2.0 if attacker.effects[:Charge] == true
        attacker.effects[:Charge] = false
    end
    if type == :DARK && @battle.pbCheckGlobalAbility(:DARKAURA)
      auramult = 1.33
      case @battle.FE
        when :DARKNESS1 then auramult = 1.4
        when :DARKNESS2 then auramult = 1.5
        when :DARKNESS3 then auramult = 1.66
      end
      basemult *= @battle.pbCheckGlobalAbility(:AURABREAK) ? 2 - auramult : auramult
    end
    if type == :FAIRY && @battle.pbCheckGlobalAbility(:FAIRYAURA)
      auramult = 1.33
      case @battle.FE
        when :DARKNESS1 then auramult = 1.3
        when :DARKNESS2 then auramult = 1.2
        when :DARKNESS3 then auramult = 1.1
      end
      basemult *= @battle.pbCheckGlobalAbility(:AURABREAK) ? 2 - auramult : auramult
    end
    basemult *= 1.5 if attacker.effects[:HelpingHand]
    basemult *= 2.0 if opponent.effects[:Minimize] && @move == :MALICIOUSMOONSAULT # Minimize for z-move
    # Specific Field Effects
    if @battle.field.isFieldEffect?
      fieldmult = moveFieldBoost
      if fieldmult != 1
        basemult *= fieldmult
        fieldmessage = moveFieldMessage
        if fieldmessage && !@fieldmessageshown
          if [:LIGHTTHATBURNSTHESKY, :ICEHAMMER, :HAMMERARM, :CRABHAMMER].include?(@move) # some moves have a {1} in them and we gotta deal.
            @battle.pbDisplay(_INTL(fieldmessage, attacker.pbThis))
          elsif [:SMACKDOWN, :THOUSANDARROWS, :ROCKSLIDE, :VITALTHROW, :CIRCLETHROW, :STORMTHROW, :DOOMDUMMY, :BLACKHOLEECLIPSE, :TECTONICRAGE, :CONTINENTALCRUSH, :WHIRLWIND, :CUT].include?(@move)
            @battle.pbDisplay(_INTL(fieldmessage, opponent.pbThis))
          else
            @battle.pbDisplay(_INTL(fieldmessage))
          end
          @fieldmessageshown = true
        end
      end
    end
    case @battle.FE
      when :CHESS
        if (CHESSMOVES).include?(@move)
          basemult*=0.5 if [:ADAPTABILITY,:ANTICIPATION,:SYNCHRONIZE,:TELEPATHY].include?(opponent.ability)
          basemult*=2.0 if [:OBLIVIOUS,:KLUTZ,:UNAWARE,:SIMPLE].include?(opponent.ability) || opponent.effects[:Confusion]>0 || (Rejuv && opponent.ability == :DEFEATIST)
          @battle.pbDisplay("The chess piece slammed forward!") if !@fieldmessageshown
          @fieldmessageshown = true
        end
        # Queen piece boost
        if attacker.pokemon.piece==:QUEEN || attacker.ability == :QUEENLYMAJESTY
          basemult*=1.5
          if attacker.pokemon.piece==:QUEEN
            @battle.pbDisplay("The Queen is dominating the board!")  && !@fieldmessageshown
            @fieldmessageshown = true
          end
        end

        #Knight piece boost
        if attacker.pokemon.piece==:KNIGHT && opponent.pokemon.piece==:QUEEN
          basemult=(basemult*3.0).round
          @battle.pbDisplay("An unblockable attack on the Queen!") if !@fieldmessageshown
          @fieldmessageshown = true
        end
      when :BIGTOP
        if ((type == :FIGHTING && pbIsPhysical?(type)) || (STRIKERMOVES).include?(@move)) # Continental Crush
          striker = 1+@battle.pbRandom(14)
          @battle.pbDisplay("WHAMMO!") if !@fieldmessageshown
          @fieldmessageshown = true
          if attacker.ability == :HUGEPOWER || attacker.ability == :GUTS || attacker.ability == :PUREPOWER || attacker.ability == :SHEERFORCE
            if striker >=9
              striker = 15
            else
              striker = 14
            end
          end
          strikermod = attacker.stages[PBStats::ATTACK]
          striker = striker + strikermod
          if striker >= 15
            @battle.pbDisplay("...OVER 9000!!!")
            provimult=3.0
          elsif striker >=13
            @battle.pbDisplay("...POWERFUL!")
            provimult=2.0
          elsif striker >=9
            @battle.pbDisplay("...NICE!")
            provimult=1.5
          elsif striker >=3
            @battle.pbDisplay("...OK!")
            provimult=1
          else
            @battle.pbDisplay("...WEAK!")
            provimult=0.5
          end
          provimult = ((provimult-1.0)/2.0)+1.0 if $game_variables[:DifficultyModes]==1 && !$game_switches[:FieldFrenzy]
          provimult = ((provimult-1.0)*2.0)+1.0 if $game_variables[:DifficultyModes]!=1 && $game_switches[:FieldFrenzy] && provimult > 1
          provimult = provimult/2.0 if $game_variables[:DifficultyModes]!=1 && $game_switches[:FieldFrenzy] && provimult < 1
          basemult*=provimult
        end
        if isSoundBased?
          provimult=1.5
          provimult=1.25 if $game_variables[:DifficultyModes]==1
          provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
          basemult*=provimult
          @battle.pbDisplay("Loud and clear!") if !@fieldmessageshown
          @fieldmessageshown = true
        end
      when :ICY
        if (@priority >= 1 && @basedamage > 0 && contactMove? && attacker.ability != :LONGREACH) || (@move == :FEINT || @move == :ROLLOUT || @move == :DEFENSECURL || @move == :STEAMROLLER || @move == :LUNGE)
          if !attacker.isAirborne?
            if attacker.pbIncreaseStat(PBStats::SPEED, 1, statmessage: false)
              if attacker.ability == :CONTRARY
                @battle.pbDisplay(_INTL("{1} lost momentum on the ice!", attacker.pbThis)) if !@fieldmessageshown
              else
                @battle.pbDisplay(_INTL("{1} gained momentum on the ice!", attacker.pbThis)) if !@fieldmessageshown
              end
              @fieldmessageshown = true
            end
          end
        end
      when :SHORTCIRCUIT
        if type == :ELECTRIC
          damageroll = @battle.field.getRoll(maximize_roll:(@battle.state.effects[:ELECTERRAIN] > 0))
          messageroll = ["Bzzt.", "Bzzapp!" , "Bzt...", "Bzap!", "BZZZAPP!"][PBStuff::SHORTCIRCUITROLLS.index(damageroll)]
          @battle.pbDisplay(messageroll) if !@fieldmessageshown
          damageroll = ((damageroll-1.0)/2.0)+1.0 if $game_variables[:DifficultyModes]==1 && !$game_switches[:FieldFrenzy]
          damageroll = ((damageroll-1.0)*2.0)+1.0 if $game_variables[:DifficultyModes]!=1 && $game_switches[:FieldFrenzy] && damageroll > 1
          damageroll = damageroll/2.0 if $game_variables[:DifficultyModes]!=1 && $game_switches[:FieldFrenzy] && damageroll < 1
          basemult*=damageroll

          @fieldmessageshown = true
        end
      when :CAVE
        if isSoundBased?
          provimult=1.5
          provimult=1.25 if $game_variables[:DifficultyModes]==1
          provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
          basemult*=provimult
          @battle.pbDisplay(_INTL("ECHO-Echo-echo!",opponent.pbThis)) if !@fieldmessageshown
          @fieldmessageshown = true
        end
      when :MOUNTAIN
        if (PBFields::WINDMOVES).include?(@move) && @battle.pbWeather== :STRONGWINDS
          provimult=1.5
          provimult=1.25 if $game_variables[:DifficultyModes]==1
          provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
          basemult*=provimult
          @battle.pbDisplay(_INTL("The wind strengthened the attack!",opponent.pbThis)) if !@fieldmessageshown
          @fieldmessageshown = true
        end
      when :SNOWYMOUNTAIN
        if (PBFields::WINDMOVES).include?(@move) && @battle.pbWeather== :STRONGWINDS
          provimult=1.5
          provimult=1.25 if $game_variables[:DifficultyModes]==1
          provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
          basemult*=provimult
          @battle.pbDisplay(_INTL("The wind strengthened the attack!",opponent.pbThis)) if !@fieldmessageshown
          @fieldmessageshown = true
        end
      when :MIRROR
        if (PBFields::MIRRORMOVES).include?(@move) && opponent.stages[PBStats::EVASION]>0
          provimult=2.0
          provimult=1.5 if $game_variables[:DifficultyModes]==1
          provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
          basemult*=provimult
          @battle.pbDisplay(_INTL("The beam was focused from the reflection!",opponent.pbThis)) if !@fieldmessageshown
          @fieldmessageshown = true
        end
        @battle.field.counter = 0
      when :DEEPEARTH
        if (priorityCheck(attacker) > 0) && @basedamage > 0
          provimult=0.7
          provimult=0.85 if $game_variables[:DifficultyModes]==1
          provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
          basemult*=provimult
          @battle.pbDisplay(_INTL("The intense pull slowed the attack...")) if !@fieldmessageshown
          @fieldmessageshown = true
        end
        if (priorityCheck(attacker) < 0) && @basedamage > 0
          provimult=1.3
          provimult=1.15 if $game_variables[:DifficultyModes]==1
          provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
          basemult*=provimult
          @battle.pbDisplay(_INTL("Slow and heavy!")) if !@fieldmessageshown
          @fieldmessageshown = true
        end
      when :CONCERT1,:CONCERT2,:CONCERT3,:CONCERT4
        if isSoundBased?
          provimult=1.5
          provimult=1.25 if $game_variables[:DifficultyModes]==1
          provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
          basemult*=provimult
          @battle.pbDisplay(_INTL("Loud and clear!")) if !@fieldmessageshown
          @fieldmessageshown = true
        end
      when :DARKNESS3,:DARKNESS2
        if [:LIGHTTHATBURNSTHESKY].include?(@move)
          @battle.pbDisplay(_INTL("One brings Shadow, One brings the Light!")) if !@fieldmessageshown
          @fieldmessageshown = true
        end
    end
    if Rejuv
      for terrain in [:ELECTERRAIN,:GRASSY,:MISTY,:PSYTERRAIN]
        if @battle.state.effects[terrain] > 0
          overlaymult = moveOverlayBoost(terrain)
          if overlaymult != 1
            basemult*=overlaymult
            overlaymessage = moveOverlayMessage(terrain)
            @battle.pbDisplay(_INTL(overlaymessage)) if overlaymessage
          end
        end
      end
    end
    #End S.Field Effects
    ##### Calculate attacker's attack stat #####
    case @function
      when 0x121 # Foul Play
        atk = opponent.attack
        atkstage = opponent.stages[PBStats::ATTACK] + 6
      when 0x184 # Body Press
        atk = attacker.defense
        atkstage = attacker.stages[PBStats::DEFENSE] + 6
      else
        atk = attacker.attack
        atkstage = attacker.stages[PBStats::ATTACK] + 6
    end
    if pbIsSpecial?(type)
      atk = attacker.spatk
      atkstage = attacker.stages[PBStats::SPATK] + 6
      if @function == 0x121 # Foul Play
        atk = opponent.spatk
        atkstage = opponent.stages[PBStats::SPATK] + 6
      elsif @function == 0x1025 # Holy Ward/Scented Shield/Sound Barrier
        atk = opponent.spdef
        atkstage = opponent.stages[PBStats::SPDEF] + 6
      end
      if @battle.FE == :GLITCH
        atk = attacker.getSpecialStat(opponent.ability == :UNAWARE, attacker: true, crit: opponent.damagestate.critical)
        atkstage = 6 # getspecialstat handles unaware
      end
    end
    # Stat-Copy Crests, ala Claydol//Dedenne
    case attacker.crested
      when :CLAYDOL then atkstage = attacker.stages[PBStats::DEFENSE] + 6 if pbIsSpecial?(type)
      when :DEDENNE then atkstage = attacker.stages[PBStats::SPEED] + 6 if !pbIsSpecial?(type)
    end
    if opponent.ability != :UNAWARE || opponent.moldbroken
      atkstage = 6 if opponent.damagestate.critical && atkstage < 6
      atk = (atk * PBStats::StageMul[atkstage]).floor
    end
    if attacker.ability == :HUSTLE && pbIsPhysical?(type)
      atk = [:BACKALLEY, :CITY].include?(@battle.FE) ? (atk * 1.75).round : (atk * 1.5).round
    end
    atkmult = 1.0
    if @battle.FE == :HAUNTED || @battle.FE == :BEWITCHED || @battle.FE == :HOLY || @battle.FE == :PSYTERRAIN || @battle.FE == :DEEPEARTH
      atkmult *= 1.5 if attacker.pbPartner.ability == :POWERSPOT
    else
      atkmult *= 1.3 if attacker.pbPartner.ability == :POWERSPOT
    end
    # pinch abilities
    if (@battle.FE == :BURNING || @battle.FE == :VOLCANIC || @battle.FE == :INFERNAL) && (attacker.ability == :BLAZE && type == :FIRE)
      atkmult *= 1.5
    elsif @battle.FE == :VOLCANICTOP && (attacker.ability == :BLAZE && type == :FIRE) && attacker.effects[:Blazed]
      atkmult *= 1.5
    elsif (@battle.FE == :FOREST || (Rejuv && @battle.FE == :GRASSY)) && (attacker.ability == :OVERGROW && type == :GRASS)
      atkmult *= 1.5
    elsif @battle.FE == :FOREST && (attacker.ability == :SWARM && type == :BUG)
      atkmult *= 1.5
    elsif ((@battle.FE == :WATERSURFACE && !attacker.isAirborne?) || @battle.FE == :UNDERWATER) && (attacker.ability == :TORRENT && type == :WATER)
      atkmult *= 1.5
    elsif @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN) && (attacker.ability == :SWARM && type == :BUG)
      atkmult *= 1.5 if @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN, 1, 2)
      atkmult *= 1.8 if @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN, 3, 4)
      atkmult *= 2.0 if @battle.FE == :FLOWERGARDEN5
    elsif @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN, 2, 5) && (attacker.ability == :OVERGROW && type == :GRASS)
      case @battle.FE
        when :FLOWERGARDEN2 then atkmult *= 1.5 if attacker.hp <= (attacker.totalhp * 0.67).floor
        when :FLOWERGARDEN3 then atkmult *= 1.6
        when :FLOWERGARDEN4 then atkmult *= 1.8
        when :FLOWERGARDEN5 then atkmult *= 2.0
      end
    elsif attacker.hp <= (attacker.totalhp / 3.0).floor
      if (attacker.ability == :OVERGROW && type == :GRASS) || (attacker.ability == :BLAZE && type == :FIRE && @battle.FE != :FROZENDIMENSION) ||
         (attacker.ability == :TORRENT && type == :WATER) || (attacker.ability == :SWARM && type == :BUG)
        atkmult *= 1.5
      end
      # Warden Pinch Abilities #
      ward_combo = [[:ORN_STARSTRUCK,:COSMIC],[:ORN_IRRADIATE,:LIGHT],[:ORN_MAESTRO,:SOUND],[:ORN_SPELLCASTER,:PSYCHIC]]
      for w in 0...ward_combo.length
        atkmult *= 1.5 if attacker.ability == ward_combo[w][0] && type == ward_combo[w][1]
      end
      # Warden Pinch Abilities #
    end
    case attacker.ability
      when :GUTS then atkmult*=1.5 if !attacker.status.nil? && pbIsPhysical?(type)
      when :PLUS, :MINUS
        if pbIsSpecial?(type) && @battle.FE != :GLITCH
          partner=attacker.pbPartner
          if partner.ability == :PLUS || partner.ability == :MINUS
            atkmult*=1.5
          elsif @battle.FE == :SHORTCIRCUIT || (Rejuv && @battle.FE == :ELECTERRAIN) || @battle.state.effects[:ELECTERRAIN] > 0
            atkmult*=1.5
          end
        end
      when :DEFEATIST then atkmult*=0.5 if attacker.hp<=(attacker.totalhp/2.0).floor
      when :HUGEPOWER then atkmult*=2.0 if pbIsPhysical?(type)
      when :PUREPOWER
        if @battle.FE == :PSYTERRAIN || @battle.state.effects[:PSYTERRAIN] > 0
          atkmult*=2.0 if pbIsSpecial?(type)
        else
          atkmult*=2.0 if pbIsPhysical?(type)
        end
      when :SOLARPOWER then atkmult*=1.5 if (@battle.pbWeather== :SUNNYDAY && !(attitemworks && attacker.item == :UTILITYUMBRELLA)) && pbIsSpecial?(type) && (@battle.FE != :GLITCH &&  @battle.FE != :FROZENDIMENSION)
      when :SLOWSTART then atkmult*=0.5 if attacker.turncount<5 && pbIsPhysical?(type) && @battle.FE != :DEEPEARTH
      when :GORILLATACTICS then atkmult*=1.5 if pbIsPhysical?(type)
      when :QUARKDRIVE then atkmult*=1.3 if (attacker.effects[:Quarkdrive][0] == PBStats::ATTACK && pbIsPhysical?(type)) || (attacker.effects[:Quarkdrive][0] == PBStats::SPATK && pbIsSpecial?(type))
      # Gen 9 Mod - Added Protosynthesis, Hadron Engine and Orichalcum Pulse
      when :PROTOSYNTHESIS then atkmult*=1.3 if (attacker.effects[:Protosynthesis][0] == PBStats::ATTACK && pbIsPhysical?(type)) || (attacker.effects[:Protosynthesis][0] == PBStats::SPATK && pbIsSpecial?(type))
      when :ORICHALCUMPULSE then atkmult*=(5461/4096.to_f) if (@battle.pbWeather== :SUNNYDAY && pbIsPhysical?(type)) &&  @battle.FE != :FROZENDIMENSION
      when :HADRONENGINE then atkmult*=(5461/4096.to_f) if ((@battle.FE == :ELECTERRAIN || @battle.state.effects[:ELECTERRAIN] > 0) && pbIsSpecial?(type)) &&  @battle.FE != :FROZENDIMENSION
    end
    # Mid Battle stat multiplying crests; Spiritomb Crest, Castform Crest
    case attacker.crested
      when :CASTFORM then atkmult*=1.5 if attacker.form == 1 && (@battle.pbWeather== :SUNNYDAY && !(attitemworks && attacker.item == :UTILITYUMBRELLA)) && pbIsSpecial?(type) && (@battle.FE != :GLITCH &&  @battle.FE != :FROZENDIMENSION)
      when :SPIRITOMB
          allyfainted = attacker.pbFaintedPokemonCount
          modifier = (allyfainted * 0.2) + 1.0
          atkmult=(atkmult*modifier).round
    end
    # Gen 9 Mod - Added Supreme Overlord
    if attacker.ability == :SUPREMEOVERLORD
      allyfainted = attacker.effects[:SupremeOverlord]
      modifier = (allyfainted * 0.1) + 1.0
      atkmult *= modifier
    end
    if ((@battle.pbWeather== :SUNNYDAY && !(attitemworks && attacker.item == :UTILITYUMBRELLA)) || @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN) || @battle.FE == :BEWITCHED) && pbIsPhysical?(type)
      atkmult*=1.5 if attacker.ability == :FLOWERGIFT || attacker.pbPartner.ability == :FLOWERGIFT
    end
    if (@battle.pbWeather== :SUNNYDAY) && pbIsPhysical?(type)
      atkmult*=1.5 if attacker.ability == :SOLARIDOL
    end
    if (@battle.pbWeather== :HAIL) && pbIsSpecial?(type)
      atkmult*=1.5 if attacker.ability == :LUNARIDOL
    end
    if attacker.pbPartner.ability == (:BATTERY) && pbIsSpecial?(type) && @battle.FE != :GLITCH
      if Rejuv && @battle.FE == :ELECTERRAIN
        atkmult*=1.5
      else
        atkmult*=1.3
      end
    end
    if @battle.FE == :FAIRYTALE
      atkmult*=2.0 if (attacker.pbPartner.ability == :STEELYSPIRIT || attacker.ability == :STEELYSPIRIT) && type == :STEEL
    else
      atkmult*=1.5 if (attacker.pbPartner.ability == :STEELYSPIRIT || attacker.ability == :STEELYSPIRIT) && type == :STEEL
    end
    atkmult*=1.5 if attacker.effects[:FlashFire] && type == :FIRE && @battle.FE != :FROZENDIMENSION

    if attitemworks
      case attacker.item
        when :THICKCLUB then atkmult*=2.0 if attacker.pokemon.species == :CUBONE || attacker.pokemon.species == :MAROWAK && pbIsPhysical?(type)
        when :DEEPSEATOOTH then atkmult*=2.0 if attacker.pokemon.species == :CLAMPERL && pbIsSpecial?(type) && @battle.FE != :GLITCH
        when :LIGHTBALL then atkmult*=2.0 if attacker.pokemon.species == :PIKACHU && @battle.FE != :GLITCH
        when :CHOICEBAND then atkmult*=1.5 if pbIsPhysical?(type)
        when :CHOICESPECS then atkmult*=1.5 if pbIsSpecial?(type) && @battle.FE != :GLITCH
        # Gen 9 Mod - Added Punching Glove
        when :PUNCHINGGLOVE then basemult*=1.1 if punchMove?
      end
    end
    if @battle.FE != :INDOOR
      if @battle.FE == :STARLIGHT || @battle.FE == :NEWWORLD
        if attacker.ability == :VICTORYSTAR
          atkmult*=1.5
        end
        partner=attacker.pbPartner
        if partner && partner.ability == :VICTORYSTAR
          atkmult*=1.5
        end
      end
      if @battle.FE == :WATERSURFACE
        atkmult*=1.5 if attacker.ability == :PROPELLERTAIL && @priority >= 1 && @basedamage > 0
      end
      if @battle.FE == :UNDERWATER
        atkmult*=0.5 if (!Rejuv || !attacker.hasType?(:WATER)) && pbIsPhysical?(type) && type != :WATER && attacker.ability != :STEELWORKER && attacker.ability != :SWIFTSWIM
        atkmult*=1.5 if attacker.ability == :PROPELLERTAIL && @priority >= 1 && @basedamage > 0
      end
      if Rejuv && @battle.FE == :CHESS
        atkmult*=1.2 if attacker.ability == :GORILLATACTICS || attacker.ability == :RECKLESS
        atkmult*=1.2 if attacker.ability == :ILLUSION && attacker.effects[:Illusion]!=nil
        if attacker.ability == :COMPETITIVE
          frac = (1.0*attacker.hp)/(1.0*attacker.totalhp)
          multiplier = 1.0
          multiplier += ((1.0-frac)/0.8)
          if frac < 0.2
            multiplier = 2.0
          end
          atkmult=(atkmult*multiplier)
        end
      end
      case attacker.ability
        when :QUEENLYMAJESTY then atkmult*=1.5 if @battle.FE == :FAIRYTALE
        when :LONGREACH then atkmult*=1.5 if (@battle.FE == :MOUNTAIN || @battle.FE == :SNOWYMOUNTAIN || @battle.FE == :SKY)
        when :CORROSION then atkmult*=1.5 if (@battle.FE == :CORROSIVE || @battle.FE == :CORROSIVEMIST || @battle.FE == :CORRUPTED)
        when :SKILLLINK then atkmult*=1.2 if (@battle.FE == :COLOSSEUM && (@function == 0xC0 || @function == 0x307 || (attacker.crested == :CINCCINO && !pbIsMultiHit))) #0xC0: 2-5 hits; 0x307: Scale Shot
      end
    end
    atkmult*=0.5 if opponent.ability == :THICKFAT && (type == :ICE || type == :FIRE) && !(opponent.moldbroken)

    ##### Calculate opponent's defense stat #####
    defense = opponent.defense
    defstage = opponent.stages[PBStats::DEFENSE] + 6
    # TODO: Wonder Room should apply around here

    applysandstorm = false
    if pbHitsSpecialStat?(type)
      defense = opponent.spdef
      defstage = opponent.stages[PBStats::SPDEF] + 6
      applysandstorm = true
      if @battle.FE == :GLITCH
        defense = opponent.getSpecialStat(attacker.ability == :UNAWARE, attacker: false, crit: opponent.damagestate.critical)
        defstage = 6 # getspecialstat handles unaware
        applysandstorm = false # getSpecialStat handles sandstorm
      end
    end
    if attacker.ability != :UNAWARE
      defstage = 6 if @function == 0xA9 # Chip Away (ignore stat stages)
      defstage = 6 if opponent.damagestate.critical && defstage > 6
      defense = (defense * PBStats::StageMul[defstage]).floor
    end
    if @battle.pbWeather == :SANDSTORM && opponent.hasType?(:ROCK) && applysandstorm
      defense = (defense * 1.5).round
    end
    defmult = 1.0
    defmult *= 0.5 if @battle.FE == :GLITCH && @function == 0xE0
    defmult *= 0.5 if attacker.crested == :ELECTRODE && pbHitsPhysicalStat?(type)
    # Field Effect defense boost
    defmult *= fieldDefenseBoost(type, opponent)

    # Abilities defense boost
    case opponent.ability
      when :ICESCALES then defmult *= 2.0 if pbIsSpecial?(type) && !opponent.moldbroken
      when :MARVELSCALE then defmult *= 1.5 if (pbIsPhysical?(type) && (!opponent.status.nil? || ([:MISTY, :RAINBOW, :FAIRYTALE, :DRAGONSDEN, :STARLIGHT].include?(@battle.FE) || @battle.state.effects[:MISTY] > 0))) && !opponent.moldbroken
      when :GRASSPELT then defmult *= 1.5 if pbIsPhysical?(type) && (@battle.FE == :GRASSY || @battle.FE == :FOREST || @battle.state.effects[:GRASSY] > 0) # Grassy Field
      when :FURCOAT then defmult *= 2.0 if pbIsPhysical?(type) && !opponent.moldbroken
      when :PUNKROCK then defmult *= 2.0 if isSoundBased? && !opponent.moldbroken
      when :QUARKDRIVE then defmult *= 1.3 if (opponent.effects[:Quarkdrive][0] == PBStats::DEFENSE && pbIsPhysical?(type)) || (opponent.effects[:Quarkdrive][0] == PBStats::SPDEF && pbIsSpecial?(type))
      # Gen 9 Mod - Added Protosynthesis
      when :PROTOSYNTHESIS then defmult *= 1.3 if (opponent.effects[:Protosynthesis][0] == PBStats::DEFENSE && pbIsPhysical?(type)) || (opponent.effects[:Protosynthesis][0] == PBStats::SPDEF && pbIsSpecial?(type))
      when :FLUFFY
        defmult *= 2.0 if contactMove? && attacker.ability != :LONGREACH && !opponent.moldbroken
        defmult *= 4.0 if contactMove? && attacker.ability != :LONGREACH && @battle.FE == :CLOUDS && !opponent.moldbroken
        defmult *= 0.5 if type == :FIRE && !opponent.moldbroken
    end
    if ((@battle.pbWeather == :SUNNYDAY && !opponent.hasWorkingItem(:UTILITYUMBRELLA)) || @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN) || @battle.FE == :BEWITCHED) && !opponent.moldbroken && pbIsSpecial?(type)
      if opponent.ability == :FLOWERGIFT && opponent.species == :CHERRIM
        defmult *= 1.5
      end
      if opponent.pbPartner.ability == :FLOWERGIFT && opponent.pbPartner.species == :CHERRIM
        defmult *= 1.5
      end
    end
    # Item defense boost
    if opponent.hasWorkingItem(:EVIOLITE) && !(@battle.FE == :GLITCH && pbIsSpecial?(type))
      evos = pbGetEvolvedFormData(opponent.pokemon.species, opponent.pokemon)
      if evos && evos.length > 0
        defmult *= 1.5
      end
    end
    if opponent.item == :PIKANIUMZ && opponent.pokemon.species == :PIKACHU && !(@battle.FE == :GLITCH && pbIsSpecial?(type))
      defmult *= 1.5
    end
    if opponent.item == :LIGHTBALL && opponent.pokemon.species == :PIKACHU && !(@battle.FE == :GLITCH && pbIsSpecial?(type))
      defmult *= 1.5
    end
    if opponent.hasWorkingItem(:ASSAULTVEST) && pbIsSpecial?(type) && @battle.FE != :GLITCH
      defmult *= 1.5
    end
    if opponent.hasWorkingItem(:DEEPSEASCALE) && @battle.FE != :GLITCH && opponent.pokemon.species == :CLAMPERL && pbIsSpecial?(type)
      defmult *= 2.0
    end
    if opponent.hasWorkingItem(:METALPOWDER) && opponent.pokemon.species == :DITTO && !opponent.effects[:Transform] && pbIsPhysical?(type)
      defmult *= 2.0
    end

    # General damage modifiers
    # variable "damage" used from here on out
    # damage at this point is generaly 1 ; unless it's a spread move in which case it's 0.75 normally or 1.25 for knight pieces on chess

    # Field Effects
    fieldBoost = typeFieldBoost(type,attacker,opponent)
    overlayBoost, overlay = typeOverlayBoost(type,attacker,opponent)
    if fieldBoost != 1 || overlayBoost != 1
      if fieldBoost > 1 && overlayBoost > 1
        boost = [fieldBoost,overlayBoost].max
        if $game_variables[:DifficultyModes]==1 && !$game_switches[:FieldFrenzy]
          boost = 1.25 if boost < 1.25
        elsif $game_variables[:DifficultyModes]!=1 && $game_switches[:FieldFrenzy]
          boost = 2.0 if boost < 2.0
        else
          boost = 1.5 if boost < 1.5
        end
      else
        boost = fieldBoost*overlayBoost
      end
      damage*=boost
      fieldmessage = typeFieldMessage(type) if fieldBoost != 1
      overlaymessage = typeOverlayMessage(type,overlay) if overlay
      if overlaymessage && !fieldmessage
        @battle.pbDisplay(_INTL(overlaymessage)) if !@fieldmessageshown_type
      else
        @battle.pbDisplay(_INTL(fieldmessage)) if fieldmessage && !@fieldmessageshown_type
      end
      @fieldmessageshown_type = true
    end
    case @battle.FE
      when :MOUNTAIN,:SNOWYMOUNTAIN
        if type == :FLYING && !pbIsPhysical?(type) && @battle.pbWeather== :STRONGWINDS
          provimult=1.5
          provimult=1.25 if $game_variables[:DifficultyModes]==1
          provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
          damage*=provimult
        end
      when :DEEPEARTH
        if type == :GROUND && opponent.hasType?(:GROUND)
          provimult=0.5
          provimult=0.75 if $game_variables[:DifficultyModes]==1 && !$game_switches[:FieldFrenzy]
          provimult=0.25 if $game_variables[:DifficultyModes]!=1 && $game_switches[:FieldFrenzy]
          damage*=provimult
          @battle.pbDisplay(_INTL("The dense earth is difficult to mold...")) if !@fieldmessageshown_type
          @fieldmessageshown_type = true
        end
    end
    case @battle.pbWeather
      when :SUNNYDAY
        if @battle.state.effects[:HarshSunlight] && type == :WATER
          @battle.pbDisplay(_INTL("The Water-type attack evaporated in the harsh sunlight!"))
          @battle.scene.pbUnVanishSprite(attacker) if @function==0xCB #Dive
          return 0
        end
      when :RAINDANCE
        if @battle.state.effects[:HeavyRain] && type == :FIRE
          @battle.pbDisplay(_INTL("The Fire-type attack fizzled out in the heavy rain!"))
          return 0
        end
    end
    # FIELD TRANSFORMATIONS
    fieldmove = @battle.field.moveData(@move)
    if fieldmove && fieldmove[:fieldchange]
      change_conditions = @battle.field.fieldChangeData
      handled = change_conditions[fieldmove[:fieldchange]] ? eval(change_conditions[fieldmove[:fieldchange]]) : true
      #don't continue if conditions to change are not met or if a multistage field changes to a different stage of itself
      if handled  && !(@battle.ProgressiveFieldCheck("All") && (PBFields::CONCERT.include?(fieldmove[:fieldchange]) || PBFields::FLOWERGARDEN.include?(fieldmove[:fieldchange]) || PBFields::DARKNESS.include?(fieldmove[:fieldchange])))
        provimult=1.3
        provimult=1.15 if $game_variables[:DifficultyModes]==1
        provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
        damage*=provimult
      end
    end
    case @battle.FE
      when :FACTORY
        if (@move == :DISCHARGE) || (@move == :OVERDRIVE)
          @battle.setField(:SHORTCIRCUIT)
          @battle.pbDisplay(_INTL("The field shorted out!"))
          provimult=1.3
          provimult=1.15 if $game_variables[:DifficultyModes]==1
          provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
          damage*=provimult
        end
      when :SHORTCIRCUIT
        if (@move == :DISCHARGE) || (@move == :OVERDRIVE)
          @battle.setField(:FACTORY)
          @battle.pbDisplay(_INTL("SYSTEM ONLINE."))
          provimult=1.3
          provimult=1.15 if $game_variables[:DifficultyModes]==1
          provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
          damage*=provimult
        end
    end

    # Gen 9 Mod - Added Hydro Steam's Damage Calc in Sunny Weather
    case type
      when :FIRE
        damage*=1.5 if @battle.pbWeather == :SUNNYDAY
        damage*=0.5 if @battle.pbWeather == :RAINDANCE
        damage*=0.5 if opponent.ability == :WATERBUBBLE
      when :WATER
        damage*=1.5 if @battle.pbWeather == :RAINDANCE || (@battle.pbWeather == :SUNNYDAY && @move == :HYDROSTEAM)
        damage*=0.5 if @battle.pbWeather == :SUNNYDAY && !@move == :HYDROSTEAM
        damage*=2 if attacker.ability == :WATERBUBBLE
    end
    # Critical hits
    if opponent.damagestate.critical
      damage*=1.5
      damage*=1.5 if attacker.ability == :SNIPER
    end
    # STAB-addition from Crests
    typecrest = false
    case attacker.crested
      when :EMPOLEON then typecrest = true if type == :ICE
      when :LUXRAY then typecrest = true if type == :DARK
      when :SAMUROTT then typecrest = true if type == :FIGHTING
      when :SIMISEAR then typecrest = true if type == :WATER
      when :SIMIPOUR then typecrest = true if type == :GRASS
      when :SIMISAGE then typecrest = true if type == :FIRE
      when :ZOROARK
        party = @battle.pbPartySingleOwner(attacker.index)
        party=party.find_all {|item| item && !item.egg? && item.hp>0 }
        if party[party.length-1] != attacker.pokemon
          typecrest = true if party[party.length-1].hasType?(type)
        end
      end
    # STAB
    # Gen 9 Mod - Added Rocky Payload, Embody Aspect
    if (attacker.hasType?(type) && (!attacker.effects[:DesertsMark])|| (attacker.ability == :STEELWORKER && type == :STEEL)  || (attacker.ability == :SOLARIDOL && type == :FIRE) || (attacker.ability == :LUNARIDOL && type == :ICE) || (attacker.ability == :ROCKYPAYLOAD && type == :ROCK) || typecrest==true)
      if attacker.ability == :ADAPTABILITY ||
          # Gen 9 Mod - Mega (Terastalized) Ogerpon gets a Tera Boost on it's STAB moves based on it's mask.
          (((attacker.form == 8 && type == :GRASS) ||
          (attacker.form == 9 && type == :WATER) ||
          (attacker.form == 10 && type == :FIRE) ||
          (attacker.form == 11 && type == :ROCK)) && attacker.species == :OGERPON)
        damage*=2.0
      elsif (attacker.ability == :STEELWORKER && type == :STEEL) && @battle.FE == :FACTORY # Factory Field
        damage*=2.0
      else
        damage*=1.5
      end
      if attacker.crested == :SILVALLY
        damage*=1.2
      end
    end
    # Gen 9 Mod - Mega (Terastalized) Ogerpon still get's STAB on it's grass type moves.
    if (((attacker.ability == :EMBODYASPECTWELLSPRING) || (attacker.ability == :EMBODYASPECTHEARTHFLAME) || (attacker.ability == :EMBODYASPECTCORNERSTONE)) && type == :GRASS)
      damage*=1.5
    end
    # Gen 9 Mod - Moves of each type used by Mega (Terastalized) Terapagos will get a boost.
    if (attacker.species == :TERAPAGOS && attacker.form == 2)
      # Gen 9 Mod - Normal moves will get 2x boost (this includes STAB).
      if (type == :NORMAL)
        damage*=2
      # Gen 9 Mod - Moves of other types will get a 1.2x boost.
      else
        damage*=1.2
      end
    end
    # Type Effectiveness (typemod has been calced earlier)
    damage = (damage * typemod / 4.0)

    damage *= 0.5 if attacker.status == :BURN && pbIsPhysical?(type) && ![:GUTS,:ORN_ATTUNEMENT].include?(attacker.ability) && @move != :FACADE
    # Random Variance
    if !$game_switches[:No_Damage_Rolls] || @battle.isOnline?
      random = 85 + @battle.pbRandom(16)
    elsif $game_switches[:No_Damage_Rolls] || !@battle.isOnline?
      random = 93
    end
    random = 85 if @battle.FE == :CONCERT1
    random = 100 if @battle.FE == :CONCERT4
    damage = (damage * (random / 100.0))
    # Final damage modifiers
    finalmult = 1.0
    if !opponent.damagestate.critical && attacker.ability != :INFILTRATOR
      # Screens
      if @category != :status && opponent.pbOwnSide.screenActive?(betterCategory(type))
        finalmult *= (!opponent.pbPartner.isFainted? || attacker.midwayThroughMove) ? 0.66 : 0.5
      end
      if opponent.pbOwnSide.effects[:AreniteWall] > 0 && opponent.damagestate.typemod > 4
        finalmult *= 0.5
      end
    end
    
    # Warden Abilities
    case attacker.ability
      when :ORN_REQUIEM       then basemult *= 1.5 if type == :DARK
      when :ORN_AFFECTION     then basemult *= 1.5 if type == :FAIRY
      when :ORN_ARSONIST      then basemult *= 1.5 if type == :FIRE
      when :ORN_VIRTUOSO      then basemult *= 1.5 if type == :SOUND
      when :ORN_HIVEMIND      then basemult *= 1.5 if type == :BUG
      when :ORN_BONECOLLECTOR then basemult *= 1.5 if type == :GROUND
      when :ORN_HAUNTED       then basemult *= 1.5 if type == :GHOST
      when :ORN_BLACKLIGHT    then basemult *= 1.2 if type == :DARK
      when :ORN_WHITEOUT      then basemult *= 1.2 if type == :LIGHT
      when :ORN_DARKMATTER    then basemult *= 1.2 if type == :COSMIC
      when :ORN_CANNONFIRE    then basemult *= 1.5 if pbStuff::BULLETMOVE.include?(@move)
      when :ORN_ICYVEINS      then basemult *= 1.3 if @battle.pbWeather == :HAIL && [:WATER,:ICE].include?(type)
      when :ORN_ATTUNEMENT    then atkmult *= 1.5  if !attacker.status.nil? && pbIsSpecial?(type)
      when :ORN_TORMENTED     then atkmult *= 1.5  if pbIsSpecial?(type)
      when :ORN_GENIUS        then atkmult *= 2.0  if pbIsSpecial?(type)
    end
    atkmult*=0.5 if opponent.ability == :ORN_REALISM && [:GHOST,:FAIRY].include?(type) && !(opponent.moldbroken)
    atkmult*=0.5 if opponent.ability == :ORN_ASTRALMAJESTY && [:LIGHT,:DRGON].include?(type) && !(opponent.moldbroken)
    atkmult*=0.5 if opponent.ability == :ORN_IRREDEEMABLE && [:LIGHT,:FAIRY].include?(type) && !(opponent.moldbroken)
    atkmult*=0.5 if opponent.ability == :ORN_TROPICALHIDE && [:GRASS,:WATER].include?(type) && !(opponent.moldbroken)
    atkmult*=0.5 if opponent.ability == :ORN_LIGHTBULB && [:DARK].include?(type) && !(opponent.moldbroken)
    atkmult*=0.5 if opponent.ability == :ORN_TERRORIZE && [:BUG].include?(type) && !(opponent.moldbroken)
    atkmult*=0.5 if opponent.ability == :ORN_WINDFURY && pbStuff::WINDMOVE.include?(@move) && !(opponent.moldbroken)
    atkmult*=1.5 if attacker.ability == :ORN_WINTERGIFT || attacker.pbPartner.ability == :ORN_WINTERGIFT
    defmult*=1.5 if attacker.ability == :ORN_WINTERGIFT || attacker.pbPartner.ability == :ORN_WINTERGIFT
    if type == :LIGHT && @battle.pbCheckGlobalAbility(:ORN_LIGHTAURA)
      auramult = 1.33
      basemult *= @battle.pbCheckGlobalAbility(:AURABREAK) ? 2 - auramult : auramult
    end
    finalmult *= 0.75 if (((opponent.ability == :ORN_PACKEDSNOW) && !opponent.moldbroken)) && pbWeather == :HAIL && opponent.damagestate.typemod > 4
    # Warden Abilities

    # Warden Crests
    atkmult*=0.25 if opponent.crested == :ORN_TYPHLOSION && [:FIGHTING,:COSMIC].include?(type)
    atkmult*=1.1 if attacker.crested==:ORN_KABUTOPS
    basemult *= 1.2 if @recoil > 0 || [0x130, 0x10B, 0x506].include?(@function) && user.crested == :ORN_TALONFLAME
    # Warden Crests

    # Final damage modifiers
    finalmult *= 0.67 if opponent.crested == :BEHEEYEM && (!opponent.hasMovedThisRound? || @battle.switchedOut[opponent.index])
    secondtypes = self.getSecondaryType(attacker)
    finalmult *= 0.5 if opponent.effects[:Shelter] && @battle.FE != :INDOOR && (type == @battle.field.mimicry || !secondtypes.nil? && secondtypes.include?(@battle.field.mimicry))
    # Gen 9 Mod - Added Purifying Salt
    finalmult *= 0.5 if opponent.ability == :PURIFYINGSALT && type == :GHOST
    finalmult *= 0.5 if (opponent.ability == :MULTISCALE && !opponent.moldbroken) && opponent.hp == opponent.totalhp
    finalmult *= 0.5 if opponent.ability == :SHADOWSHIELD && (opponent.hp == opponent.totalhp || @battle.FE == :DIMENSIONAL)
    finalmult *= 0.33 if opponent.ability == :SHADOWSHIELD && (opponent.hp == opponent.totalhp && (@battle.FE == :DARKNESS2 || @battle.FE == :DARKNESS3))
    finalmult *= 2.0 if attacker.ability == :TINTEDLENS && opponent.damagestate.typemod < 4
    finalmult *= 2.0 if attacker.ability == :EXECUTION && (opponent.hp <= (opponent.totalhp / 2).floor)
    finalmult *= 0.75 if opponent.pbPartner.ability == :FRIENDGUARD && !opponent.moldbroken
    finalmult *= 0.5 if (opponent.ability == :PASTELVEIL || opponent.pbPartner.ability == :PASTELVEIL) && @type == :POISON && (@battle.FE == :MISTY || @battle.FE == :RAINBOW || (@battle.state.effects[:MISTY] > 0))
    if @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN, 3, 5)
      if (opponent.pbPartner.ability == :FLOWERVEIL && opponent.hasType?(:GRASS)) || (opponent.ability == :FLOWERVEIL && !opponent.moldbroken)
        finalmult *= 0.75
        @battle.pbDisplay(_INTL("The Flower Veil softened the attack!"))
      end
    end
    finalmult *= 0.75 if (((opponent.ability == :SOLIDROCK || opponent.ability == :FILTER) && !opponent.moldbroken) || opponent.ability == :PRISMARMOR) && opponent.damagestate.typemod > 4
    finalmult *= 0.75 if opponent.ability == :SHADOWSHIELD && [:STARLIGHT, :NEWWORLD, :DARKCRYSTALCAVERN].include?(@battle.FE) && opponent.damagestate.typemod
    finalmult *= 0.70 if opponent.crested == :AMPHAROS && opponent.damagestate.typemod > 4
    finalmult *= 2.0 if attacker.ability == :STAKEOUT && @battle.switchedOut[opponent.index]
    finalmult *= [1.0 + attacker.effects[:Metronome] * 0.2, 2.0].min if (attitemworks && attacker.item == :METRONOME) && attacker.movesUsed[-2] == attacker.movesUsed[-1]
    finalmult *= [1.0 + attacker.effects[:Metronome] * 0.2, 2.0].min if @battle.FE == :CONCERT4 && attacker.movesUsed[-2] == attacker.movesUsed[-1]
    finalmult *= 1.2 if attitemworks && attacker.item == :EXPERTBELT && opponent.damagestate.typemod > 4
    finalmult *= 1.25 if attacker.ability == :NEUROFORCE && opponent.damagestate.typemod > 4
    finalmult *= 1.3 if attitemworks && attacker.item == :LIFEORB
    # Gen 9 Mod - Moves will deal double damage to an opponent that last used Glaive Rush. Also includes Electro Drift and Collision Course.
    finalmult *= 2.0 if opponent.effects[:GlaiveRush] == true
    finalmult *= (5461 / 4096.to_f) if [:ELECTRODRIFT, :COLLISIONCOURSE].include?(@move) && opponent.damagestate.typemod > 4
    if opponent.damagestate.typemod > 4 && opponent.itemWorks?
      hasberry = false
      case type
        when :FIGHTING   then hasberry = opponent.item == :CHOPLEBERRY
        when :FLYING     then hasberry = opponent.item == :COBABERRY
        when :POISON     then hasberry = opponent.item == :KEBIABERRY
        when :GROUND     then hasberry = opponent.item == :SHUCABERRY
        when :ROCK       then hasberry = opponent.item == :CHARTIBERRY
        when :BUG        then hasberry = opponent.item == :TANGABERRY
        when :GHOST      then hasberry = opponent.item == :KASIBBERRY
        when :STEEL      then hasberry = opponent.item == :BABIRIBERRY
        when :FIRE       then hasberry = opponent.item == :OCCABERRY
        when :WATER      then hasberry = opponent.item == :PASSHOBERRY
        when :GRASS      then hasberry = opponent.item == :RINDOBERRY
        when :ELECTRIC   then hasberry = opponent.item == :WACANBERRY
        when :PSYCHIC    then hasberry = opponent.item == :PAYAPABERRY
        when :ICE        then hasberry = opponent.item == :YACHEBERRY
        when :DRAGON     then hasberry = opponent.item == :HABANBERRY
        when :DARK       then hasberry = opponent.item == :COLBURBERRY
        when :FAIRY      then hasberry = opponent.item == :ROSELIBERRY
        when :COSMIC     then hasberry = opponent.item == :ORN_OLIBERRY
        when :LIGHT      then hasberry = opponent.item == :ORN_PATOTOBERRY
        when :SOUND      then hasberry = opponent.item == :ORN_AVOCABERRY
      end
    end
    hasberry = true if opponent.hasWorkingItem(:CHILANBERRY) && type == :NORMAL
    if hasberry && !([:UNNERVE, :ASONECHILLING, :ASONEGRIM].include?(attacker.ability) || [:UNNERVE, :ASONECHILLING, :ASONEGRIM].include?(attacker.pbPartner.ability))
      finalmult *= 0.5
      finalmult *= 0.5 if opponent.ability == :RIPEN
      opponent.pbDisposeItem(true, true, true, true)
      if !@battle.pbIsOpposing?(attacker.index)
        @battle.pbDisplay(_INTL("{2}'s {1} weakened the damage from the attack!", getItemName(opponent.pokemon.itemRecycle), opponent.pbThis))
      else
        @battle.pbDisplay(_INTL("The {1} weakened the damage to {2}!", getItemName(opponent.pokemon.itemRecycle), opponent.pbThis))
      end
    end
    finalmult *= 0.8 if opponent.crested == :MEGANIUM || opponent.pbPartner.crested == :MEGANIUM
    if attacker.crested == :SEVIPER
      multiplier = 0.5 * (opponent.pokemon.hp * 1.0) / (opponent.pokemon.totalhp * 1.0)
      multiplier += 1.0
      finalmult = (finalmult * multiplier)
    end
    if @zmove
      if opponent.pbOwnSide.effects[:MatBlock] || opponent.effects[:Protect] ||
         opponent.pbOwnSide.effects[:WideGuard] && [:AllOpposing, :AllNonUsers].include?(attacker.pbTarget(self))
        if @move == :UNLEASHEDPOWER
          @battle.pbDisplay(_INTL("The Interceptor's power broke through {1}'s Protect!", opponent.pbThis))
        elsif !opponent.effects[:ProtectNegation]
          @battle.pbDisplay(_INTL("{1} couldn't fully protect itself!", opponent.pbThis))
          finalmult /= 4
        end
      end
    end
    # Gen 9 Mod - Added Ruinous Abilities (This is scuffed imo) --> prolly should do it in finalmult instead
    if (attacker.pbOpposing1.ability == :VESSELOFRUIN || attacker.pbOpposing2.ability == :VESSELOFRUIN || attacker.pbPartner.ability == :VESSELOFRUIN) && attacker.ability != :VESSELOFRUIN && pbIsSpecial?(type) 
      atkmult *= 0.75
    end
    if (attacker.pbOpposing1.ability == :TABLETSOFRUIN || attacker.pbOpposing2.ability == :TABLETSOFRUIN || attacker.pbPartner.ability == :TABLETSOFRUIN) && attacker.ability != :TABLETSOFRUIN && pbIsPhysical?(type)
      atkmult *= 0.75
    end
    if ((opponent.pbOpposing1.ability == :SWORDOFRUIN || opponent.pbOpposing2.ability == :SWORDOFRUIN || opponent.pbPartner.ability == :SWORDOFRUIN) && opponent.ability != :SWORDOFRUIN)
      if @battle.state.effects[:WonderRoom] != 0 && pbIsSpecial?(type)
        defmult *= 0.75
      elsif @battle.state.effects[:WonderRoom] == 0 && pbIsPhysical?(type)
        defmult *= 0.75
      end
    end
    if ((opponent.pbOpposing1.ability == :BEADSOFRUIN || opponent.pbOpposing2.ability == :BEADSOFRUIN || opponent.pbPartner.ability == :BEADSOFRUIN) && opponent.ability != :BEADSOFRUIN) 
      if @battle.state.effects[:WonderRoom] != 0 && pbIsPhysical?(type)
        defmult *= 0.75
      elsif @battle.state.effects[:WonderRoom] == 0 && pbIsSpecial?(type)
        defmult *= 0.75
      end
    end

    # O.Kabutops Crest #
    finalmult *= 1.2 if attacker.crested == :ORN_KABUTOPS && opponent.damagestate.typemod > 4
    basemult *= 1.5 if attacker.crested == :ORN_KABUTOPS && sharpMove?

    # O.Kabutops Crest #

    finalmult = pbModifyDamage(finalmult, attacker, opponent)
    ##### Main damage calculation #####
    basedmg *= basemult
    atk *= atkmult
    defense *= defmult
    totaldamage = (((((2.0 * attacker.level / 5 + 2).floor * basedmg * atk / defense).floor / 50.0).floor + 1) * damage * finalmult).round
    totaldamage = 1 if totaldamage < 1
    opponent.damagestate.calcdamage = totaldamage
    return totaldamage
  end

  def pbCritRate?(attacker, opponent)
    return -1 if self.is_a?(PokeBattle_Confusion)
    return -1 if (opponent.ability == :BATTLEARMOR || opponent.ability == :SHELLARMOR) && !opponent.moldbroken
    return -1 if opponent.pbOwnSide.effects[:LuckyChant] > 0
    return 3 if attacker.effects[:LaserFocus] > 0 || @function == 0xA0 || @function == 0x319 || @function == 0x90B # Frost Breath, Surging Strikes, # Gen 9 Mod - Added Flower Trick
    return 3 if @function == 0x201 && attacker.hp <= ((attacker.totalhp) * 0.5).floor # Gale Strike
    return 3 if attacker.ability == :MERCILESS && (opponent.status == :POISON || @battle.FE == :CORROSIVEMIST || ([:CORROSIVE, :WASTELAND, :MURKWATERSURFACE].include?(@battle.FE) && !attacker.isAirborne?))
    return 3 if (opponent.ability == :RATTLED || opponent.ability == :WIMPOUT) && @battle.FE == :COLOSSEUM
    return 3 if attacker.crested == :ARIADOS && (opponent.status == :POISON || opponent.stages[PBStats::SPEED] < 0) # ariados crest
    return 3 if (attacker.ability == :QUICKDRAW && attacker.effects[:QuickDrawSnipe])

    c = 0
    c += attacker.effects[:FocusEnergy]
    c += 1 if !@data.nil? && highCritRate?
    c += 1 if attacker.inHyperMode? && getMoveType(@move) == :SHADOW
    c += 1 if attacker.ability == :SUPERLUCK
    c += 2 if attacker.hasWorkingItem(:STICK) && (attacker.pokemon.species == :FARFETCHD || attacker.pokemon.species == :SIRFETCHD)
    c += 2 if attacker.hasWorkingItem(:LUCKYPUNCH) && (attacker.pokemon.species == :CHANSEY)
    c += 2 if attacker.crested == :ORN_KABUTOPS
    if @battle.FE == :MIRROR
      buffs = 0
      buffs = attacker.stages[PBStats::EVASION] if attacker.stages[PBStats::EVASION] > 0
      buffs = buffs.to_i + attacker.stages[PBStats::ACCURACY] if attacker.stages[PBStats::ACCURACY] > 0
      buffs = buffs.to_i - opponent.stages[PBStats::EVASION] if opponent.stages[PBStats::EVASION] < 0
      buffs = buffs.to_i - opponent.stages[PBStats::ACCURACY] if opponent.stages[PBStats::ACCURACY] < 0
      buffs = buffs.to_i
      c += buffs if buffs > 0
    end
    c += 1 if attacker.hasWorkingItem(:RAZORCLAW)
    c += 1 if attacker.hasWorkingItem(:SCOPELENS)
    c += 3 if sharpMove? && attacker.crested == :SAMUROTT
    c += 1 if attacker.crested == :FEAROW # Fearow Crest
    c += 1 if attacker.speed > opponent.speed && @battle.FE == :GLITCH
    if Rejuv && @battle.FE == :CHESS
      c += 1 if (opponent.ability == :RECKLESS || opponent.ability == :GORILLATACTICS)
      c += 1 if [:STOMPINGTANTRUM, :THRASH, :OUTRAGE].include?(opponent.lastMoveUsed)
      if attacker.ability == :MERCILESS
        frac = (1.0 * opponent.hp) / (1.0 * opponent.totalhp)
        if frac < 0.8
          c += 1
        elsif frac < 0.6
          c += 2
        elsif frac < 0.4
          c += 3
        end
      end
    end
    c = 3 if c > 3
    return c
  end
end

class PokeBattle_Battler
  # For Charisma
  def pbUseMove(choice, flags = { danced: false, totaldamage: 0, specialusage: false, specialZ: false })
    if @battle.recorded == true
      $game_variables[:BattleDataArray].last().pokemonTrackMove(choice, self, @battle.battlers)
    end
    danced = flags[:danced]
      # TODO: lastMoveUsed is not to be updated on nested calls
    flags[:totaldamage] = 0 if !flags[:totaldamage]
      # hasMovedThisRound by itself isn't enough for, say, Fake Out + Instruct.
    @isFirstMoveOfRound = !self.hasMovedThisRound?
      # Start using the move
    pbBeginTurn(choice)
      # Force the use of certain moves if they're already being used
    if @effects[:TwoTurnAttack] != 0 || @effects[:HyperBeam] > 0 || @effects[:Outrage] > 0 || @effects[:Rollout] > 0 || @effects[:Uproar] > 0 || @effects[:Bide] > 0
      PBDebug.log("[Continuing move]") if $INTERNAL
      choice[2] = PokeBattle_Move.pbFromPBMove(@battle, PBMove.new(@currentMove), self) if @currentMove != 0
      flags[:specialusage] = true
    elsif @effects[:Encore] > 0 && !choice[2].zmove && choice[2] != @battle.struggle
      if @battle.pbCanShowCommands?(@index)
        PBDebug.log("[Using Encore move]") if $INTERNAL
        if choice[1] != @effects[:EncoreIndex]   # Was Encored mid-round
          choice[1] = @effects[:EncoreIndex]
          choice[2] = @moves[@effects[:EncoreIndex]]
          if choice[2].move == :ACUPRESSURE
            choice[3] = self.index
          else
            choice[3] = -1   # No target chosen
          end
        end
      end
    end
    basemove = choice[2]
    return if !basemove

    if !flags[:specialusage]
        # TODO: Quick Claw message
    end
    PBDebug.log("  #{self.name} used   #{basemove.name}") if $INTERNAL
    return false if self.effects[:SkyDrop] || self.effects[:Commander]   # Gen 9 Mod - Tatsugiri can't use move if in Dondozo's mouth

    if !pbTryUseMove(choice, basemove, flags)
      if self.vanished
        @battle.scene.pbUnVanishSprite(self)
        droprelease = self.effects[:SkyDroppee]
        if droprelease != nil
          oppmon = droprelease
          oppmon.effects[:SkyDrop] = false
          @effects[:SkyDroppee] = nil
          @battle.scene.pbUnVanishSprite(oppmon)
          @battle.pbDisplay(_INTL("{1} is freed from the Sky Drop effect!", oppmon.pbThis))
        end
      end
        # Commented out because the cases we tested (Encore / Disable / Sketch / Mimic / Spite / Instruct)
        # all work after a sleep turn using the last used move.
        # self.lastMoveUsed = -1
      if !flags[:specialusage]
          # self.lastMoveUsedSketch = -1 if self.effects[:TwoTurnAttack] == 0
          # self.lastRegularMoveUsed = -1
        self.lastRoundMoved = @battle.turncount
      end
      self.effects[:Metronome] = 0
      pbCancelMoves
      @battle.pbGainEXP
      pbEndTurn(choice)
      @battle.pbJudgeSwitch
      return
    end
    if !flags[:specialusage]
      @battle.ai.addMoveToMemory(self, basemove) if !choice[2].zmove
      ppmove = choice[2].zmove ? self.moves[choice[1]] : basemove
      if !pbReducePP(ppmove) && !choice[2].zmove
        @battle.pbDisplay(_INTL("{1} used\r\n{2}!", pbThis, basemove.getMoveUseName))
        @battle.pbDisplay(_INTL("But there was no PP left for the move!"))
        self.lastMoveUsed = -1
        if !flags[:specialusage]
          self.lastMoveUsedSketch = -1 if self.effects[:TwoTurnAttack] == 0
          self.lastRegularMoveUsed = -1
          self.lastRoundMoved = @battle.turncount
        end
        pbEndTurn(choice)
        @battle.pbJudgeSwitch
        return
      end
    end
    @battle.pbUseZMove(self.index, choice, self.item, flags[:specialZ]) if choice[2].zmove && (!flags[:specialusage] || flags[:specialZ])
    if basemove.function != 0x92   # Echoed Voice
      self.effects[:EchoedVoice] = 0
    end
    if basemove.function != 0x91   # Fury Cutter
      self.effects[:FuryCutter] = 0
    end
    if @effects[:Powder] && basemove.type == :FIRE
      @battle.pbDisplay(_INTL("The powder around {1} exploded!", pbThis))
      @battle.pbCommonAnimation("Powder", self, nil)
      pbReduceHP((@totalhp / 4.0).floor)
      pbFaint if @hp < 1
      return false
    end
      # Remember that user chose a two-turn move
    if basemove.pbTwoTurnAttack(self)
        # Beginning use of two-turn attack
      @effects[:TwoTurnAttack] = basemove.move
      @currentMove = basemove.move
    else
      @effects[:TwoTurnAttack] = 0   # Cancel use of two-turn attack
      @effects[:SkyDroppee] = nil if basemove.move != :SKYDROP
    end
      # "X used Y!" message
    case basemove.pbDisplayUseMessage(self, choice)
      when 2     # Continuing Bide
        if !flags[:specialusage]
          self.lastRoundMoved = @battle.turncount
        end
        return
      when 1     # Starting Bide
        if $cache.moves[basemove.move]
          self.lastMoveUsed = basemove.move
          @lastMoveChoice = choice.clone
          if !flags[:specialusage]
            self.lastMoveUsedSketch = basemove.move if self.effects[:TwoTurnAttack] == 0
            self.lastRegularMoveUsed = basemove.move
            if self.effects[:ChoiceBand] == nil && (self.hasWorkingItem(:CHOICEBAND) || self.hasWorkingItem(:CHOICESPECS) || self.hasWorkingItem(:CHOICESCARF))
              self.effects[:ChoiceBand] = basemove.move
            end
            if self.effects[:GorillaLock] == nil && self.ability == :GORILLATACTICS
              self.effects[:GorillaLock] = basemove.move
            end
            self.movesUsed.push(basemove.move)   # For Last Resort
            self.lastRoundMoved = @battle.turncount
          else
            self.lastRegularMoveUsed = -1 if basemove.move == :STRUGGLE
          end
          @battle.lastMoveUsed = basemove.move
          @battle.lastMoveUser = self.index
        end
        return
      when -1   # Was hurt while readying Focus Punch, fails use
        if $cache.moves[basemove.move]
          self.lastMoveUsed = basemove.move
          @lastMoveChoice = choice.clone
          if !flags[:specialusage]
            self.lastMoveUsedSketch = basemove.move if self.effects[:TwoTurnAttack] == 0
            self.lastRegularMoveUsed = basemove.move
            self.movesUsed.push(basemove.move)   # For Last Resort
            self.lastRoundMoved = @battle.turncount
          else
            self.lastRegularMoveUsed = -1 if basemove.move == :STRUGGLE
          end
          @battle.lastMoveUsed = basemove.move
          @battle.lastMoveUser = self.index
        end
        return
    end
      # Find the user and target(s)
    targets = []
    pbFindUser(choice, targets)
    user = self
      # Status Z-move effects
    pbZStatus(basemove.move, user) if choice[2].zmove && choice[2].category == :status && PBStuff::TYPETOZCRYSTAL[basemove.type] == user.item
      # moldbreaker
      # Gen 9 Mod - Added Mycelium Might
    if (user.ability == :MOLDBREAKER || user.ability == :TERAVOLT || user.ability == :TURBOBLAZE) || (user.ability == :MYCELIUMMIGHT && basemove.basedamage == 0 && user.effects[:TwoTurnAttack] == 0) ||
       basemove.function == 0x166 || basemove.function == 0x176 || basemove.function == 0x200   # Solgaluna/crozma signatures
      for i in 0..3
          # Gen 9 Mod - Added Ability Shield
        if !@battle.battlers[i].hasWorkingItem(:ABILITYSHIELD)
          @battle.battlers[i].moldbroken = true
        else
          @battle.battlers[i].moldbroken = false
        end
      end
    else
      for i in 0..3
        @battle.battlers[i].moldbroken = false
      end
    end
    if user.ability == :CORROSION
      for battlers in targets
        battlers.corroded = true
      end
    else
      for battlers in targets
        battlers.corroded = false
      end
    end
      # Battle Arena only - assume failure
      # Check whether Selfdestruct works
    if !basemove.pbOnStartUse(user)   # Only Selfdestruct can return false here
      if $cache.moves[basemove.move]
        user.lastMoveUsed = basemove.move
        @lastMoveChoice = choice.clone
        if !flags[:specialusage]
          user.lastMoveUsedSketch = basemove.move if user.effects[:TwoTurnAttack] == 0
          user.lastRegularMoveUsed = basemove.move
          user.movesUsed.push(basemove.move)   # For Last Resort
          user.lastRoundMoved = @battle.turncount
        else
          self.lastRegularMoveUsed = -1 if basemove.move == :STRUGGLE
        end
        @battle.lastMoveUsed = basemove.move
        @battle.lastMoveUser = user.index
      end
        # Might pbEndTurn need to be called here?
      return
    end
      # Record move as having been used
    if $cache.moves[basemove.move]
      user.lastMoveUsed = basemove.move
      @lastMoveChoice = choice.clone
      user.lastRoundMoved = @battle.turncount
      if !flags[:specialusage]
        user.lastMoveUsedSketch = basemove.move
        user.lastRegularMoveUsed = basemove.move
        if user.effects[:ChoiceBand] == nil && (user.hasWorkingItem(:CHOICEBAND) || user.hasWorkingItem(:CHOICESPECS) || user.hasWorkingItem(:CHOICESCARF))
          user.effects[:ChoiceBand] = basemove.move
        end
        if user.effects[:GorillaLock] == nil && user.ability == :GORILLATACTICS
          user.effects[:GorillaLock] = basemove.move
        end
        if !basemove.zmove
          user.movesUsed.push(basemove.move)   # For Last Resort
          user.effects[:Metronome] = 0 if basemove.move != user.movesUsed[-2]
        end
      else
        self.lastRegularMoveUsed = -1 if basemove.move == :STRUGGLE
      end
      @battle.lastMoveUsed = basemove.move
      @battle.lastMoveUser = user.index
      if basemove.zmove
        user.lastMoveUsed = -1
        user.lastMoveUsedSketch = -1
        user.lastRegularMoveUsed = -1
        @battle.lastMoveUsed = -1
      end
    end
    targetchoices = pbTarget(basemove)
      # Try to use move against user if there aren't any targets
    if targets.length == 0 && @effects[:TwoTurnAttack] == 0
      user = pbChangeUser(basemove, user)
      cancelcheck = false
      if basemove.typeFieldBoost(basemove.pbType(user), user, nil) == 0
        @battle.pbDisplay(_INTL(basemove.typeFieldMessage(basemove.pbType(user)))) if !basemove.fieldmessageshown_type
        basemove.fieldmessageshown_type = true
        user.pbCancelMoves
        cancelcheck = true
      end
      if basemove.moveFieldBoost == 0
        @battle.pbDisplay(_INTL(basemove.moveFieldMessage)) if !basemove.fieldmessageshown
        basemove.fieldmessageshown = true
        user.pbCancelMoves
        cancelcheck = true
      end
      if !cancelcheck
        if [:SingleNonUser, :RandomOpposing, :AllOpposing, :AllNonUsers, :Partner, :UserOrPartner, :SingleOpposing, :OppositeOpposing, :DragonDarts].include?(targetchoices)
          @battle.pbDisplay(_INTL("But there was no target..."))
          @effects[:Rollout] = 0 if @effects[:Rollout] > 0
          if PBStuff::TWOTURNMOVE.include?(basemove.move)   # Sprites for two turn moves
            @battle.scene.pbUnVanishSprite(user)
          end
        else
          PBDebug.logonerr {
            basemove.pbEffect(user, nil)
          }
        end
        unless !basemove
          pbDancerMoveCheck(basemove.move) unless danced
        end
      end
    else
        # We have targets
      dragondarthit = nil
      if targetchoices == :DragonDarts && targets.length > 1
        originaltargets = targets.clone
        for target in originaltargets
          if !basemove.pbAccuracyCheck(user, target)
            if targets.length > 1
              targets.delete(target)
              @battle.pbDisplay(_INTL("{1}'s attack missed!", user.pbThis))
            else
              dragondarthit = false
            end
            user.missAcc = true
          end
        end
        dragondarthit = true if dragondarthit.nil?
      end
      movesucceeded = false
      showanimation = true
      disguisebustcheck = false
      alltargets = []
      basemove.fieldmessageshown = false
      basemove.fieldmessageshown_type = false
      if @effects[:TwoTurnAttack] != 0 && targets.length == 0
        numhits = basemove.pbNumHits(user)
        pbProcessMoveAgainstTarget(basemove, user, nil, numhits, flags, false, alltargets, showanimation)
      end

      if targets.length > 0 && targetchoices == :AllOpposing
          # Add target's partner to list of targets
        pbAddTarget(targets, targets[0].pbPartner)
      end
      for i in 0...targets.length
        alltargets.push(targets[i].index)
      end

      killtracker = []
        # For each target in turn
      i = 0
      loop do
        break if i >= targets.length

          # Get next target
        userandtarget = [user, targets[i]]
        success = pbChangeTarget(basemove, userandtarget, targets)
        user = userandtarget[0]
        target = userandtarget[1]
        if target.effects[:MagicBounced] || target.isFainted?
          success = false
        end
        if !success
          i += 1
          next
        end
        numhits = basemove.pbNumHits(user)
          # Ledian and Cinccino crests
        if targetchoices != :AllOpposing && numhits < 2
          case user.crested
            when :LEDIAN
              numhits = 4 if basemove.punchMove?
            when :CINCCINO
              hitchances = [2, 2, 3, 3, 4, 5]
              ret = hitchances[@battle.pbRandom(hitchances.length)]
              ret = 5 if user.ability == :SKILLLINK
              numhits = ret if !basemove.pbIsMultiHit
          end
        end
          # Parental bond
        if numhits == 1 && (user.ability == :PARENTALBOND || user.crested == :ORN_ARCANINE) && !choice[2].zmove
          counter1 = 0
          counter2 = 0
          for k in @battle.battlers
            next if k.isFainted?

            counter1 += 1
          end
          for j in @battle.battlers
            next unless user.pbIsOpposing?(j.index)
            next if j.isFainted?

            counter2 += 1
          end
          user.effects[:ParentalBond] = true unless (targetchoices == :AllNonUsers && counter1 != 2) || (targetchoices == :AllOpposing && counter2 != 1)
          numhits = 2 unless (targetchoices == :AllNonUsers && counter1 != 2) || (targetchoices == :AllOpposing && counter2 != 1)
        else
          user.effects[:ParentalBond] = false
        end
        if numhits == 1 && basemove.contactMove? && user.crested == :TYPHLOSION && !choice[2].zmove
          counter1 = 0
          counter2 = 0
          for k in @battle.battlers
            next if k.isFainted?

            counter1 += 1
          end
          for j in @battle.battlers
            next unless user.pbIsOpposing?(j.index)
            next if j.isFainted?

            counter2 += 1
          end
          user.effects[:TyphBond] = true unless (targetchoices == :AllNonUsers && counter1 != 2) || (targetchoices == :AllOpposing && counter2 != 1)
          numhits = 2 unless (targetchoices == :AllNonUsers && counter1 != 2) || (targetchoices == :AllOpposing && counter2 != 1)
        else
          user.effects[:TyphBond] = false
        end
          # Reset damage state, set Focus Band/Focus Sash to available
        target.damagestate.reset
        if target.hasWorkingItem(:FOCUSBAND) && @battle.pbRandom(10) == 0
          target.damagestate.focusband = true
        end
        if target.hasWorkingItem(:FOCUSSASH)
          target.damagestate.focussash = true
        end
        if target.crested == :RAMPARDOS && target.pokemon.rampCrestUsed == false
          target.damagestate.rampcrest = true
        end
        target.lastMoveTaken = basemove.move
          # Use move against the current target
        hitcheck, killflag = pbProcessMoveAgainstTarget(basemove, user, target, numhits, flags, false, alltargets, showanimation, precheckedacc: dragondarthit)
        hitcheck = 0 if hitcheck == nil
        killtracker.push(target) if killflag
        disguisebustcheck = true if target.damagestate.disguise
        showanimation = false unless (hitcheck <= 0 && disguisebustcheck == false && @effects[:TwoTurnAttack] == 0 && (basemove.pbIsSpecial?(basemove.type) || basemove.pbIsPhysical?(basemove.type)))
        movesucceeded = true if (hitcheck && hitcheck > 0) || disguisebustcheck
          # Probopass Crest
        if user.crested == :PROBOPASS
          if basemove.basedamage > 0 && basemove.move != :PROBOPOG
            @battle.pbDisplay(_INTL("{1}'s mini noses followed up on the attack!", user.pbThis))
            if basemove.target == :AllOpposing || basemove.target == :AllNonUsers
              movetarget = target
              movetarget = user.pbCrossOpposing if user.pbPartner == target
              movetarget = movetarget.pbPartner if movetarget.isFainted?
            else
              movetarget = target
              movetarget = movetarget.pbPartner if movetarget.isFainted?
            end
            if movetarget.isFainted?
              @battle.pbDisplay(_INTL("But there was no target left!", user.pbThis))
            else
              user.pbUseMoveSimple(:PROBOPOG, -1, movetarget.index)
            end
          end
        end
        i += 1
      end
      basemove.fieldmessageshown = false
      basemove.fieldmessageshown_type = false

        # Activation Timing: after the move fully resolves
        # On Kill effects
      for target in killtracker
        if user.hp > 0 && target.hp <= 0 && flags[:totaldamage] > 0
          if user.ability == :EXECUTION
            user.pbRecoverHP(self.totalhp / 8, true)
            @battle.pbDisplay(_INTL("{1}'s Execution healed some of its wounds!", user.pbThis))
          end
          if !@battle.pbAllFainted?(@battle.pbParty(target.index))
            if [:GRIMNEIGH, :ASONEGRIM].include?(user.ability)
              if !user.pbTooHigh?(PBStats::SPATK)
                @battle.pbCommonAnimation("StatUp", self, nil)
                user.pbIncreaseStatBasic(PBStats::SPATK, 1)
                abilityname = user.ability == :ASONEGRIM ? "Grim Neigh" : getAbilityName(user.ability)
                @battle.pbDisplay(_INTL("{1}'s {2} raised its Special Attack!", user.pbThis, abilityname))
              end
            end
            if [:MOXIE, :CHILLINGNEIGH, :ASONECHILLING].include?(user.ability)
             if !user.pbTooHigh?(PBStats::ATTACK)
                @battle.pbCommonAnimation("StatUp", self, nil)
                user.pbIncreaseStatBasic(PBStats::ATTACK, 1)
                abilityname = user.ability == :ASONECHILLING ? "Chilling Neigh" : getAbilityName(user.ability)
                @battle.pbDisplay(_INTL("{1}'s {2} raised its Attack!", user.pbThis, abilityname))
              end
            elsif [:ORN_CHARISMA].include?(user.ability)
             if !user.pbTooHigh?(PBStats::SPATK)
                @battle.pbCommonAnimation("StatUp", self, nil)
                user.pbIncreaseStatBasic(PBStats::SPATK, 1)
                abilityname = user.ability == :ASONECHILLING ? "Chilling Neigh" : getAbilityName(user.ability)
                @battle.pbDisplay(_INTL("{1}'s {2} raised its Special Attack!", user.pbThis, abilityname))
              end
            end
            if user.ability == :BEASTBOOST
              aBoost = user.attack
              dBoost = user.defense
              saBoost = user.spatk
              sdBoost = user.spdef
              spdBoost = user.speed
              boostStat = [aBoost, dBoost, saBoost, sdBoost, spdBoost].max
              statindex = [aBoost, dBoost, saBoost, sdBoost, spdBoost].index(boostStat) + 1
              statmod = @battle.FE == :DIMENSIONAL ? 2 : 1
              if !user.pbTooHigh?(statindex)
                @battle.pbCommonAnimation("StatUp", self, nil)
                user.pbIncreaseStatBasic(statindex, statmod)
                @battle.pbDisplay(_INTL("{1}'s Beast Boost raised its {2}!", user.pbThis, pbGetStatName(statindex)))
              end
            end
            if @battle.FE == :COLOSSEUM
              aBoost = target.attack
              dBoost = target.defense
              saBoost = target.spatk
              sdBoost = target.spdef
              spdBoost = target.speed
              boostStat = [aBoost, dBoost, saBoost, sdBoost, spdBoost].max
              statindex = [aBoost, dBoost, saBoost, sdBoost, spdBoost].index(boostStat) + 1
              if !user.pbTooHigh?(statindex)
                user.pbIncreaseStat(statindex, 1, statmessage: false)
                if user.ability == :CONTRARY
                  @battle.pbDisplay(_INTL("The cheering audience lowered {1}'s {2}!", user.pbThis, pbGetStatName(statindex)))
                else
                  @battle.pbDisplay(_INTL("The cheering audience raised {1}'s {2}!", user.pbThis, pbGetStatName(statindex)))
                end
              end
            end
            if @battle.FE == :BACKALLEY && basemove.move == :PURSUIT
              if !user.pbTooHigh?(PBStats::SPEED)
                @battle.pbCommonAnimation("StatUp", self, nil)
                user.pbIncreaseStatBasic(PBStats::SPEED, 1)
                @battle.pbDisplay(_INTL("{1}'s Pursuit raised its Speed!", user.pbThis))
              end
            end
            if user.species == :GRENINJA && user.ability == :BATTLEBOND && !@battle_bond_flags.include?(user.pokemon)
              unless LegacyBattleBond
                battleBondActive = false
                if !user.pbTooHigh?(PBStats::ATTACK)
                  @battle.pbCommonAnimation("StatUp", self, nil)
                  user.pbIncreaseStatBasic(PBStats::ATTACK, 1)
                  @battle.pbDisplay(_INTL("{1}'s {2} raised its Attack!", user.pbThis, getAbilityName(user.ability)))
                  battleBondActive = true
                end
                if !user.pbTooHigh?(PBStats::SPATK)
                  @battle.pbCommonAnimation("StatUp", self, nil)
                  user.pbIncreaseStatBasic(PBStats::SPATK, 1)
                  @battle.pbDisplay(_INTL("{1}'s {2} raised its Special Attack!", user.pbThis, getAbilityName(user.ability)))
                  battleBondActive = true
                end
                if !user.pbTooHigh?(PBStats::SPEED)
                  @battle.pbCommonAnimation("StatUp", self, nil)
                  user.pbIncreaseStatBasic(PBStats::SPEED, 1)
                  @battle.pbDisplay(_INTL("{1}'s {2} raised its Speed!", user.pbThis, getAbilityName(user.ability)))
                  battleBondActive = true
                end
                @battle_bond_flags.push(user.pokemon) if battleBondActive
              else
                if !user.effects[:Transform]
                  @battle.pbDisplay(_INTL("{1} became fully charged due to its bond with its Trainer!", user.pbThis))
                  @battle.pbCommonAnimation("MegaEvolution", user, nil)
                  user.form = 1
                  user.pbUpdate(true)
                  @battle.scene.pbChangePokemon(user, user.pokemon) if user.effects[:Substitute] == 0
                  @battle.pbDisplay(_INTL("{1} transformed into Ash-Greninja!", user.pbThis))
                  @battle_bond_flags.push(user.pokemon)
                end
              end
            end
          end
        end
      end
        # Swalot Crest
      if user.crested == :SWALOT
        if basemove.move == :BELCH
          move = :SPITUP
          movename = getMoveName(move)
          @battle.pbDisplay(_INTL("{1} used {2}!", user.pbThis, movename))
          movetarget = targets[0]
          movetarget = movetarget.pbPartner if movetarget.isFainted?
          if movetarget.isFainted?
            @battle.pbDisplay(_INTL("But there was no target left!", user.pbThis))
          else
            user.pbUseMoveSimple(move, -1, movetarget.index)
          end
        end
        if ![:STOCKPILE, :SPITUP, :SWALLOW].include?(basemove.move) && user.effects[:Stockpile] < 3
          user.effects[:Stockpile] += 1
          @battle.pbDisplay(_INTL("{1} stockpiled {2}!", user.pbThis, user.effects[:Stockpile]))
          if user.pbIncreaseStat(PBStats::DEFENSE, 1, abilitymessage: false, statsource: user)
            user.effects[:StockpileDef] += 1
          end
          if user.pbIncreaseStat(PBStats::SPDEF, 1, abilitymessage: false, statsource: user)
            user.effects[:StockpileSpDef] += 1
          end
        end
      end

      if user.missAcc
        if user.hasWorkingItem(:BLUNDERPOLICY)
          if user.pbIncreaseStat(PBStats::SPEED, 2, abilitymessage: false, statsource: user)
            if user.ability == :CONTRARY
              @battle.pbDisplay(_INTL("The Blunder Policy harshly lowered   #{user.pbThis}'s Speed!"))
            else
              @battle.pbDisplay(_INTL("The Blunder Policy sharply raised   #{user.pbThis}'s Speed!"))
            end
            user.pbDisposeItem(false)
          end
        end
        if @battle.ProgressiveFieldCheck(PBFields::CONCERT)
          @battle.reduceField
        end
      end

        # Throat Spray
      if user.hasWorkingItem(:THROATSPRAY) && basemove.isSoundBased? && user.hp > 0
        if user.pbIncreaseStat(PBStats::SPATK, 1, abilitymessage: false, statsource: user)
          if user.ability == :CONTRARY
            @battle.pbDisplay(_INTL("The Throat Spray lowered   #{user.pbThis}'s Special Attack!"))
          else
            @battle.pbDisplay(_INTL("The Throat Spray raised   #{user.pbThis}'s Special Attack!"))
          end
          user.pbDisposeItem(false)
        end
      end

        # Metronome item
      if (user.hasWorkingItem(:METRONOME) || @battle.FE == :CONCERT4) && movesucceeded
        user.effects[:Metronome] += 1
      else
        user.effects[:Metronome] = 0
      end

        # Magic Bounce
      for i in targets
        if !i.effects[:BouncedMove].nil?   # lía
          move = i.effects[:BouncedMove].move
          i.effects[:BouncedMove] = nil
          @battle.pbDisplay(_INTL("{1} bounced the {2} back!", i.pbThis, basemove.name))
          if @battle.FE == :MIRROR
            if i.pbCanIncreaseStatStage?(PBStats::EVASION)
              i.pbIncreaseStatBasic(PBStats::EVASION, 1)
              @battle.pbCommonAnimation("StatUp", i, nil)
              @battle.pbDisplay(_INTL("{1}'s Magic Bounce increased its evasion!", i.pbThis, basemove.name))
            end
          end
            # pbUseMoveSimple(moveid,index=-1,target=-1,danced=false)
          i.pbUseMoveSimple(move, -1, user.index, false)
          i.effects[:MagicBounced] = false
        end
      end

        # Misc Field Effects 2
      if @battle.FE == :DIMENSIONAL
        combust = user.totalhp
        if combust != 0
          if (basemove.move == :DIG || basemove.move == :DIVE ||
            basemove.move == :FLY || basemove.move == :BOUNCE) &&
             user.effects[:TwoTurnAttack] != 0
            combust -= 1 if user.ability == :STURDY
            @battle.pbDisplay(_INTL("The corrupted field damaged {1}!", user.pbThis)) if combust != 0
            user.pbReduceHP(combust) if combust != 0
            user.pbFaint if user.isFainted?
          end
        end
      end

        # Goth Crest
      if user.crested == :GOTHITELLE && user.hasType?(:DARK) && flags[:totaldamage] > 0 && @effects[:HealBlock] == 0
        hpgain = flags[:totaldamage] / 4.0
        hpgain = user.pbRecoverHP([hpgain.floor, 1].max, true)
        if hpgain > 0
          @battle.pbDisplay(_INTL("{1} restored some HP using the Gothitelle Crest!", user.pbThis))
        end
      end

        # Sheer Force affected items
      if !(user.ability == :SHEERFORCE && (basemove.effect > 0 || [0x908].include?(basemove.function)))   # Gen 9 Mod - Electro Shot needs to be affected by Sheer Force.

          # Shell Bell
        if (user.hasWorkingItem(:SHELLBELL) || (user.crested == :TORTERRA && !user.isFainted?)) && flags[:totaldamage] > 0 && @effects[:HealBlock] == 0
          hpgain = @battle.FE == :ASHENBEACH ? flags[:totaldamage] / 4.0 : flags[:totaldamage] / 8.0
          hpgain = user.pbRecoverHP([hpgain.floor, 1].max, true)
          if hpgain > 0
            @battle.pbDisplay(_INTL("{1} restored a little HP using its Shell Bell!", user.pbThis))
          end
        end

          # Life Orb
        if user.hasWorkingItem(:LIFEORB) && movesucceeded && user.ability != :MAGICGUARD && !(user.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
          hploss = user.pbReduceHP([(user.totalhp / 10.0).floor, 1].max, true)
          if hploss > 0
            @battle.pbDisplay(_INTL("{1} lost some of its HP!", user.pbThis))
          end
        end

        user.pbFaint if user.isFainted?   # no return
      end

      for i in alltargets
        target = @battle.battlers[i]
        if target.effects[:ItemRemoval] == :Pickpocket
          if target.item.nil? && !user.item.nil? && user.effects[:Substitute] == 0 && user.ability != :STICKYHOLD &&
           !battle.pbIsUnlosableItem(user, user.item) && !battle.pbIsUnlosableItem(target, user.item)
            target.item = user.item
            user.item = nil
            if user.pokemon.corrosiveGas
              user.pokemon.corrosiveGas = false
              target.pokemon.corrosiveGas = true
            end
            if @battle.pbIsWild? && target.pokemon.itemInitial.nil? && user.pokemon.itemInitial == target.item && !user.isbossmon && !target.isbossmon   # In a wild battle
              target.pokemon.itemInitial = target.item
              target.pokemon.itemReallyInitialHonestlyIMeanItThisTime = target.item
              user.pokemon.itemInitial = nil
            end
            @battle.pbCommonAnimation("Thief", target, user)
            @battle.pbDisplay(_INTL("{1} pickpocketed {2}'s {3}!", target.pbThis, user.pbThis(true), getItemName(target.item)))
          end
          target.effects[:ItemRemoval] = nil
        end
      end

        # Mold Breaker reset
      for i in 0..3
        @battle.battlers[i].moldbroken = false
        @battle.battlers[i].corroded = false
      end

        # Dancer
      unless !basemove
        pbDancerMoveCheck(basemove.move) unless danced
      end
      if danced
        if user.effects[:Outrage] > 0
          user.effects[:Outrage] = 0
        end
      end
        # Switch moves
      for i in @battle.battlers
        if i.userSwitch
          i.userSwitch = false
            # remove gem when switching out before hitting pbEndTurn
          if i.takegem
            i.pbDisposeItem(false, true, true, true)
            i.takegem = false
          end
          @battle.pbDisplay(_INTL("{1} went back to {2}!", i.pbThis, @battle.pbGetOwner(i.index).name))
          newpoke = 0
          newpoke = @battle.pbSwitchInBetween(i.index, true, false)
          @battle.pbMessagesOnReplace(i.index, newpoke)
          i.vanished = false
          i.pbResetForm
          @battle.pbReplace(i.index, newpoke, false)
          @battle.pbOnActiveOne(i)
          i.pbAbilitiesOnSwitchIn(true)
        end
        if i.forcedSwitch
            # remove gem when forced switching out mid attack
          if i.takegem
            i.pbDisposeItem(false, true, true, true)
            i.takegem = false
          end
          i.forcedSwitch = false
          party = @battle.pbParty(i.index)
          j = -1
          until j != -1
            j = @battle.pbRandom(party.length)
            if !((i.isFainted? || j != i.pokemonIndex) && (pbPartner.isFainted? || j != i.pbPartner.pokemonIndex) && party[j] && !party[j].isEgg? && party[j].hp > 0)
              j = -1
            end
            if !@battle.pbCanSwitchLax?(i.index, j, false)
              j = -1
            end
            if Rejuv and party[j].isbossmon
              j = -1
            end
          end
          newpoke = j
          i.vanished = false
          i.pbResetForm
          @battle.pbReplace(i.index, newpoke, false)
          @battle.pbDisplay(_INTL("{1} was dragged out!", i.pbThis))
          @battle.pbOnActiveOne(i)
          i.pbAbilitiesOnSwitchIn(true)
          i.forcedSwitchEarlier = true
        end
      end
    end
    if basemove.function == 0xE0   # Self-Destruct / Explosion
      user.effects[:DelayFaint] = false
      user.hp = 0
      user.pbFaint
    end
    @battle.fieldEffectAfterMove(basemove, user)
    @battle.pbGainEXP
      # Check if move order should be switched for shell trap

      # Remember trainer has used z-move
    if basemove.zmove
      side = @battle.pbIsOpposing?(self.index) ? 1 : 0
      owner = @battle.pbGetOwnerIndex(self.index)
      @battle.zMove[side][owner] = -2 if @battle.zMove[side][owner] != -1
    end
      # End of move usage
    pbEndTurn(choice)
    @battle.pbJudgeSwitch
    return
  end
  # Warden Ability Redirect
  def pbChangeTarget(basemove, userandtarget, targets)
    priority = @battle.pbPriority
    changeeffect = 0
    user = userandtarget[0]
    target = userandtarget[1]
    targetchoices = pbTarget(basemove)
    unless (basemove.function == 0x179) || user.ability == :STALWART || user.ability == :PROPELLERTAIL
      movetypes = [basemove.pbType(user), *basemove.getSecondaryType(user)]

      # LightningRod here, considers Hidden Power as Normal
      if targets.length == 1 && movetypes.include?(:ELECTRIC) && target.ability != :LIGHTNINGROD
        for i in priority # use Pokémon earliest in priority
          next if i.index == user.index || i.isFainted?

          if i.ability == :LIGHTNINGROD && !i.moldbroken
            target = i # X's LightningRod took the attack!
            changeeffect = 1
            break
          end
        end
      end

      # Storm Drain here, considers Hidden Power as Normal
      if targets.length == 1 && movetypes.include?(:WATER) && target.ability != :STORMDRAIN
        for i in priority # use Pokémon earliest in priority
          next if i.index == user.index || i.isFainted?

          if i.ability == :STORMDRAIN && !i.moldbroken
            target = i # X's Storm Drain took the attack!
            changeeffect = 2
            break
          end
        end
      end

      # Cacophony here, considers Hidden Power as Normal
      if targets.length == 1 && movetypes.include?(:SOUND) && target.ability != :ORN_CACOPHONY
        for i in priority # use Pokémon earliest in priority
          next if i.index == user.index || i.isFainted?

          if i.ability == :ORN_CACOPHONY && !i.moldbroken
            target = i # X's Storm Drain took the attack!
            changeeffect = 4
            break
          end
        end
      end

      # Change target to user of Follow Me (overrides Magic Coat
      # because check for Magic Coat below uses this target)
      if [:SingleNonUser, :SingleOpposing, :RandomOpposing, :OppositeOpposing, :DragonDarts].include?(targetchoices)
        for i in priority # use Pokémon latest in priority
          next if !pbIsOpposing?(i.index) || i.isFainted?

          if i.effects[:FollowMe] || i.effects[:RagePowder]
            unless (i.effects[:RagePowder] && (self.ability == :OVERCOAT || self.hasType?(:GRASS) || (self.hasWorkingItem(:SAFETYGOGGLES) || self.crested == :ORN_TALONFLAME))) # change target to this
              target = i
              changeeffect = 0
            end
          end
        end
      end
    end
    # TODO: Pressure here is incorrect if Magic Coat redirects target
    if target.ability == (:PRESSURE)
      pressuredmove = (basemove.zmove && !user.zmoves.nil? && user.zmoves.include?(basemove)) ? user.moves[user.zmoves.index(basemove)] : basemove
      pbReducePP(pressuredmove) # Reduce PP
      if @battle.FE == :DIMENSIONAL || @battle.FE == :DEEPEARTH
        pbReducePP(pressuredmove)
      end
    end
    # Change user to user of Snatch
    if !basemove.zmove && basemove.canSnatch?
      for i in priority
        if i.effects[:Snatch]
          @battle.pbDisplay(_INTL("{1} Snatched {2}'s move!",i.pbThis,user.pbThis(true)))
          i.effects[:Snatch]=false
          target=user
          user=i
          # Snatch's PP is reduced if old user has Pressure
          userchoice=@battle.choices[user.index][1]
          if target.ability == (:PRESSURE) && userchoice>=0
            pressuremove=user.moves[userchoice]
            pbSetPP(pressuremove,pressuremove.pp-1) if pressuremove.pp>0
            if @battle.FE == :DIMENSIONAL || @battle.FE == :DEEPEARTH
              pressuremove=user.moves[userchoice]
              pbSetPP(pressuremove,pressuremove.pp-1) if pressuremove.pp>0
            end
          end
        end
      end
    end

    statusMoveProtection = false
    if basemove.canProtect?
      statusMoveProtection = (target.pbOwnSide.effects[:QuickGuard] && basemove.priorityCheck(user) > 0) ||
                             (target.pbOwnSide.effects[:WideGuard] && [:AllOpposing, :AllNonUsers].include?(basemove.target)) ||
                             [:Protect, :BanefulBunker, :SpikyShield].include?(target.effects[:Protect]) ||
                             (target.effects[:Protect] == :KingsShield && [:FAIRYTALE, :CHESS].include?(@battle.FE)) ||
                             (target.effects[:Protect] == :Obstruct && [:DIMENSIONAL, :CHESS].include?(@battle.FE))
    end
    statusMoveProtection = true if target.pbOwnSide.effects[:CraftyShield]
    statusMoveProtection = false if target.effects[:ProtectNegation]

    userandtarget[0]=user
    userandtarget[1]=target
    if target.ability == (:SOUNDPROOF) && basemove.isSoundBased? &&
       basemove.function!=0x19 &&   # Heal Bell handled elsewhere
       basemove.function!=0xE5 &&   # Perish Song handled elsewhere
       !(target.moldbroken)
      @battle.pbDisplay(_INTL("{1}'s {2} blocks {3}!",target.pbThis,
         getAbilityName(target.ability),basemove.name))
      return false
    end
    if basemove.canMagicCoat? && target.effects[:MagicCoat] && !statusMoveProtection
      # switch user and target
      changeeffect=3
      target.effects[:MagicCoat]=false
      user, target = target, user

      # Magic Coat's PP is reduced if old user has Pressure
      userchoice = @battle.choices[user.index][1]
      if target.ability == :PRESSURE && userchoice >= 0
        pressuremove = user.moves[userchoice]
        pbSetPP(pressuremove, pressuremove.pp - 1) if pressuremove.pp > 0
        if @battle.FE == :DIMENSIONAL || @battle.FE == :DEEPEARTH
          pressuremove = user.moves[userchoice]
          pbSetPP(pressuremove, pressuremove.pp - 1) if pressuremove.pp > 0
        end
      end
    end
    if !user.effects[:MagicBounced] && basemove.canMagicCoat? && target.ability == :MAGICBOUNCE && !target.moldbroken &&
       !PBStuff::TWOTURNMOVE.include?(target.effects[:TwoTurnAttack]) && changeeffect != 3 && !statusMoveProtection
      target.effects[:MagicBounced] = true
      target.effects[:BouncedMove] = basemove
    end
    if changeeffect == 1
      @battle.pbDisplay(_INTL("{1}'s Lightning Rod took the move!", target.pbThis))
    elsif changeeffect == 2
      @battle.pbDisplay(_INTL("{1}'s Storm Drain took the move!", target.pbThis))
    elsif changeeffect == 3
      # Target refers to the move's old user
      @battle.pbDisplay(_INTL("{1}'s {2} was bounced back by Magic Coat!", user.pbThis, basemove.name))
    elsif changeeffect == 4
      @battle.pbDisplay(_INTL("{1}'s Cacophony took the move!", target.pbThis))
    end
    userandtarget[0] = user
    userandtarget[1] = target
    return true
  end

  # O.Feralgatr Crest
  def pbIncreaseStatBasic(stat, increment, mirrorable:true)
    increment *= 2 if ((self.ability == :SIMPLE) && !(self.moldbroken)) || (self.crested == :ORN_FERALIGATR)
    initial = @stages[stat]
    @stages[stat] += increment
    @stages[stat] = 6 if @stages[stat] > 6
    @effects[:Jealousy] = true
    @statsRaisedSinceLastCheck[stat] += @stages[stat] - initial if mirrorable
  end
  def pbIncreaseStat(stat, increment, abilitymessage:true, statmessage:true, ignoreContrary: false, statsource: nil, mirrorable:true)
    # Contrary handling
    if self.ability == :CONTRARY && !self.moldbroken && !ignoreContrary
      @statrepeat = true
      return pbReduceStat(stat, increment, abilitymessage: abilitymessage, statmessage: statmessage, ignoreContrary: true, statdropper: statsource, mirrorable: mirrorable)
    end

    # Increase stat only if you can
    if pbCanIncreaseStatStage?(stat, abilitymessage)
      pbIncreaseStatBasic(stat, increment, mirrorable: mirrorable)

      # Animation
      if !@statupanimplayed
        @battle.pbCommonAnimation("StatUp", self, nil)
        @statupanimplayed = true
      end

      # Battle message
      arrStatTexts = [
        _INTL("{1}'s {2} rose!", pbThis, pbGetStatName(stat)),
        _INTL("{1}'s {2} rose sharply!", pbThis, pbGetStatName(stat)),
        _INTL("{1}'s {2} rose drastically!", pbThis, pbGetStatName(stat)),
        _INTL("{1}'s {2} went way up!", pbThis, pbGetStatName(stat))
      ]
      increment *= 2 if (self.ability == :SIMPLE && !self.moldbroken) || self.crested == :ORN_FERALIGATR
      @battle.pbDisplay(_INTL("{1}'s crest is boosting it's setup capabilities!",self.pbThis)) if self.crested == :ORN_FERALIGATR
      if increment > 3
        @battle.pbDisplay(arrStatTexts[3]) if statmessage
      elsif increment == 3
        @battle.pbDisplay(arrStatTexts[2]) if statmessage
      elsif increment == 2
        @battle.pbDisplay(arrStatTexts[1]) if statmessage
      else
        @battle.pbDisplay(arrStatTexts[0]) if statmessage
      end
      @battle.reduceField if stat == PBStats::EVASION && @battle.ProgressiveFieldCheck(PBFields::CONCERT, 2, 4)
      return true
    end
    return false
  end
  def pbReduceStatBasic(stat, increment)
    increment *= 2 if ((self.ability == :SIMPLE) && !(self.moldbroken)) || (self.crested == :ORN_FERALIGATR)
    @stages[stat] -= increment
    @stages[stat] = -6 if @stages[stat] < -6
    @statLowered = true
    @effects[:LashOut] = true
  end
  def pbReduceStat(stat,increment,abilitymessage:true,statmessage:true, statdropper: nil, defiant_proc: true, mirrordrop: false, ignoreContrary: false, mirrorable: true)
    # here we play uno reverse if we have Mirror Armor
    if self.ability == :MIRRORARMOR && !mirrordrop && !self.moldbroken && statdropper != self
      if !statdropper.nil?
        if statdropper.hp != 0
          @battle.pbDisplay(_INTL("{1}'s Mirror Armor reflected the stat drop!", pbThis))
          return statdropper.pbReduceStat(stat, increment, abilitymessage: abilitymessage, statmessage: statmessage, mirrordrop: true)
        end
      else
        mirrorOpp = self.pbOppositeOpposing
        if mirrorOpp.hp != 0
          @battle.pbDisplay(_INTL("{1}'s Mirror Armor reflected the stat drop!", pbThis))
          return mirrorOpp.pbReduceStat(stat, increment, abilitymessage: abilitymessage, statmessage: statmessage, mirrordrop: true)
        elsif mirrorOpp.pbPartner.hp != 0
          @battle.pbDisplay(_INTL("{1}'s Mirror Armor reflected the stat drop!", pbThis))
          return mirrorOpp.pbPartner.pbReduceStat(stat, increment, abilitymessage: abilitymessage, statmessage: statmessage, mirrordrop: true)
        end
      end
      @battle.pbDisplay(_INTL("{1}'s Mirror Armor blocked the stat drop!", pbThis))
      return false
    end

    # here we call increase if we have contrary
    if self.ability == :CONTRARY && !ignoreContrary && !self.moldbroken
      return pbIncreaseStat(stat, increment, abilitymessage: abilitymessage, statmessage: statmessage, ignoreContrary: true)
    end

    # Reduce only if you actually can
    if pbCanReduceStatStage?(stat, abilitymessage, statdropper == self)
      pbReduceStatBasic(stat, increment)

      # Reduce animation
      if !@statdownanimplayed
        @battle.pbCommonAnimation("StatDown", self)
        @statdownanimplayed = true
      end

      # Battle message
      increment *= 2 if ((self.ability == :SIMPLE) && !(self.moldbroken)) || (self.crested == :ORN_FERALIGATR)
      harsh = ""
      harsh = "harshly " if increment == 2
      harsh = "dramatically " if increment >= 3
      stat_text = _INTL("{1}'s {2} {3}fell!", pbThis, pbGetStatName(stat), harsh)
      @battle.pbDisplay(stat_text) if statmessage

      # Defiant/Competitive boost
      if defiant_proc
        if self.ability == :DEFIANT && pbCanIncreaseStatStage?(PBStats::ATTACK) && (statdropper.nil? || self.pbIsOpposing?(statdropper.index))
          increment = 2
          increment = 3 if @battle.FE == :BACKALLEY
          pbIncreaseStat(PBStats::ATTACK, increment, statmessage: false)
          if @battle.FE == :BACKALLEY
            @battle.pbDisplay(_INTL("Defiant dramatically raised {1}'s Attack!", pbThis))
          else
            @battle.pbDisplay(_INTL("Defiant sharply raised {1}'s Attack!", pbThis))
          end
          if @battle.FE == :COLOSSEUM
            pbIncreaseStat(PBStats::DEFENSE, 2, statmessage: false)
            @battle.pbDisplay(_INTL("Defiant sharply raised {1}'s Defense!", pbThis))
          end
        end
        if self.ability == :COMPETITIVE && !(Rejuv && @battle.FE == :CHESS) && pbCanIncreaseStatStage?(PBStats::SPATK) && (statdropper.nil? || self.pbIsOpposing?(statdropper.index))
          increment = 2
          increment = 3 if @battle.FE == :CITY
          pbIncreaseStat(PBStats::SPATK, increment, statmessage: false)
          if @battle.FE == :CITY
            @battle.pbDisplay(_INTL("Competitive dramatically raised {1}'s Special Attack!", pbThis))
          else
            @battle.pbDisplay(_INTL("Competitive sharply raised {1}'s Special Attack!", pbThis))
          end
          if @battle.FE == :COLOSSEUM
            pbIncreaseStat(PBStats::SPDEF, 2, statmessage: false)
            @battle.pbDisplay(_INTL("Defiant sharply raised {1}'s Special Defense!", pbThis))
          end
        end
      end
      @battle.reduceField if (stat == PBStats::EVASION || stat == PBStats::ACCURACY) && @battle.ProgressiveFieldCheck(PBFields::CONCERT, 2, 4)
      return true
    end
    return false
  end
  
  # O.Kabuto Crest
  def pbSpeed()
    if @effects[:SpeedSwap] == 0
      speed = @speed
    else
      speed = @effects[:SpeedSwap]
    end
    stage = @stages[PBStats::SPEED] + 6
    speed = (speed * PBStats::StageMul[stage]).floor
    if @unburdened
      if self.ability != :UNBURDEN || self.item != nil
        @unburdened = false
      else
        speed = speed * 2
      end
    end
    if self.pbOwnSide.effects[:Tailwind] > 0
      speed = speed * 2
    end
   case self.ability
      when :SWIFTSWIM
        speed *= 2 if @battle.pbWeather == :RAINDANCE && !self.hasWorkingItem(:UTILITYUMBRELLA) || @battle.FE == :UNDERWATER || ([:WATERSURFACE, :MURKWATERSURFACE].include?(@battle.FE) && !self.isAirborne?)
      when :SURGESURFER
        speed *= 2 if [:ELECTERRAIN, :SHORTCIRCUIT, :UNDERWATER].include?(@battle.FE) || ([:WATERSURFACE, :MURKWATERSURFACE].include?(@battle.FE) && !self.isAirborne?) || @battle.state.effects[:ELECTERRAIN] > 0
      when :TELEPATHY
        speed *= 2 if @battle.FE == :PSYTERRAIN || @battle.state.effects[:PSYTERRAIN] > 0
      when :CHLOROPHYLL
        speed *= 2 if (@battle.pbWeather == :SUNNYDAY || @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN, 4, 5)) && !self.hasWorkingItem(:UTILITYUMBRELLA)
      when :QUICKFEET
        speed *= 1.5 if !self.status.nil? || (Rejuv && @battle.FE == :ELECTERRAIN)
      when :SANDRUSH
        speed *= 2 if @battle.pbWeather == :SANDSTORM || @battle.FE == :DESERT || @battle.FE == :ASHENBEACH
      when :SLUSHRUSH
        speed *= 2 if @battle.pbWeather == :HAIL || @battle.FE == :ICY || @battle.FE == :SNOWYMOUNTAIN || @battle.FE == :FROZENDIMENSION
      when :SLOWSTART
        speed *= 0.5 if self.turncount < 5 && @battle.FE != :DEEPEARTH
      when :QUARKDRIVE
        speed *= 1.5 if self.effects[:Quarkdrive][0] == PBStats::SPEED
      # Gen 9 Mod - Added Protosynthesis
      when :PROTOSYNTHESIS
        speed *= 1.5 if self.effects[:Protosynthesis][0] == PBStats::SPEED
    end
    case @battle.FE
      when :NEWWORLD
        speed *= 0.75 if !self.isAirborne?
      when :WATERSURFACE, :MURKWATERSURFACE
        speed *= 0.75 if !self.isAirborne? && self.ability != :SURGESURFER && self.ability != :SWIFTSWIM && !self.hasType?(:WATER)
      when :UNDERWATER
        speed *= 0.5 if !self.hasType?(:WATER) && self.ability != :SWIFTSWIM && self.ability != :STEELWORKER
    end
    if self.itemWorks?
      if self.item == :CHOICESCARF
        speed = (speed * 1.5).floor
      elsif [:MACHOBRACE, :POWERWEIGHT, :POWERBRACER, :POWERBELT, :POWERANKLET, :POWERLENS, :POWERBAND, :CANONPOWERWEIGHT, :CANONPOWERBRACER, :CANONPOWERBELT, :CANONPOWERANKLET, :CANONPOWERLENS, :CANONPOWERBAND].include?(self.item)
        speed = (speed / 2.0).floor
      elsif @battle.FE == :DEEPEARTH && self.item == :FLOATSTONE
        speed = (speed * 1.2).floor
      elsif self.item == :QUICKPOWDER && self.pokemon.species == :DITTO && !self.effects[:Transform]
        speed = (speed * 2.0).floor
      end
    end
    speed *= 1.1 if self.crested == :ORN_KABUTOPS
    speed *= 2 if self.crested == :CASTFORM && self.form == 3 && (@battle.pbWeather == :HAIL || [:ICY, :SNOWYMOUNTAIN, :FROZENDIMENSION].include?(@battle.FE))
    speed *= 2 if self.crested == :EMPOLEON && @battle.pbWeather == :HAIL || [:ICY, :SNOWYMOUNTAIN, :FROZENDIMENSION].include?(@battle.FE)
    speed *= 0.5 if self.item == :IRONBALL && @battle.FE != :DEEPEARTH
    if self.status == :PARALYSIS && self.ability != :QUICKFEET
      speed = (speed / 2.0).floor
    end
    speed = 1 if speed <= 1
    return speed.floor
  end

  def pbEffectsOnDealingDamage(move, user, target, damage, innards)
    movetypes = [move.pbType(user), *move.getSecondaryType(user)]
    # Gen 9 Mod - Store that target was hit for calculating Rage Fist damage.
    if target.damagestate.calcdamage > 0 && !target.damagestate.substitute
      @battle.addBattlerHit(target)
    end
    return if target.nil?
    return if move.basedamage == 0

    # Make the target flinch
    # needs to be checked before mummy/wandering spirit stench is check before ability change
    if target.damagestate.calcdamage > 0 && !target.damagestate.substitute
      # Gen 9 Mod - Added Covert Cloak
      if (target.ability != :SHIELDDUST || target.moldbroken) && !target.hasWorkingItem(:COVERTCLOAK)
        if (user.hasWorkingItem(:KINGSROCK) || user.hasWorkingItem(:RAZORFANG)) && !move.canFlinch?
          if @battle.pbRandom(10) == 0
            target.effects[:Flinch] = true
          end
        elsif user.ability == :STENCH && !move.canFlinch?
          if @battle.pbRandom(10) == 0 || ([:WASTELAND, :MURKWATERSURFACE, :BACKALLEY, :CITY].include?(@battle.FE) && @battle.pbRandom(10) < 2)
            target.effects[:Flinch] = true
          end
        end
      end
    end
    # Gen 9 Mod - Added Punching Glove
    if target.damagestate.calcdamage > 0 && !target.damagestate.substitute && !move.zmove && move.contactMove? && user.ability != :LONGREACH && !(user.hasWorkingItem(:PUNCHINGGLOVE) && move.punchMove?)
      eschance = 3
      eschance = 6 if @battle.FE == :CORRUPTED
      if user.ability == :POISONTOUCH && @battle.pbRandom(10) < eschance && target.pbCanPoison?(false)
        target.pbPoison(user)
        @battle.pbDisplay(_INTL("{1}'s {2} poisoned {3}!", user.pbThis, getAbilityName(user.ability), target.pbThis(true)))
      end
      # Gen 9 Mod - Added Toxic Chain
      if user.ability == :TOXICCHAIN && @battle.pbRandom(10) < eschance && target.pbCanPoison?(false)
        target.pbPoison(user, true)
        @battle.pbDisplay(_INTL("{1}'s {2} badly poisoned {3}!", user.pbThis, getAbilityName(user.ability), target.pbThis(true)))
      end
      if user.ability == :CORROSION && @battle.FE == :WASTELAND
        if @battle.pbRandom(10) == 0
          case @battle.pbRandom(4)
            when 0 then target.pbBurn(user)       if target.pbCanBurn?(false)
            when 1 then target.pbPoison(user)     if target.pbCanPoison?(false)
            when 2 then target.pbParalyze(user)   if target.pbCanParalyze?(false)
            when 3 then target.pbFreeze           if target.pbCanFreeze?(false)
          end
        end
      end
      if !user.hasWorkingItem(:PROTECTIVEPADS)
        if target.effects[:BeakBlast] && user.ability != :MAGICGUARD && !(user.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM) && user.pbCanBurn?(false)
          user.pbBurn(target)
          @battle.pbDisplay(_INTL("{1} was burned by the heat!", user.pbThis))
        end
        if target.ability == :AFTERMATH && !user.isFainted? && target.hp <= 0 && !@battle.pbCheckGlobalAbility(:DAMP) && user.ability != :MAGICGUARD && !(user.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
          PBDebug.log("[#{user.pbThis} hurt by Aftermath]")
          @battle.scene.pbDamageAnimation(user, 0)
          if @battle.FE == :CORROSIVEMIST
            user.pbReduceHP((user.totalhp / 2.0).floor)
            @battle.pbDisplay(_INTL("{1} was caught in the toxic aftermath!", user.pbThis))
          else
            user.pbReduceHP((user.totalhp / 4.0).floor)
            @battle.pbDisplay(_INTL("{1} was caught in the aftermath!", user.pbThis))
          end
        end
        if [:IRONBARBS, :ROUGHSKIN].include?(target.ability) && !user.isFainted? && user.ability != :MAGICGUARD && !(user.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
          @battle.scene.pbDamageAnimation(user, 0)
          user.pbReduceHP((user.totalhp / 8.0).floor)
          @battle.pbDisplay(_INTL("{1}'s {2} hurt {3}!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
        end
        if target.hasWorkingItem(:ROCKYHELMET, true) && !user.isFainted? && user.ability != :MAGICGUARD && !(user.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
          @battle.scene.pbDamageAnimation(user, 0)
          user.pbReduceHP((user.totalhp / 6.0).floor)
          @battle.pbDisplay(_INTL("{1} was hurt by the {2}!", user.pbThis, getItemName(target.item)))
        end
        eschance = 3
        eschance = 6 if [:FOREST, :WASTELAND, :BEWITCHED].include?(@battle.FE)
        # Effect Spore
        if !user.hasType?(:GRASS) && user.ability != :OVERCOAT && target.ability == :EFFECTSPORE && @battle.pbRandom(10) < eschance
          rnd = @battle.pbRandom(3)
          if rnd == 0 && user.pbCanPoison?(false)
            user.pbPoison(target)
            @battle.pbDisplay(_INTL("{1}'s {2} poisoned {3}!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
          elsif rnd == 1 && user.pbCanSleep?(false)
            user.pbSleep
            @battle.pbDisplay(_INTL("{1}'s {2} made {3} sleep!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
          elsif rnd == 2 && user.pbCanParalyze?(false)
            user.pbParalyze(target)
            @battle.pbDisplay(_INTL("{1}'s {2} paralyzed {3}! It may be unable to move!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
          end
        end
        if target.ability == :FLAMEBODY && @battle.pbRandom(10) < 3 && user.pbCanBurn?(false) && @battle.FE != :FROZENDIMENSION
          user.pbBurn(target)
          @battle.pbDisplay(_INTL("{1}'s {2} burned {3}!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
        end
        eschance = 3
        eschance = 6 if @battle.FE == :WASTELAND || @battle.FE == :CORRUPTED
        if target.ability == :POISONPOINT && @battle.pbRandom(10) < eschance && user.pbCanPoison?(false)
          user.pbPoison(target)
          @battle.pbDisplay(_INTL("{1}'s {2} poisoned {3}!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
        end
        eschance = 3
        eschance = 6 if @battle.FE == :SHORTCIRCUIT || (Rejuv && @battle.FE == :ELECTERRAIN)
        if target.ability == :STATIC && @battle.pbRandom(10) < eschance && user.pbCanParalyze?(false)
          user.pbParalyze(target)
          @battle.pbDisplay(_INTL("{1}'s {2} paralyzed {3}! It may be unable to move!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
        end
        if target.ability == :CUTECHARM && @battle.pbRandom(10) < 3
          if user.ability != :OBLIVIOUS &&
             ((user.gender == 1 && target.gender == 0) || (user.gender == 0 && target.gender == 1)) && user.effects[:Attract] < 0 && !user.isFainted?
            user.effects[:Attract] = target.index
            @battle.pbDisplay(_INTL("{1}'s {2} infatuated {3}!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
            if user.hasWorkingItem(:DESTINYKNOT) && target.ability != :OBLIVIOUS && target.effects[:Attract] < 0
              target.effects[:Attract] = user.index
              @battle.pbDisplay(_INTL("{1}'s {2} infatuated {3}!", user.pbThis, getItemName(user.item), target.pbThis(true)))
            end
          end
        end
        if target.ability == :PERISHBODY && user.effects[:PerishSong] == 0 && target.effects[:PerishSong] == 0 && @battle.FE != :HOLY
          if @battle.FE == :INFERNAL
            @battle.pbDisplay(_INTL("Both Pokémon will faint in one turn!"))
            user.effects[:PerishSong] = 2
            user.effects[:PerishSongUser] = target.index
            target.effects[:PerishSong] = 2
            target.effects[:PerishSongUser] = target.index
          else
            @battle.pbDisplay(_INTL("Both Pokémon will faint in three turns!"))
            user.effects[:PerishSong] = 4
            user.effects[:PerishSongUser] = target.index
            target.effects[:PerishSong] = 4
            target.effects[:PerishSongUser] = target.index
          end
          if @battle.FE == :DIMENSIONAL || @battle.FE == :HAUNTED || @battle.FE == :INFERNAL
            target.effects[:MeanLook] = user.index
            @battle.pbDisplay(_INTL("{1} can't escape now!", target.pbThis))
          end
        end
        if target.ability == :GOOEY
          if user.ability == :CONTRARY
            if @battle.FE == :SWAMP || @battle.FE == :MURKWATERSURFACE
              user.pbReduceStat(PBStats::SPEED, 2, statmessage: false, ignoreContrary: true)
              @battle.pbDisplay(_INTL("{1}'s {2} sharply boosted {3}'s Speed!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
            else
              user.pbReduceStat(PBStats::SPEED, 1, statmessage: false, ignoreContrary: true)
              @battle.pbDisplay(_INTL("{1}'s {2} boosted {3}'s Speed!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
            end
          elsif [:WHITESMOKE, :CLEARBODY, :FULLMETALBODY].include?(user.ability)
            @battle.pbDisplay(_INTL("{1}'s {2} prevents stat loss!", user.pbThis, getAbilityName(user.ability)))
          elsif @battle.FE == :SWAMP || @battle.FE == :MURKWATERSURFACE
            user.pbReduceStat(PBStats::SPEED, 2, statmessage: false, ignoreContrary: true)
            @battle.pbDisplay(_INTL("{1}'s {2} harshly lowered {3}'s Speed!", target.pbThis, getAbilityName(target.ability), user.pbThis(true))) if user.ability != :MIRRORARMOR
          else
            user.pbReduceStat(PBStats::SPEED, 1, statmessage: false, ignoreContrary: true)
            @battle.pbDisplay(_INTL("{1}'s {2} lowered {3}'s Speed!", target.pbThis, getAbilityName(target.ability), user.pbThis(true))) if user.ability != :MIRRORARMOR
          end
          if @battle.FE == :WASTELAND && user.pbCanPoison?(false)
            user.pbPoison(target)
            @battle.pbDisplay(_INTL("{1}'s {2} poisoned {3}!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
          end
        end
        if target.ability == :TANGLINGHAIR
          if user.ability == :CONTRARY
            user.pbReduceStat(PBStats::SPEED, 1, statmessage: false, ignoreContrary: true)
            @battle.pbDisplay(_INTL("{1}'s {2} boosted {3}'s Speed!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
          elsif user.ability == :WHITESMOKE || user.ability == :CLEARBODY || user.ability == :FULLMETALBODY
            @battle.pbDisplay(_INTL("{1}'s {2} prevents stat loss!", user.pbThis, getAbilityName(user.ability)))
          else
            user.pbReduceStat(PBStats::SPEED, 1, statmessage: false, ignoreContrary: true)
            @battle.pbDisplay(_INTL("{1}'s {2} lowered {3}'s Speed!", target.pbThis, getAbilityName(target.ability), user.pbThis(true))) if user.ability != :MIRRORARMOR
          end
        end
        if target.hasWorkingItem(:STICKYBARB, true) && user.item.nil? && !user.isFainted?
          user.item = target.item
          target.item = nil
          if !@battle.opponent && !@battle.pbIsOpposing?(user.index)
            if user.pokemon.itemInitial.nil? && target.pokemon.itemInitial == user.item
              user.pokemon.itemInitial = user.item
              target.pokemon.itemInitial = nil
            end
          end
          @battle.pbDisplay(_INTL("{1}'s {2} was transferred to {3}!", target.pbThis, getItemName(user.item), user.pbThis(true)))
        end
        if target.ability == :MUMMY && !user.isFainted?
          if user.ability != :MUMMY && !PBStuff::FIXEDABILITIES.include?(user.ability)
            neutralgas = true if user.ability == :NEUTRALIZINGGAS
            user.ability = :MUMMY
            user.effects[:GorillaLock] = nil
            @battle.pbDisplay(_INTL("{1} was mummified by {2}!", user.pbThis, target.pbThis(true)))
            @battle.neutralizingGasDisable(user.index) if neutralgas
          end
        end
        if target.ability == :WANDERINGSPIRIT && !user.isFainted? # && !@user.isBoss
          if ![:WANDERINGSPIRIT, :NEUTRALIZINGGAS].include?(user.ability) && !PBStuff::FIXEDABILITIES.include?(user.ability)
            tmp = user.ability
            user.ability = target.ability
            target.ability = tmp
            user.effects[:GorillaLock] = nil
            @battle.pbDisplay(_INTL("{1} swapped its {2} Ability with its target!", target.pbThis, getAbilityName(target.ability)))
            user.pbAbilitiesOnSwitchIn(true)
            target.pbAbilitiesOnSwitchIn(true)
          end
        end
        # Gen 9 Mod - Added Lingering Aroma
        if target.ability == :LINGERINGAROMA && !user.isFainted?
          if user.ability != :LINGERINGAROMA && !PBStuff::FIXEDABILITIES.include?(user.ability) && !user.hasWorkingItem(:ABILITYSHIELD) # Gen 9 Mod - Added Ability Shield
            neutralgas = true if user.ability == :NEUTRALIZINGGAS
            user.ability = :LINGERINGAROMA
            user.effects[:GorillaLock] = nil
            @battle.pbDisplay(_INTL("A lingering aroma clings to {1}!", user.pbThis))
            @battle.neutralizingGasDisable(user.index) if neutralgas
          end
        end
      end
    end
    if target.damagestate.calcdamage > 0
      if @battle.FE == :GLITCH # Glitch Field Hyper Beam Reset
        if user.hp > 0 && target.hp <= 0
          user.effects[:HyperBeam] = 0
        end
      end
      pbRecoilCalc(move, user, target, damage, innards)
      # Bastiodon Crest
      if target.crested == :BASTIODON && !target.damagestate.disguise &&
         user.ability != :MAGICGUARD && !(user.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
        user.pbReduceHP([1, (damage / 2).floor].max)
        target.pbRecoverHP([1, (damage / 2).floor].max) if !target.isFainted?
        @battle.pbDisplay(_INTL("{1}'s crest causes {2} to take recoil damage and {3} to recover!", target.pbThis, user.pbThis(true), target.pbThis))
      end
      if target.ability == :INNARDSOUT && !user.isFainted? &&
         target.hp <= 0 && user.ability != :MAGICGUARD && !(user.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
        PBDebug.log("[#{user.pbThis} hurt by Innards Out]")
        @battle.scene.pbDamageAnimation(user, 0)
        user.pbReduceHP(innards)
        @battle.pbDisplay(_INTL("{2}'s innards hurt {1}!", user.pbThis, target.pbThis))
      end
      if !target.damagestate.substitute
        if target.effects[:ShellTrap] && move.pbIsPhysical?(movetypes[0]) && user.pbOwnSide != target.pbOwnSide && !(user.ability == :SHEERFORCE && move.effect > 0)
          target.effects[:ShellTrap] = false
        end
        if (target.ability == :CURSEDBODY && @battle.FE != :HOLY && (@battle.pbRandom(10) < 3 || (target.isFainted? && @battle.FE == :HAUNTED))) || target.crested == :BEHEEYEM
          if user.effects[:Disable] <= 0 && move.pp > 0 && !user.isFainted?
            user.effects[:Disable] = 4
            user.effects[:DisableMove] = move.move
            @battle.pbDisplay(_INTL("{1}'s {2} disabled {3}!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
          end
        end
        if target.ability == :GULPMISSILE && target.species == :CRAMORANT && !user.isFainted? && target.form != 0
          @battle.scene.pbDamageAnimation(user, 0)
          if user.ability != :MAGICGUARD && !(user.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
            if @battle.FE == :UNDERWATER
              eff = PBTypes.twoTypeEff(:WATER, user.type1, user.type2)
              user.pbReduceHP((user.totalhp * eff / 16.0).floor)
            else
              user.pbReduceHP((user.totalhp / 4.0).floor)
            end
          end
          if target.form == 1 # Gulping Form
            if user.pbReduceStat(PBStats::DEFENSE, 1, abilitymessage: false, statdropper: target)
              if user.ability == :CONTRARY
                @battle.pbDisplay(_INTL("{1}'s {2} raised {3}'s Defense!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
              else
                @battle.pbDisplay(_INTL("{1}'s {2} lowered {3}'s Defense!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
              end
            end
          elsif target.form == 2 # Gorging Form
            if user.pbCanParalyze?(false)
              user.pbParalyze(target)
              @battle.pbDisplay(_INTL("{1}'s {2} paralyzed {3}! It may be unable to move!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
            end
          end
          @battle.pbDisplay(_INTL("{1}'s {2} hurt {3}!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
          target.form = 0
          target.pbUpdate(false)
          @battle.scene.pbChangePokemon(target, target.pokemon)
          @battle.pbDisplay(_INTL("{1} returned to normal!", target.pbThis))
        end
        if target.effects[:Illusion] != nil
          target.effects[:Illusion] = nil
          @battle.pbAnimation(:TRANSFORM, target, target) if !target.isFainted?
          @battle.scene.pbChangePokemon(target, target.pokemon)
          @battle.pbDisplay(_INTL("{1}'s {2} was broken!", target.pbThis, getAbilityName(:ILLUSION)))
        end
        if target.ability == :JUSTIFIED && movetypes.include?(:DARK)
          if target.pbCanIncreaseStatStage?(PBStats::ATTACK)
            stat = @battle.FE == :HOLY ? 2 : 1
            target.pbIncreaseStatBasic(PBStats::ATTACK, stat)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s {2} raised its Attack!", target.pbThis, getAbilityName(target.ability)))
          end
        end
        if target.ability == :RATTLED && [:BUG, :DARK, :GHOST].intersect?(movetypes)
          if target.pbCanIncreaseStatStage?(PBStats::SPEED)
            target.pbIncreaseStatBasic(PBStats::SPEED, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s {2} raised its Speed!", target.pbThis, getAbilityName(target.ability)))
          end
        end
        if target.ability == :WEAKARMOR && move.pbIsPhysical?(movetypes[0])
          if target.pbCanReduceStatStage?(PBStats::DEFENSE, false, true)
            target.pbReduceStatBasic(PBStats::DEFENSE, 1)
            @battle.pbCommonAnimation("StatDown", target, nil)
            @battle.pbDisplay(_INTL("{1}'s {2} lowered its Defense!", target.pbThis, getAbilityName(target.ability)))
          end
          if target.pbCanIncreaseStatStage?(PBStats::SPEED)
            target.pbIncreaseStatBasic(PBStats::SPEED, 2)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s {2} sharply raised its Speed!", target.pbThis, getAbilityName(target.ability)))
          end
        end
        # Gen 9 Mod - Added Toxic Debris.
        if target.ability == (:TOXICDEBRIS) && target.pbOpposingSide.effects[:ToxicSpikes] < 2 && move.pbIsPhysical?(movetypes) && !(@battle.FE == :WATERS || @battle.FE == :MURKWATERS)
           target.pbOpposingSide.effects[:ToxicSpikes] += 1
          if !@battle.pbIsOpposing?(target.index)
             @battle.pbDisplay(_INTL("Poison spikes were scattered all around the foe's team's feet!"))
          else
             @battle.pbDisplay(_INTL("Poison spikes were scattered all around your team's feet!"))
          end
        end
        if target.ability == :STAMINA
          if target.pbCanIncreaseStatStage?(PBStats::DEFENSE)
            target.pbIncreaseStatBasic(PBStats::DEFENSE, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s {2} raised its Defense!", target.pbThis, getAbilityName(target.ability)))
          end
        end
        if target.crested == :NOCTOWL
          if target.pbCanIncreaseStatStage?(PBStats::SPDEF)
            target.pbIncreaseStatBasic(PBStats::SPDEF, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s Crest raised its Special Defense!", target.pbThis))
          end
        end
        if target.ability == :WATERCOMPACTION && movetypes.include?(:WATER)
          if @battle.FE != :ASHENBEACH
            if target.pbCanIncreaseStatStage?(PBStats::DEFENSE)
              target.pbIncreaseStatBasic(PBStats::DEFENSE, 2)
              @battle.pbCommonAnimation("StatUp", target, nil)
              @battle.pbDisplay(_INTL("{1}'s Water Compaction sharply raised its Defense!", target.pbThis, getAbilityName(target.ability)))
            end
          else
            boost = false
            if target.pbCanIncreaseStatStage?(PBStats::DEFENSE)
              target.pbIncreaseStatBasic(PBStats::DEFENSE, 2)
              @battle.pbCommonAnimation("StatUp", target, nil) if !boost
              boost = true
            end
            if target.pbCanIncreaseStatStage?(PBStats::SPDEF)
              target.pbIncreaseStatBasic(PBStats::SPDEF, 2)
              @battle.pbCommonAnimation("StatUp", target, nil) if !boost
              boost = true
            end
            @battle.pbDisplay(_INTL("{1}'s {2} sharply raised its Defense and Special Defense!", target.pbThis, getAbilityName(target.ability))) if boost
          end
        end
        # Cotton Down
        if target.ability == :COTTONDOWN
          @battle.pbDisplay(_INTL("{1}'s {2} scatters cotton around!", target.pbThis, getAbilityName(target.ability)))
          for i in @battle.battlers
            next if i == target
            statdrop = 1
            statdrop = 2 if @battle.FE == :BEWITCHED || @battle.FE == :GRASSY
            if i.pbReduceStat(PBStats::SPEED, statdrop, abilitymessage: false)
              @battle.pbDisplay(_INTL("The cotton reduces {1}'s Speed!", i.pbThis)) if i.ability != :MIRRORARMOR
            end
          end
        end
        # Sand Spit
        if target.ability == :SANDSPIT
          if !(@battle.state.effects[:HeavyRain] || @battle.state.effects[:HarshSunlight] ||
             @battle.weather == :STRONGWINDS || @battle.weather == :SANDSTORM || [:NEWWORLD, :UNDERWATER, :DIMENSIONAL].include?(@battle.FE))
            @battle.pbAnimation(:SANDSTORM, self, nil)
            @battle.weather = :SANDSTORM
            @battle.weatherduration = 5
            @battle.weatherduration = 8 if target.hasWorkingItem(:SMOOTHROCK) || [:DESERT, :ASHENBEACH, :SKY].include?(@battle.FE)
            @battle.pbCommonAnimation("Sandstorm")
            @battle.pbDisplay(_INTL("A sandstorm brewed!"))
            if [:DESERT, :ASHENBEACH].include?(@battle.FE) && user.pbCanReduceStatStage?(PBStats::ACCURACY)
              user.pbReduceStatBasic(PBStats::ACCURACY, 1)
              @battle.pbCommonAnimation("StatDown", user, nil)
              @battle.pbDisplay(_INTL("{1}'s accuracy fell!", user.pbThis))
            end
          end
        end
        # Steam Engine
        if target.ability == :STEAMENGINE && [:WATER, :FIRE].intersect?(movetypes)
          if target.pbCanIncreaseStatStage?(PBStats::SPEED)
            target.pbIncreaseStatBasic(PBStats::SPEED, 6)
            @battle.pbCommonAnimation("StatUp", target)
            @battle.pbDisplay(_INTL("{1}'s {2} drastically raised its Speed!", target.pbThis, getAbilityName(target.ability)))
          end
        end
        if target.hasWorkingItem(:ABSORBBULB) && movetypes.include?(:WATER)
          if target.pbIncreaseStat(PBStats::SPATK, 1, statmessage: false, statsource: target)
            if target.ability == :CONTRARY && !target.moldbroken
              @battle.pbDisplay(_INTL("{1}'s {2} lowered its Special Attack!", target.pbThis, getItemName(target.item)))
            else
              @battle.pbDisplay(_INTL("{1}'s {2} raised its Special Attack!", target.pbThis, getItemName(target.item)))
            end
            target.pbDisposeItem(false)
          end
        end
        if (target.hasWorkingItem(:SNOWBALL) && movetypes.include?(:ICE)) || (target.hasWorkingItem(:CELLBATTERY) && movetypes.include?(:ELECTRIC))
          if target.pbIncreaseStat(PBStats::ATTACK, 1, statmessage: false, statsource: target)
            if target.ability == :CONTRARY && !target.moldbroken
              @battle.pbDisplay(_INTL("{1}'s {2} lowered its Attack!", target.pbThis, getItemName(target.item)))
            else
              @battle.pbDisplay(_INTL("{1}'s {2} raised its Attack!", target.pbThis, getItemName(target.item)))
            end
            target.pbDisposeItem(false)
          end
        end
        if target.hasWorkingItem(:LUMINOUSMOSS) && movetypes.include?(:WATER)
          if target.pbIncreaseStat(PBStats::SPDEF, 1, statmessage: false, statsource: target)
            if target.ability == :CONTRARY && !target.moldbroken
              @battle.pbDisplay(_INTL("{1}'s {2} lowered its Special Defense!", target.pbThis, getItemName(target.item)))
            else
              @battle.pbDisplay(_INTL("{1}'s {2} raised its Special Defense!", target.pbThis, getItemName(target.item)))
            end
            target.pbDisposeItem(false)
          end
        end
        if !([:UNNERVE, :ASONECHILLING, :ASONEGRIM].include?(user.ability) || [:UNNERVE, :ASONECHILLING, :ASONEGRIM].include?(user.pbPartner.ability))
          if target.hasWorkingItem(:KEEBERRY) && move.pbIsPhysical?(movetypes[0]) && user.ability != :SHEERFORCE
            if target.pbCanIncreaseStatStage?(PBStats::DEFENSE)
              @battle.pbCommonAnimation("Nom", target)
              target.pbIncreaseStat(PBStats::DEFENSE, 1, statmessage: false, statsource: target)
              if target.ability == :CONTRARY && !target.moldbroken
                @battle.pbDisplay(_INTL("{1}'s {2} lowered its Defense!", target.pbThis, getItemName(target.item)))
              else
                @battle.pbDisplay(_INTL("{1}'s {2} raised its Defense!", target.pbThis, getItemName(target.item)))
              end
              target.pbDisposeItem(true)
            end
          end

          if target.hasWorkingItem(:MARANGABERRY) && move.pbIsSpecial?(movetypes[0]) && user.ability != :SHEERFORCE
            if target.pbCanIncreaseStatStage?(PBStats::SPDEF)
              @battle.pbCommonAnimation("Nom", target)
              target.pbIncreaseStat(PBStats::SPDEF, 1, statmessage: false, statsource: target)
              if target.ability == :CONTRARY && !target.moldbroken
                @battle.pbDisplay(_INTL("{1}'s {2} lowered its Special Defense!", target.pbThis, getItemName(target.item)))
              else
                @battle.pbDisplay(_INTL("{1}'s {2} raised its Special Defense!", target.pbThis, getItemName(target.item)))
              end
              target.pbDisposeItem(true)
            end
          end

          if target.hasWorkingItem(:JABOCABERRY, true) && !user.isFainted? && move.pbIsPhysical?(movetypes[0])
            @battle.pbCommonAnimation("Nom", target)
            @battle.scene.pbDamageAnimation(user, 0)
            user.pbReduceHP((user.totalhp / 8.0).floor)
            @battle.pbDisplay(_INTL("{1} was hurt by the {2}!", user.pbThis, getItemName(target.item)))
            target.pbDisposeItem(true)
          end
          if target.hasWorkingItem(:ROWAPBERRY, true) && !user.isFainted? && move.pbIsSpecial?(movetypes[0])
            @battle.pbCommonAnimation("Nom", target)
            @battle.scene.pbDamageAnimation(user, 0)
            user.pbReduceHP((user.totalhp / 8.0).floor)
            @battle.pbDisplay(_INTL("{1} was hurt by the {2}!", user.pbThis, getItemName(target.item)))
            target.pbDisposeItem(true)
          end
        end
        if target.hasWorkingItem(:WEAKNESSPOLICY) && target.damagestate.typemod > 4
          if target.pbIncreaseStat(PBStats::ATTACK, 2, statmessage: false, statsource: target)
            if target.ability == :CONTRARY && !target.moldbroken
              @battle.pbDisplay(_INTL("{1}'s {2} harshly lowered its Attack!", target.pbThis, getItemName(:WEAKNESSPOLICY)))
            else
              @battle.pbDisplay(_INTL("{1}'s {2} sharply raised its Attack!", target.pbThis, getItemName(:WEAKNESSPOLICY)))
            end
            target.pbDisposeItem(false)
          end
          if target.pbIncreaseStat(PBStats::SPATK, 2, statmessage: false, statsource: target)
            if target.ability == :CONTRARY && !target.moldbroken
              @battle.pbDisplay(_INTL("{1}'s {2} harshly lowered its Special Attack!", target.pbThis, getItemName(:WEAKNESSPOLICY)))
            else
              @battle.pbDisplay(_INTL("{1}'s {2} sharply raised its Special Attack!", target.pbThis, getItemName(:WEAKNESSPOLICY)))
            end
            target.pbDisposeItem(false)
          end
        end
        if target.ability == :ANGERPOINT
          if target.pbCanIncreaseStatStage?(PBStats::ATTACK) && target.damagestate.critical
            target.stages[PBStats::ATTACK] = 6
            @battle.pbCommonAnimation("StatUp", target)
            @battle.pbDisplay(_INTL("{1}'s {2} maxed its Attack!", target.pbThis, getAbilityName(target.ability)))
          end
        end
        if target.effects[:Rage] && target.pbIsOpposing?(user.index)
          # TODO: Apparently triggers if opposing Pokémon uses Future Sight after a Future Sight attack
          if target.pbCanIncreaseStatStage?(PBStats::ATTACK)
            target.pbIncreaseStatBasic(PBStats::ATTACK, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s rage is building!", target.pbThis))
          end
        end
      end
      # Gen 9 Mod - Thermal Exchange
      if !target.damagestate.substitute
        if target.ability == (:THERMALEXCHANGE) && (movetypes == :FIRE)
          if target.pbCanIncreaseStatStage?(PBStats::ATTACK)
            target.pbIncreaseStatBasic(PBStats::ATTACK, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s {2} raised its Attack!", target.pbThis, getAbilityName(target.ability)))
          end
        end
      end
      # Gen 9 Mod - Wind Power
      if target.ability == (:WINDPOWER) && move.windMove?
        # Gen 9 Mod - Charge lasts until the user uses an electric move.
        if target.effects[:Charge] == false
          target.effects[:Charge] = true
          @battle.pbCommonAnimation("Charge", target, nil)
        end
        @battle.pbDisplay(_INTL("Being hit by {1} charged {2} with power!",move.name, target.pbThis))
      end
      # Gen 9 Mod - Electromorphosis
      # Gen 9 Mod - Charge lasts until the user uses an electric move.
      if target.ability == (:ELECTROMORPHOSIS)
        if target.effects[:Charge] == false
          target.effects[:Charge] = true
          @battle.pbCommonAnimation("Charge", target, nil)
        end
        @battle.pbDisplay(_INTL("Being hit by {1} charged {2} with power!", move.name, target.pbThis))
      end
      # Gen 9 Mod - Seed Sower
      if target.ability == (:SEEDSOWER)
        if ((@battle.canChangeFE?(:GRASSY)) || @battle.canChangeFE?([:GRASSY,:DRAGONSDEN])) && !(@battle.state.effects[:GRASSY] > 0)
          if @battle.FE == :FROZENDIMENSION
            @battle.pbDisplay(_INTL("The frozen dimension remains unchanged."))
          else
            duration = 5
            duration = 8 if self.hasWorkingItem(:AMPLIFIELDROCK)
            @battle.pbAnimation(:GRASSYTERRAIN, self, nil)
            @battle.setField(:GRASSY, duration)
            @battle.pbDisplay(_INTL("The terrain became grassy!"))
          end
        end
      end
      if target.hasWorkingItem(:AIRBALLOON, true)
        target.pbDisposeItem(false, true, false)
        @battle.pbDisplay(_INTL("{1}'s Air Balloon popped!", target.pbThis))
      end
    end
    if !target.effects[:ItemRemoval].nil?
      if target.item
        if target.ability == :STICKYHOLD && !target.moldbroken
          abilityname = getAbilityName(target.ability)
          @battle.pbDisplay(_INTL("{1}'s {2} made {3} ineffective!", target.pbThis, abilityname, basemove.name))
        elsif target.effects[:ItemRemoval] == :Remove && !@battle.pbIsUnlosableItem(target, target.item)
          target.effects[:ChoiceBand] = nil
          # Knocking of the item
          itemname = getItemName(target.item)
          target.item = nil
          target.pokemon.corrosiveGas = false
          @battle.pbDisplay(_INTL("{1} knocked off {2}'s {3}!", user.pbThis, target.pbThis(true), itemname))
        elsif target.effects[:ItemRemoval] == :Steal && !@battle.pbIsUnlosableItem(target, target.item) && !@battle.pbIsUnlosableItem(user, target.item) && user.item.nil?
          itemname = getItemName(target.item)
          user.item = target.item
          target.item = nil
          if target.pokemon.corrosiveGas
            target.pokemon.corrosiveGas = false
            user.pokemon.corrosiveGas = true
          end
          target.effects[:ChoiceBand] = nil
          # In a wild battle
          if !@battle.opponent && user.pokemon.itemInitial.nil? && target != user.pbPartner && target.pokemon.itemInitial == user.item && !target.isbossmon && !user.isbossmon
            user.pokemon.itemInitial = user.item
            user.pokemon.itemReallyInitialHonestlyIMeanItThisTime = user.item
            target.pokemon.itemInitial = nil
          end
          if @move == :THIEF
            @battle.pbCommonAnimation("Thief", user, target)
          else
            @battle.pbCommonAnimation("Covet", user, target)
          end
          @battle.pbDisplay(_INTL("{1} stole {2}'s {3}!", user.pbThis, target.pbThis(true), itemname))
        end
      end
      target.effects[:ItemRemoval] = nil
    end
  end

  def pbRecoilCalc(move, user, target, damage, innards)
    if move.recoil > 0 && !target.damagestate.disguise && user.item != :ORN_BODYARMOR && 
      ![:ORN_RAPIDASH,:ORN_ARCANINE,:ORN_TALONFLAME,:ORN_MEGANIUM].include?(user.crested)
       user.ability != :ROCKHEAD && user.crested != :RAMPARDOS && user.ability != :MAGICGUARD &&
       !(move.move == :WILDCHARGE && @battle.FE == :ELECTERRAIN) && !(user.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
      recoilmultiplier = move.recoil
      recoilmultiplier = 0.25 if move.move == :WAVECRASH && (@battle.FE == :WATERSURFACE || @battle.FE == :UNDERWATER)
      recoildamage = [1, (damage * recoilmultiplier).floor].max
      user.pbReduceHP(recoildamage)
      @battle.pbDisplay(_INTL("{1} is damaged by the recoil!", user.pbThis))
    end
    if move.recoil > 0 && !target.damagestate.disguise && [:ORN_RAPIDASH,:ORN_MEGANIUM].include?(user.crested)
      recoilmultiplier = move.recoil
      recoilmultiplier = 0.25 if move.move == :WAVECRASH && (@battle.FE == :WATERSURFACE || @battle.FE == :UNDERWATER)
      recoildamage = [1, (damage * recoilmultiplier).floor].max
      user.pbRecoverHP(recoildamage)
      @battle.pbDisplay(_INTL("{1}'s crest has turned recoil damage into health!", user.pbThis)) if user.crested == :ORN_RAPIDASH
      @battle.pbDisplay(_INTL("{1}'s crest converted the damage to regrowth!", user.pbThis)) if user.crested == :ORN_MEGANIUM
    end
  end
end

class PokeBattle_Battle
  def pbEndOfRoundPhase
    for i in 0...4
      if @battlers[i].effects[:ShellTrap] && !pbChoseMoveFunctionCode?(i, 0x16B)
        pbDisplay(_INTL("{1}'s Shell Trap didn't work.", @battlers[i].name))
      end
    end
    for i in 0...4
      @battlers[i].forcedSwitchEarlier = false
      next if @battlers[i].hp <= 0

      @battlers[i].damagestate.reset
      @battlers[i].midwayThroughMove = false
      @battlers[i].forcedSwitchEarlier = false
      @battlers[i].effects[:Protect] = false
      @battlers[i].effects[:ProtectNegation] = false
      @battlers[i].effects[:Endure] = false
      @battlers[i].effects[:HyperBeam] -= 1 if @battlers[i].effects[:HyperBeam] > 0
      @battlers[i].effects[:BeakBlast] = false
      @battlers[i].effects[:ShellTrap] = false
      @battlers[i].effects[:ShellTrapTarget] = -1
      if (@field.effect == :BURNING || @field.effect == :VOLCANIC || @field.effect == :INFERNAL) && @battlers[i].effects[:BurnUp] # Burning/Volcanic Field
        @battlers[i].type1 = @battlers[i].pokemon.type1
        @battlers[i].type2 = @battlers[i].pokemon.type2
        @battlers[i].effects[:BurnUp] = false
      end
      @battlers[i].effects[:Powder] = false
      @battlers[i].effects[:MeFirst] = false
      @battlers[i].effects[:Jealousy] = false
      @battlers[i].effects[:LashOut] = false
      @battlers[i].effects[:HelpingHand] = false
      @battlers[i].effects[:MagicCoat] = false
      @battlers[i].effects[:QuickDrawSnipe] = false
      @battlers[i].effects[:ThroatChop] -= 1 if @battlers[i].effects[:ThroatChop] > 0
      @battlers[i].itemUsed = false
      @battlers[i].effects[:SyrupBomb] -= 1     if @battlers[i].effects[:SyrupBomb] > 0 # Gen 9 Mod - Added Syrup Bomb effects.
      @battlers[i].effects[:SyrupBomb] = 0    if @battlers[i].effects[:SyrupBombUser] == -1 # Gen 9 Mod - Added Syrup Bomb effects.
    end
    @state.effects[:IonDeluge] = false
    @state.effects[:Round] = false
    for i in 0...2
      sides[i].resetProtect
    end
    @usepriority = false # recalculate priority
    priority = pbPriority
    if @trickroom > 0
      @trickroom = @trickroom - 1 if @field.effect != :FROZENDIMENSION
      if @trickroom == 0
        pbDisplay("The twisted dimensions returned to normal!")
      end
    end
    if @state.effects[:WonderRoom] > 0
      @state.effects[:WonderRoom] -= 1 if @field.effect != :FROZENDIMENSION
      if @state.effects[:WonderRoom] == 0
        for i in @battlers
          if i.wonderroom
            i.pbSwapDefenses
          end
        end
        pbDisplay("Wonder Room wore off, and the Defense and Sp. Def stats returned to normal!")
      end
    end
    priority = pbPriority
    # Field Effects
    endmessage = false
    for i in priority
      next if i.isFainted?

      if i.crested == :VESPIQUEN
        mon = i
        if mon.effects[:VespiCrest] == false
          if mon.totalhp != mon.hp
            pbDisplay(_INTL("Vespiquen's swarm patched up her injuries!", i.pbThis)) if endmessage == false
            endmessage = true
            hpgain = (mon.totalhp / 16).floor
            hpgain = mon.pbRecoverHP(hpgain, true)
          end
        end
      end
    end
    for i in priority
      next if i.isFainted?

      case @field.effect
        when :ELECTERRAIN # Electric Terrain
          next if i.hp <= 0

          if i.ability == :VOLTABSORB && i.effects[:HealBlock] == 0 && Rejuv
            hpgain = (i.totalhp / 16.0).floor
            hpgain = i.pbRecoverHP(hpgain, true)
            pbDisplay(_INTL("{1} absorbed stray electricity!", i.pbThis)) if hpgain > 0
          end
        when :GRASSY # Grassy Field
          next if i.hp <= 0

          if !i.isAirborne? && i.effects[:HealBlock] == 0 && !PBStuff::TWOTURNMOVE.include?(i.effects[:TwoTurnAttack]) && i.totalhp != i.hp
            pbDisplay(_INTL("The grassy terrain healed the Pokémon on the field.", i.pbThis)) if !endmessage
            endmessage = true
            hpgain = (i.totalhp / 16.0).floor
            hpgain = i.pbRecoverHP(hpgain, true)
          end
          if i.ability == :SAPSIPPER && i.effects[:HealBlock] == 0
            hpgain = (i.totalhp / 16.0).floor
            hpgain = i.pbRecoverHP(hpgain, true)
            pbDisplay(_INTL("{1} drank tree sap to recover!", i.pbThis)) if hpgain > 0
          end
        when :BURNING, :VOLCANIC, :INFERNAL # Burning Field
          next if i.hp <= 0

          if !i.isAirborne?
            if i.ability == :FLASHFIRE
              if !i.effects[:FlashFire]
                i.effects[:FlashFire] = true
                pbDisplay(_INTL("{1}'s {2} raised its Fire power!", i.pbThis, getAbilityName(i.ability)))
              end
            end
            if i.burningFieldPassiveDamage?
              eff = PBTypes.twoTypeEff(:FIRE, i.type1, i.type2)
              if eff > 0
                @scene.pbDamageAnimation(i, 0)
                if [:LEAFGUARD, :ICEBODY, :FLUFFY, :GRASSPELT].include?(i.ability)
                  eff = eff * 2
                end
                eff = eff * 2 if i.effects[:TarShot]
                pbDisplay(_INTL("The Pokémon were burned by the field!", i.pbThis)) if !endmessage
                endmessage = true
                i.pbReduceHP([(i.totalhp * eff / 32).floor, 1].max)
                if i.hp <= 0
                  return if !i.pbFaint
                end
              end
            end
          end
          if @field.effect == :INFERNAL
            if i.effects[:Torment] == true
              @scene.pbDamageAnimation(i, 0)
              i.pbReduceHP((i.totalhp / 8).floor)
              pbDisplay(_INTL("{1} is damaged by Torment!", i.pbThis))
            end
          end
        when :CORROSIVE # Corrosive Field
          next if i.hp <= 0

          if i.ability == :GRASSPELT
            @scene.pbDamageAnimation(i, 0)
            i.pbReduceHP((i.totalhp / 8.0).floor)
            pbDisplay(_INTL("{1}'s Pelt was corroded!", i.pbThis))
            if i.hp <= 0
              return if !i.pbFaint
            end
          end
        when :CORROSIVEMIST # Corrosive Mist Field
          if i.pbCanPoison?(false, true) && !@battle.pbCheckGlobalAbility(:NEUTRALIZINGGAS)
            pbDisplay(_INTL("The Pokémon were poisoned by the corrosive mist!", i.pbThis)) if !endmessage
            endmessage = true
            i.pbPoison(i)
          end
        when :FOREST # Forest Field
          next if i.hp <= 0

          if i.ability == :SAPSIPPER && i.effects[:HealBlock] == 0
            hpgain = (i.totalhp / 16.0).floor
            hpgain = i.pbRecoverHP(hpgain, true)
            pbDisplay(_INTL("{1} drank tree sap to recover!", i.pbThis)) if hpgain > 0
          end
        when :VOLCANICTOP
          eruptionChecker if @state.effects[:HarshSunlight]
          # eruption check - insane, too much, but makes typh op, so i no question
          next if i.hp <= 0

          if @eruption
            if i.hasType?(:FIRE) ||
               i.ability == :MAGMAARMOR || i.ability == :FLASHFIRE ||
               i.ability == :FLAREBOOST || i.ability == :BLAZE ||
               i.ability == :FLAMEBODY || i.ability == :SOLIDROCK ||
               i.ability == :STURDY || i.ability == :BATTLEARMOR ||
               i.ability == :SHELLARMOR || i.ability == :WATERBUBBLE ||
               i.ability == :MAGICGUARD || i.ability == :WONDERGUARD ||
               i.ability == :PRISMARMOR || i.effects[:AquaRing] ||
               i.pbOwnSide.effects[:WideGuard] || (i.pbOwnSide.effects[:AreniteWall] > 0)
              pbDisplay(_INTL("{1} is immune to the eruption!", i.pbThis))
            else
              eff = PBTypes.twoTypeEff(:FIRE, i.type1, i.type2)
              eff /= 2 if i.ability == :THICKFAT
              eff *= 2 if i.effects[:TarShot]
              @scene.pbDamageAnimation(i, 0)
              i.pbReduceHP([(i.totalhp * (eff / 32.0)).floor, 1].max)
              pbDisplay(_INTL("{1} is hurt by the eruption!", i.pbThis))
              if i.hp <= 0
                return if !i.pbFaint
              end
            end
            if i.ability == :MAGMAARMOR
              boost = false
              if !i.pbTooHigh?(PBStats::DEFENSE)
                i.pbIncreaseStatBasic(PBStats::DEFENSE, 1)
                pbCommonAnimation("StatUp", i, nil)
                boost = true
              end
              if !i.pbTooHigh?(PBStats::SPDEF)
                i.pbIncreaseStatBasic(PBStats::SPDEF, 1)
                pbCommonAnimation("StatUp", i, nil)
                boost = true
              end
              if boost
                pbDisplay(_INTL("{1}'s Magma Armor raised its defenses!", i.pbThis))
              end
            end
            if i.ability == :FLAREBOOST
              if !i.pbTooHigh?(PBStats::SPATK)
                i.pbIncreaseStatBasic(PBStats::SPATK, 1)
                pbCommonAnimation("StatUp", i, nil)
                pbDisplay(_INTL("{1}'s Flare Boost raised its Sp. Attack!", i.pbThis))
              end
            end
            if i.ability == :FLASHFIRE
              if !i.effects[:FlashFire]
                i.effects[:FlashFire] = true
                pbDisplay(_INTL("{1}'s {2} raised its Fire power!", i.pbThis, getAbilityName(i.ability)))
              end
            end
            if i.ability == :BLAZE
              if !i.effects[:Blazed]
                i.effects[:Blazed] = true
                pbDisplay(_INTL("{1}'s {2} raised its Fire power!", i.pbThis, getAbilityName(i.ability)))
              end
            end
            if i.status == :SLEEP && i.ability != :SOUNDPROOF
              i.pbCureStatus
              pbDisplay(_INTL("{1} woke up due to the eruption!", i.pbThis))
            end
            if i.effects[:LeechSeed] >= 0
              i.effects[:LeechSeed] = -1
              pbDisplay(_INTL("{1}'s Leech Seed burned away in the eruption!", i.pbThis))
            end
          end
        # eruption check - insane, too much, but makes typh op, so i no question
        when :SHORTCIRCUIT # Shortcircuit Field
          next if i.hp <= 0

          if i.ability == :VOLTABSORB && i.effects[:HealBlock] == 0
            hpgain = (i.totalhp / 16.0).floor
            hpgain = i.pbRecoverHP(hpgain, true)
            pbDisplay(_INTL("{1} absorbed stray electricity!", i.pbThis)) if hpgain > 0
          end
        when :WATERSURFACE # Water Surface
          next if i.hp <= 0

          if (i.ability == :WATERABSORB || i.ability == :DRYSKIN) && i.effects[:HealBlock] == 0 && !i.isAirborne?
            hpgain = (i.totalhp / 16.0).floor
            hpgain = i.pbRecoverHP(hpgain, true)
            pbDisplay(_INTL("{1} absorbed some of the water!", i.pbThis)) if hpgain > 0
          end
          if i.effects[:TarShot] == true
            i.effects[:TarShot] = false
            pbDisplay(_INTL("The tar washed off {1} in the water!", i.pbThis))
          end
        when :UNDERWATER
          next if i.hp <= 0

          if i.effects[:TarShot] == true
            i.effects[:TarShot] = false
            pbDisplay(_INTL("The tar washed off {1} in the water!", i.pbThis))
          end
          if (i.ability == :WATERABSORB || i.ability == :DRYSKIN) && i.effects[:HealBlock] == 0
            hpgain = (i.totalhp / 16.0).floor
            hpgain = i.pbRecoverHP(hpgain, true)
            pbDisplay(_INTL("{1} absorbed some of the water!", i.pbThis)) if hpgain > 0
          end
          if i.underwaterFieldPassiveDamamge?
            eff = PBTypes.twoTypeEff(:WATER, i.type1, i.type2)
            if eff > 4
              @scene.pbDamageAnimation(i, 0)
              if i.ability == :FLAMEBODY || i.ability == :MAGMAARMOR
                eff = eff * 2
              end
              i.pbReduceHP([(i.totalhp * eff / 32).floor, 1].max)
              pbDisplay(_INTL("{1} struggled in the water!", i.pbThis))
              if i.hp <= 0
                return if !i.pbFaint
              end
            end
          end
        when :MURKWATERSURFACE # Murkwater Surface
          if i.murkyWaterSurfacePassiveDamage?
            eff = PBTypes.twoTypeEff(:POISON, i.type1, i.type2)
            if i.ability == :FLAMEBODY || i.ability == :MAGMAARMOR || i.ability == :DRYSKIN || i.ability == :WATERABSORB
              eff = eff * 2
            end
            if !$cache.moves[i.effects[:TwoTurnAttack]].nil? &&
               $cache.moves[i.effects[:TwoTurnAttack]].function == 0xCB # Dive
              @scene.pbDamageAnimation(i, 0)
              i.pbReduceHP([(i.totalhp * eff / 8).floor, 1].max)
              pbDisplay(_INTL("{1} suffocated underneath the toxic water!", i.pbThis))
            elsif !i.isAirborne?
              @scene.pbDamageAnimation(i, 0)
              i.pbReduceHP([(i.totalhp * eff / 32).floor, 1].max)
              pbDisplay(_INTL("{1} is hurt by the toxic water!", i.pbThis))
            end
          end
          if i.isFainted?
            return if !i.pbFaint
          end
          if (i.hasType?(:POISON) && (i.ability == :DRYSKIN || i.ability == :WATERABSORB)) && !i.isAirborne? && i.effects[:HealBlock] == 0 && i.hp < i.totalhp
            pbCommonAnimation("Poison", i, nil)
            i.pbRecoverHP((i.totalhp / 8.0).floor, true)
            pbDisplay(_INTL("{1} is healed by the poisoned water!", i.pbThis))
          end
        when :DIMENSIONAL # Dimension Field (Rejuv)
          if i.effects[:HealBlock] != 0
            @scene.pbDamageAnimation(i, 0)
            i.pbReduceHP((i.totalhp / 16).floor)
            pbDisplay(_INTL("{1} is damaged by the Heal Block!", i.pbThis))
            if i.hp <= 0
              return if !i.pbFaint
            end
          end
        when :CORRUPTED # Corrupted Cave Field (Rejuv)
          next if i.hp <= 0

          if i.ability == :GRASSPELT || i.ability == :LEAFGUARD || i.ability == :FLOWERVEIL
            @scene.pbDamageAnimation(i, 0)
            i.pbReduceHP((i.totalhp / 8).floor)
            pbDisplay(_INTL("{1}'s foliage caused harm!", i.pbThis))
            if i.hp <= 0
              return if !i.pbFaint
            end
          end
          if !i.isAirborne? && !i.hasType?(:POISON) && i.ability != :WONDERSKIN && i.ability != :IMMUNITY && i.ability != :PASTELVEIL
            if i.pbCanPoison?(false, true)
              pbDisplay(_INTL("{1} was poisoned!", i.pbThis)) if endmessage == false
              endmessage = true
              i.pbPoison(i)
            end
          end
        when :BEWITCHED # Bewitched Woods (Rejuv)
          next if i.hp <= 0

          if !i.isAirborne? && i.hasType?(:GRASS) && i.effects[:HealBlock] == 0 && i.totalhp != i.hp
            pbDisplay(_INTL("The woods healed the grass Pokemon on the field.", i.pbThis)) if !endmessage
            endmessage = true
            hpgain = (i.totalhp / 16.0).floor
            hpgain = i.pbRecoverHP(hpgain, true)
          end
          if i.ability == :NATURALCURE
            i.status = nil
          end
      end
      if @state.effects[:ELECTERRAIN] > 0
       next if i.hp <= 0

        if i.ability == :VOLTABSORB && i.effects[:HealBlock] == 0
          hpgain = (i.totalhp / 16.0).floor
          hpgain = i.pbRecoverHP(hpgain, true)
          pbDisplay(_INTL("{1} absorbed stray electricity!", i.pbThis)) if hpgain > 0
        end
      end
      if @state.effects[:GRASSY] > 0
        next if i.hp <= 0

        if !i.isAirborne? && i.effects[:HealBlock] == 0 && !PBStuff::TWOTURNMOVE.include?(i.effects[:TwoTurnAttack]) && i.totalhp != i.hp
          pbDisplay(_INTL("The grassy terrain healed the Pokémon on the field.", i.pbThis)) if !endmessage
          endmessage = true
          hpgain = (i.totalhp / 16.0).floor
          hpgain = i.pbRecoverHP(hpgain, true)
        end
        if i.ability == :SAPSIPPER && i.effects[:HealBlock] == 0
          hpgain = (i.totalhp / 16.0).floor
          hpgain = i.pbRecoverHP(hpgain, true)
          pbDisplay(_INTL("{1} drank tree sap to recover!", i.pbThis)) if hpgain > 0
        end
      end
    end
    # eruption check 2 (having the hazard removal in the main loop above causes the messaging to malfunction)
    if @field.effect == :VOLCANICTOP
      if @eruption
        hazardsOnSide = false
        for i in priority
          if i.pbOwnSide.effects[:Spikes] > 0
            i.pbOwnSide.effects[:Spikes] = 0
            hazardsOnSide = true
          end
          if i.pbOwnSide.effects[:ToxicSpikes] > 0
            i.pbOwnSide.effects[:ToxicSpikes] = 0
            hazardsOnSide = true
          end
          if i.pbOwnSide.effects[:StealthRock]
            i.pbOwnSide.effects[:StealthRock] = false
            hazardsOnSide = true
          end
          if i.pbOwnSide.effects[:StickyWeb]
            i.pbOwnSide.effects[:StickyWeb] = false
            hazardsOnSide = true
          end
        end
        if hazardsOnSide
          pbDisplay(_INTL("The eruption removed all hazards from the field!"))
        end
      end
    end
    # End Field stuff
    # Weather
    # Unsure what this is really doing, cass thinks it's probably nothing. But just in case ?? ~a
    #if @field.effect != :UNDERWATER
    #  @field.counter = 0 if @weather != :HAIL && @field.effect == :MOUNTAIN
    #end
    for i in priority
      if i.ability == :TEMPEST
        weathers = pbRandom(5)
        rainbowhold = 0
        case weathers
          when 0
            if @weather == :SUNNYDAY
              rainbowhold = 8
            end
            @weather = :RAINDANCE
            @weatherduration = 8
            pbCommonAnimation("Rain", nil, nil)
            pbDisplay(_INTL("Storm-9 created a downpour!"))
            if rainbowhold != 0
              fieldbefore = @field.effect
              setField(:RAINBOW, rainbowhold)
              if fieldbefore != :RAINBOW
                pbDisplay(_INTL("The weather created a rainbow!"))
              else
                pbDisplay(_INTL("The weather refreshed the rainbow!"))
              end
            end
         when 1
            @weather = :HAIL
            @weatherduration = 8
            pbCommonAnimation("Hail", nil, nil)
            # Gen 9 Mod - Hail/Snow/Both
            pbDisplay(_INTL("Storm-9 brought " + HAILSNOWLOWMOD + "fall!"))
            for facemon in @battlers
              if facemon.species == :EISCUE && facemon.form == 1 # Eiscue
                facemon.pbRegenFace
                pbDisplayPaused(_INTL("{1} transformed!", facemon.name))
              end
            end
         when 2
            @weather = :SANDSTORM
            @weatherduration = 8
            pbCommonAnimation("Sandstorm", nil, nil)
            pbDisplay(_INTL("Storm-9 whipped up a duststorm!"))
          when 3
            @weather = :STRONGWINDS
            @weatherduration = 8
            pbCommonAnimation("Wind", nil, nil)
            pbDisplay(_INTL("Storm-9 whipped up terrible winds!"))
          when 4
            @weather = :SHADOWSKY
            @weatherduration = 8
            pbCommonAnimation("ShadowSky", nil, nil)
            pbDisplay(_INTL("Storm-9 shrouded the sky in a dark aura..."))
        end
      end
    end
    if @storm9 && !pbCheckGlobalAbility(:TEMPEST)
      @storm9 = false
      noWeather
    end
    case @weather
      when :SUNNYDAY
        @weatherduration = @weatherduration - 1 if @weatherduration > 0
        if @weatherduration == 0
          pbDisplay(_INTL("The sunlight faded."))
          pbDisplay(_INTL("The starry sky shone through!")) if @field.effect == :STARLIGHT
          @weather = 0
          persistentWeather
        else
          pbCommonAnimation("Sunny")
          if @field.effect == :DARKCRYSTALCAVERN # Dark Crystal Cavern
            duration = @weatherduration + 1
            setField(:CRYSTALCAVERN, duration)
            @field.duration_condition = proc { |battle| battle.weather == :SUNNYDAY }
            @field.permanent_condition = proc { |battle| battle.FE != :CRYSTALCAVERN }
            pbDisplay(_INTL("The sun lit up the crystal cavern!"))
          end
          if pbWeather == :SUNNYDAY
            for i in priority
              next if i.isFainted?

              if (i.ability == :SOLARPOWER || (i.crested == :CASTFORM && i.form == 1)) && @field.effect != :FROZENDIMENSION
                pbDisplay(_INTL("{1} was hurt by the sunlight!", i.pbThis))
                @scene.pbDamageAnimation(i, 0)
                i.pbReduceHP((i.totalhp / 8.0).floor)
                if i.isFainted?
                  return if !i.pbFaint
                end
              end
              if Rejuv && @field.effect == :DESERT && (i.hasType?(:GRASS) || i.hasType?(:WATER)) && !(i.ability == :SOLARPOWER || i.ability == :CHLOROPHYLL)
                pbDisplay(_INTL("{1} was hurt by the sunlight!", i.pbThis))
                @scene.pbDamageAnimation(i, 0)
                i.pbReduceHP((i.totalhp / 8.0).floor)
                if i.isFainted?
                  return if !i.pbFaint
                end
              end
              if Rejuv && @field.effect == :DESERT && (i.hasType?(:GRASS) || i.hasType?(:WATER)) && !(i.ability == :SOLARPOWER || i.ability == :CHLOROPHYLL)
                pbDisplay(_INTL("{1} was hurt by the sunlight!",i.pbThis))
                @scene.pbDamageAnimation(i,0)
                i.pbReduceHP((i.totalhp/8.0).floor)
                if i.isFainted?
                  return if !i.pbFaint
                end
              end
            end
          end
          # Gen 9 Mod - Added Protosynthesis
          protosynthesisCheck
        end
      when :RAINDANCE
        @weatherduration = @weatherduration - 1 if @weatherduration > 0
        if @weatherduration == 0
          pbDisplay(_INTL("The rain stopped."))
          pbDisplay(_INTL("The starry sky shone through!")) if @field.effect == :STARLIGHT
          @weather = 0
          persistentWeather
        else
          pbCommonAnimation("Rain")
          if @field.effect == :BURNING
            breakField
            pbDisplay(_INTL("The rain snuffed out the flame!"))
          end
          if @field.effect == :VOLCANIC
            setField(:CAVE)
            pbDisplay(_INTL("The rain snuffed out the flame!"))
          end
        end
      when :SANDSTORM
        @weatherduration = @weatherduration - 1 if @weatherduration > 0
        if @weatherduration == 0
          pbDisplay(_INTL("The sandstorm subsided."))
          pbDisplay(_INTL("The starry sky shone through!")) if @field.effect == :STARLIGHT
          @weather = 0
          persistentWeather
        else
          pbCommonAnimation("Sandstorm")
          if @field.effect == :BURNING
            breakField
            pbDisplay(_INTL("The sand snuffed out the flame!"))
          end
          if @field.effect == :VOLCANIC
            setField(:CAVE)
            pbDisplay(_INTL("The sand snuffed out the flame!"))
          end
          if @field.effect == :RAINBOW
            breakField if @field.duration == 0
            endTempField if @field.duration > 0
            pbDisplay(_INTL("The weather blocked out the rainbow!"))
          end
          if pbWeather == :SANDSTORM
            endmessage = false
            reductions = []
            for i in priority
              next if i.isFainted?

              if (!i.hasType?(:GROUND) && !i.hasType?(:ROCK) && !i.hasType?(:STEEL) && !(i.ability == :SANDVEIL || i.ability == :SANDRUSH ||
                i.ability == :SANDFORCE || i.ability == :MAGICGUARD || i.ability == :TEMPEST || (i.ability == :WONDERGUARD && @field.effect == :COLOSSEUM) || i.ability == :OVERCOAT) &&
              !(i.item == :SAFETYGOGGLES) && !i.crested == :ORN_TALONFLAME && ($cache.moves[i.effects[:TwoTurnAttack]].nil? || ![0xCA, 0xCB].include?($cache.moves[i.effects[:TwoTurnAttack]].function))) || # Dig, Dive
                 (i.effects[:DesertsMark] && i.ability != :MAGICGUARD) # Desert's mark sand immunity negation
                pbDisplay(_INTL("The Pokémon were buffeted by the sandstorm!", i.pbThis)) if !endmessage
                endmessage = true
                @scene.pbDamageAnimation(i, 0, quick: true)
                 if Rejuv && @field.effect == :DESERT
                  reductions.push [i, (i.totalhp / 8.0).floor]
                else
                  reductions.push [i, (i.totalhp / 16.0).floor]
                end
              end
            end
            pbReduceBattlersHP(reductions)
          end
        end
      when :HAIL
        @weatherduration = @weatherduration - 1 if @weatherduration > 0
        if @weatherduration == 0
          # Gen 9 Mod - Hail/Snow/Both
          pbDisplay(_INTL("The "+ HAILSNOWLOWMOD + " stopped."))
          pbDisplay(_INTL("The starry sky shone through!")) if @field.effect == :STARLIGHT
          @weather = 0
          persistentWeather
        else
          pbCommonAnimation("Hail")
          if @field.effect == :RAINBOW
            breakField if @field.duration == 0
            endTempField if @field.duration > 0
            pbDisplay(_INTL("The weather blocked out the rainbow!"))
          end
          if pbWeather == :HAIL
            endmessage = false
            reductions = []
            for i in priority
              next if i.isFainted?

              # Gen 9 Mod - Hail/Snow/Both remove damage when only snow
              if HAILSNOWMOD != "Snow"
                if !i.hasType?(:ICE) && i.item != :SAFETYGOGGLES && i.crested == :ORN_TALONFLAME &&
                   ![:TEMPEST, :ICEBODY, :SNOWCLOAK, :SLUSHRUSH, :LUNARIDOL, :MAGICGUARD, :OVERCOAT].include?(i.ability) &&
                   i.crested != :EMPOLEON && !(i.crested == :CASTFORM && i.form == 3) && !(i.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM) &&
                   ($cache.moves[i.effects[:TwoTurnAttack]].nil? || ![0xCA, 0xCB].include?($cache.moves[i.effects[:TwoTurnAttack]].function)) # Dig, Dive
                  pbDisplay(_INTL("The Pokémon were buffeted by the hail!", i.pbThis)) if !endmessage
                  endmessage = true
                  @scene.pbDamageAnimation(i, 0, quick: true)
                  if @field.effect == :FROZENDIMENSION
                    reductions.push [i, (i.totalhp / 8.0).floor]
                  else
                    reductions.push [i, (i.totalhp / 16.0).floor]
                  end
                end
              end
            end
            pbReduceBattlersHP(reductions)
            if @field.effect == :MOUNTAIN
              @field.counter += 1
              if @field.counter == 3
                setField(:SNOWYMOUNTAIN)
                pbDisplay(_INTL("The mountain was covered in snow!"))
              end
            end
          end
        end
      when :STRONGWINDS
        @weatherduration = @weatherduration - 1 if @weatherduration > 0
        if @weatherduration == 0
          pbDisplay(_INTL("The strong wind petered out."))
          @weather = 0
          persistentWeather
        else
          pbCommonAnimation("Wind")
        end
      when :SHADOWSKY
        @weatherduration = @weatherduration - 1 if @weatherduration > 0
        if @weatherduration == 0
          pbDisplay(_INTL("The shadow sky faded."))
          pbDisplay(_INTL("The starry sky shone through!")) if @field.effect == :STARLIGHT
          @weather = 0
          persistentWeather
        else
          pbCommonAnimation("ShadowSky")
          if @weather == :SHADOWSKY
            endmessage = false
            reductions = []
            for i in priority
              next if i.isFainted?

              if !i.isShadow? && i.item != :SAFETYGOGGLES &&
                 ![:TEMPEST, :MAGICGUARD, :OVERCOAT].include?(i.ability) &&
                 !(i.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM) &&
                 ($cache.moves[i.effects[:TwoTurnAttack]].nil? || ![0xCA, 0xCB].include?($cache.moves[i.effects[:TwoTurnAttack]].function)) # Dig, Dive
                pbDisplay(_INTL("The Pokémon were hurt by the shadow sky!", i.pbThis)) if !endmessage
                endmessage = true
                @scene.pbDamageAnimation(i, 0, quick: true)
                if @field.effect == :DIMENSIONAL || @field.effect == :FROZENDIMENSION
                  reductions.push [i, (i.totalhp / 8.0).floor]
                else
                  reductions.push [i, (i.totalhp / 16.0).floor]
                end
              end
            end
            pbReduceBattlersHP(reductions)
          end
        end
    end
    # Temporal Shift
    for i in priority
      next if i.isFainted?

      if i.ability == :TEMPORALSHIFT
        for j in priority
          next if j.isFainted?

          if !(i == j || i.pbPartner == j || j.hasType?(:NORMAL)) && j.effects[:FutureSight] == 0
            j.effects[:FutureSight] = 3
            j.effects[:FutureSightMove] = :HEX
            j.effects[:FutureSightUser] = i.index
            j.effects[:FutureSightPokemonIndex] = i.pokemonIndex
            pbDisplay(_INTL("{1} casts a hex!", i.pbThis))
            break
          end
        end
      end
    end
    # Future Sight/Doom Desire
    for i in battlers # not priority
      next if i.effects[:FutureSight] <= 0

      i.effects[:FutureSight] -= 1
      next if i.isFainted? || i.effects[:FutureSight] != 0

      moveuser = nil
      # check if battler on the field
      move, moveuser, disabled_items = i.pbFutureSightUserPlusMove
      type = move.pbType(moveuser)
      pbDisplay(_INTL("{1} took the {2} attack!", i.pbThis, move.name))
      typemod = move.pbTypeModifier(type, moveuser, i)
      typemod = move.irregularTypeMods(moveuser, i, typemod, type)
      typemod = move.fieldTypeChange(moveuser, i, typemod)
      typemod = move.overlayTypeChange(moveuser, i, typemod, false)
      twoturninvul = PBStuff::TWOTURNMOVE.include?(i.effects[:TwoTurnAttack])
      if (i.isFainted? || move.pbAccuracyCheck(moveuser, i) && !(i.ability == :WONDERGUARD && typemod <= 4)) && !twoturninvul
        i.damagestate.reset
        damage = nil
        if i.effects[:FutureSightMove] == :FUTURESIGHT && !i.hasType?(:DARK)
          moveuser.hp != 0 ? pbAnimation(:FUTUREDUMMY, moveuser, i) : pbAnimation(:FUTUREDUMMY, i, i)
        elsif i.effects[:FutureSightMove] == :DOOMDESIRE
          moveuser.hp != 0 ? pbAnimation(:DOOMDUMMY, moveuser, i) : pbAnimation(:DOOMDUMMY, i, i)
        elsif i.effects[:FutureSightMove] == :HEX && !i.hasType?(:NORMAL)
          moveuser.hp != 0 ? pbAnimation(:HEXDUMMY, moveuser, i) : pbAnimation(:HEXDUMMY, i, i)
        end
        move.pbReduceHPDamage(damage, moveuser, i)
        move.pbEffectMessages(moveuser, i)
      elsif i.ability == :WONDERGUARD && typemod <= 4 && !twoturninvul
        pbDisplay(_INTL("{1} avoided damage with Wonder Guard!", i.pbThis))
      else
        pbDisplay(_INTL("But it failed!"))
      end
      i.effects[:FutureSight] = 0
      i.effects[:FutureSightMove] = 0
      i.effects[:FutureSightUser] = -1
      i.effects[:FutureSightPokemonIndex] = -1
      if !disabled_items.empty?
        moveuser.item = disabled_items[:item]
        moveuser.ability = disabled_items[:ability]
      end
      if i.isFainted?
        return if !i.pbFaint

        next
      end
    end
    for i in priority
      next if !i.isbossmon
      next if i.isFainted?

      if i.chargeAttack
        next if i.status == :SLEEP || i.status == :FREEZE

        chargeAttack = i.chargeAttack
        if i.turncount % chargeAttack[:turns] == 0
          if i.chargeTurns? == false && i.turncount % chargeAttack[:turns] == 0
            for m in @party1
              m.status = :FAINTED
              m.hp = 0
            end
            pbDisplay(_INTL("{1} unleashed it's power!", i.pbThis))
            pbAnimation(:EXPLOSION, i, i)
            for j in priority
              next if j.isFainted?
              next if j.isbossmon

              j.pbReduceHP(j.hp, true)
              j.pbFaint if j.isFainted?
            end
            @decision = 2
            return
          end
        else
          if chargeAttack[:intermediateattack]
            if chargeAttack[:canIntermediateAttack] == true
              newmove = PokeBattle_BossMove.new(self, i, chargeAttack[:intermediateattack])
              i.pbUseMoveSimpleBoss(newmove, -1)
            else
              chargeAttack[:canIntermediateAttack] = true
            end
          end
        end
      end
    end
    for i in priority
      next if i.isFainted?

      # Meganium + Meganium Crest
      if i.crested == :MEGANIUM || (i.pbPartner.crested == :MEGANIUM && !i.pbPartner.isFainted?)
        hpgain = i.pbRecoverHP((i.totalhp / 16).floor, true)
        pbDisplay(_INTL("The Meganium Crest restored {1}'s HP a little!", i.pbThis(true))) if hpgain > 0
      end
      # Rain Dish
      if ((i.ability == :RAINDISH || (i.crested == :CASTFORM && i.form == 2)) && (pbWeather == :RAINDANCE && !i.hasWorkingItem(:UTILITYUMBRELLA))) && i.effects[:HealBlock] == 0
        hpgain = i.pbRecoverHP((i.totalhp / 16.0).floor, true)
        pbDisplay(_INTL("{1}'s Rain Dish restored its HP a little!", i.pbThis)) if hpgain > 0
      end

      # Dry Skin
      if i.ability == :DRYSKIN
        if pbWeather == :RAINDANCE
          if !i.hasWorkingItem(:UTILITYUMBRELLA) && i.effects[:HealBlock] == 0
            hpgain = i.pbRecoverHP((i.totalhp / 8.0).floor, true)
            pbDisplay(_INTL("{1}'s Dry Skin was healed by the rain!", i.pbThis)) if hpgain > 0
          end
        elsif pbWeather == :SUNNYDAY
          if !i.hasWorkingItem(:UTILITYUMBRELLA)
            @scene.pbDamageAnimation(i, 0)
            hploss = i.pbReduceHP((i.totalhp / 8.0).floor)
            pbDisplay(_INTL("{1}'s Dry Skin was hurt by the sunlight!", i.pbThis)) if hploss > 0
          end
        elsif @field.effect == :CORROSIVEMIST || @field.effect == :CORRUPTED
          if !i.hasType?(:STEEL)
            if !i.hasType?(:POISON)
              @scene.pbDamageAnimation(i, 0)
              hploss = i.pbReduceHP((i.totalhp / 8.0).floor)
              pbDisplay(_INTL("{1}'s Dry Skin absorbed the poison!", i.pbThis)) if hploss > 0
            elsif i.effects[:HealBlock] == 0
              hpgain = i.pbRecoverHP((i.totalhp / 8.0).floor, true)
              pbDisplay(_INTL("{1}'s Dry Skin was healed by the poison!", i.pbThis)) if hpgain > 0
            end
          end
        elsif @field.effect == :DESERT
          @scene.pbDamageAnimation(i, 0)
          hploss = i.pbReduceHP((i.totalhp / 8.0).floor)
          pbDisplay(_INTL("{1}'s Dry Skin was hurt by the desert air!", i.pbThis)) if hploss > 0
        elsif @field.effect == :MISTY || @battle.state.effects[:MISTY] > 0
          if i.effects[:HealBlock] == 0
            hpgain = (i.totalhp / 16.0).floor
            hpgain = i.pbRecoverHP(hpgain, true)
            pbDisplay(_INTL("{1}'s Dry Skin was healed by the mist!", i.pbThis)) if hpgain > 0
          end
        elsif @field.effect == :SWAMP # Swamp Field
          if i.effects[:HealBlock] == 0
            hpgain = (i.totalhp / 16.0).floor
            hpgain = i.pbRecoverHP(hpgain, true)
            pbDisplay(_INTL("{1}'s Dry Skin was healed by the murk!", i.pbThis)) if hpgain > 0
          end
        end
      end
      # Ice Body
      if i.ability == :ICEBODY && (pbWeather == :HAIL || @field.effect == :ICY || @field.effect == :SNOWYMOUNTAIN || @field.effect == :FROZENDIMENSION) && i.effects[:HealBlock] == 0
        hpgain = i.pbRecoverHP((i.totalhp / 16.0).floor, true)
        pbDisplay(_INTL("{1}'s Ice Body restored its HP a little!", i.pbThis)) if hpgain > 0
      end
      if i.crested == :DRUDDIGON && pbWeather == :SUNNYDAY && i.effects[:HealBlock] == 0
        hpgain = i.pbRecoverHP((i.totalhp / 16.0).floor, true)
        pbDisplay(_INTL("{1}'s Crest restored its HP a little!", i.pbThis)) if hpgain > 0
      end
      if i.isFainted?
        return if !i.pbFaint

        next
      end
    end
    # Wish
    for i in priority
      if i.effects[:Wish] > 0
        i.effects[:Wish] -= 1
        if i.effects[:Wish] == 0
          next if i.isFainted?

          hpgain = i.pbRecoverHP(i.effects[:WishAmount], true)
          if hpgain > 0
            wishmaker = pbThisEx(i.index, i.effects[:WishMaker])
            pbDisplay(_INTL("{1}'s wish came true!", wishmaker))
          end
        end
      end
    end
    # Fire Pledge + Grass Pledge combination damage - should go here
    for i in priority
      next if i.isFainted?

      # Shed Skin
      if i.ability == :SHEDSKIN
        if (pbRandom(10) < 3 || @field.effect == :DRAGONSDEN) && !i.status.nil?
          pbDisplay(_INTL("{1}'s Shed Skin cured its {2} problem!", i.pbThis, i.status.downcase))
          i.status = nil
          i.statusCount = 0
          if @field.effect == :DRAGONSDEN
            pbDisplay(_INTL("{1}'s scaled sheen glimmers brightly!", i.pbThis))
            if i.effects[:HealBlock] == 0
              hpgain = (i.totalhp / 4.0).floor
              hpgain = i.pbRecoverHP(hpgain, true)
            end
            animDDShedSkin = true
            if !i.pbTooHigh?(PBStats::SPEED)
              i.pbIncreaseStatBasic(PBStats::SPEED, 1)
              pbCommonAnimation("StatUp", i, nil)
              animDDShedSkin = false
            end
            if !i.pbTooHigh?(PBStats::SPATK)
              i.pbIncreaseStatBasic(PBStats::SPATK, 1)
              pbCommonAnimation("StatUp", i, nil) if animDDShedSkin
            end
            animDDShedSkin = true
            if !i.pbTooLow?(PBStats::DEFENSE)
              i.pbReduceStat(PBStats::DEFENSE, 1)
              pbCommonAnimation("StatDown", i, nil)
              animDDShedSkin = false
            end
            if !i.pbTooLow?(PBStats::SPDEF)
              i.pbReduceStat(PBStats::SPDEF, 1)
              pbCommonAnimation("StatDown", i, nil) if animDDShedSkin
            end
          end
        end
      end
      # Hydration
      if i.ability == :HYDRATION && ((pbWeather == :RAINDANCE && !i.hasWorkingItem(:UTILITYUMBRELLA)) || (@field.effect == :WATERSURFACE && !i.isAirborne?) || @field.effect == :UNDERWATER)
        if !i.status.nil?
          pbDisplay(_INTL("{1}'s Hydration cured its {2} problem!", i.pbThis, i.status.downcase))
          i.status = nil
          i.statusCount = 0
        end
        if @field.effect == :CLOUDS && pbWeather == :RAINDANCE && i.hp != i.totalhp
          i.pbRecoverHP((i.totalhp / 16.0).floor, true)
          pbDisplay(_INTL("{1}'s Hydration restored its health!", i.pbThis))
        end
      end
      if i.ability == :WATERVEIL && (@field.effect == :WATERSURFACE || @field.effect == :UNDERWATER)
        if !i.status.nil?
          pbDisplay(_INTL("{1}'s Water Veil cured its {2} problem!", i.pbThis, i.status.downcase))
          i.status = nil
          i.statusCount = 0
        end
      end
      # Healer
      if i.ability == :HEALER
        partner = i.pbPartner
        if pbRandom(10) < 3 && partner.hp > 0 && !partner.status.nil?
          pbDisplay(_INTL("{1}'s Healer cured its partner's {2} problem!", i.pbThis, partner.status.downcase))
          partner.status = nil
          partner.statusCount = 0
        end
      end
    end
    # Held berries/Leftovers/Black Sludge
    for i in priority
      next if i.isFainted?

      i.pbPassiveItemHP
      i.pbBerryHerbCheck
      if i.isFainted?
        return if !i.pbFaint

        next
      end
    end
    # Aqua Ring
    for i in priority
      next if i.hp <= 0

      if i.effects[:AquaRing]
        if @field.effect == :CORROSIVEMIST && !i.hasType?(:STEEL) && !i.hasType?(:POISON)
          @scene.pbDamageAnimation(i, 0)
          i.pbReduceHP((i.totalhp / 16.0).floor)
          pbDisplay(_INTL("{1}'s Aqua Ring absorbed poison!", i.pbThis))
          if i.hp <= 0
            return if !i.pbFaint
          end
        elsif i.effects[:HealBlock] == 0
          hpgain = (i.totalhp / 16.0).floor
          if Rejuv && @battle.FE == :GRASSY
            hpgain = (hpgain * 1.6).floor if i.hasWorkingItem(:BIGROOT)
          else
            hpgain = (hpgain * 1.3).floor if i.hasWorkingItem(:BIGROOT)
          end
          hpgain = (hpgain * 1.3).floor  if i.crested == :SHIINOTIC
          hpgain = (hpgain * 2).floor if [:MISTY, :SWAMP, :WATERSURFACE, :UNDERWATER].include?(@field.effect)
          hpgain = i.pbRecoverHP(hpgain, true)
          pbDisplay(_INTL("{1}'s Aqua Ring restored its HP a little!", i.pbThis)) if hpgain > 0
        end
      end
    end
    # Ingrain
    for i in priority
      next if i.hp <= 0

      if i.effects[:Ingrain]
        if ((!Rejuv && @field.effect == :SWAMP) || @field.effect == :CORROSIVE || @field.effect == :CORRUPTED) && (!i.hasType?(:STEEL) && !i.hasType?(:POISON))
          unless i.ability == :MAGICGUARD
            @scene.pbDamageAnimation(i, 0)
            i.pbReduceHP((i.totalhp / 16.0).floor)
            pbDisplay(_INTL("{1} absorbed foul nutrients with its roots!", i.pbThis))
            if i.hp <= 0
              return if !i.pbFaint
            end
          end
        else
          if @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN, 3, 5)
            hpgain = (i.totalhp / 4.0).floor
          elsif @field.effect == :FOREST || @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN, 2, 5) || (Rejuv && @field.effect == :GRASSY) || @state.effects[:GRASSY] > 0
            hpgain = (i.totalhp / 8.0).floor
          elsif i.effects[:HealBlock] == 0
            hpgain = (i.totalhp / 16.0).floor
          end
          if i.effects[:HealBlock] == 0
            if Rejuv && @battle.FE == :GRASSY
              hpgain = (hpgain * 1.6).floor if i.hasWorkingItem(:BIGROOT)
            else
              hpgain = (hpgain * 1.3).floor if i.hasWorkingItem(:BIGROOT)
            end
            hpgain = (hpgain * 1.3).floor if i.crested == :SHIINOTIC
            hpgain = i.pbRecoverHP(hpgain, true)
            pbDisplay(_INTL("{1} absorbed nutrients with its roots!", i.pbThis)) if hpgain > 0
          end
        end
      end
    end
    # Leech Seed
    for i in priority
      if i.effects[:LeechSeed] >= 0
        recipient = @battlers[i.effects[:LeechSeed]]
        if recipient && !recipient.isFainted? && i.ability != :MAGICGUARD && !(i.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM) # if recipient exists
          hploss = (i.totalhp / 8.0).floor
          hploss = hploss * 2 if @field.effect == :WASTELAND
          pbCommonAnimation("LeechSeed", recipient, i)
          i.pbReduceHP(hploss, true)
          next if recipient.isFainted?

          if i.ability == :LIQUIDOOZE
            hploss = hploss * 2 if @field.effect == :MURKWATERSURFACE || @field.effect == :CORRUPTED || @field.effect == :WASTELAND
            if Rejuv && @battle.FE == :GRASSY
              hploss = (hploss * 1.3).floor
              hploss = (hploss * 1.6).floor if recipient.hasWorkingItem(:BIGROOT)
            else
              hploss = (hploss * 1.3).floor if recipient.hasWorkingItem(:BIGROOT)
            end
            hploss = (hploss * 1.3).floor if recipient.crested == :SHIINOTIC
            recipient.pbReduceHP(hploss, true)
            pbDisplay(_INTL("{1} sucked up the liquid ooze!", recipient.pbThis))
          else
            if recipient.effects[:HealBlock] == 0
              if Rejuv && @battle.FE == :GRASSY
                hploss = (hploss * 1.3).floor
                hploss = (hploss * 1.6).floor if recipient.hasWorkingItem(:BIGROOT)
              else
                hploss = (hploss * 1.3).floor if recipient.hasWorkingItem(:BIGROOT)
              end
              hploss = (hploss * 1.3).floor if recipient.crested == :SHIINOTIC
              recipient.pbRecoverHP(hploss, true)
            end
            pbDisplay(_INTL("{1}'s health was sapped by Leech Seed!", i.pbThis))
          end
          if i.isFainted?
            return if !i.pbFaint
          end
          if recipient.isFainted?
            return if !recipient.pbFaint
          end
          if Rejuv && @field.effect == :SWAMP
            stat = sample([PBStats::ATTACK, PBStats::DEFENSE, PBStats::SPATK, PBStats::SPDEF, PBStats::SPEED])
            i.pbReduceStat(stat, 1, abilitymessage: true, statdropper: recipient)
          end
        end
      end
    end
    for i in priority
      next if i.isFainted?

      # Petrification
      if i.status == :PETRIFIED && (i.effects[:Petrification] >= 0)
        recipient = @battlers[i.effects[:Petrification]]
        if recipient && !recipient.isFainted? && i.ability != :MAGICGUARD && !(i.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM) # if recipient exists
          pbCommonAnimation("Petrification", recipient, i)
          hploss = i.pbReduceHP((i.totalhp / 8).floor, true)
          next if recipient.isFainted?

          if i.ability == :LIQUIDOOZE
            hploss = hploss * 2 if @field.effect == :MURKWATERSURFACE || @field.effect == :CORRUPTED || @field.effect == :WASTELAND
            if Rejuv && @battle.FE == :GRASSY
              hploss = (hploss * 1.6).floor if recipient.hasWorkingItem(:BIGROOT)
            else
              hploss = (hploss * 1.3).floor if recipient.hasWorkingItem(:BIGROOT)
            end
            hploss = (hploss * 1.3).floor if recipient.crested == :SHIINOTIC
            recipient.pbReduceHP(hploss, true)
            pbDisplay(_INTL("{1} sucked up the liquid ooze!", recipient.pbThis))
          else
            if recipient.effects[:HealBlock] == 0
              if Rejuv && @battle.FE == :GRASSY
                hploss = (hploss * 1.6).floor if recipient.hasWorkingItem(:BIGROOT)
              else
                hploss = (hploss * 1.3).floor if recipient.hasWorkingItem(:BIGROOT)
              end
              hploss = (hploss * 1.3).floor if recipient.crested == :SHIINOTIC
              recipient.pbRecoverHP(hploss, true)
            end
            pbDisplay(_INTL("{1}'s health was drained by {2}!", i.pbThis, recipient.pbThis))
          end
          if i.isFainted?
            return if !i.pbFaint
          end
          if recipient.isFainted?
            return if !recipient.pbFaint
          end
        end
      end
      # Poison/Bad poison
      if i.ability != :MAGICGUARD && !(i.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM) && !(i.ability == :GUTS && @battle.FE == :CROWD)
        if (i.ability == :POISONHEAL || i.crested == :ZANGOOSE) &&
           (i.status == :POISON || [:CORROSIVEMIST, :CORRUPTED].include?(@battle.FE) || ([:CORROSIVE, :MURKWATERSURFACE, :WASTELAND].include?(@battle.FE) && !i.isAirborne?))
          if i.effects[:HealBlock] == 0
            if i.hp < i.totalhp
              pbCommonAnimation("Poison", i, nil)
              i.pbRecoverHP((i.totalhp / 8.0).floor, true)
              pbDisplay(_INTL("{1} is healed by poison!", i.pbThis))
            end
            if i.statusCount > 0
              i.effects[:Toxic] += 1
              i.effects[:Toxic] = [15, i.effects[:Toxic]].min
            end
          end
        elsif i.status == :POISON
          i.pbContinueStatus
          if i.statusCount == 0
            i.pbReduceHP((i.totalhp / 8.0).floor)
          else
            i.effects[:Toxic] += 1
            i.effects[:Toxic] = [15, i.effects[:Toxic]].min
            i.pbReduceHP((i.totalhp / 16.0).floor * i.effects[:Toxic])
          end
          if pbCheckGlobalAbility(:STOPPN)
            showMessage = false
            if i.pbReduceStat(PBStats::DEFENSE, 1, abilitymessage: false)
              showMessage = true
            end
            if i.pbReduceStat(PBStats::SPDEF, 1, abilitymessage: false)
              showMessage = true
            end
            if showMessage
              if i.ability == :CONTRARY
                pbDisplay(_INTL("{1}'s defenses increased!", i.pbThis))
              else
                pbDisplay(_INTL("{1}'s defenses were corroded...", i.pbThis))
              end
            end
          end
        end
      end
      # Burn
      if i.status == :BURN && i.ability != :MAGICGUARD && !(i.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
        i.pbContinueStatus
        if !(i.ability == :GUTS && @battle.FE == :CROWD)
          if i.ability == :HEATPROOF || @field.effect == :ICY
            i.pbReduceHP((i.totalhp / 32.0).floor)
          else
            i.pbReduceHP((i.totalhp / 16.0).floor)
          end
        end
      end
      # Shiinotic Crest
      if i.crested == :SHIINOTIC
        for j in priority
          next if j == i
          next if j.isFainted?
          next if j.status.nil?

          hploss = (j.totalhp / 16.0).floor
          hploss = hploss * 2 if @field.effect == :WASTELAND
          pbCommonAnimation("LeechSeed", i, j)
          j.pbReduceHP(hploss, true)
          if j.ability == :LIQUIDOOZE
            hploss = hploss * 2 if @field.effect == :MURKWATERSURFACE || @field.effect == :CORRUPTED || @field.effect == :WASTELAND
            if Rejuv && @battle.FE == :GRASSY
              hploss = (hploss * 1.6).floor if i.hasWorkingItem(:BIGROOT)
            else
              hploss = (hploss * 1.3).floor if i.hasWorkingItem(:BIGROOT)
            end
            hploss = (hploss * 1.3).floor if i.crested == :SHIINOTIC
            i.pbReduceHP(hploss, true)
            pbDisplay(_INTL("{1} sucked up the liquid ooze!", i.pbThis))
          else
            if i.effects[:HealBlock] == 0
              if Rejuv && @battle.FE == :GRASSY
                hploss = (hploss * 1.6).floor if i.hasWorkingItem(:BIGROOT)
              else
                hploss = (hploss * 1.3).floor if i.hasWorkingItem(:BIGROOT)
              end
              hploss = (hploss * 1.3).floor if i.crested == :SHIINOTIC
              i.pbRecoverHP(hploss, true)
            end
            pbDisplay(_INTL("{1}'s health was sapped by {2}'s Crest!", i.pbThis, i.pbThis))
          end
          if j.isFainted?
            return if !j.pbFaint
          end
          if i.isFainted?
            return if !i.pbFaint
          end
        end
      end
      # Nightmare
      if i.effects[:Nightmare] && i.ability != :MAGICGUARD && !(i.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM) && @field.effect != :RAINBOW
        if ((i.status == :SLEEP || (i.ability == :COMATOSE && @battle.FE != :ELECTERRAIN)) || @battle.FE == :INFERNAL || i.pbOpposing1.ability == :WORLDOFNIGHTMARES || i.pbOpposing2.ability == :WORLDOFNIGHTMARES)
          pbCommonAnimation("Nightmare", i, nil)
          pbDisplay(_INTL("{1} is locked in a nightmare!", i.pbThis))
          hploss = (i.totalhp / 4.0).floor
          hploss = (i.totalhp / 3.0).floor if @field.effect == :HAUNTED || @field.effect == :DARKNESS3
          i.pbReduceHP(hploss, true)
        else
          i.effects[:Nightmare] = false
        end
      end
      # Gen 9 Mod - Salt Cure damage effect.
      if i.effects[:SaltCure] && i.ability != :MAGICGUARD
        pbCommonAnimation("SaltCure", i, nil)
        @scene.pbDamageAnimation(i,0)
        divisor = i.hasType?(:STEEL) || i.hasType?(:WATER) ? 4.0 : 8.0
        i.pbReduceHP((i.totalhp / divisor).floor)
        pbDisplay(_INTL("{1} is hurt by Salt Cure!", i.pbThis))
      end
      if i.isFainted?
        return if !i.pbFaint

        next
      end
    end
    # Curse
    for i in priority
      next if i.isFainted?
      next if !i.effects[:Curse]

      if @field.effect == :HOLY
        i.effects[:Curse] = false
        pbDisplay(_INTL("{1}'s curse was lifted!", i.pbThis))
      end
      if i.ability != :MAGICGUARD && !(i.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
        pbCommonAnimation("Curse", i, nil)
        pbDisplay(_INTL("{1} is afflicted by the curse!", i.pbThis))
        i.pbReduceHP((i.totalhp / 4.0).floor, true)
      end
      if i.isFainted?
        return if !i.pbFaint

        next
      end
    end
    # Multi-turn attacks (Bind/Clamp/Fire Spin/Magma Storm/Sand Tomb/Whirlpool/Wrap)
     for i in priority
      next if i.isFainted?

      i.pbBerryHerbCheck
      if i.effects[:MultiTurn] > 0
        i.effects[:MultiTurn] -= 1
        movename = getMoveName(i.effects[:MultiTurnAttack])
        if i.effects[:MultiTurn] == 0
          pbDisplay(_INTL("{1} was freed from {2}!", i.pbThis, movename))
          i.effects[:BindingBand] = false
        elsif i.ability != :MAGICGUARD && !(i.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
          pbDisplay(_INTL("{1} is hurt by {2}!", i.pbThis, movename))
          if i.effects[:MultiTurnAttack] == :BIND
            pbCommonAnimation("Bind", i, nil)
          elsif i.effects[:MultiTurnAttack] == :CLAMP
            pbCommonAnimation("Clamp", i, nil)
          elsif i.effects[:MultiTurnAttack] == :FIRESPIN
            pbCommonAnimation("FireSpin", i, nil)
          elsif i.effects[:MultiTurnAttack] == :MAGMASTORM
            pbCommonAnimation("Magma Storm", i, nil)
          elsif i.effects[:MultiTurnAttack] == :SANDTOMB || i.effects[:MultiTurnAttack] == :DESERTSMARK
            pbCommonAnimation("SandTomb", i, nil)
          elsif i.effects[:MultiTurnAttack] == :WRAP
            pbCommonAnimation("Wrap", i, nil)
          elsif i.effects[:MultiTurnAttack] == :INFESTATION
            pbCommonAnimation("Infestation", i, nil)
          elsif i.effects[:MultiTurnAttack] == :WHIRLPOOL
            pbCommonAnimation("Whirlpool", i, nil)
          else
            pbCommonAnimation("Wrap", i, nil)
          end
          @scene.pbDamageAnimation(i, 0)
          binddamage = 0
          if i.effects[:BindingBand]
            binddamage += 1
          end
          if i.effects[:MultiTurnAttack] == :MAGMASTORM && @field.effect == :DRAGONSDEN
            binddamage += 1
          elsif i.effects[:MultiTurnAttack] == :SANDTOMB && @field.effect == :DESERT
            binddamage += 1
          elsif i.effects[:MultiTurnAttack] == :WHIRLPOOL && (@field.effect == :WATERSURFACE || @field.effect == :UNDERWATER)
            binddamage += 1
          elsif i.effects[:MultiTurnAttack] == :INFESTATION && @field.effect == :FOREST
            binddamage += 1
          elsif i.effects[:MultiTurnAttack] == :FIRESPIN && (@field.effect == :BURNING || @field.effect == :HAUNTED)
            binddamage += 1
          elsif i.effects[:MultiTurnAttack] == :INFESTATION && @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN, 3, 5)
            case @battle.FE
              when :FLOWERGARDEN3 then binddamage += 1
              when :FLOWERGARDEN4 then binddamage += 2
              when :FLOWERGARDEN5 then binddamage += 3
            end
          elsif i.effects[:MultiTurnAttack] == :THUNDERCAGE && @field.effect == :ELECTERRAIN
            binddamage += 1
          elsif i.effects[:MultiTurnAttack] == :SNAPTRAP && @field.effect == :GRASSY
            binddamage += 1
          end
          i.pbReduceHP((i.totalhp / [8.0, 6.0, 4.0, 3.0, 2.0][binddamage]).floor)
          if i.effects[:MultiTurnAttack] == :SANDTOMB && @field.effect == :ASHENBEACH
            i.pbReduceStat(PBStats::ACCURACY, 1, abilitymessage: true)
          end
          if Rejuv && @field.effect == :SWAMP && (i.effects[:MultiTurnAttack] == :SNAPTRAP || i.effects[:MultiTurnAttack] == :INFESTATION)
            stat = sample([PBStats::ATTACK, PBStats::DEFENSE, PBStats::SPATK, PBStats::SPDEF, PBStats::SPEED])
            i.pbReduceStat(stat, 1, abilitymessage: true)
          end
        end
      end
      if i.hp <= 0
        return if !i.pbFaint

        next
      end
      i.pbBerryHerbCheck
    end
    # Taunt
    for i in priority
      next if i.isFainted?
      next if i.effects[:Taunt] == 0

      i.effects[:Taunt] -= 1
      if i.effects[:Taunt] == 0
        pbDisplay(_INTL("{1} recovered from the taunting!", i.pbThis))
      end
    end
    # Encore
    for i in priority
      next if i.isFainted?
      next if i.effects[:Encore] == 0

      if i.moves[i.effects[:EncoreIndex]].move != i.effects[:EncoreMove]
        i.effects[:Encore] = 0
        i.effects[:EncoreIndex] = 0
        i.effects[:EncoreMove] = 0
      else
        i.effects[:Encore] -= 1
        if i.effects[:Encore] == 0 || i.moves[i.effects[:EncoreIndex]].pp == 0
          i.effects[:Encore] = 0
          pbDisplay(_INTL("{1}'s encore ended!", i.pbThis))
        end
      end
    end
    # Disable/Cursed Body
    for i in priority
      next if i.isFainted?
      next if i.effects[:Disable] == 0

      i.effects[:Disable] -= 1
      if i.effects[:Disable] == 0
        i.effects[:DisableMove] = 0
        pbDisplay(_INTL("{1} is disabled no more!", i.pbThis))
      end
    end
    # Magnet Rise
    for i in priority
      next if i.isFainted?

      if i.effects[:MagnetRise] > 0
        i.effects[:MagnetRise] -= 1
        if i.effects[:MagnetRise] == 0
          pbDisplay(_INTL("{1} stopped levitating.", i.pbThis))
        end
      end
    end
    # ChtonicMalady
    for i in priority
      next if i.isFainted?
      next if i.effects[:Torment] == false

      if i.effects[:ChtonicMalady] > 0
        i.effects[:ChtonicMalady] -= 1
        if i.effects[:ChtonicMalady] == 0
          i.effects[:Torment] = false
          pbDisplay(_INTL("{1}'s torment wore off.", i.pbThis))
        end
      end
    end
    # Telekinesis
    for i in priority
      next if i.isFainted?

      if i.effects[:Telekinesis] > 0
        i.effects[:Telekinesis] -= 1
        if i.effects[:Telekinesis] == 0
          pbDisplay(_INTL("{1} stopped levitating.", i.pbThis))
        end
      end
    end
    # Heal Block
    for i in priority
      next if i.isFainted?

      if i.effects[:HealBlock] > 0
        i.effects[:HealBlock] -= 1
        if i.effects[:HealBlock] == 0
          pbDisplay(_INTL("The heal block on {1} ended.", i.pbThis))
        end
      end
    end
    # Embargo
    for i in priority
      next if i.isFainted?

      if i.effects[:Embargo] > 0
        i.effects[:Embargo] -= 1
        if i.effects[:Embargo] == 0
          pbDisplay(_INTL("The embargo on {1} was lifted.", i.pbThis(true)))
        end
      end
    end
    # Yawn
    for i in priority
      next if i.isFainted?

      if i.effects[:Yawn] > 0
        i.effects[:Yawn] -= 1
        if i.effects[:Yawn] == 0 && i.pbCanSleepYawn?
          i.pbSleep
          pbDisplay(_INTL("{1} fell asleep!", i.pbThis))
          i.pbBerryHerbCheck
        end
      end
    end
    # Perish Song
    perishSongUsers = []
    for i in priority
      next if i.isFainted?

      if i.effects[:PerishSong] > 0
        if (i.isbossmon && i.immunities[:moves].include?(:PERISHSONG))
          pbDisplay(_INTL("{1} grew resistant to the Perish Song!", i.pbThis))
          i.effects[:PerishSong] = 0
          next
        end
        i.effects[:PerishSong] -= 1
        pbDisplay(_INTL("{1}'s Perish count fell to {2}!", i.pbThis, i.effects[:PerishSong]))
        if i.effects[:PerishSong] == 0
          i.immunities[:moves].push(:PERISHSONG) if i.isbossmon
          perishSongUsers.push(i.effects[:PerishSongUser])
          i.pbReduceHP(i.hp, true)
        end
      end
      if i.isFainted?
        return if !i.pbFaint
      end
    end
    if perishSongUsers.length > 0
      # If all remaining Pokemon fainted by a Perish Song triggered by a single side
      if (perishSongUsers.find_all { |item| pbIsOpposing?(item) }.length == perishSongUsers.length) ||
         (perishSongUsers.find_all { |item| !pbIsOpposing?(item) }.length == perishSongUsers.length)
        pbJudgeCheckpoint(@battlers[perishSongUsers[0]])
      end
    end
    if @decision > 0
      pbGainEXP
      return
    end
    texts = ["Your", "The opposing"]
    # Reflect
    for i in 0...2
      next if sides[i].effects[:Reflect] == 0

      sides[i].effects[:Reflect] -= 1
      pbDisplay(_INTL("#{texts[i]} team's Reflect faded!")) if sides[i].effects[:Reflect] == 0
    end
    # Light Screen
    for i in 0...2
      next if sides[i].effects[:LightScreen] == 0

      sides[i].effects[:LightScreen] -= 1
      pbDisplay(_INTL("#{texts[i]} team's Light Screen faded!")) if sides[i].effects[:LightScreen] == 0
    end
    # Aurora Veil
    for i in 0...2
      next if sides[i].effects[:AuroraVeil] == 0

      sides[i].effects[:AuroraVeil] -= 1
      pbDisplay(_INTL("#{texts[i]} team's Aurora Veil faded!")) if sides[i].effects[:AuroraVeil] == 0
    end
    for i in 0...2
      next if sides[i].effects[:AreniteWall] == 0

      sides[i].effects[:AreniteWall] -= 1
      pbDisplay(_INTL("#{texts[i]} team's Arenite Wall faded!")) if sides[i].effects[:AreniteWall] == 0
    end
    # Safeguard
    for i in 0...2
      next if sides[i].effects[:Safeguard] == 0

      sides[i].effects[:Safeguard] -= 1
      pbDisplay(_INTL("#{texts[i]} team is no longer protected by Safeguard!")) if sides[i].effects[:Safeguard] == 0
    end
    # Mist
    for i in 0...2
      next if sides[i].effects[:Mist] == 0

      sides[i].effects[:Mist] -= 1
      pbDisplay(_INTL("#{texts[i]} team's Mist faded!")) if sides[i].effects[:Mist] == 0
    end
    # Tailwind
    for i in 0...2
      next if sides[i].effects[:Tailwind] == 0

      sides[i].effects[:Tailwind] -= 1
      pbDisplay(_INTL("#{texts[i]} team's tailwind stopped blowing!")) if sides[i].effects[:Tailwind] == 0
    end
    # Lucky Chant
    for i in 0...2
      next if sides[i].effects[:LuckyChant] == 0

      sides[i].effects[:LuckyChant] -= 1
      pbDisplay(_INTL("#{texts[i]} team's Lucky Chant faded!")) if sides[i].effects[:LuckyChant] == 0
    end
    # Mud Sport
    if @state.effects[:MudSport] > 0
      @state.effects[:MudSport] -= 1
      if @state.effects[:MudSport] == 0
        if Rejuv && @field.backup == :ELECTERRAIN && @field.effect != :ELECTERRAIN
          breakField
          pbDisplay(_INTL("The field electrified again!"))
        else
          pbDisplay(_INTL("The effects of Mud Sport faded."))
        end
      end
    end
    # Water Sport
    if @state.effects[:WaterSport] > 0
      @state.effects[:WaterSport] -= 1
      pbDisplay(_INTL("The effects of Water Sport faded.")) if @state.effects[:WaterSport] == 0
    end
    # Gravity
    if @state.effects[:Gravity] > 0
      @state.effects[:Gravity] -= 1 if @field.effect != :FROZENDIMENSION
      if @state.effects[:Gravity] == 0
        if @field.backup == :NEWWORLD && @field.effect != :NEWWORLD
          breakField
          pbDisplay(_INTL("The world broke apart again!"))
        else
          pbDisplay(_INTL("Gravity returned to normal."))
        end
      end
    end

    # Terrain
    if @field.duration > 0
      @field.checkPermCondition(self)
    end
    if @field.duration > 0
      @field.duration -= 1
      @field.duration = 0 if @field.duration_condition && !@field.duration_condition.call(self)
      if @field.duration == 0 && @field.effect != :INDOOR
        endTempField
        pbDisplay(_INTL("The terrain returned to normal."))
      end
    end
    # Terrain overlays
    if @state.effects[:ELECTERRAIN] > 0
      @state.effects[:ELECTERRAIN] -= 1 if @field.effect != :FROZENDIMENSION
      pbDisplay(_INTL("The surging electricity dissipated.")) if @state.effects[:ELECTERRAIN] == 0
      quarkdriveCheck
    end
    if @state.effects[:GRASSY] > 0
      @state.effects[:GRASSY] -= 1 if @field.effect != :FROZENDIMENSION
      pbDisplay(_INTL("The surrounding grass withered.")) if @state.effects[:GRASSY] == 0
    end
    if @state.effects[:MISTY] > 0
      @state.effects[:MISTY] -= 1 if @field.effect != :FROZENDIMENSION
      pbDisplay(_INTL("The surrounding mist dispersed.")) if @state.effects[:MISTY] == 0
    end
    if @state.effects[:PSYTERRAIN] > 0
      @state.effects[:PSYTERRAIN] -= 1 if @field.effect != :FROZENDIMENSION
      pbDisplay(_INTL("The psychic energy left as mysteriously as it came.")) if @state.effects[:PSYTERRAIN] == 0
    end
    if @state.effects[:RAINBOW] > 0
      @state.effects[:RAINBOW] -= 1 if @field.effect != :FROZENDIMENSION
      pbDisplay(_INTL("The rainbow disappeared.")) if @state.effects[:RAINBOW] == 0
    end
    # Trick Room - should go here
    # Wonder Room - should go here
    # Magic Room
    if @state.effects[:MagicRoom] > 0
      @state.effects[:MagicRoom] -= 1 if @field.effect != :FROZENDIMENSION
      pbDisplay(_INTL("The area returned to normal.")) if @state.effects[:MagicRoom] == 0
    end
    # Fairy Lock
    if @state.effects[:FairyLock] > 0
      @state.effects[:FairyLock] -= 1
      # Fairy Lock seems to have no end-of-effect text so I've added some.
      pbDisplay(_INTL("The Fairy Lock was released.")) if @state.effects[:FairyLock] == 0
    end
    # Uproar
    for i in priority
      next if i.isFainted?

      if i.effects[:Uproar] > 0
        for j in priority
          if !j.isFainted? && j.status == :SLEEP && !j.ability == :SOUNDPROOF
            j.effects[:Nightmare] = false
            j.status = nil
            j.statusCount = 0
            pbDisplay(_INTL("{1} woke up in the uproar!", j.pbThis))
          end
        end
        i.effects[:Uproar] -= 1
        if i.effects[:Uproar] == 0
          pbDisplay(_INTL("{1} calmed down.", i.pbThis))
        else
          pbDisplay(_INTL("{1} is making an uproar!", i.pbThis))
        end
      end
    end

    # Slow Start's end message
    for i in priority
      next if i.isFainted?

      if i.ability == :SLOWSTART && i.turncount == 4 && @battle.FE != :DEEPEARTH
        pbDisplay(_INTL("{1} finally got its act together!", i.pbThis))
      end
    end

    # Wasteland hazard interaction
    if @field.effect == :WASTELAND
      for i in priority
        is_fainted_before = i.isFainted?
        partner_fainted_before = @doublebattle && i.pbPartner.isFainted?
        # Stealth Rock
        if i.pbOwnSide.effects[:StealthRock]
          pbDisplay(_INTL("The waste swallowed up the pointed stones!"))
          i.pbOwnSide.effects[:StealthRock] = false
          pbDisplay(_INTL("...Rocks spewed out from the ground below!"))
          for mon in [i, i.pbPartner]
            next if mon.isFainted? || PBStuff::TWOTURNMOVE.include?(mon.effects[:TwoTurnAttack]) || mon.ability == :MAGICGUARD

            eff = PBTypes.twoTypeEff(:ROCK, mon.type1, mon.type2)
            next if eff <= 0

            @scene.pbDamageAnimation(mon, 0)
            mon.pbReduceHP([(mon.totalhp * eff / 16).floor, 1].max)
          end
        end

        # Spikes
        if i.pbOwnSide.effects[:Spikes] > 0
          pbDisplay(_INTL("The waste swallowed up the spikes!"))
          spikescount = i.pbOwnSide.effects[:Spikes]
          i.pbOwnSide.effects[:Spikes] = 0
          pbDisplay(_INTL("...Stalagmites burst up from the ground!"))
          for mon in [i, i.pbPartner]
            next if mon.isFainted? || mon.isAirborne? || PBStuff::TWOTURNMOVE.include?(mon.effects[:TwoTurnAttack]) || mon.ability == :MAGICGUARD

            @scene.pbDamageAnimation(mon, 0)
            mon.pbReduceHP([(spikescount * mon.totalhp / 3.0).floor, 1].max)
          end
        end

        # Toxic Spikes
        if i.pbOwnSide.effects[:ToxicSpikes] > 0
          pbDisplay(_INTL("The waste swallowed up the toxic spikes!"))
          tspikescount = i.pbOwnSide.effects[:ToxicSpikes]
          i.pbOwnSide.effects[:ToxicSpikes] = 0
          pbDisplay(_INTL("...Poison needles shot up from the ground!"))
          for mon in [i, i.pbPartner]
            next if mon.isFainted? || mon.isAirborne? || mon.hasType?(:STEEL) || mon.hasType?(:POISON)
            next if PBStuff::TWOTURNMOVE.include?(mon.effects[:TwoTurnAttack])

            if mon.ability != :MAGICGUARD
              @scene.pbDamageAnimation(mon, 0)
              mon.pbReduceHP([(tspikescount * mon.totalhp / 8.0).floor, 1].max)
            end
            if mon.status.nil? && mon.pbCanPoison?(false)
              mon.status = :POISON
              if tspikescount > 1
                mon.statusCount = 1
                mon.effects[:Toxic] = 0
              else
                mon.statusCount = 0
              end
              pbCommonAnimation("Poison", mon, nil)
            end
          end
        end

        # Sticky Web
        if i.pbOwnSide.effects[:StickyWeb]
          pbDisplay(_INTL("The waste swallowed up the sticky web!"))
          i.pbOwnSide.effects[:StickyWeb] = false
          pbDisplay(_INTL("...Sticky string shot out of the ground!"))
          for mon in [i, i.pbPartner]
            next if mon.isFainted? && !PBStuff::TWOTURNMOVE.include?(mon.effects[:TwoTurnAttack])

            if mon.ability == :CONTRARY
              if !mon.pbTooHigh?(PBStats::SPEED, ignoreContrary: true)
                mon.pbIncreaseStatBasic(PBStats::SPEED, 4)
                pbCommonAnimation("StatUp", mon, nil)
                pbDisplay(_INTL("{1}'s Speed went way up!", mon.pbThis))
              end
            else
              if !mon.pbTooLow?(PBStats::SPEED, ignoreContrary: true)
                mon.pbReduceStatBasic(PBStats::SPEED, 4)
                pbCommonAnimation("StatDown", mon, nil)
                pbDisplay(_INTL("{1}'s Speed was severely lowered!", mon.pbThis))
              end
            end
          end
        end

        # Fainting
        if @doublebattle && !partner_fainted_before
          partner = i.pbPartner
          if partner && partner.hp <= 0
            partner.pbFaint
          end
        end
        if i.hp <= 0 && !is_fainted_before
          return if !i.pbFaint

          next
        end
      end
    end
    # End Wasteland hazards
    for i in priority
      next if i.isFainted?

      # Mimicry
      if i.ability == :MIMICRY
        protype = -1
        case @field.effect
          when :CRYSTALCAVERN
            protype = @field.getRoll
          when :NEWWORLD
            protype = @battle.getRandomType
          else
            protype = @field.mimicry if @field.mimicry
        end
        camotype = protype
        if !camotype.nil? && !i.hasType?(camotype)
          i.type1 = camotype
          i.type2 = nil
          pbDisplay(_INTL("{1} had its type changed to {2}!", i.pbThis, camotype.capitalize))
        end
      end
      # Speed Boost
      # A Pokémon's turncount is 0 if it became active after the beginning of a round
      if i.turncount > 0 && (i.ability == :SPEEDBOOST || (@field.effect == :ELECTERRAIN && i.ability == :MOTORDRIVE) ||
        ([:VOLCANIC, :VOLCANICTOP, :WATERSURFACE, :UNDERWATER, :INFERNAL].include?(@field.effect) && i.ability == :STEAMENGINE))
        if !i.pbTooHigh?(PBStats::SPEED)
          i.pbIncreaseStatBasic(PBStats::SPEED, 1)
          pbCommonAnimation("StatUp", i, nil)
          pbDisplay(_INTL("{1}'s {2} raised its Speed!", i.pbThis, getAbilityName(i.ability)))
        end
      end
      if i.ability == :ACCUMULATION && i.turncount > 0 && i.lastMoveUsed != :SPITUP && i.lastMoveUsed != :SWALLOW
        if i.effects[:Stockpile] < 3
          i.effects[:Stockpile] += 1
          i.pbIncreaseStatBasic(PBStats::DEFENSE, 1)
          i.effects[:StockpileDef] += 1
          i.pbIncreaseStatBasic(PBStats::SPDEF, 1)
          i.effects[:StockpileSpDef] += 1
          pbDisplay(_INTL("{1} stockpiled with Accumulation!", i.pbThis))
        end
      end
      # Gen 9 Mod - Added Clear Amulet
      if @field.effect == :SWAMP && ![:HEAVYDUTYBOOTS, :CLEARAMULET].include?(i.item) && !i.isAirborne? &&
        ![:WHITESMOKE, :CLEARBODY, :QUICKFEET, :SWIFTSWIM, :PROPELLERTAIL, :STEAMENGINE].include?(i.ability)
        statdrop = 1
        statdrop = 2 if i.effects[:MultiTurn] > 0 && Rejuv
        if i.pbReduceStat(PBStats::SPEED, statdrop, statmessage: false)
          if i.ability == :CONTRARY
            pbDisplay(_INTL("{1}'s Speed rose!", i.pbThis))
          else
            pbDisplay(_INTL("{1}'s Speed sank...", i.pbThis))
          end
        end
      end
      if (@field.effect == :DESERT || @field.effect == :HAUNTED) && i.ability == :WANDERINGSPIRIT
        if !i.pbTooLow?(PBStats::SPEED)
          i.pbReduceStat(PBStats::SPEED, 1, statmessage: false)
          pbDisplay(_INTL("{1}'s Wandering Spirit lowered its Speed!", i.pbThis))
        end
      end
      #sleepyswamp #sleepydimension #spookydreams #fairyringsleep #sleepycorro
      if (i.status == :SLEEP || (i.ability == :COMATOSE && @battle.FE != :ELECTERRAIN)) && i.ability != :MAGICGUARD
        if @field.effect == :SWAMP # Swamp Field
          if i.effects[:MultiTurn] > 0 && Rejuv
            hploss = i.pbReduceHP((i.totalhp / 8.0).floor, true)
          else
            hploss = i.pbReduceHP((i.totalhp / 16.0).floor, true)
          end
          pbDisplay(_INTL("{1}'s strength is sapped by the swamp!", i.pbThis)) if hploss > 0
        elsif @field.effect == :DIMENSIONAL # Dimensional Field (Rejuv)
          hploss = i.pbReduceHP((i.totalhp / 16.0).floor, true)
          pbDisplay(_INTL("{1}'s dream is corrupted by the dimension!", i.pbThis)) if hploss > 0
        elsif @field.effect == :HAUNTED && !i.hasType?(:GHOST) # Haunted Field (Rejuv)
          hploss = i.pbReduceHP((i.totalhp / 16.0).floor, true)
          pbDisplay(_INTL("{1}'s dream is corrupted by the evil spirits!", i.pbThis)) if hploss > 0
        elsif @field.effect == :BEWITCHED # Bewitched Woods (Rejuv)
          hploss = i.pbReduceHP((i.totalhp / 16.0).floor, true)
          pbDisplay(_INTL("{1}'s dream is corrupted by the evil in the woods!", i.pbThis)) if hploss > 0
        elsif @field.effect == :CORROSIVE && !i.isAirborne? && !i.hasType?(:STEEL) && !i.hasType?(:POISON) &&
              ![:POISONHEAL, :TOXICBOOST, :WONDERGUARD, :IMMUNITY, :PASTELVEIL].include?(i.ability) && i.crested != :ZANGOOSE
          hploss = i.pbReduceHP((i.totalhp / 16.0).floor, true)
          pbDisplay(_INTL("{1} is seared by the corrosion!", i.pbThis)) if hploss > 0
        end
      end
      if i.hp <= 0
        return if !i.pbFaint

        next
      end
      # sleepyrainbow
      if i.status == :SLEEP || (i.ability == :COMATOSE && @battle.FE != :ELECTERRAIN)
        if @field.effect == :RAINBOW && i.effects[:HealBlock] == 0 # Rainbow Field
          hpgain = (i.totalhp / 16.0).floor
          hpgain = i.pbRecoverHP(hpgain, true)
          pbDisplay(_INTL("{1} recovered health in its peaceful sleep!", i.pbThis))
        end
      end
      # Check HP berry after sleep damage from fields
      i.pbBerryHerbCheck
      # Gen 9 Mod - Syrup Bomb implementation
      if i.effects[:SyrupBomb] > 0
        if i.ability == :CONTRARY && !i.pbTooHigh?(PBStats::SPEED)
          i.pbIncreaseStatBasic(PBStats::SPEED, 1)
          pbCommonAnimation("StatUp",i,nil)
          pbDisplay(_INTL("The sticky syrup raised {1}'s speed!?", i.pbThis))
        elsif !i.pbTooLow?(PBStats::SPEED)
          i.pbReduceStatBasic(PBStats::SPEED, 1)
          pbCommonAnimation("StatDown",i,nil)
          pbDisplay(_INTL("The sticky syrup lowered {1}'s speed!", i.pbThis))
        end
      end
      if i.hp <= 0
        return if !i.pbFaint

        next
      end
      # Water Compaction on Water-based Fields
      if i.ability == :WATERCOMPACTION
        if @field.effect == :UNDERWATER || ([:SWAMP, :WATERSURFACE, :MURKWATERSURFACE].include?(@field.effect) && !i.isAirborne?)
          if !i.pbTooHigh?(PBStats::DEFENSE)
            i.pbIncreaseStatBasic(PBStats::DEFENSE, 2)
            pbCommonAnimation("StatUp", i, nil)
            pbDisplay(_INTL("{1}'s Water Compaction sharply raised its defense!", i.pbThis))
          end
        end
      end
      if i.effects[:Octolock] >= 0
        if i.pbCanReduceStatStage?(PBStats::DEFENSE, false) || i.pbCanReduceStatStage?(PBStats::SPDEF, false)
          pbCommonAnimation("Bind", i, nil)
          showMessage = false
          if i.pbReduceStat(PBStats::DEFENSE, 1, abilitymessage: false, statdropper: @battlers[i.effects[:Octolock]])
            showMessage = true
          end
          if i.pbReduceStat(PBStats::SPDEF, 1, abilitymessage: false, statdropper: @battlers[i.effects[:Octolock]])
            showMessage = true
          end
          if showMessage
            if i.ability == :CONTRARY
              pbDisplay(_INTL("The Octolock increased {1}'s defenses!", i.pbThis))
            else
              pbDisplay(_INTL("The Octolock lowered {1}'s defenses!", i.pbThis))
            end
          end
        end
      end
      if Rejuv && i.effects[:SwampWeb]
        if @battle.FE == :SWAMP
          stat = sample([PBStats::ATTACK, PBStats::DEFENSE, PBStats::SPATK, PBStats::SPDEF, PBStats::SPEED])
          i.pbReduceStat(stat, 1, abilitymessage: true)
        end
      end
      # Bad Dreams
      if (i.status == :SLEEP || (i.ability == :COMATOSE && @battle.FE != :ELECTERRAIN)) && i.ability != :MAGICGUARD && !(i.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM) && @field.effect != :RAINBOW
        if i.pbOpposing1.ability == :BADDREAMS || i.pbOpposing2.ability == :BADDREAMS
          hpdrain = (i.totalhp / 8.0).floor
          hpdrain = (i.totalhp / 6.0).floor if @battle.FE == :DARKNESS2
          hpdrain = (i.totalhp / 4.0).floor if @battle.FE == :INFERNAL || @battle.FE == :DARKNESS3
          hploss = i.pbReduceHP(hpdrain, true)
          pbDisplay(_INTL("{1} is having a bad dream!", i.pbThis)) if hploss > 0
        end
      end
      if i.isFainted?
        return if !i.pbFaint

        next
      end
      # World of Nightmares
      if i.pbOpposing1.ability == :WORLDOFNIGHTMARES || i.pbOpposing2.ability == :WORLDOFNIGHTMARES
        nightmarechip = [64, i.turncount].min
        nightmarechip * 2 if @battle.FE == :NEWWORLD
        hploss = i.pbReduceHP(((i.totalhp / 32).floor) * nightmarechip, true)
        pbDisplay(_INTL("{1}'s nightmares are becoming a reality!", i.pbThis)) if hploss > 0
      end
      if i.isFainted?
        return if !i.pbFaint

        next
      end
      # Pickup (help me -Orsan).
      # tested on SV and in showdown, it deprioritizes items that activate during an attack, such as type berries, focus sashes, and presumably gems. thats represented here as pickupB.
      if i.ability == :PICKUP && i.item.nil?
        pickedup = false
        for pickuptarget in pickupA
          if !pickedup && i.index != pickuptarget && battlers[pickuptarget].pokemon.itemRecycle && !battlers[pickuptarget].isFainted?
            i.item = battlers[pickuptarget].pokemon.itemRecycle
            battlers[pickuptarget].pokemon.itemRecycle = nil
            pbDisplay(_INTL("{1} found one {2}!", i.pbThis, getItemName(i.item)))
            pickedup = true
          end
        end
        for pickuptarget in pickupB
          if !pickedup && i.index != pickuptarget && battlers[pickuptarget].pokemon.itemRecycle && !battlers[pickuptarget].isFainted?
            i.item = battlers[pickuptarget].pokemon.itemRecycle
            battlers[pickuptarget].pokemon.itemRecycle = nil
            pbDisplay(_INTL("{1} found one {2}!", i.pbThis, getItemName(i.item)))
            pickedup = true
          end
        end
        i.pbPassiveItemHP
        i.pbBerryHerbCheck
        seedCheck
      end
      # Harvest
      if i.ability == :HARVEST && i.item.nil? && i.pokemon.itemRecycle # if an item was recycled, check
        if pbIsBerry?(i.pokemon.itemRecycle) && (pbRandom(100) > 50 || (pbWeather == :SUNNYDAY && !i.hasWorkingItem(:UTILITYUMBRELLA)) ||
           @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN, 2, 5) || (Rejuv && @battle.FE == :GRASSY))
          i.item = i.pokemon.itemRecycle
          i.pokemon.itemInitial = i.pokemon.itemRecycle
          i.pokemon.itemRecycle = nil
          firstberryletter = getItemName(i.item).split(//).first
          if firstberryletter == "A" || firstberryletter == "E" || firstberryletter == "I" ||
             firstberryletter == "O" || firstberryletter == "U"
            pbDisplay(_INTL("{1} harvested an {2}!", i.pbThis, getItemName(i.item)))
          else
            pbDisplay(_INTL("{1} harvested a {2}!", i.pbThis, getItemName(i.item)))
          end
          i.pbBerryHerbCheck
        end
      end
      # Gen 9 Mod - Added Cud Chew
      if i.ability == :CUDCHEW
        if i.effects[:CudChew][0] == 0
          berryCudChew = getItemName(i.effects[:CudChew][1])
          pbDisplayPaused(_INTL("{1} regurgitated its {2} to eat it again!", i.pbThis, berryCudChew))
          i.pbUseBerry(i.effects[:CudChew][1], true)
          i.effects[:CudChew][0] = -1
          i.effects[:CudChew][1] = nil
        elsif i.effects[:CudChew][0] > 0
          i.effects[:CudChew][0] = 0
        end
      end
      # Ball Fetch
      puts i.effects[:BallFetch]
      if i.ability == :BALLFETCH && !i.effects[:BallFetch].nil? && i.item.nil?
        pokeball = i.effects[:BallFetch]
        i.item = pokeball
        i.pokemon.itemInitial = pokeball
        PBDebug.log("[Ability triggered] #{i.pbThis}'s Ball Fetch found #{getItemName(pokeball)}")
        pbDisplay(_INTL("{1} fetched a {2}!", i.pbThis, getItemName(pokeball)))
      end
      # Moody
      if i.ability == :CLOUDNINE && @field.effect == :RAINBOW
        failsafe = 0
        randoms = []
        loop do
          failsafe += 1
          break if failsafe == 1000

          randomnumber = 1 + pbRandom(7)
          if !i.pbTooHigh?(randomnumber)
            randoms.push(randomnumber)
            break
          end
        end
        if failsafe != 1000
          i.stages[randoms[0]] += 1
          i.stages[randoms[0]] = 6 if i.stages[randoms[0]] > 6
          pbCommonAnimation("StatUp", i, nil)
          pbDisplay(_INTL("{1}'s Cloud Nine raised its {2}!", i.pbThis, i.pbGetStatName(randoms[0])))
        end
      end
      if i.ability == :MOODY
        randomup = []
        randomdown = []
        failsafe1 = 0
        failsafe2 = 0
        loop do
          failsafe1 += 1
          break if failsafe1 == 1000

          randomnumber = 1 + pbRandom(Gen <= 7 ? 7 : 5)
          if !i.pbTooHigh?(randomnumber)
            randomup.push(randomnumber)
            break
          end
        end
        loop do
          failsafe2 += 1
          break if failsafe2 == 1000

          randomnumber = 1 + pbRandom(Gen <= 7 ? 7 : 5)
          if !i.pbTooLow?(randomnumber) && randomnumber != randomup[0]
            randomdown.push(randomnumber)
            break
          end
        end
        if failsafe1 != 1000
          i.stages[randomup[0]] += 2
          i.stages[randomup[0]] = 6 if i.stages[randomup[0]] > 6
          pbCommonAnimation("StatUp", i, nil)
          pbDisplay(_INTL("{1}'s Moody sharply raised its {2}!", i.pbThis, i.pbGetStatName(randomup[0])))
        end
        if failsafe2 != 1000
          i.stages[randomdown[0]] -= 1
          pbCommonAnimation("StatDown", i, nil)
          pbDisplay(_INTL("{1}'s Moody lowered its {2}!", i.pbThis, i.pbGetStatName(randomdown[0])))
        end
      end
      i.pbBerryHerbCheck
    end
    # Gen 9 Mod - Checks and updates for Opportunist
    priority.each {|i| i.opportunistCheck}
    priority.each {|i| i.statsRaisedSinceLastCheck.clear}
    for i in priority
      next if i.isFainted?
      next if !i.itemWorks?

      # Toxic Orb
      if i.item == :TOXICORB && i.status.nil? && i.pbCanPoison?(false, true)
        i.status = :POISON
        i.statusCount = 1
        i.effects[:Toxic] = 0
        pbCommonAnimation("Poison", i, nil)
        pbDisplay(_INTL("{1} was poisoned by its {2}!", i.pbThis, getItemName(i.item)))
      end
      # Flame Orb
      if i.item == :FLAMEORB && i.status.nil? && i.pbCanBurn?(false, true)
        i.status = :BURN
        i.statusCount = 0
        pbCommonAnimation("Burn", i, nil)
        pbDisplay(_INTL("{1} was burned by its {2}!", i.pbThis, getItemName(i.item)))
      end
      # Sticky Barb
      if i.item == :STICKYBARB && i.ability != :MAGICGUARD && !(i.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
        pbDisplay(_INTL("{1} is hurt by its {2}!", i.pbThis, getItemName(i.item)))
        @scene.pbDamageAnimation(i, 0)
        i.pbReduceHP((i.totalhp / 8.0).floor)
      end
      if i.isFainted?
        return if !i.pbFaint

        next
      end
    end
    # Emergency exit caused by passive end of turn damage
    for i in priority
      if i.userSwitch
        i.userSwitch = false
        pbDisplay(_INTL("{1} went back to {2}!", i.pbThis, pbGetOwner(i.index).name))
        newpoke = 0
        newpoke = pbSwitchInBetween(i.index, true, false)
        pbMessagesOnReplace(i.index, newpoke)
        i.vanished = false
        i.pbResetForm
        pbReplace(i.index, newpoke, false)
        pbOnActiveOne(i)
        i.pbAbilitiesOnSwitchIn(true)
      end
    end
    # Hunger Switch
    for i in priority
      next if i.isFainted?

      if i.ability == :HUNGERSWITCH && i.species == :MORPEKO && @battle.FE != :FROZENDIMENSION
        i.form = (i.form == 0) ? 1 : 0
        i.pbUpdate(true)
        scene.pbChangePokemon(i, i.pokemon)
        pbDisplay(_INTL("{1} transformed!", i.pbThis))
      end
    end
    # Form checks
    for i in 0...4
      next if @battlers[i].isFainted?

      @battlers[i].pbCheckForm
      @battlers[i].pbCheckFormRoundEnd
    end
    pbGainEXP

    # Checks if a pokemon on either side has fainted on this turn
    # for retaliate
    player   = priority[0]
    opponent = priority[1]
    player.pbOwnSide.effects[:Retaliate] = player.isFainted? || (@doublebattle && player.pbPartner.isFainted?)
    opponent.pbOwnSide.effects[:Retaliate] = opponent.isFainted? || (@doublebattle && opponent.pbPartner.isFainted?)
    for i in priority
      next if i.isFainted?
      next if i.nil?
      next if !Rejuv
      next if @party2[0].nil?

      @state.effects[:sosBuffer] = 3 if @state.effects[:sosBuffer] == 0 && (@doublebattle && i.isbossmon && i.pbPartner.issossmon)
      @state.effects[:sosBuffer] = 4 if @state.effects[:sosBuffer] == 0 && $cache.bosses[@party2[0].bossId] && $cache.bosses[@party2[0].bossId].name == "Spacea"
    end
    # sosBuffer
    if @state.effects[:sosBuffer] > 0
      @state.effects[:sosBuffer] -= 1
    end
   pbBossSOS(priority) if Rejuv && @state.effects[:sosBuffer] == 0
    pbSwitch
    return if @decision > 0

    for i in priority
      next if i.isFainted?

      i.pbAbilitiesOnSwitchIn(false)
    end
    for i in 0...4
      if @battlers[i].turncount > 0
        if @battlers[i].ability == :TRUANT
          @battlers[i].effects[:Truant] = !@battlers[i].effects[:Truant]
        else
          @battlers[i].effects[:Truant] = false
        end
      end
      if @battlers[i].effects[:LockOn] > 0 # Also Mind Reader
        @battlers[i].effects[:LockOn] -= 1
        @battlers[i].effects[:LockOnPos] = -1 if @battlers[i].effects[:LockOn] == 0
      end
      @battlers[i].effects[:Roost] = false
      @battlers[i].effects[:Flinch] = false
      @battlers[i].effects[:FollowMe] = false
      @battlers[i].effects[:RagePowder] = false
      # Gen 9 Mod - Fixed Charge to work until the user uses an electric move
      @battlers[i].effects[:Charge] = false if @battlers[i].effects[:Charge] == true && Gen <= 8
      @battlers[i].effects[:LaserFocus] -= 1 if @battlers[i].effects[:LaserFocus] > 0
      @battlers[i].effects[:Snatch] = false
      @battlers[i].effects[:Electrify] = false
      @battlers[i].lastHPLost = 0
      @battlers[i].lastAttacker = -1
      @battlers[i].effects[:Counter] = -1
      @battlers[i].effects[:CounterTarget] = -1
      @battlers[i].effects[:MirrorCoat] = -1
      @battlers[i].effects[:MirrorCoatTarget] = -1
    end
    @pickupA = []
    @pickupB = []
    # Gen 9 Mod - Checks and updates for Opportunist
    priority.each {|i| i.opportunistCheck}
    priority.each {|i| i.statsRaisedSinceLastCheck.clear}
    # invalidate stored priority
    @usepriority = false
    @eruption = false
  end

  def pbPriority(ignorequickclaw = true, megacalc = false)
    return @priority if @usepriority && !megacalc # use stored priority if round isn't over yet (best ged rid of this in gen 8)

    @priority.clear
    priorityarray = []
    quickclawarray = [0, 0, 0, 0]
    # -Move priority take precedence(stored as priorityarray[i][0])
    # -Then Items  (stored as priorityarray[i][1])
    # -Then speed (stored as priorityarray[i][2]) (trick room is applied by just making speed negative.)
    # -The last element is just the battler index (which is otherwise lost when sorting)
    for i in 0..3
      priorityarray[i] = [0, 0, 0, i] # initializes the array and stores the battler index

      # Move priority
      pri = 0
      if @choices[i][0] == :switch || @battle.switchedOut[i] # If switching or has switched
        pri = 12
      end
      if @choices[i][0] == :item # Used item
        pri = 11
      end
      if @choices[i][0] == :move # Is a move
        pri = @choices[i][2].priority # Base move priority
        pri -= 1 if @battle.FE == :DEEPEARTH && @choices[i][2].move == :COREENFORCER
        pri += 1 if [:ORN_POUNCE,:ORN_LEADERSHIP].include?(battlers[i].ability) && battlers[i].turncount == 1
        pri += 1 if @field.effect == :CHESS && @battlers[i].pokemon && @battlers[i].pokemon.piece == :KING
        pri += 1 if @battlers[i].ability == :PRANKSTER && @choices[i][2].basedamage == 0 && @battlers[i].effects[:TwoTurnAttack] == 0 # Is status move
        pri += 1 if @battlers[i].ability == :GALEWINGS && @choices[i][2].type == :FLYING && (@battlers[i].hp == @battlers[i].totalhp || ((@field.effect == :MOUNTAIN || @field.effect == :SNOWYMOUNTAIN) && pbWeather == :STRONGWINDS))
        pri += 1 if @choices[i][2].move == :GRASSYGLIDE && (@field.effect == :GRASSY || @battle.state.effects[:GRASSY] > 0)
        pri += 1 if @choices[i][2].move == :QUASH && @field.effect == :DIMENSIONAL
        pri += 1 if @choices[i][2].basedamage != 0 && @battlers[i].crested == :FERALIGATR && @battlers[i].turncount == 1 # Feraligatr Crest
        pri += 3 if @battlers[i].ability == :TRIAGE && PBStuff::HEALFUNCTIONS.include?(@choices[i][2].function)
        pri += 3 if @battlers[i].crested == :ORN_MEGANIUM && (PBStuff::HEALFUNCTIONS.include?(@choices[i][2].function) || @choices[i][2].recoil > 0)
        pri = -2 if @battlers[i].ability == :MYCELIUMMIGHT && @choices[i][2].basedamage == 0 && @battlers[i].effects[:TwoTurnAttack] == 0 # Is status move # Gen 9 Mod - Added Mycelium Might
      end
      priorityarray[i][0] = pri

      # Item/stall priority (all items overwrite stall priority)
      priorityarray[i][1] = -1 if @battlers[i].ability == :STALL
      if !ignorequickclaw && @choices[i][0] == :move # Is a move
        if @battlers[i].ability == :QUICKDRAW && pbRandom(100) < 30
          priorityarray[i][1] = 1
          quickclawarray[i] = :QUICKDRAW
        elsif @battlers[i].itemWorks? && @battlers[i].item == :QUICKCLAW && pbRandom(100) < 20
          priorityarray[i][1] = 1
          quickclawarray[i] = :QUICKCLAW
        elsif @battlers[i].custap
          priorityarray[i][1] = 1
          quickclawarray[i] = :CUSTAPBERRY
        end
      end
      priorityarray[i][1] = -2 if (@battlers[i].itemWorks? && (@battlers[i].item == :LAGGINGTAIL || @battlers[i].item == :FULLINCENSE))

      # speed priority
      priorityarray[i][2] = @battlers[i].pbSpeed if @trickroom == 0
      priorityarray[i][2] = -@battlers[i].pbSpeed if @trickroom > 0

    end
    priorityarray.sort!

    # Speed ties. Only works correctly if two pokemon speed tie
    for i in 0..2
      for j in (i + 1)..3
        if priorityarray[i][0] == priorityarray[j][0] && priorityarray[i][1] == priorityarray[j][1] && priorityarray[i][2] == priorityarray[j][2]
          if pbRandom(2) == pbTieBreak
            priorityarray[i], priorityarray[j] = priorityarray[j], priorityarray[i]
          end
        end
      end
    end
    priorityarray.reverse!

    # Quick claw battle message
    for i in 0..3
      battler = @battlers[priorityarray[i][3]]
      @priority[i] = battler
      if (battler.ability == :QUICKDRAW) && quickclawarray[priorityarray[i][3]] == :QUICKDRAW
        if priorityarray[i][1] == 1 && !ignorequickclaw
          battler.effects[:QuickDrawSnipe] if @battle.FE == :COLOSSEUM
          pbDisplayBrief(_INTL("{1}'s Quick Draw let it move first!", battler.pbThis))
        end
      elsif (battler.itemWorks? && battler.item == :QUICKCLAW) && quickclawarray[priorityarray[i][3]] == :QUICKCLAW
        pbDisplayBrief(_INTL("{1}'s Quick Claw let it move first!", battler.pbThis)) if priorityarray[i][1] == 1 && !ignorequickclaw
      end
    end

    @usepriority = true
    return @priority
  end
end

class PokeBattle_Pokemon
  def initZmoves(crystal,player=false)
    zcrystal_to_type = PBStuff::TYPETOZCRYSTAL.invert
    @zmoves = [nil,nil,nil,nil]
    if crystal == :INTERCEPTZ
      @zmoves[0] = PBMove.new(:UNLEASHEDPOWER)
      @zmoves[1] = PBMove.new(:BLINDINGSPEED)
      @zmoves[2] = $game_switches[:RenegadeRoute] && player ? PBMove.new(:CHTHONICMALADY) : PBMove.new(:ELYSIANSHIELD)
      @zmoves[3] = PBMove.new(:DOMAINSHIFT)
    elsif (crystal == :WARDENIUMZ && IS_WARDEN_MON.include?(@species))
      @zmoves[0] = PBMove.new(:ORN_ORIGINALGENESIS)
      @zmoves[1] = PBMove.new(:ORN_ORIGINALGENESIS1)
      @zmoves[2] = PBMove.new(:ORN_ORIGINALGENESIS2)
      @zmoves[3] = PBMove.new(:ORN_ORIGINALGENESIS3)
    elsif zcrystal_to_type[crystal]
      for i in 0...@moves.length
        move = @moves[i]
        next if move.type != zcrystal_to_type[crystal]
        @zmoves[i] = move.category == :status ? PBMove.new(move.move) : PBMove.new(PBStuff::CRYSTALTOZMOVE[crystal])
      end
    elsif (PBStuff::MOVETOZCRYSTAL.invert)[crystal]
      case crystal
      when :ALORAICHIUMZ then return if !(@species==:RAICHU && (@form==1))
      when :DECIDIUMZ then return if !(@species==:DECIDUEYE && (@form==0))
      when :INCINIUMZ then return if @species!=:INCINEROAR
      when :PRIMARIUMZ then return if @species!=:PRIMARINA
      when :EEVIUMZ then return if @species!=:EEVEE
      when :PIKANIUMZ then return if @species!=:PIKACHU
      when :SNORLIUMZ then return if @species!=:SNORLAX
      when :MEWNIUMZ then return if @species!=:MEW
      when :TAPUNIUMZ then return if !(@species==:TAPUKOKO || @species==:TAPULELE || @species==:TAPUFINI || @species==:TAPUBULU)
      when :MARSHADIUMZ then return if @species!=:MARSHADOW
      when :KOMMONIUMZ then return if @species!=:KOMMOO
      when :LYCANIUMZ then return if @species!=:LYCANROC
      when :MIMIKIUMZ then return if @species!=:MIMIKYU
      when :SOLGANIUMZ then return if !((@species==:NECROZMA && @form==1) || @species==:SOLGALEO)
      when :LUNALIUMZ then return if !((@species==:NECROZMA && @form==2) || @species==:LUNALA)
      when :ULTRANECROZIUMZ then return if !(@species==:NECROZMA && @form!=0)
      end
      for i in 0...@moves.length
        move = @moves[i]
        next if crystal != PBStuff::MOVETOZCRYSTAL[move.move]
        @zmoves[i] = PBMove.new(PBStuff::CRYSTALTOZMOVE[crystal])
      end
    end
  end
end

class PokeBattle_AI
  def checkZMoves
    return if @attacker.zmoves.nil?
    return if !@battle.pbCanZMove?(@index)

    # Special case processing- there are specific moves that should intentionally be made z-moves
    # if both the move and the z-crystal are present
    bestbase = 0
    for i in 0...@attacker.zmoves.length
      move = @attacker.zmoves[i]
      next if move.nil?
      next if @attacker.moves[i].nil?
      next if @attacker.moves[i].pp == 0

      if (move.move == :CONVERSION || move.move == :SPLASH || move.move == :CELEBRATE) && @attacker.item == :NORMALIUMZ
        zmove = move
        break
      end
      if (move.move == :NATUREPOWER && @attacker.item == :NORMALIUMZ)
        newmove = PokeBattle_Move.pbFromPBMove(@battle, PBMove.new(@battle.field.naturePower), @attacker)
        if newmove.basedamage > 0
          zmove = PokeBattle_Move.pbFromPBMove(@battle, PBMove.new(PBStuff::CRYSTALTOZMOVE[PBStuff::TYPETOZCRYSTAL[newmove.type]]), @attacker, newmove)
          break
        end
      end
      if (move.move == :EXTREMEEVOBOOST && @attacker.item == :EEVIUMZ)
        zmove = move
        break
      end
      if @attacker.item == :WARDENIUMZ && IS_WARDEN_MON.include?(@attacker.species)
        zmove = move
        break
      end
      next if $cache.moves[move.move].category == :status # Skip all other status moves

      thisbase = move.basedamage
      if bestbase < thisbase
        bestbase = thisbase
        zmove = move
      end
    end
    # if there's a zmove, put it on the moves list and run it with the rest
    if zmove
      @attacker.moves.push(zmove)
      @mondata.zmove = zmove
      @mondata.scorearray.each { |array| array.push(-1) }
      @mondata.roughdamagearray.each { |array| array.push(-1) }
    end
  end
end

class PBStuff
  ZMOVES = [
    :BREAKNECKBLITZ, :ALLOUTPUMMELING, :SUPERSONICSKYSTRIKE, :ACIDDOWNPOUR, :TECTONICRAGE, :CONTINENTALCRUSH,
    :SAVAGESPINOUT, :NEVERENDINGNIGHTMARE, :CORKSCREWCRASH, :INFERNOOVERDRIVE, :HYDROVORTEX, :BLOOMDOOM,
    :GIGAVOLTHAVOC, :SHATTEREDPSYCHE, :SUBZEROSLAMMER, :DEVASTATINGDRAKE, :BLACKHOLEECLIPSE, :TWINKLETACKLE,
    :STOKEDSPARKSURFER, :SINISTERARROWRAID, :MALICIOUSMOONSAULT, :OCEANICOPERETTA, :EXTREMEEVOBOOST, :CATASTROPIKA,
    :PULVERIZINGPANCAKE, :GENESISSUPERNOVA, :GUARDIANOFALOLA, :SOULSTEALING7STARSTRIKE, :CLANGOROUSSOULBLAZE,
    :SPLINTEREDSTORMSHARDS, :LETSSNUGGLEFOREVER,:SEARINGSUNRAZESMASH, :MENACINGMOONRAZEMAELSTROM, :LIGHTTHATBURNSTHESKY,
    :UNLEASHEDPOWER, :BLINDINGSPEED, :ELYSIANSHIELD, :CHTHONICMALADY, :DOMAINSHIFT,

    :ORN_ASTRALSTARSTORM,:ORN_ARCLIGHTBARRAGE,:ORN_ACOUSTICOVERLOAD,:ORN_ORIGINALGENESIS,:ORN_ORIGINALGENESIS1,:ORN_ORIGINALGENESIS2,:ORN_ORIGINALGENESIS3,
  ]

  TYPETOZCRYSTAL = {
    :NORMAL   => :NORMALIUMZ, :FIGHTING => :FIGHTINIUMZ,
    :FLYING   => :FLYINIUMZ,  :POISON   => :POISONIUMZ, 
    :GROUND   => :GROUNDIUMZ, :ROCK     => :ROCKIUMZ,
    :BUG      => :BUGINIUMZ,  :GHOST    => :GHOSTIUMZ,
    :STEEL    => :STEELIUMZ,  :FIRE     => :FIRIUMZ, 
    :WATER    => :WATERIUMZ,  :GRASS    => :GRASSIUMZ, 
    :ELECTRIC => :ELECTRIUMZ, :PSYCHIC  => :PSYCHIUMZ,
    :ICE      => :ICIUMZ,     :DRAGON   => :DRAGONIUMZ, 
    :DARK     => :DARKINIUMZ, :FAIRY    => :FAIRIUMZ,
    :COSMIC   => :COSMICIUMZ, :LIGHT    => :LIGHTIUMZ,
    :SOUND    => :SOUNDIUMZ,  :QMARKS   => :WARDENIUMZ,
  }

  CRYSTALTOZMOVE = {
    :NORMALIUMZ => :BREAKNECKBLITZ,           :FIGHTINIUMZ => :ALLOUTPUMMELING,
    :FLYINIUMZ => :SUPERSONICSKYSTRIKE,       :POISONIUMZ => :ACIDDOWNPOUR,
    :GROUNDIUMZ => :TECTONICRAGE,             :ROCKIUMZ => :CONTINENTALCRUSH,
    :BUGINIUMZ => :SAVAGESPINOUT,             :GHOSTIUMZ => :NEVERENDINGNIGHTMARE,
    :STEELIUMZ => :CORKSCREWCRASH,            :FIRIUMZ => :INFERNOOVERDRIVE,
    :WATERIUMZ => :HYDROVORTEX,               :GRASSIUMZ => :BLOOMDOOM,
    :ELECTRIUMZ => :GIGAVOLTHAVOC,            :PSYCHIUMZ => :SHATTEREDPSYCHE,
    :ICIUMZ => :SUBZEROSLAMMER,               :DRAGONIUMZ => :DEVASTATINGDRAKE,
    :DARKINIUMZ => :BLACKHOLEECLIPSE,         :FAIRIUMZ => :TWINKLETACKLE,
    :ALORAICHIUMZ => :STOKEDSPARKSURFER,      :DECIDIUMZ => :SINISTERARROWRAID,
    :INCINIUMZ => :MALICIOUSMOONSAULT,        :PRIMARIUMZ => :OCEANICOPERETTA,
    :EEVIUMZ => :EXTREMEEVOBOOST,             :PIKANIUMZ => :CATASTROPIKA,
    :SNORLIUMZ => :PULVERIZINGPANCAKE,        :MEWNIUMZ => :GENESISSUPERNOVA,
    :TAPUNIUMZ => :GUARDIANOFALOLA,           :MARSHADIUMZ => :SOULSTEALING7STARSTRIKE,
    :KOMMONIUMZ => :CLANGOROUSSOULBLAZE,      :LYCANIUMZ => :SPLINTEREDSTORMSHARDS,
    :MIMIKIUMZ => :LETSSNUGGLEFOREVER,        :SOLGANIUMZ => :SEARINGSUNRAZESMASH,
    :LUNALIUMZ => :MENACINGMOONRAZEMAELSTROM, :ULTRANECROZIUMZ => :LIGHTTHATBURNSTHESKY,
    :COSMICIUMZ => :ORN_ASTRALSTARSTORM,      :LIGHTIUMZ => :ORN_ARCLIGHTBARRAGE,
    :SOUNDIUMZ => :ORN_ACOUSTICOVERLOAD,      :WARDENIUMZ      => :ORN_ORIGINALGENESIS,
  }

  WARDEN_MEGASTONE = {:ORN_GENGAR => [:ORN_GENGARITE], :ORN_DODRIO => [:ORN_DODRINITE], :ORN_ARBOK => [:ORN_ARBOKINITE], :ORN_STARMIE => [:ORN_STARMITE], :ORN_STEELIX => [:ORN_STEELIXITE], :ORN_XATU => [:ORN_XATUNITE], :ORN_SEISMITOAD => [:ORN_SEISMITOADITE], :ORN_GOLURK => [:ORN_GOLITE], :ORN_GYARADOS => [:ORN_GYARADOSITE], :ORN_AVALUGG => [:ORN_AVALUGGITE], :ORN_RAPIDASH => [:ORN_RAPIDASHINITE], :ORN_AERODACTYL => [:ORN_AERODACTYLITE], :ORN_GIGALITH => [:ORN_GIGANITE], :ORN_GLISCOR => [:ORN_GLISCITE], :ORN_SUDOWOODO => [:ORN_SUDOWOODITE], :ORN_NOCTOWL => [:ORN_NOCTOWLITE], :ORN_ELECTRODE => [:ORN_ELECTRONITE], :ORN_BEEDRILL => [:ORN_BEEDRILLITE], :ORN_MACHAMP => [:ORN_MACHAMPITE], :ORN_VENUSAUR => [:ORN_VENUSAURITE], :ORN_SHARPEDO => [:ORN_SHARPEDONITE], :ORN_CHANDELURE => [:ORN_CHANDELITE], :ORN_GLALIE => [:ORN_GLALITITE], :ORN_FROSLASS => [:ORN_FROSLASSITE], :ORN_INFERNAPE => [:ORN_INFERNAPINITE], :ORN_SABLEYE => [:ORN_SABLENITE], :ORN_BEARTIC => [:ORN_BEARTICITE], :ORN_SCEPTILE => [:ORN_SCEPTILITE], :ORN_TYRANITAR => [:ORN_TYRANITARITE], :ORN_HIPPOWDON => [:ORN_HIPPOWDONITE], :ORN_AMPHAROS => [:ORN_AMPHAROSITE], :ORN_ALTARIA => [:ORN_ALTARIANITE], :ORN_HERACROSS => [:ORN_HERACRONITE], :ORN_SAWSBUCK => [:ORN_SAWSBUCKITE], :ORN_AGGRON => [:ORN_AGGRONITE], :ORN_SLOWKING => [:ORN_SLOWKINGITE], :ORN_CORVIKNIGHT => [:ORN_CORVINITE], :ORN_KINGDRA => [:ORN_KINGDRANITE], :ORN_BUTTERFREE => [:ORN_BUTTERFRITE], :ORN_FURRET => [:ORN_FURRETITE], :ORN_GARDEVOIR => [:ORN_GARDEVOIRITE], :ORN_GALLADE => [:ORN_GALLADITE], :ORN_DUGTRIO => [:ORN_DUGTRIOITE], :ORN_MELOETTA => [:ORN_MELOETTITE], :ORN_ABSOL => [:ORN_ABSOLITE], :ORN_METAGROSS => [:ORN_METAGROSSITE], :ORN_MEDICHAM => [:ORN_MEDICHAMITE], :ORN_PIDGEOT => [:ORN_PIDGEOTITE], :ORN_BLISSEY => [:ORN_BLISSITE], :ORN_TENTACRUEL => [:ORN_TENTACRUELITE], :ORN_TSAREENA => [:ORN_TSAREENITEX, :ORN_TSAREENITEY], :ORN_BEHEEYEM => [:ORN_BEHEEYEMITE], :ORN_SANDACONDA => [:ORN_SANDACONITE], :ORN_RAICHU => [:ORN_RAICHUNITE], :ORN_COFAGRIGUS => [:ORN_COFAGRINITE], :ORN_SWAMPERT => [:ORN_SWAMPERTITE], :ORN_GOTHITELLE => [:ORN_GOTHITELLITE], :ORN_CHARIZARD => [:ORN_CHARIZARDITE], :ORN_WIGGLYTUFF => [:ORN_WIGGNITE], :ORN_MANECTRIC => [:ORN_MANECTITE], :ORN_MAMOSWINE => [:ORN_MAMOSWINITE], :ORN_TORTERRA => [:ORN_TORTERRANITE], :ORN_LOPUNNY => [:ORN_LOPUNNITE], :ORN_GOTHITELLE2 => [:ORN_GOTHITELLITE2], :ORN_DONPHAN => [:ORN_DONPHANITE], :ORN_GARCHOMP => [:ORN_GARCHOMPITE], :ORN_NINETALES => [:ORN_NINETALITE], :ORN_TOXTRICITY => [:ORN_TOXTRICITE], :ORN_DUGTRIO2 => [:ORN_DUGTRIOITE2], :ORN_LUVDISC => [:ORN_LUVDISCITE], :ORN_ABSOL2 => [:ORN_ABSOLITE2], :ORN_ABOMASNOW => [:ORN_ABOMASITE], :ORN_SABLEYE2 => [:ORN_SABLENITE2], :ORN_GARBODOR => [:ORN_GARBODINITE], :ORN_ALTARIA2 => [:ORN_ALTARIANITE2], :ORN_SWAMPERT2 => [:ORN_SWAMPERTITE2], :ORN_MASQUERAIN2 => [:ORN_MASQUERITE2], :ORN_BARBARACLE => [:ORN_BARBARACLITE], :ORN_FALINKS => [:ORN_FALINKITE], :ORN_MISMAGIUS => [:ORN_MISMAGITE], :ORN_COALOSSAL => [:ORN_COALOSSALITE], :ORN_GIGALITH2 => [:ORN_GIGANITE2], :ORN_DRAGONITE => [:ORN_DRAGITE], :ORN_DRAGAPULT => [:ORN_DRAGAPULTITE], :ORN_BANETTE => [:ORN_BANETTITE], :ORN_HOUNDOOM => [:ORN_HOUNDOOMINITE], :ORN_EMPOLEON => [:ORN_EMPOLEONITE], :ORN_JUMPLUFF2 => [:ORN_JUMPINITE2], :ORN_EXPLOUD => [:ORN_EXPLOUDINITE], :ORN_CENTISKORCH => [:ORN_CENTISKORITE], :ORN_SALAMENCE => [:ORN_SALAMENCITE], :ORN_GRAPPLOCT => [:ORN_GRAPPLOCTITE], :ORN_HATTERENE => [:ORN_HATTERENITE], :ORN_CHIMECHO => [:ORN_CHIMECHITE], :ORN_GRIMMSNARL2 => [:ORN_GRIMMSNARLITE2], :ORN_WYRDEER2 => [:ORN_WYRDEERITE2], :ORN_URSALUNA => [:ORN_URSALUNITE], :ORN_EMOLGA => [:ORN_EMOLGITE], :ORN_VESPIQUEN => [:ORN_VESPIQUENITE], :ORN_BLAZIKEN => [:ORN_BLAZIKENITE], :ORN_GARGANACL => [:ORN_GARGANACLITE], :ORN_WOBBUFFET => [:ORN_WOBBNITE], :ORN_PLUSLE => [:ORN_PLUSITE], :ORN_MINUN => [:ORN_MINUNITE], :ORN_BLASTOISE => [:ORN_BLASTOISINITE], :ORN_CACTURNE2 => [:ORN_CACTURNITE2], :ORN_URSALUNA2 => [:ORN_URSALUNITE2], :ORN_DREDNAW => [:ORN_DREDNITE], :ORN_MELMETAL => [:ORN_MELMETALITE], :ORN_WHIMSICOTT2 => [:ORN_WHIMSICOTTITE2], :ORN_CHARIZARD2 => [:ORN_CHARIZARDITE2]}
  WARDEN_MEGASTONE.default = []

  POKEMONTOCREST = {
    :TYPHLOSION  => :TYPHCREST,         :ARIADOS   => :ARIACREST,
    :FERALIGATR   => :FERACREST,        :DEDENNE   => :DEDECREST,
    :MEGANIUM   => :MEGCREST,           :MAGCARGO   => :MAGCREST,
    :BEHEEYEM  =>  :BEHECREST,          :VESPIQUEN => :VESPICREST,
    :GLACEON => :GLACCREST,             :LEAFEON     => :LEAFCREST,
    :FEAROW   => :FEARCREST,            :DUSKNOIR   => :DUSKCREST,
    :STANTLER    => :STANTCREST,        :WYRDEER    => :STANTCREST,
    :RELICANTH   => :RELICREST,         :ORICORIO  => :ORICREST,
    :SILVALLY     => :SILVCREST,        :SEVIPER   => :SEVCREST,
    :COFAGRIGUS  => :COFCREST,          :SKUNTANK   => :SKUNCREST,
    :WHISCASH => :WHISCREST,            :DARMANITAN    => :DARMCREST,
    :CHERRIM  => :CHERCREST,            :CLAYDOL     => :CLAYCREST,
    :ZANGOOSE   => :ZANGCREST,          :RAMPARDOS     => :RAMPCREST,
    :LEDIAN     => :LEDICREST,          :SPIRITOMB  => :SPIRITCREST,
    :TORTERRA   => :TORCREST,           :EMPOLEON    => :EMPCREST,
    :INFERNAPE    => :INFCREST,         :CASTFORM    => :CASTCREST,
    :BOLTUND   => :BOLTCREST,           :THIEVUL   => :THIEVCREST,
    :LUXRAY   => :LUXCREST,             :NOCTOWL    => :NOCCREST,
    :DRUDDIGON   => :DRUDDICREST,       :PHIONE    => :PHIONECREST,
    :DELCATTY     => :DELCREST,         :SWALOT  => :SWACREST,
    :CINCCINO  => :CINCCREST,           :PROBOPASS  => :PROBOCREST,
    :BASTIODON => :BASTCREST,           :HYPNO   => :HYPCREST,
    :GOTHITELLE => :GOTHCREST,          :REUNICLUS => :REUNICREST,
    :ELECTRODE  => :ELECCREST,          :CRABOMINABLE => :CRABCREST,
    :SIMISEAR   => :SEARCREST,          :SIMIPOUR   => :POURCREST,
    :SIMISAGE   => :SAGECREST,          :LUVDISC   => :LUVCREST,
    :SAWSBUCK   => :SAWSCREST,          :SHIINOTIC => :SHIINCREST,
    :AMPHAROS   => :AEAMPHCREST,        :ZOROARK  => :ZOROCREST,
    :SAMUROTT  => :SAMUCREST,           :CRYOGONAL => :CRYCREST,
    :FURRET => :FURRCREST,              :ORN_KABUTOPS => :ORN_SLICNDICCREST,
    :ORN_SWAMPERT => :ORN_HELIOSCREST,  :ORN_RAPIDASH => :ORN_RAPIDCREST,
    :ORN_ARCANINE => :ORN_GDBOICREST,   :ORN_TALONFLAME => :ORN_TALONCREST,
    :ORN_UMBREON => :ORN_UMBRECREST,    :ORN_TYPHLOSION => :ORN_BRRRRCREST,
    :ORN_FERALIGATR => :ORN_SWOLECREST, :ORN_MEGANIUM => :ORN_MEGAMINCREST,
  }
  POKEMONTOCREST.default = []

  BITEMOVE     = [:BITE,:CRUNCH,:THUNDERFANG,:FIREFANG,:ICEFANG,:POISONFANG,:HYPERFANG,:PSYCHICFANGS,:FISHIOUSREND,:ORN_VISEGRIP,:ORN_STRAFE,:ORN_DRAGONGNAW,:ORN_NECROPHAGY,:ORN_FLYTRAP,:ORN_FROSTBITE,:ORN_VENOMDRAIN,:ORN_MINDDRAIN,:ORN_AQUAFANG,:ORN_SLURP,:ORN_SUCKBLOOD]
  BULLETMOVE   = [:ACIDSPRAY,:AURASPHERE,:BARRAGE,:BULLETSEED,:EGGBOMB,:ELECTROBALL,:ENERGYBALL,:FOCUSBLAST,:GYROBALL,:ICEBALL,:MAGNETBOMB,:MISTBALL,:MUDBOMB,:OCTAZOOKA,:ROCKWRECKER,:SEARINGSHOT,:SEEDBOMB,:SHADOWBALL,:SLUDGEBOMB,:WEATHERBALL,:ZAPCANNON,:BEAKBLAST,:PYROBALL,:ORN_LOVEBURST,:ORN_CHAKRABLAST,:ORN_CHIORB,:ORN_FIREBALL,:ORN_CATAPULT,:ORN_HELLBULLET,:ORN_TIMEBOMB,:ORN_CORALBOMB,:ORN_ALKALINEBOMB,:ORN_BOMBARDMENT,:ORN_SHRAPNEL,:ORN_CLUSTERROCKETS,:ORN_SONICBLAST,:ORN_MUDBLAST,:ORN_DIRTYBOMB,:ORN_MANABLAST]
  NOCOPYMOVE   = [:ASSIST,:COPYCAT,:MEFIRST,:METRONOME,:MIMIC,:MIRRORMOVE,:NATUREPOWER,:SHELLTRAP,:SKETCH,:SLEEPTALK,:STRUGGLE,:BEAKBLAST,:FOCUSPUNCH,:TRANSFORM,:BELCH,:CHATTER,:KINGSSHIELD,:BANEFULBUNKER,:BESTOW,:COUNTER,:COVET,:DESTINYBOND,:DETECT,:ENDURE,:FEINT,:FOLLOWME,:HELPINGHAND,:MATBLOCK,:MIRRORCOAT,:PROTECT,:RAGEPOWDER,:SNATCH,:SPIKYSHIELD,:SPOTLIGHT,:SWITCHEROO,:THIEF,:TRICK,:ORN_GOLDRUSH,:ORN_RAYOFLIGHT,:ORN_GRABANDGO]
  DANCEMOVE    = [:QUIVERDANCE,:DRAGONDANCE,:FIERYDANCE,:FEATHERDANCE,:PETALDANCE,:SWORDSDANCE,:TEETERDANCE,:LUNARDANCE,:REVELATIONDANCE,:ORN_DEATHWALTZ,:ORN_MACABREDANCE,:ORN_LOVELOOP,:ORN_WEAPONMASTERY]
  POWDERMOVES  = [:COTTONSPORE,:SLEEPPOWDER,:STUNSPORE,:SPORE,:RAGEPOWDER,:POISONPOWDER,:POWDER,:MAGICPOWDER,:ORN_STARDUST]
  PULSEMOVES   = [:AURASPHERE,:DRAGONPULS,:DARKPULSE,:WATERPULSE,:ORIGINPULSE,:ORN_ETHEREALBURST,:ORN_MYSTICPULSE,:ORN_SHADOWRAY,:ORN_GAIAPULSE,:ORN_RAINBOWBEAM,:ORN_PRIMALWAVE,:ORN_PULSE,:ORN_MAGNETICCANNON,:ORN_AERIALPULSE,:ORN_WRAITHPULSE]
  UNFREEZEMOVE = [:FLAMEWHEEL,:SACREDFIRE,:FLAREBLITZ,:FUSIONFLARE,:SCALD,:STEAMERUPTION,:BURNUP,:PYROBALL,:SCORCHINGSANDS,:ORN_SOLARFLARE,:ORN_SOLARMETEOR,:ORN_CHIDORI,:ORN_ANCIENTFIRE,:ORN_CRIMSONGATE,:ORN_FIREBALL,:ORN_FLAMEVOLLEY,:ORN_FLARESWEEP,:ORN_HEATSIPHON,:ORN_INFERNALBLADE,:ORN_MELTINGHORN,:ORN_SIZZLE,:ORN_BURNINGOFUDA,:ORN_LIGHTSABER,:ORN_SPARKLE,:ORN_PYROKINESIS,:ORN_STONESURGE,:ORN_RASENGAN]
  SLICINGMOVES = [:SACREDSWORD,:AERIALACE,:SOLARBLADE,:LEAFBLADE,:CUT,:SMARTSTRIKE,:BEHEMOTHBLADE,:RAZORSHELL,:FURYCUTTER,:XSCISSOR,:NIGHTSLASH,:AIRCUTTER,:AIRSLASH,:SHADOWCLAW,:RAZORLEAF,:SLASH,:CROSSPOISON,:PSYCHOCUT,:ORN_DEATHREAP,:ORN_WYVERNSLASH,:ORN_EXCALIBUR,:ORN_EDGESTRIKE,:ORN_INFERNALBLADE,:ORN_GRIMREAPER,:ORN_COUPDEGRACE,:ORN_LIGHTSABER,:ORN_LUMINOUSBLADE,:ORN_SHINYPLUMES,:ORN_SLICINGTAIL,:ORN_DIAMONDBLADE,:ORN_SMARTBLADE,:ORN_SWORDSTRIKE,:ORN_SWEEPINGTALON,:ORN_ICICLESTRIKE]
  WINDMOVE     = [:HEATWAVE,:HURRICANE,:TAILWIND,:PETALBLIZZARD,:BLIZZARD,:ICYWIND,:RAZORWIND,:WHIRLWIND,:SANDSTORM,:SILVERWIND,:TWISTER,:FAIRYWIND,:AIRCUTTER,:AEROBLAST,:GUST,:OMINOUSWIND,:ORN_DRAGONGALE,:ORN_SWEEPINGWIND,:ORN_BOREASBREATH,:ORN_DEATHVORTEX,:ORN_GALEHOLD,:ORN_TORNADO,:ORN_TURBULENCE,:ORN_TYPHOON,:ORN_ICEVORTEX,:ORN_ASTRALWIND,:ORN_TEMPESTFLARE,:ORN_AERIALPULSE,:ORN_DRACOTEMPEST,:ORN_PETALTEMPEST,:ORN_DUSTDEVILS,:ORN_NUMBINGWIND,:ORN_MIASMA]
end

# New Warden Data #
EVOSTONES = [:FIRESTONE,:THUNDERSTONE,:WATERSTONE,:LEAFSTONE,:MOONSTONE,:SUNSTONE,:DUSKSTONE,:DAWNSTONE,:SHINYSTONE,:LINKSTONE,:ICESTONE,:SWEETAPPLE,:TARTAPPLE,:CHIPPEDPOT,:CRACKEDPOT,:NIGHTMAREFUEL,:XENWASTE,:GALARICACUFF,:GALARICAWREATH,:BLACKAUGURITE,:PEATBLOCK,:ORN_FIRESTONE,:ORN_THUNDERSTONE,:ORN_WATERSTONE,:ORN_LEAFSTONE,:ORN_MOONSTONE,:ORN_SUNSTONE,:ORN_DUSKSTONE,:ORN_DAWNSTONE,:ORN_SHINYSTONE,:ORN_ICESTONE,:ORN_LINKSTONE,:ORN_HUMMINGSTONE,:ORN_SANDSTONE,:ORN_WINDSTONE,:ORN_IRONSTONE,:ORN_NOXIOUSSTONE,:ORN_POWERSTONE,:ORN_SWARMSTONE,:ORN_GEMSTONE,:ORN_ROYALSTONE]
GEMS = [:FIREGEM,:WATERGEM,:ELECTRICGEM,:GRASSGEM,:ICEGEM,:FIGHTINGGEM,:POISONGEM,:GROUNDGEM,:FLYINGGEM,:PSYCHICGEM,:BUGGEM,:ROCKGEM,:GHOSTGEM,:DRAGONGEM,:DARKGEM,:STEELGEM,:NORMALGEM,:FAIRYGEM,:ORN_COSMICGEM,:ORN_LIGHTGEM,:ORN_SOUNDGEM]
ItemHandlers::UseOnPokemon.copy(:FIRESTONE,:ORN_FIRESTONE,:ORN_THUNDERSTONE,:ORN_WATERSTONE,:ORN_LEAFSTONE,:ORN_MOONSTONE,:ORN_SUNSTONE,:ORN_DUSKSTONE,:ORN_DAWNSTONE,:ORN_SHINYSTONE,:ORN_ICESTONE,:ORN_LINKSTONE,:ORN_HUMMINGSTONE,:ORN_SANDSTONE,:ORN_WINDSTONE,:ORN_IRONSTONE,:ORN_NOXIOUSSTONE,:ORN_POWERSTONE,:ORN_SWARMSTONE,:ORN_GEMSTONE,:ORN_ROYALSTONE)

class PokeBattle_Move
  alias warden_pbTypeModifierNonBattler pbTypeModifierNonBattler
  alias warden_pbHitsPhysicalStat? pbHitsPhysicalStat?
  alias warden_pbHitsSpecialStat? pbHitsSpecialStat?
  alias warden_pbTypeModMessages pbTypeModMessages
  alias warden_pbReduceHPDamage pbReduceHPDamage
  alias warden_pbAccuracyCheck pbAccuracyCheck
  alias warden_pbTypeModifier pbTypeModifier

  # Warden Abilities #
  def pbTypeModMessages(type, attacker, opponent)
    secondtype = getSecondaryType(attacker)
    if opponent.ability == :ORN_CACOPHONY && !opponent.moldbroken && (type == :SOUND || (!secondtype.nil? && secondtype.include?(:SOUND)))
      if opponent.pbCanIncreaseStatStage?(PBStats::SPATK)
        opponent.pbIncreaseStatBasic(PBStats::SPATK, 1)
        @battle.pbCommonAnimation("StatUp", opponent, nil)
        @battle.pbDisplay(_INTL("{1}'s {2} raised its Special Attack!", opponent.pbThis, getAbilityName(opponent.ability)))
      else
        @battle.pbDisplay(_INTL("{1}'s {2} made {3} ineffective!", opponent.pbThis, getAbilityName(opponent.ability), self.name))
      end
      return 0
    elsif opponent.ability == :ORN_COMETSTORM && !opponent.moldbroken && (type == :ROCK || (!secondtype.nil? && secondtype.include?(:ROCK)))
      if opponent.pbCanIncreaseStatStage?(PBStats::SPATK)
        opponent.pbIncreaseStatBasic(PBStats::SPATK, 1)
        @battle.pbCommonAnimation("StatUp", opponent, nil)
        @battle.pbDisplay(_INTL("{1}'s {2} raised its Special Attack!", opponent.pbThis, getAbilityName(opponent.ability)))
      else
        @battle.pbDisplay(_INTL("{1}'s {2} made {3} ineffective!", opponent.pbThis, getAbilityName(opponent.ability), self.name))
      end
      if opponent.pbCanIncreaseStatStage?(PBStats::SPEED)
        opponent.pbIncreaseStatBasic(PBStats::SPEED, 1)
        @battle.pbCommonAnimation("StatUp", opponent, nil)
        @battle.pbDisplay(_INTL("{1}'s {2} raised its Speed!", opponent.pbThis, getAbilityName(opponent.ability)))
      else
        @battle.pbDisplay(_INTL("{1}'s {2} made {3} ineffective!", opponent.pbThis, getAbilityName(opponent.ability), self.name))
      end
      return 0
    else
      return warden_pbTypeModMessages(type, attacker, opponent)
    end
  end

  def pbAccuracyCheck(attacker, opponent, precheckedacc: nil)
    return true if attacker.ability == :ORN_SHARPSHOOTER && !@move.contactMove?
    accstage = attacker.stages[PBStats::ACCURACY]
    accstage = 0 if opponent.ability == :UNAWARE && !opponent.moldbroken
    evastage = opponent.stages[PBStats::EVASION]
    evastage = 0 if opponent.effects[:Foresight] || opponent.effects[:MiracleEye] || @function == 0xA9 || ([:UNAWARE, :KEENEYE, :MINDSEYE].include?(attacker.ability) && !opponent.moldbroken) # Gen 9 Mod - Added Mind's Eye
    accstage -= evastage
    accstage = accstage.clamp(-6, 6)
    accuracy = accstage >= 0 ? (accstage + 3) * 100.0 / 3 : 300.0 / (3 - accstage)
    if attacker.ability == :HUSTLE && @basedamage > 0 && pbIsSpecial?(pbType(attacker))
      accuracy *= 0.8
      return @battle.pbRandom(100) < (baseaccuracy * accuracy / 100.0).floor
    elsif attacker.ability == :ORN_PRECISION
      accuracy *= 1.3
      return @battle.pbRandom(100) < (baseaccuracy * accuracy / 100.0).floor
    end
    return warden_pbAccuracyCheck(attacker, opponent, precheckedacc: nil)
  end

  def pbReduceHPDamage(damage, attacker, opponent)
    ward_abils = [:ORN_ETHEREAL,:ORN_TELEFACE,:ORN_DESTRUCTIVECORE]
    if ward_abils.include?(opponent.ability)
      if opponent.effects[:Ethereal] && (!attacker || attacker.index != opponent.index) && contactMove?
          opponent.effects[:Substitute] <= 0 && opponent.damagestate.typemod != 0 && !opponent.moldbroken
        @battle.pbDisplay(_INTL("The attack phased through {1}'s Ethereal form.", opponent.name))
        opponent.effects[:Ethereal] = false
        damage = 0
        @battle.pbDisplay(_INTL("{1} became corporeal.", opponent.name))
      end
      if opponent.effects[:Teleface] && (!attacker || attacker.index != opponent.index) && opponent.effects[:Substitute] <= 0 && opponent.damagestate.typemod != 0 && !opponent.moldbroken && move.pbIsPhysical?
        @battle.pbDisplay(_INTL("{1}'s TV was busted!", opponent.name))
        opponent.effects[:Teleface] = false
        damage = 0
      end
      return damage
    else
      return warden_pbReduceHPDamage(damage, attacker, opponent)
    end
  end

  def pbHitsSpecialStat?(type = @type)
    return true if @function == 0x1024   # Matrix Shot
    return warden_pbHitsSpecialStat?(type = @type)
  end

  def pbHitsPhysicalStat?(type = @type)
    return true if @function == 0x122
    return warden_pbHitsPhysicalStat?(type = @type)
  end

  def pbTypeModifier(type, attacker, opponent, zorovar = false)
    atype = type # attack type
    otype1 = opponent.type1
    otype2 = opponent.type2
    mod1 = PBTypes.oneTypeEff(atype, otype1)
    mod2 = otype1 == otype2 || otype2.nil? ? 2 : PBTypes.oneTypeEff(atype, otype2)
    warden_functions = [0x101C,0x101D,0x101E,0x101F,0x1020,0x1021,0x1022]
    warden_ability = [:ORN_CONDUCTOR,:ORN_ANTIGRAVITY,:ORN_OPAQUENESS,:ORN_CACOPHONY]
    crest_mon = [:ORN_UMBREON,:ORN_SWAMPERT,:ORN_ARCANINE,:ORN_MEGANIUM]
    if warden_functions.include?(@function)
      case @function
        when 0x101C # Fly Trap
          mod1 = 4 if otype1 == :BUG
          mod2 = 4 if otype2 == :BUG
        when 0X101D # Satelite Ray
          mod1 = 4 if otype1 == :COSMIC
          mod2 = 4 if otype2 == :COSMIC
        when 0X101E # Fantasy Seal
          mod1 = 4 if otype1 == :GHOST
          mod2 = 4 if otype2 == :GHOST
        when 0x101F # Battle of Wits
          mod1 = 4 if otype1 == :PSYCHIC
          mod2 = 4 if otype2 == :PSYCHIC
        when 0x1020 # Erosion
          mod1 = 4 if otype1 == :ROCK
          mod2 = 4 if otype2 == :ROCK
        when 0x1021 # Corrode
          mod1 = 4 if otype1 == :STEEL
          mod2 = 4 if otype2 == :STEEL
        when 0x1022 # Boil
          mod1 = 4 if otype1 == :WATER
          mod2 = 4 if otype2 == :WATER
        when 0x0123 # Glitch
          glitch_type = [[:FIRE, :FLYING, :STEEL, :FAIRY, :SOUND],[:GRASS, :PSYCHIC, :DARK]]
          mod1 = 1 if glitch_type[0].include?(otype1)
          mod2 = 1 if glitch_type[0].include?(otype2)
          mod1 = 4 if glitch_type[1].include?(otype1)
          mod2 = 4 if glitch_type[1].include?(otype2)
      end
      return mod1 * mod2
    elsif warden_ability.include?(attacker.ability)
      case attacker.ability
        when :ORN_CONDUCTOR
          mod1 = 2 if [:GROUND,:ELECTRIC].include?(otype1) && atype == :ELECTRIC
          mod2 = 2 if [:GROUND,:ELECTRIC].include?(otype2) && atype == :ELECTRIC
        when :ORN_ANTIGRAVITY
          mod1 = 2 if [:SOUND,:GROUND].include?(atype) && otype1 == :COSMIC
          mod2 = 2 if [:SOUND,:GROUND].include?(atype) && otype2 == :COSMIC
      end
      case opponent.ability
        when :ORN_OPAQUENESS
          mod1, mod2 = 0, 0 if atype == :LIGHT
        when :ORN_CACOPHONY 
          mod1, mod2 = 0, 0 if atype == :SOUND
        when :ORN_COMETSTORM
          mod1, mod2 = 0, 0 if atype == :ROCK
      end
      return mod1 * mod2
    elsif crest_mon.include?(opponent.crested)
      mod1, mod2 = 0, 0 if atype == :POISON && opponent.crested == :ORN_MEGANIUM
      mod1, mod2 = 1, 1 if [:GHOST, :DARK].include?(atype) && opponent.crested == :ORN_UMBREON
      mod1, mod2 = 0, 0 if [:WATER,:DRAGON].include?(atype) && opponent.crested == :ORN_SWAMPERT
      mod1 = 4 if atype == :DRAGON && otype1 == :FAIRY && opponent.crested == :ORN_ARCANINE
      mod2 = 4 if atype == :DRAGON && otype2 == :FAIRY && opponent.crested == :ORN_ARCANINE
      return mod1 * mod2
    else
      return warden_pbTypeModifier(type, attacker, opponent, zorovar = false)
    end
  end

  def pbTypeModifierNonBattler(type, attacker, opponent)
    atype = type # attack type
    otype1 = opponent.type1
    otype2 = opponent.type2
    mod1 = PBTypes.oneTypeEff(atype, otype1)
    mod2 = otype1 == otype2 ? 2 : PBTypes.oneTypeEff(atype, otype2)
    warden_functions = [0x101C,0x101D,0x101E,0x101F,0x1020,0x1021,0x1022]
    warden_ability = [:ORN_CONDUCTOR,:ORN_ANTIGRAVITY,:ORN_OPAQUENESS,:ORN_CACOPHONY]
    crest_mon = [:ORN_UMBREON,:ORN_SWAMPERT,:ORN_ARCANINE,:ORN_MEGANIUM]
    if warden_functions.include?(@function)
      case @function
        when 0x101C # Fly Trap
          mod1 = 4 if otype1 == :BUG
          mod2 = 4 if otype2 == :BUG
        when 0X101D # Satelite Ray
          mod1 = 4 if otype1 == :COSMIC
          mod2 = 4 if otype2 == :COSMIC
        when 0X101E # Fantasy Seal
          mod1 = 4 if otype1 == :GHOST
          mod2 = 4 if otype2 == :GHOST
        when 0x101F # Battle of Wits
          mod1 = 4 if otype1 == :PSYCHIC
          mod2 = 4 if otype2 == :PSYCHIC
        when 0x1020 # Erosion
          mod1 = 4 if otype1 == :ROCK
          mod2 = 4 if otype2 == :ROCK
        when 0x1021 # Corrode
          mod1 = 4 if otype1 == :STEEL
          mod2 = 4 if otype2 == :STEEL
        when 0x1022 # Boil
          mod1 = 4 if otype1 == :WATER
          mod2 = 4 if otype2 == :WATER
        when 0x0123 # Glitch
          glitch_type = [[:FIRE, :FLYING, :STEEL, :FAIRY, :SOUND],[:GRASS, :PSYCHIC, :DARK]]
          mod1 = 1 if glitch_type[0].include?(otype1)
          mod2 = 1 if glitch_type[0].include?(otype2)
          mod1 = 4 if glitch_type[1].include?(otype1)
          mod2 = 4 if glitch_type[1].include?(otype2)
      end
      return mod1 * mod2
    elsif warden_ability.include?(attacker.ability)
      case attacker.ability
        when :ORN_CONDUCTOR
          mod1 = 2 if [:GROUND,:ELECTRIC].include?(otype1) && atype == :ELECTRIC
          mod2 = 2 if [:GROUND,:ELECTRIC].include?(otype2) && atype == :ELECTRIC
        when :ORN_ANTIGRAVITY
          mod1 = 2 if [:SOUND,:GROUND].include?(atype) && otype1 == :COSMIC
          mod2 = 2 if [:SOUND,:GROUND].include?(atype) && otype2 == :COSMIC
      end
      case opponent.ability
        when :ORN_OPAQUENESS
          mod1, mod2 = 0, 0 if atype == :LIGHT
        when :ORN_CACOPHONY 
          mod1, mod2 = 0, 0 if atype == :SOUND
        when :ORN_COMETSTORM
          mod1, mod2 = 0, 0 if atype == :ROCK
      end
      return mod1 * mod2
    elsif crest_mon.include?(opponent.crested)
      mod1, mod2 = 0, 0 if atype == :POISON && opponent.crested == :ORN_MEGANIUM
      mod1, mod2 = 1, 1 if [:GHOST, :DARK].include?(atype) && opponent.crested == :ORN_UMBREON
      mod1, mod2 = 0, 0 if [:WATER,:DRAGON].include?(atype) && opponent.crested == :ORN_SWAMPERT
      mod1 = 4 if atype == :DRAGON && otype1 == :FAIRY && opponent.crested == :ORN_ARCANINE
      mod2 = 4 if atype == :DRAGON && otype2 == :FAIRY && opponent.crested == :ORN_ARCANINE
      return mod1 * mod2
    else
      return warden_pbTypeModifierNonBattler(type, attacker, opponent)
    end
  end
end

class PokeBattle_Battle
  alias warden_pbEndOfRoundPhase pbEndOfRoundPhase
  alias warden_pbIsUnlosableItem pbIsUnlosableItem

  def pbWardenCrestEffectsEOR(mon,priority)
    if mon.crested == :ORN_SWAMPERT && @battle.pbWeather == :SUNNYDAY
      mon.pbRecoverHP((mon.totalhp / 8.0).floor, true)
      pbDisplay(_INTL("{1}'s crest restored its health!", mon.pbThis))
    end
    if mon.crested == :ORN_UMBREON
      mon.pbRecoverHP((mon.totalhp / 16.0).floor, true)
      pbDisplay(_INTL("{1}'s crest restored its health!", mon.pbThis))
    end
  end

  def pbIsUnlosableItem(pkmn,item)
    return true if PBStuff::WARDEN_MEGASTONE[pkmn.species].include?(item)
    return warden_pbIsUnlosableItem(pkmn,item)
  end

  def pbEndOfRoundPhase
    priority = pbPriority
    for i in priority
      # Pure Heart
      if i.ability == :ORN_PUREHEART
        i.pbRecoverHP((i.totalhp / 16.0).floor, true)
        pbDisplay(_INTL("{1}'s Pure Heart restored its health!", i.pbThis))
      elsif i.ability == :ORN_CLAYFORM && pbWeather == :SANDSTORM
        i.pbRecoverHP((i.totalhp / 8.0).floor, true)
        pbDisplay(_INTL("{1}'s Clay Form restored its health!", i.pbThis))
      elsif i.ability == :ORN_SYNTHESIZE && pbWeather == :SUNNYDAY
        i.pbRecoverHP((i.totalhp / 8.0).floor, true)
        pbDisplay(_INTL("{1}'s Synthesize restored its health!", i.pbThis))
      end
      if @battle.state.effects[:ELECTERRAIN] > 0 || @battle.FE == :ELECTERRAIN
        for facemon in @battlers
          if facemon.species == :ORN_EISCUE && facemon.form == 1   # Eiscue
            facemon.pbRegenTele
            pbDisplayPaused(_INTL("{1} transformed!", facemon.name))
          end
        end
      end
      if i.ability == :ORN_REGROWTH
        stat_ids = [PBStats::ATTACK, PBStats::DEFENSE, PBStats::SPEED, PBStats::SPATK, PBStats::SPDEF, PBStats::ACCURACY, PBStats::EVASION]
        if i.turncount > 0
          lowered_stats = false
          for s in 0...stat_ids.length
            lowered_stats = true if i.stages[stat_ids[s]] < 0
          end
          pbDisplay(_INTL("{1}'s crest boosts it's rate of photosynthesis!", i.pbThis)) if i.crested == :ORN_MEGANIUM
          if !lowered_stats && i.hp < i.totalhp && i.effects[:HealBlock] == 0 && i.hp != 0
            hpgain = (i.crested = :ORN_MEGANIUM) ? (i.totalhp / 8) : (i.totalhp / 16)
            i.pbRecoverHP((hpgain).floor, true)
            pbDisplay(_INTL("{1}'s {2} restored its HP a little!", i.pbThis,getAbilityName(i.ability)))
          end
          if lowered_stats
            pbCommonAnimation("StatUp", i, nil)
            for s in 0...stat_ids.length
              stat_gain = (i.crested == :ORN_MEGANIUM && i.stages[stat_ids[s]] < -1) ? 2 : 1
              i.pbIncreaseStatBasic(stat_ids[s], stat_gain)
            end
            pbDisplay(_INTL("{1}'s {2} raised its lower stats!", i.pbThis, getAbilityName(i.ability)))
          end
        end
      end
      pbWardenCrestEffectsEOR(i,priority) if Rejuv
    end
    warden_pbEndOfRoundPhase
  end
end

class PokeBattle_Battler
  alias warden_pbProcessMoveAgainstTarget pbProcessMoveAgainstTarget
  alias warden_pbCompatibleZMoveFromMove? pbCompatibleZMoveFromMove?
  alias warden_pbEffectsOnDealingDamage pbEffectsOnDealingDamage
  alias warden_pbCanReduceStatStage? pbCanReduceStatStage?
  alias warden_pbAbilitiesOnSwitchIn pbAbilitiesOnSwitchIn
  alias warden_pbCheckFormRoundEnd pbCheckFormRoundEnd
  alias warden_pbSuccessCheck pbSuccessCheck
  alias warden_pbInitEffects pbInitEffects
  alias warden_pbCanStatus? pbCanStatus?
  alias warden_pbCheckForm pbCheckForm
  alias warden_hasCrest? hasCrest?

  def pbInitEffects(batonpass, fakebattler=false)
    warden_pbInitEffects(batonpass, fakebattler=false)
    @effects[:Ethereal] = (self.ability == :ORN_ETHEREAL)
    @effects[:Teleface] = (self.ability == :ORN_TELEFACE && self.species==:ORN_EISCUE && self.form==0)
  end

  def pbSuccessCheck(basemove, user, target, flags, accuracy = true, precheckedacc: nil)
    return true if user.ability == :ORN_SHARPSHOOTER && !basemove.contactMove?
    return warden_pbSuccessCheck(basemove, user, target, flags, accuracy, precheckedacc: nil)
  end

  def pbAbilitiesOnSwitchIn(onactive)
    return if @hp <= 0
    # Dishearten
    warden_pbAbilitiesOnSwitchIn(onactive)
    if self.ability == :ORN_DISHEARTEN && onactive
      for i in 0...4
        next if !pbIsOpposing?(i) || @battle.battlers[i].isFainted?
        @battle.battlers[i].pbReduceSpecialAttackStatStageDishearten(self)
      end
    elsif self.ability == :ORN_DISARRAY && onactive
      if @battle.trickroom == 0
        @battle.trickroom = 5
        if [:CHESS, :NEWWORLD, :PSYTERRAIN].include?(@battle.FE) || self.hasWorkingItem(:AMPLIFIELDROCK) || (Rejuv && @battle.FE == :STARLIGHT)
          @battle.trickroom = 8
        end
        if @battle.FE == :DIMENSIONAL
          rnd = @battle.pbRandom(6)
          @battle.trickroom = 3 + rnd
        end
        @battle.pbDisplay(_INTL("{1} twisted the dimensions!", self.pbThis))
      else
        @battle.trickroom = 0
        @battle.pbDisplay(_INTL("The twisted dimensions returned to normal!", self.pbThis))
      end
      for i in @battle.battlers
        if i.hasWorkingItem(:ROOMSERVICE)
          if i.pbReduceStat(PBStats::SPEED, 1, abilitymessage: false, statdropper: i)
            if i.ability == :CONTRARY && !i.moldbroken
              @battle.pbDisplay(_INTL("The Room Service raised #{i.pbThis}'s Speed!"))
            else
              @battle.pbDisplay(_INTL("The Room Service lowered #{i.pbThis}'s Speed!"))
            end
            i.pbDisposeItem(false)
          end
        end
      end
    elsif self.ability == :TELEFACE && self.form == 1 && self.species == :ORN_EISCUE && onactive
      if @battle.state.effects[:ELECTERRAIN] > 0 || @battle.FE == :ELECTERRAIN
        self.pbRegenTele
        @battle.pbDisplay(_INTL("{1} transformed!",self.pbThis))
      end
    end
    if self.crested == :ORN_TYPHLOSION && onactive
      @battle.setField(:FACTORY)
      @battle.pbDisplay(_INTL("Gears litter the battlefield."))
      @battle.pbAnimation(:SHIFTGEAR, self, self)
      statchange = @battle.FE == :FACTORY || @battle.FE == :CITY ? 2 : 1
      self.pbIncreaseStat(PBStats::ATTACK, statchange, abilitymessage: false, statsource: self)
      self.pbIncreaseStat(PBStats::SPEED, 2, abilitymessage: false, statsource: self)
      @battle.pbDisplay(_INTL("{1}'s crest supercharges it's gears!",self.pbThis))
      @battle.pbAnimation(:MAGNETRISE,self, self)
      self.effects[:MagnetRise]=5
      if @battle.FE == :ELECTERRAIN || @battle.FE == :FACTORY || @battle.FE == :SHORTCIRCUIT || @battle.state.effects[:ELECTERRAIN] > 0 # Electric/Factory Field
        self.effects[:MagnetRise]=8
      end
      @battle.pbDisplay(_INTL("{1} floats above the battlefield via electromagnetism.",self.pbThis))
    end
    if self.crested == :ORN_KABUTOPS && onactive
      @battle.pbDisplay(_INTL("{1}'s crest sharpens it's senses!", self.pbThis))
    end
  end

  def pbEffectsOnDealingDamage(move, user, target, damage, innards)
    return if target.nil?
    return if move.basedamage == 0
    if target.damagestate.calcdamage > 0
      if !target.damagestate.substitute && !move.zmove
        if target.ability == :ORN_VITALITY
          if target.pbCanIncreaseStatStage?(PBStats::SPDEF)
            target.pbIncreaseStatBasic(PBStats::SPDEF, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s {2} raised its Special Defense!", target.pbThis, getAbilityName(target.ability)))
          end
        elsif move.contactMove? && PBStuff::BITEMOVE.include?(move)
          if user.ability == :ORN_LEECHINGFANGS
            changehp=(target.totalhp/8).floor # Changed by DemICE 06-Oct-2023 Reworking Leeching Fangs to absorb 1/8 of opponent's total hp.
            changehp*=1.3 if user.hasActiveItem?(:BIGROOT)
            if target.ability == :LIQUIDOOZE
              changehp*=2 if (@battle.FE == :WASTELAND || @battle.FE == :MURKWATERSURFACE || @battle.FE == :CORRUPTED)
              user.pbReduceHP(changehp, true)
              @battle.pbDisplay(_INTL("{1} sucked up the liquid ooze!", user.pbThis))
            else
              user.pbRecoverHP(changehp, true)
              @battle.pbDisplay(_INTL("{1} drained HP with {2}!",user.pbThis,user.abilityName))
            end
          end
        elsif target.ability == :ORN_HIVEBODY && move.contactMove?
          chance = 50
          if @battle.pbRandom(100) >= chance
            user.effects[:MultiTurn] = 5 + @battle.pbRandom(2)
            user.effects[:MultiTurn] = 8 if target.hasWorkingItem(:GRIPCLAW)
            user.effects[:MultiTurnAttack] = :INFESTATION
            user.effects[:MultiTurnUser] = target.index
            @battle.pbDisplay(_INTL("{1} has been infested!", user.pbThis))
          end
        elsif target.ability == :ORN_MAELSTROM && move.contactMove?
          chance = 50
          if @battle.pbRandom(100) >= chance
            user.effects[:MultiTurn] = 5 + @battle.pbRandom(2)
            user.effects[:MultiTurn] = 8 if target.hasWorkingItem(:GRIPCLAW)
            user.effects[:MultiTurnAttack] = :WHIRLPOOL
            user.effects[:MultiTurnUser] = target.index
            @battle.pbDisplay(_INTL("{1} became trapped in the vortex!", user.pbThis))
          end
        elsif target.ability == :ORN_SCORCHSCALE && move.priority > 0
          user.pbBurn(target) if user.pbCanBurn?(false) && @battle.FE != :FROZENDIMENSION
          @battle.pbDisplay(_INTL("{1}'s {2} burned {3}!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
        end
      end
    end
    if user.crested == :ORN_FERALIGATR && user.hp > 0 && target.hp <= 0
      if user.pbCanIncreaseStatStage?(PBStats::SPEED)
        user.pbIncreaseStatBasic(PBStats::SPEED, 1)
        @battle.pbCommonAnimation("StatUp", user, nil)
        @battle.pbDisplay(_INTL("{1}'s crest boosts it's speed!", user.pbThis))
      end
    end
    pbWardenCrestMessages(move, user, target)
    warden_pbEffectsOnDealingDamage(move, user, target, damage, innards)
  end

  def pbCanReduceStatStage?(stat, showMessages = false, selfreduce = false, ignoreContrary: false)
    return false if isFainted? && !(Rejuv && isbossmon && @shieldCount > 0)
    if self.crested == :ORN_FERALIGATR
      @battle.pbDisplay(_INTL("{1}'s crest prevented it's stats from being lowered!", pbThis))
      return false
    end
    if !selfreduce
     abilityname = getAbilityName(self.ability)
     if stat == PBStats::DEFENSE && self.ability == :ORN_UNBREAKABLE && !self.moldbroken
        @battle.pbDisplay(_INTL("{1}'s {2} prevents Defense loss!", pbThis, abilityname)) if showMessages
        return false
      elsif stat == PBStats::SPATK && self.ability == :ORN_INTUITION && !self.moldbroken
        @battle.pbDisplay(_INTL("{1}'s {2} prevents Special Attack loss!", pbThis, abilityname)) if showMessages
        return false
      elsif [PBStats::DEFENSE,PBStats::SPDEF].include?(stat) && self.ability == :ORN_IMPENETRABLE && !self.moldbroken
        @battle.pbDisplay(_INTL("{1}'s {2} prevents Defense loss!", pbThis, abilityname)) if showMessages && stat == PBStats::DEFENSE
        @battle.pbDisplay(_INTL("{1}'s {2} prevents Special Defense loss!", pbThis, abilityname)) if showMessages && stat == PBStats::SPDEF
        return false
      elsif ([self.ability,pbPartner.ability].include?(:ORN_NEBULACLOUD) && hasType?(:COSMIC) && !self.moldbroken)
        cloud_user = (pbPartner.ability == :ORN_NEBULACLOUD) ? pbPartner.pbThis : pbThis
        @battle.pbDisplay(_INTL("{1}'s {2} prevents Stat loss!", cloud_user, abilityname)) if showMessages
        return false
      else
        return warden_pbCanReduceStatStage?(stat, showMessages, selfreduce, ignoreContrary: false)
      end
    else
      return warden_pbCanReduceStatStage?(stat, showMessages, selfreduce, ignoreContrary: false)
    end
  end
  
  def pbProcessMoveAgainstTarget(basemove, user, target, numhits, flags = { totaldamage: 0 }, nocheck = false, alltargets = nil, showanimation = true, precheckedacc: nil)
    if target
      aboveHalfHp = target.hp > (target.totalhp / 2.0).floor
      fainted = target.isFainted?
      if !fainted && aboveHalfHp && target.hp <= (target.totalhp / 2.0).floor && damage > 0
        if target.ability == :ORN_FORTIFICATION
          if !pbTooHigh?(PBStats::DEFENSE)
            target.pbIncreaseStatBasic(PBStats::DEFENSE, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s Fortifiction boosted its Defense!", target.pbThis))
          end
          if !pbTooHigh?(PBStats::SPDEF)
            target.pbIncreaseStatBasic(PBStats::SPDEF, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s Fortifiction boosted its Special Defense!", target.pbThis))
          end
        elsif target.ability == :ORN_TERMINATOR
          if !pbTooHigh?(PBStats::ATTACK)
            target.pbIncreaseStatBasic(PBStats::ATTACK, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s Terminator boosted its Attack!", target.pbThis))
          end
        elsif target.ability == :ORN_VENGEFUL
          if !pbTooHigh?(PBStats::ATTACK)
            target.pbIncreaseStatBasic(PBStats::ATTACK, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s Vengeful boosted its Attack!", target.pbThis))
          end
          if !pbTooHigh?(PBStats::SPEED)
            target.pbIncreaseStatBasic(PBStats::SPEED, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s Vengeful boosted its Speed!", target.pbThis))
          end
        end
      end
    end
    if user.ability == :ORN_REAPER && target.isFainted?
      user.pbRecoverHP(user.totalhp / 5)
      @battle.pbCommonAnimation("StatUp", target, nil)
      @battle.pbDisplay(_INTL("{1} restored health by defeating the foe!", user.pbThis))
    end
    return warden_pbProcessMoveAgainstTarget(basemove, user, target, numhits, flags, nocheck, alltargets, showanimation, precheckedacc: nil)
  end

  def pbCanStatus?(showMessages, ignorestatus = false, moldbroken = self.moldbroken, ownStatus = false)
    failure = :none
    failure = :ORN_NEBULACLOUD if ((@ability == :ORN_NEBULACLOUD || pbPartner.ability == :ORN_NEBULACLOUD)) && hasType?(:COSMIC) && !moldbroken
    if failure != :none
      if showMessages
        case failure
          when :ORN_NEBULACLOUD then @battle.pbDisplay(_INTL("{1} is protected by Nebula Cloud!", pbThis))
        end
      end
      return false
    else
      return warden_pbCanStatus?(showMessages, ignorestatus, moldbroken, ownStatus)
    end
  end

  def pbCheckForm(basemove = nil)
    transformed = false
    if (self.pokemon && self.pokemon.species == :ORN_TOGEDEMARU) && !self.isFainted?
      if self.ability == :ORN_DESTRUCTIVECORE && @hp<=((@totalhp/2.0).floor)
        if self.form == 0
          self.form = 1; transformed=true
        end
      end
    end
    if transformed
    end
    warden_pbCheckForm(basemove = nil)
  end

  def pbCheckFormRoundEnd
    # Warden Mons
    if self.species == :ORN_WISHIWASHI && !self.isFainted?
      if self.ability == :ORN_DARKSWARM && !@effects[:Transform]
        schoolHP = (self.totalhp / 4.0).floor
        if (self.hp > schoolHP && self.level > 19)
          if self.form != 1
            self.form = 1
            pbUpdate(true)
            @battle.scene.pbChangePokemon(self, @pokemon)
            @battle.pbDisplay(_INTL("{1} formed a swarm!", pbThis))
          end
        else
          if self.form != 0
            self.form = 0
            pbUpdate(true)
            @battle.scene.pbChangePokemon(self, @pokemon)
            @battle.pbDisplay(_INTL("{1} stopped swarming!", pbThis))
          end
        end
      end
    end
    if self.species == :ORN_UNOWN && !self.isFainted?
      if self.ability == :ORN_SYMPHONY && !@effects[:Transform]
        schoolHP = (self.totalhp / 4.0).floor
        if (self.hp > schoolHP && self.level > 19)
          if self.form != 1
            self.form = 1
            pbUpdate(true)
            @battle.scene.pbChangePokemon(self, @pokemon)
            @battle.pbDisplay(_INTL("{1} formed a symphony!", pbThis))
          end
        else
          if self.form != 0
            self.form = 0
            pbUpdate(true)
            @battle.scene.pbChangePokemon(self, @pokemon)
            @battle.pbDisplay(_INTL("{1} stopped coordinating!", pbThis))
          end
        end
      end
    end
    warden_pbCheckFormRoundEnd
  end

  def pbCompatibleZMoveFromMove?(move,moveindex = false)
    pkmn=self
    return true if pkmn.item == :WARDENIUMZ
    return warden_pbCompatibleZMoveFromMove?(move,moveindex)
  end
  
  # New Definitions
  def pbReduceSpecialAttackStatStageDishearten(opponent)
    # Ways intimidate doesn't work
    return false if isFainted? && !(Rejuv && isbossmon && @shieldCount > 0)
    return false if @effects[:Substitute] > 0

    if [:CLEARBODY, :WHITESMOKE, :HYPERCUTTER, :FULLMETALBODY].include?(self.ability) || (Gen > 7 && [:INNERFOCUS, :OBLIVIOUS, :OWNTEMPO, :SCRAPPY].include?(self.ability))
      abilityname = getAbilityName(self.ability)
      oppabilityname = getAbilityName(opponent.ability)
      @battle.pbDisplay(_INTL("{1}'s {2} prevented {3}'s {4} from working!", pbThis, abilityname, opponent.pbThis(true), oppabilityname))
      if hasWorkingItem(:ADRENALINEORB) && pbCanIncreaseStatStage?(PBStats::SPEED, false) && self.stages[PBStats::SPATK] > -6
        triggerAdrenalineOrb
      end
      return false
    end
    if pbOwnSide.effects[:Mist] > 0
      @battle.pbDisplay(_INTL("{1} is protected by Mist!", pbThis))
      if hasWorkingItem(:ADRENALINEORB) && pbCanIncreaseStatStage?(PBStats::SPEED, false) && self.stages[PBStats::SPATK] > -6
        triggerAdrenalineOrb
      end
      return false
    end
    # Gen 9 Mod - Clear Amulet prevents stat drop from intimidate
    if hasWorkingItem(:CLEARAMULET)
      itemname = getItemName(self.item)
      oppabilityname = getAbilityName(opponent.ability)
      @battle.pbDisplay(_INTL("{1}'s {2} prevented {3}'s {4} from working!", pbThis, itemname, opponent.pbThis(true), oppabilityname))
      return false
    end
    # Gen 9 Mod - Guard Dog raises attack on Intimidate
    if (self.ability == :GUARDDOG)
      @battle.pbDisplay(_INTL("{1} got angry!",pbThis))
      pbIncreaseStat(PBStats::SPATK, 1)
      if hasWorkingItem(:ADRENALINEORB) && pbCanIncreaseStatStage?(PBStats::SPEED, false) && self.stages[PBStats::SPATK] > -6
        triggerAdrenalineOrb
      end
      return false
    end

    # reduce stat only if you can
    if @battle.FE == :CROWD && pbCanReduceStatStage?(PBStats::DEFENSE, false)
      pbReduceStat(PBStats::DEFENSE, 1, statmessage: false, statdropper: opponent, defiant_proc: false)
      oppabilityname = getAbilityName(opponent.ability)
      @battle.pbDisplay(_INTL("{1}'s {2} cuts {3}'s Defense!", opponent.pbThis, oppabilityname, pbThis(true))) if self.ability != :CONTRARY
      @battle.pbDisplay(_INTL("{1}'s {2} boosts {3}'s Defense!", opponent.pbThis, oppabilityname, pbThis(true))) if self.ability == :CONTRARY
      # Defiant/Competitive
      if self.ability == :DEFIANT
        increment = 2
        increment = 3 if @battle.FE == :BACKALLEY
        pbIncreaseStat(PBStats::SPATK, increment, statmessage: false)
        if @battle.FE == :BACKALLEY
          @battle.pbDisplay(_INTL("Defiant dramatically raised {1}'s Special Attck!", pbThis))
        else
          @battle.pbDisplay(_INTL("Defiant sharply raised {1}'s Special Attck!", pbThis))
        end
      end
      if self.ability == :COMPETITIVE && !(Rejuv && @battle.FE == :CHESS)
        increment = 2
        increment = 3 if @battle.FE == :CITY
        pbIncreaseStat(PBStats::ATTACK, increment, statmessage: false)
        if @battle.FE == :CITY
          @battle.pbDisplay(_INTL("Competitive dramatically raised {1}'s Attack!", pbThis))
        else
          @battle.pbDisplay(_INTL("Competitive sharply raised {1}'s Attack!", pbThis))
        end
      end
    end
    if pbReduceStat(PBStats::SPATK, 1, statmessage: false, statdropper: opponent, defiant_proc: false)
      # Battle message
      oppabilityname = getAbilityName(opponent.ability)
      @battle.pbDisplay(_INTL("{1}'s {2} cuts {3}'s Special Attck!", opponent.pbThis, oppabilityname, pbThis(true))) if !(self.ability == :CONTRARY)
      @battle.pbDisplay(_INTL("{1}'s {2} boosts {3}'s Special Attck!", opponent.pbThis, oppabilityname, pbThis(true))) if (self.ability == :CONTRARY)

      if self.ability == :RATTLED && Gen > 7
        pbIncreaseStat(PBStats::SPEED, 1, statmessage: false)
        @battle.pbDisplay(_INTL("{1}'s Rattled raised its Speed!", pbThis))
      end

      # Defiant/Competitive
      if self.ability == :DEFIANT
        increment = 2
        increment = 3 if @battle.FE == :BACKALLEY
        pbIncreaseStat(PBStats::SPATK, increment, statmessage: false)
        if @battle.FE == :BACKALLEY
          @battle.pbDisplay(_INTL("Defiant dramatically raised {1}'s Special Attck!", pbThis))
        else
          @battle.pbDisplay(_INTL("Defiant sharply raised {1}'s Special Attck!", pbThis))
        end
      end
      if self.ability == :COMPETITIVE && !(Rejuv && @battle.FE == :CHESS)
        increment = 2
        increment = 3 if @battle.FE == :CITY
        pbIncreaseStat(PBStats::ATTACK, increment, statmessage: false)
        if @battle.FE == :CITY
          @battle.pbDisplay(_INTL("Competitive dramatically raised {1}'s Attack!", pbThis))
        else
          @battle.pbDisplay(_INTL("Competitive sharply raised {1}'s Attack!", pbThis))
        end
      end

      # Item triggers
      if hasWorkingItem(:ADRENALINEORB) && pbCanIncreaseStatStage?(PBStats::SPEED, false)
        triggerAdrenalineOrb
      end
      if hasWorkingItem(:WHITEHERB)
        reducedstats = false
        for i in 1..7
          if self.stages[i] < 0
            self.stages[i] = 0
            reducedstats = true
          end
        end
        if reducedstats
          itemname = self.item.nil? ? "" : getItemName(self.item)
          @battle.pbDisplay(_INTL("{1}'s {2} restored its status!", pbThis, itemname))
          pbDisposeItem(false)
        end
      end

      return true
    end
    return false
  end

  def pbRegenTele
    self.form=0
    @effects[:Teleface] = true
    pbUpdate(true)
    @battle.scene.pbChangePokemon(self,@pokemon)
  end

  def pbResetForm
    return if !@pokemon
    if !@effects[:Transform]
      if (@pokemon.species == :AEGISLASH && self.form < 2) || [:CASTFORM, :CHERRIM, :WISHIWASHI, :DITTO, :MEW, :MORPEKO, :CRAMORANT, :ORN_WISHIWASHI, :ORN_UNOWN].include?(@pokemon.species) 
      elsif [:DARMANITAN, :MINIOR, :ORN_TOGEDEMARU].include?(@pokemon.species)
        self.form=@startform
      end
    end
    pbUpdate(true)
  end

  def pbWardenCrestMessages(move, user, target)
    if target.crested == :ORN_TYPHLOSION
      @battle.pbDisplay(_INTL("{1}'s crest weakened the blow!",target.pbThis)) if move.type == :FIGHTING
      @battle.pbDisplay(_INTL("{1}'s crest shielded it from the cosmos!",target.pbThis)) if move.type == :COSMIC
    end
    if target.crested == :ORN_FERALIGATR && [:GRASS,:WATER].include?(move.type)
      @battle.pbDisplay(_INTL("{1}'s crest is providing Tropical effects!",target.pbThis))
    end
    if user.crested == :ORN_KABUTOPS && move.sharpMove?
      @battle.pbDisplay(_INTL("{1}'s crest sharpens it's scythes!",user.pbThis))
    end
    if user.crested == :ORN_KABUTOPS && target.damagestate.typemod > 4
      @battle.pbDisplay(_INTL("{1}'s crest let's it hone in on it's opponent's weak spots!",user.pbThis))
    end
    if target.crested == :ORN_MEGANIUM && move.type == :POISON && move.category != :status
      @battle.pbDisplay(_INTL("{1} is being shielded from toxic substances by it's crest!",target.pbthis))
    end
  end
end
