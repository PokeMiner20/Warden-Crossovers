class PokeBattle_Move
  alias warden_pbHitsSpecialStat? pbHitsSpecialStat?
  alias warden_pbHitsPhysicalStat? pbHitsPhysicalStat?
  alias warden_pbTypeModifier pbTypeModifier
  alias warden_pbTypeModifierNonBattler pbTypeModifierNonBattler

  def pbHitsSpecialStat?(type = @type)
    return true if @function == 0x1024   # Matrix Shot
    return warden_pbHitsSpecialStat?(type = @type)
  end

  def pbHitsPhysicalStat?(type = @type)
    return true if @function == 0x122
    return warden_pbHitsPhysicalStat?(type = @type)
  end

  def pbTypeModifier(type, attacker, opponent, zorovar = false)
    atype = type # attack type
    otype1 = opponent.type1
    otype2 = opponent.type2
    mod1 = PBTypes.oneTypeEff(atype, otype1)
    mod2 = otype1 == otype2 || otype2.nil? ? 2 : PBTypes.oneTypeEff(atype, otype2)
    warden_functions = [0x101C,0x101D,0x101E,0x101F,0x1020,0x1021,0x1022]
    warden_ability = [:ORN_CONDUCTOR,:ORN_ANTIGRAVITY,:ORN_OPAQUENESS,:ORN_CACOPHONY]
    if warden_functions.include?(@function)
      case @function
        when 0x101C # Fly Trap
          mod1 = 4 if otype1 == :BUG
          mod2 = 4 if otype2 == :BUG
        when 0X101D # Satelite Ray
          mod1 = 4 if otype1 == :COSMIC
          mod2 = 4 if otype2 == :COSMIC
        when 0X101E # Fantasy Seal
          mod1 = 4 if otype1 == :GHOST
          mod2 = 4 if otype2 == :GHOST
        when 0x101F # Battle of Wits
          mod1 = 4 if otype1 == :PSYCHIC
          mod2 = 4 if otype2 == :PSYCHIC
        when 0x1020 # Erosion
          mod1 = 4 if otype1 == :ROCK
          mod2 = 4 if otype2 == :ROCK
        when 0x1021 # Corrode
          mod1 = 4 if otype1 == :STEEL
          mod2 = 4 if otype2 == :STEEL
        when 0x1022 # Boil
          mod1 = 4 if otype1 == :WATER
          mod2 = 4 if otype2 == :WATER
        when 0x0123 # Glitch
          glitch_type = [[:FIRE, :FLYING, :STEEL, :FAIRY, :SOUND],[:GRASS, :PSYCHIC, :DARK]]
          mod1 = 1 if glitch_type[0].include?(otype1)
          mod2 = 1 if glitch_type[0].include?(otype2)
          mod1 = 4 if glitch_type[1].include?(otype1)
          mod2 = 4 if glitch_type[1].include?(otype2)
      end
      return mod1 * mod2
    elsif warden_ability.include?(attacker.ability)
      case attacker.ability
        when :ORN_CONDUCTOR
          mod1 = 2 if [:GROUND,:ELECTRIC].include?(otype1) && atype == :ELECTRIC
          mod2 = 2 if [:GROUND,:ELECTRIC].include?(otype2) && atype == :ELECTRIC
        when :ORN_ANTIGRAVITY
          mod1 = 2 if [:SOUND,:GROUND].include?(atype) && otype1 == :COSMIC
          mod2 = 2 if [:SOUND,:GROUND].include?(atype) && otype2 == :COSMIC
      end
      case opponent.ability
        when :ORN_OPAQUENESS
          mod1, mod2 = 0, 0 if atype == :LIGHT
        when :ORN_CACOPHONY 
          mod1, mod2 = 0, 0 if atype == :SOUND
        when :ORN_COMETSTORM
          mod1, mod2 = 0, 0 if atype == :ROCK
      end
      return mod1 * mod2
    elsif opponent.crested == :ORN_UMBREON
      mod1, mod2 = 1, 1 if [:GHOST, :DARK].include?(atype)
      return mod1 * mod2
    elsif opponent.crested == :ORN_SWAMPERT
       mod1, mod2 = 0, 0 if [:WATER,:DRAGON].include?(atype)
       return mod1 * mod2
    elsif opponent.crested == :ORN_ARCANINE
       mod1 = 4 if atype == :DRAGON && otype1 == :FAIRY
       mod2 = 4 if atype == :DRAGON && otype2 == :FAIRY
       return mod1 * mod2
    else
      return warden_pbTypeModifier(type, attacker, opponent, zorovar = false)
    end
  end

  def pbTypeModifierNonBattler(type, attacker, opponent)
    atype = type # attack type
    otype1 = opponent.type1
    otype2 = opponent.type2
    mod1 = PBTypes.oneTypeEff(atype, otype1)
    mod2 = otype1 == otype2 ? 2 : PBTypes.oneTypeEff(atype, otype2)
    warden_functions = [0x101C,0x101D,0x101E,0x101F,0x1020,0x1021,0x1022]
    warden_ability = [:ORN_CONDUCTOR,:ORN_ANTIGRAVITY]
    if warden_functions.include?(@function)
      case @function
        when 0x101C # Fly Trap
          mod1 = 4 if otype1 == :BUG
          mod2 = 4 if otype2 == :BUG
        when 0X101D # Satelite Ray
          mod1 = 4 if otype1 == :COSMIC
          mod2 = 4 if otype2 == :COSMIC
        when 0X101E # Fantasy Seal
          mod1 = 4 if otype1 == :GHOST
          mod2 = 4 if otype2 == :GHOST
        when 0x101F # Battle of Wits
          mod1 = 4 if otype1 == :PSYCHIC
          mod2 = 4 if otype2 == :PSYCHIC
        when 0x1020 # Erosion
          mod1 = 4 if otype1 == :ROCK
          mod2 = 4 if otype2 == :ROCK
        when 0x1021 # Corrode
          mod1 = 4 if otype1 == :STEEL
          mod2 = 4 if otype2 == :STEEL
        when 0x1022 # Boil
          mod1 = 4 if otype1 == :WATER
          mod2 = 4 if otype2 == :WATER
        when 0x0123 # Glitch
          glitch_type = [[:FIRE, :FLYING, :STEEL, :FAIRY, :SOUND],[:GRASS, :PSYCHIC, :DARK]]
          mod1 = 1 if glitch_type[0].include?(otype1)
          mod2 = 1 if glitch_type[0].include?(otype2)
          mod1 = 4 if glitch_type[1].include?(otype1)
          mod2 = 4 if glitch_type[1].include?(otype2)
      end
      return mod1 * mod2
    elsif warden_ability.include?(attacker.ability)
      case attacker.ability
        when :ORN_CONDUCTOR
          mod1 = 2 if [:GROUND,:ELECTRIC].include?(otype1) && atype == :ELECTRIC
          mod2 = 2 if [:GROUND,:ELECTRIC].include?(otype2) && atype == :ELECTRIC
        when :ORN_ANTIGRAVITY
          mod1 = 2 if [:SOUND,:GROUND].include?(atype) && otype1 == :COSMIC
          mod2 = 2 if [:SOUND,:GROUND].include?(atype) && otype2 == :COSMIC
      end
      return mod1 * mod2
    else
      return warden_pbTypeModifierNonBattler(type, attacker, opponent)
    end
  end

  def pbCalcDamage(attacker, opponent, hitnum: 0)
    opponent.damagestate.critical = false
    opponent.damagestate.typemod = 0
    opponent.damagestate.calcdamage = 0
    basedmg = @basedamage # From PBS file
    basedmg = [attacker.happiness, 250].min if attacker.crested == :LUVDISC && basedmg != 0
    basedmg = pbBaseDamage(basedmg, attacker, opponent) # Some function codes alter base power
    return 0 if basedmg == 0

    basedmg = basedmg * 0.3 if attacker.crested == :CINCCINO && !pbIsMultiHit

    damage = 1.0 # variable for overall damage, defined early due to spread damaage modifiers, only used later
    # Multi-targeting attacks
    if pbTargetsAll?(attacker) || attacker.midwayThroughMove
      if attacker.pokemon.piece == :KNIGHT && battle.FE == :CHESS && attacker.pbTarget(self) == :AllOpposing
        @battle.pbDisplay(_INTL("The knight forked the opponents!")) if !attacker.midwayThroughMove
        damage *= 1.25
      else
        damage *= 0.75
      end
      attacker.midwayThroughMove = true
    end

    # Prevent third dart in case first dart killed an opponent in doubles.
    attacker.midwayThroughMove = true if attacker.pbTarget(self) == :DragonDarts

    # Type effectiveness
    type = pbType(attacker)
    typemod = pbTypeModMessages(type, attacker, opponent)
    opponent.damagestate.typemod = typemod
    if typemod == 0
      opponent.damagestate.calcdamage = 0
      opponent.damagestate.critical = false
      return 0
    end

    critchance = pbCritRate?(attacker, opponent)
    if critchance >= 0
      ratios = [24, 8, 2, 1]
      opponent.damagestate.critical = @battle.pbRandom(ratios[critchance]) == 0
    end
    ##### Calcuate base power of move #####

    basemult = 1.0
    # classic prep stuff
    attitemworks = attacker.itemWorks?(true)
    #oppitemworks = opponent.itemWorks?(true)
    case attacker.ability
      when :TECHNICIAN
        if basedmg <= 60
          basemult *= 1.5
        elsif (@battle.FE == :FACTORY || @battle.ProgressiveFieldCheck(PBFields::CONCERT)) && basedmg <= 80
          basemult *= 1.5
        end
      when :STRONGJAW     then basemult *= 1.5 if PBStuff::BITEMOVE.include?(@move)
      when :SHARPNESS     then basemult *= 1.5 if sharpMove?
      when :TRUESHOT      then basemult *= 1.3 if PBStuff::BULLETMOVE.include?(@move)
      when :TOUGHCLAWS    then basemult *= 1.3 if contactMove?
      when :IRONFIST
        if @battle.FE == :CROWD
          basemult *= 1.2 if punchMove?
        else
          basemult *= 1.2 if punchMove?
        end
      when :RECKLESS      then basemult *= 1.2 if @recoil > 0 || [0x130, 0x10B, 0x506].include?(@function) # Shadow End, High Jump Kick, Axe Kick
      when :FLAREBOOST    then basemult *= 1.5 if (attacker.status == :BURN || @battle.FE == :BURNING || @battle.FE == :VOLCANIC || @battle.FE == :INFERNAL) && pbIsSpecial?(type) && @battle.FE != :FROZENDIMENSION
      when :TOXICBOOST
        if (attacker.status == :POISON || @battle.FE == :CORROSIVE || @battle.FE == :CORROSIVEMIST || @battle.FE == :WASTELAND || @battle.FE == :MURKWATERSURFACE) && pbIsPhysical?(type)
          if @battle.FE == :CORRUPTED
            basemult *= 2.0
          else
            basemult *= 1.5
          end
        end
      when :PUNKROCK
        if isSoundBased?
          case @battle.FE
            when :BIGTOP then basemult *= 1.5
            when :CAVE then basemult *= 1.5
            else
              basemult *= 1.3
          end
        end
      when :RIVALRY       then basemult *= attacker.gender == opponent.gender ? 1.25 : 0.75 if attacker.gender != 2
      when :MEGALAUNCHER  then basemult *= 1.5 if [:AURASPHERE, :DRAGONPULSE, :DARKPULSE, :WATERPULSE, :ORIGINPULSE, :TERRAINPULSE].include?(@move)
      when :SANDFORCE     then basemult *= 1.3 if (@battle.pbWeather == :SANDSTORM || @battle.FE == :DESERT || @battle.FE == :ASHENBEACH) && (type == :ROCK || type == :GROUND || type == :STEEL)
      when :ANALYTIC      then basemult *= 1.3 if (@battle.battlers.find_all { |battler| battler && battler.hp > 0 && !battler.hasMovedThisRound? && !@battle.switchedOut[battler.index] }).length == 0
      when :SHEERFORCE    then basemult *= 1.3 if effect > 0 || [0x908].include?(@function) # Gen 9 Mod - Electro Shot needs to be affected by Sheer Force.
      when :AERILATE
        if @type == :NORMAL && type == :FLYING
          case @battle.FE
            when :MOUNTAIN, :SNOWYMOUNTAIN, :SKY then basemult *= 1.5
            else
              basemult *= 1.2
          end
        end
      when :GALVANIZE
        if @type == :NORMAL && type == :ELECTRIC
          case @battle.FE
            when :ELECTERRAIN, :FACTORY then basemult *= 1.5
            when :SHORTCIRCUIT then basemult *= 2
            else
              if @battle.state.effects[:ELECTERRAIN] > 0
                basemult *= 1.5
              else
                basemult *= 1.2
              end
          end
        end
      when :REFRIGERATE
        if @type == :NORMAL && type == :ICE
          case @battle.FE
            when :ICY, :SNOWYMOUNTAIN, :FROZENDIMENSION then basemult *= 1.5
            else
              basemult *= 1.2
          end
        end
      when :PIXILATE
        if @type == :NORMAL && (type == :FAIRY || (type == :NORMAL && @battle.FE == :GLITCH))
          case @battle.FE
            when :MISTY then basemult *= 1.5
            else
              if @battle.state.effects[:MISTY] > 0
                basemult *= 1.5
              else
                basemult *= 1.2
              end
          end
        end
      when :DUSKILATE     then basemult *= 1.2 if @type == :NORMAL && (type == :DARK || (type == :NORMAL && @battle.FE == :GLITCH))
      when :NORMALIZE     then basemult *= 1.2 if !@zmove
      when :TRANSISTOR    then basemult *= 1.5 if type == :ELECTRIC
      when :DRAGONSMAW    then basemult *= 1.5 if type == :DRAGON
      when :STEELWORKER   then basemult *= @battle.FE == :FACTORY ? 2.0 : 1.5 if type == :STEEL
      when :SOLARIDOL     then basemult *= 1.5 if type == :FIRE
      when :LUNARIDOL     then basemult *= 1.5 if type == :ICE
      when :TERAVOLT      then basemult *= 1.5 if (Rejuv && @battle.FE == :ELECTERRAIN && type == :ELECTRIC)
      when :INEXORABLE    then basemult *= 1.3 if type == :DRAGON && (!opponent.hasMovedThisRound? || @battle.switchedOut[opponent.index])
    end
    case opponent.ability
      when :HEATPROOF     then basemult *= 0.5 if !opponent.moldbroken && type == :FIRE
      when :DRYSKIN       then basemult *= 1.25 if !opponent.moldbroken && type == :FIRE
      when :TRANSISTOR    then basemult *= 0.5 if (@battle.FE == :ELECTERRAIN && type == :GROUND) && !opponent.moldbroken
    end
    if attitemworks
      if $cache.items[attacker.item].checkFlag?(:typeboost) == type
        if $cache.items[attacker.item].checkFlag?(:gem)
          basemult *= 1.3
          @battle.pbDisplay(_INTL("The {1} strengthened {2}'s power!", getItemName(attacker.item), self.name)) unless attacker.takegem
          attacker.takegem = true
        else
          basemult *= 1.2
        end
      else
        case attacker.item
          when :MUSCLEBAND then basemult *= 1.1 if pbIsPhysical?(type)
          when :WISEGLASSES then basemult *= 1.1 if pbIsSpecial?(type)
          when :LUSTROUSORB then basemult *= 1.2 if attacker.pokemon.species == :PALKIA && (type == :DRAGON || type == :WATER)
          when :ADAMANTORB then basemult *= 1.2 if attacker.pokemon.species == :DIALGA && (type == :DRAGON || type == :STEEL)
          when :GRISEOUSORB then basemult *= 1.2 if attacker.pokemon.species == :GIRATINA && (type == :DRAGON || type == :GHOST)
          when :SOULDEW then basemult *= 1.2 if (attacker.pokemon.species == :LATIAS || attacker.pokemon.species == :LATIOS) && (type == :DRAGON || type == :PSYCHIC)
          # Gen 9 Mod - Ogerpon's Masks give it a 1.2x boost to all damaging moves it uses.
          when :WELLSPRINGMASK, :HEARTHFLAMEMASK, :CORNERSTONEMASK then basemult *= 1.2 if (attacker.pokemon.species == :OGERPON)
        end
      end
    end
    basemult = pbBaseDamageMultiplier(basemult, attacker, opponent)
    # standard crest damage multipliers
    case attacker.crested
      when :FERALIGATR then basemult *= 1.5 if PBStuff::BITEMOVE.include?(@move)
      when :CLAYDOL then basemult *= 1.5 if isBeamMove?
      when :DRUDDIGON then basemult *= 1.3 if type == :DRAGON || type == :FIRE
      when :BOLTUND then basemult *= 1.5 if PBStuff::BITEMOVE.include?(@move) && (!opponent.hasMovedThisRound? || @battle.switchedOut[opponent.index])
      when :FEAROW then basemult *= 1.5 if PBStuff::STABBINGMOVE.include?(@move)
      when :DUSKNOIR then basemult *= 1.5 if basedmg <= 60 || ((@battle.FE == :FACTORY || @battle.ProgressiveFieldCheck(PBFields::CONCERT)) && basedmg <= 80)
      when :CRABOMINABLE then basemult *= 1.5 if attacker.lastHPLost > 0
      when :AMPHAROS then basemult *= attacker.hasType?(type) ? 1.2 : 1.5 if attacker.moves[0] == self
      when :LUXRAY then basemult *= 1.2 if @type == :NORMAL && type == :ELECTRIC
      when :SAWSBUCK
        case attacker.form
          when 0 then basemult *= 1.2 if @type == :NORMAL && type == :WATER
          when 1 then basemult *= 1.2 if @type == :NORMAL && type == :FIRE
          when 2 then basemult *= 1.2 if @type == :NORMAL && type == :GROUND
          when 3 then basemult *= 1.2 if @type == :NORMAL && type == :ICE
        end
    end
    #type mods
    case type
      when :FIRE then basemult *= 0.33 if @battle.state.effects[:WaterSport] > 0
      when :ELECTRIC
        basemult *= 0.33 if @battle.state.effects[:MudSport] > 0
        # Gen 9 Mod - Charge lasts until the user uses an electric move.
        basemult *= 2.0 if attacker.effects[:Charge] == true
        attacker.effects[:Charge] = false
    end
    if type == :DARK && @battle.pbCheckGlobalAbility(:DARKAURA)
      auramult = 1.33
      case @battle.FE
        when :DARKNESS1 then auramult = 1.4
        when :DARKNESS2 then auramult = 1.5
        when :DARKNESS3 then auramult = 1.66
      end
      basemult *= @battle.pbCheckGlobalAbility(:AURABREAK) ? 2 - auramult : auramult
    end
    if type == :FAIRY && @battle.pbCheckGlobalAbility(:FAIRYAURA)
      auramult = 1.33
      case @battle.FE
        when :DARKNESS1 then auramult = 1.3
        when :DARKNESS2 then auramult = 1.2
        when :DARKNESS3 then auramult = 1.1
      end
      basemult *= @battle.pbCheckGlobalAbility(:AURABREAK) ? 2 - auramult : auramult
    end
    basemult *= 1.5 if attacker.effects[:HelpingHand]
    basemult *= 2.0 if opponent.effects[:Minimize] && @move == :MALICIOUSMOONSAULT # Minimize for z-move
    # Specific Field Effects
    if @battle.field.isFieldEffect?
      fieldmult = moveFieldBoost
      if fieldmult != 1
        basemult *= fieldmult
        fieldmessage = moveFieldMessage
        if fieldmessage && !@fieldmessageshown
          if [:LIGHTTHATBURNSTHESKY, :ICEHAMMER, :HAMMERARM, :CRABHAMMER].include?(@move) # some moves have a {1} in them and we gotta deal.
            @battle.pbDisplay(_INTL(fieldmessage, attacker.pbThis))
          elsif [:SMACKDOWN, :THOUSANDARROWS, :ROCKSLIDE, :VITALTHROW, :CIRCLETHROW, :STORMTHROW, :DOOMDUMMY, :BLACKHOLEECLIPSE, :TECTONICRAGE, :CONTINENTALCRUSH, :WHIRLWIND, :CUT].include?(@move)
            @battle.pbDisplay(_INTL(fieldmessage, opponent.pbThis))
          else
            @battle.pbDisplay(_INTL(fieldmessage))
          end
          @fieldmessageshown = true
        end
      end
    end
    case @battle.FE
      when :CHESS
        if (CHESSMOVES).include?(@move)
          basemult*=0.5 if [:ADAPTABILITY,:ANTICIPATION,:SYNCHRONIZE,:TELEPATHY].include?(opponent.ability)
          basemult*=2.0 if [:OBLIVIOUS,:KLUTZ,:UNAWARE,:SIMPLE].include?(opponent.ability) || opponent.effects[:Confusion]>0 || (Rejuv && opponent.ability == :DEFEATIST)
          @battle.pbDisplay("The chess piece slammed forward!") if !@fieldmessageshown
          @fieldmessageshown = true
        end
        # Queen piece boost
        if attacker.pokemon.piece==:QUEEN || attacker.ability == :QUEENLYMAJESTY
          basemult*=1.5
          if attacker.pokemon.piece==:QUEEN
            @battle.pbDisplay("The Queen is dominating the board!")  && !@fieldmessageshown
            @fieldmessageshown = true
          end
        end

        #Knight piece boost
        if attacker.pokemon.piece==:KNIGHT && opponent.pokemon.piece==:QUEEN
          basemult=(basemult*3.0).round
          @battle.pbDisplay("An unblockable attack on the Queen!") if !@fieldmessageshown
          @fieldmessageshown = true
        end
      when :BIGTOP
        if ((type == :FIGHTING && pbIsPhysical?(type)) || (STRIKERMOVES).include?(@move)) # Continental Crush
          striker = 1+@battle.pbRandom(14)
          @battle.pbDisplay("WHAMMO!") if !@fieldmessageshown
          @fieldmessageshown = true
          if attacker.ability == :HUGEPOWER || attacker.ability == :GUTS || attacker.ability == :PUREPOWER || attacker.ability == :SHEERFORCE
            if striker >=9
              striker = 15
            else
              striker = 14
            end
          end
          strikermod = attacker.stages[PBStats::ATTACK]
          striker = striker + strikermod
          if striker >= 15
            @battle.pbDisplay("...OVER 9000!!!")
            provimult=3.0
          elsif striker >=13
            @battle.pbDisplay("...POWERFUL!")
            provimult=2.0
          elsif striker >=9
            @battle.pbDisplay("...NICE!")
            provimult=1.5
          elsif striker >=3
            @battle.pbDisplay("...OK!")
            provimult=1
          else
            @battle.pbDisplay("...WEAK!")
            provimult=0.5
          end
          provimult = ((provimult-1.0)/2.0)+1.0 if $game_variables[:DifficultyModes]==1 && !$game_switches[:FieldFrenzy]
          provimult = ((provimult-1.0)*2.0)+1.0 if $game_variables[:DifficultyModes]!=1 && $game_switches[:FieldFrenzy] && provimult > 1
          provimult = provimult/2.0 if $game_variables[:DifficultyModes]!=1 && $game_switches[:FieldFrenzy] && provimult < 1
          basemult*=provimult
        end
        if isSoundBased?
          provimult=1.5
          provimult=1.25 if $game_variables[:DifficultyModes]==1
          provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
          basemult*=provimult
          @battle.pbDisplay("Loud and clear!") if !@fieldmessageshown
          @fieldmessageshown = true
        end
      when :ICY
        if (@priority >= 1 && @basedamage > 0 && contactMove? && attacker.ability != :LONGREACH) || (@move == :FEINT || @move == :ROLLOUT || @move == :DEFENSECURL || @move == :STEAMROLLER || @move == :LUNGE)
          if !attacker.isAirborne?
            if attacker.pbIncreaseStat(PBStats::SPEED, 1, statmessage: false)
              if attacker.ability == :CONTRARY
                @battle.pbDisplay(_INTL("{1} lost momentum on the ice!", attacker.pbThis)) if !@fieldmessageshown
              else
                @battle.pbDisplay(_INTL("{1} gained momentum on the ice!", attacker.pbThis)) if !@fieldmessageshown
              end
              @fieldmessageshown = true
            end
          end
        end
      when :SHORTCIRCUIT
        if type == :ELECTRIC
          damageroll = @battle.field.getRoll(maximize_roll:(@battle.state.effects[:ELECTERRAIN] > 0))
          messageroll = ["Bzzt.", "Bzzapp!" , "Bzt...", "Bzap!", "BZZZAPP!"][PBStuff::SHORTCIRCUITROLLS.index(damageroll)]
          @battle.pbDisplay(messageroll) if !@fieldmessageshown
          damageroll = ((damageroll-1.0)/2.0)+1.0 if $game_variables[:DifficultyModes]==1 && !$game_switches[:FieldFrenzy]
          damageroll = ((damageroll-1.0)*2.0)+1.0 if $game_variables[:DifficultyModes]!=1 && $game_switches[:FieldFrenzy] && damageroll > 1
          damageroll = damageroll/2.0 if $game_variables[:DifficultyModes]!=1 && $game_switches[:FieldFrenzy] && damageroll < 1
          basemult*=damageroll

          @fieldmessageshown = true
        end
      when :CAVE
        if isSoundBased?
          provimult=1.5
          provimult=1.25 if $game_variables[:DifficultyModes]==1
          provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
          basemult*=provimult
          @battle.pbDisplay(_INTL("ECHO-Echo-echo!",opponent.pbThis)) if !@fieldmessageshown
          @fieldmessageshown = true
        end
      when :MOUNTAIN
        if (PBFields::WINDMOVES).include?(@move) && @battle.pbWeather== :STRONGWINDS
          provimult=1.5
          provimult=1.25 if $game_variables[:DifficultyModes]==1
          provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
          basemult*=provimult
          @battle.pbDisplay(_INTL("The wind strengthened the attack!",opponent.pbThis)) if !@fieldmessageshown
          @fieldmessageshown = true
        end
      when :SNOWYMOUNTAIN
        if (PBFields::WINDMOVES).include?(@move) && @battle.pbWeather== :STRONGWINDS
          provimult=1.5
          provimult=1.25 if $game_variables[:DifficultyModes]==1
          provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
          basemult*=provimult
          @battle.pbDisplay(_INTL("The wind strengthened the attack!",opponent.pbThis)) if !@fieldmessageshown
          @fieldmessageshown = true
        end
      when :MIRROR
        if (PBFields::MIRRORMOVES).include?(@move) && opponent.stages[PBStats::EVASION]>0
          provimult=2.0
          provimult=1.5 if $game_variables[:DifficultyModes]==1
          provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
          basemult*=provimult
          @battle.pbDisplay(_INTL("The beam was focused from the reflection!",opponent.pbThis)) if !@fieldmessageshown
          @fieldmessageshown = true
        end
        @battle.field.counter = 0
      when :DEEPEARTH
        if (priorityCheck(attacker) > 0) && @basedamage > 0
          provimult=0.7
          provimult=0.85 if $game_variables[:DifficultyModes]==1
          provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
          basemult*=provimult
          @battle.pbDisplay(_INTL("The intense pull slowed the attack...")) if !@fieldmessageshown
          @fieldmessageshown = true
        end
        if (priorityCheck(attacker) < 0) && @basedamage > 0
          provimult=1.3
          provimult=1.15 if $game_variables[:DifficultyModes]==1
          provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
          basemult*=provimult
          @battle.pbDisplay(_INTL("Slow and heavy!")) if !@fieldmessageshown
          @fieldmessageshown = true
        end
      when :CONCERT1,:CONCERT2,:CONCERT3,:CONCERT4
        if isSoundBased?
          provimult=1.5
          provimult=1.25 if $game_variables[:DifficultyModes]==1
          provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
          basemult*=provimult
          @battle.pbDisplay(_INTL("Loud and clear!")) if !@fieldmessageshown
          @fieldmessageshown = true
        end
      when :DARKNESS3,:DARKNESS2
        if [:LIGHTTHATBURNSTHESKY].include?(@move)
          @battle.pbDisplay(_INTL("One brings Shadow, One brings the Light!")) if !@fieldmessageshown
          @fieldmessageshown = true
        end
    end
    if Rejuv
      for terrain in [:ELECTERRAIN,:GRASSY,:MISTY,:PSYTERRAIN]
        if @battle.state.effects[terrain] > 0
          overlaymult = moveOverlayBoost(terrain)
          if overlaymult != 1
            basemult*=overlaymult
            overlaymessage = moveOverlayMessage(terrain)
            @battle.pbDisplay(_INTL(overlaymessage)) if overlaymessage
          end
        end
      end
    end
    #End S.Field Effects
    ##### Calculate attacker's attack stat #####
    case @function
      when 0x121 # Foul Play
        atk = opponent.attack
        atkstage = opponent.stages[PBStats::ATTACK] + 6
      when 0x184 # Body Press
        atk = attacker.defense
        atkstage = attacker.stages[PBStats::DEFENSE] + 6
      else
        atk = attacker.attack
        atkstage = attacker.stages[PBStats::ATTACK] + 6
    end
    if pbIsSpecial?(type)
      atk = attacker.spatk
      atkstage = attacker.stages[PBStats::SPATK] + 6
      if @function == 0x121 # Foul Play
        atk = opponent.spatk
        atkstage = opponent.stages[PBStats::SPATK] + 6
      elsif @function == 0x1025 # Holy Ward/Scented Shield/Sound Barrier
        atk = opponent.spdef
        atkstage = opponent.stages[PBStats::SPDEF] + 6
      end
      if @battle.FE == :GLITCH
        atk = attacker.getSpecialStat(opponent.ability == :UNAWARE, attacker: true, crit: opponent.damagestate.critical)
        atkstage = 6 # getspecialstat handles unaware
      end
    end
    # Stat-Copy Crests, ala Claydol//Dedenne
    case attacker.crested
      when :CLAYDOL then atkstage = attacker.stages[PBStats::DEFENSE] + 6 if pbIsSpecial?(type)
      when :DEDENNE then atkstage = attacker.stages[PBStats::SPEED] + 6 if !pbIsSpecial?(type)
    end
    if opponent.ability != :UNAWARE || opponent.moldbroken
      atkstage = 6 if opponent.damagestate.critical && atkstage < 6
      atk = (atk * PBStats::StageMul[atkstage]).floor
    end
    if attacker.ability == :HUSTLE && pbIsPhysical?(type)
      atk = [:BACKALLEY, :CITY].include?(@battle.FE) ? (atk * 1.75).round : (atk * 1.5).round
    end
    atkmult = 1.0
    if @battle.FE == :HAUNTED || @battle.FE == :BEWITCHED || @battle.FE == :HOLY || @battle.FE == :PSYTERRAIN || @battle.FE == :DEEPEARTH
      atkmult *= 1.5 if attacker.pbPartner.ability == :POWERSPOT
    else
      atkmult *= 1.3 if attacker.pbPartner.ability == :POWERSPOT
    end
    # pinch abilities
    if (@battle.FE == :BURNING || @battle.FE == :VOLCANIC || @battle.FE == :INFERNAL) && (attacker.ability == :BLAZE && type == :FIRE)
      atkmult *= 1.5
    elsif @battle.FE == :VOLCANICTOP && (attacker.ability == :BLAZE && type == :FIRE) && attacker.effects[:Blazed]
      atkmult *= 1.5
    elsif (@battle.FE == :FOREST || (Rejuv && @battle.FE == :GRASSY)) && (attacker.ability == :OVERGROW && type == :GRASS)
      atkmult *= 1.5
    elsif @battle.FE == :FOREST && (attacker.ability == :SWARM && type == :BUG)
      atkmult *= 1.5
    elsif ((@battle.FE == :WATERSURFACE && !attacker.isAirborne?) || @battle.FE == :UNDERWATER) && (attacker.ability == :TORRENT && type == :WATER)
      atkmult *= 1.5
    elsif @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN) && (attacker.ability == :SWARM && type == :BUG)
      atkmult *= 1.5 if @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN, 1, 2)
      atkmult *= 1.8 if @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN, 3, 4)
      atkmult *= 2.0 if @battle.FE == :FLOWERGARDEN5
    elsif @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN, 2, 5) && (attacker.ability == :OVERGROW && type == :GRASS)
      case @battle.FE
        when :FLOWERGARDEN2 then atkmult *= 1.5 if attacker.hp <= (attacker.totalhp * 0.67).floor
        when :FLOWERGARDEN3 then atkmult *= 1.6
        when :FLOWERGARDEN4 then atkmult *= 1.8
        when :FLOWERGARDEN5 then atkmult *= 2.0
      end
    elsif attacker.hp <= (attacker.totalhp / 3.0).floor
      if (attacker.ability == :OVERGROW && type == :GRASS) || (attacker.ability == :BLAZE && type == :FIRE && @battle.FE != :FROZENDIMENSION) ||
         (attacker.ability == :TORRENT && type == :WATER) || (attacker.ability == :SWARM && type == :BUG)
        atkmult *= 1.5
      end
      # Warden Pinch Abilities #
      ward_combo = [[:ORN_STARSTRUCK,:COSMIC],[:ORN_IRRADIATE,:LIGHT],[:ORN_MAESTRO,:SOUND],[:ORN_SPELLCASTER,:PSYCHIC]]
      for w in 0...ward_combo.length
        atkmult *= 1.5 if attacker.ability == ward_combo[w][0] && type == ward_combo[w][1]
      end
      # Warden Pinch Abilities #
    end
    case attacker.ability
      when :GUTS then atkmult*=1.5 if !attacker.status.nil? && pbIsPhysical?(type)
      when :PLUS, :MINUS
        if pbIsSpecial?(type) && @battle.FE != :GLITCH
          partner=attacker.pbPartner
          if partner.ability == :PLUS || partner.ability == :MINUS
            atkmult*=1.5
          elsif @battle.FE == :SHORTCIRCUIT || (Rejuv && @battle.FE == :ELECTERRAIN) || @battle.state.effects[:ELECTERRAIN] > 0
            atkmult*=1.5
          end
        end
      when :DEFEATIST then atkmult*=0.5 if attacker.hp<=(attacker.totalhp/2.0).floor
      when :HUGEPOWER then atkmult*=2.0 if pbIsPhysical?(type)
      when :PUREPOWER
        if @battle.FE == :PSYTERRAIN || @battle.state.effects[:PSYTERRAIN] > 0
          atkmult*=2.0 if pbIsSpecial?(type)
        else
          atkmult*=2.0 if pbIsPhysical?(type)
        end
      when :SOLARPOWER then atkmult*=1.5 if (@battle.pbWeather== :SUNNYDAY && !(attitemworks && attacker.item == :UTILITYUMBRELLA)) && pbIsSpecial?(type) && (@battle.FE != :GLITCH &&  @battle.FE != :FROZENDIMENSION)
      when :SLOWSTART then atkmult*=0.5 if attacker.turncount<5 && pbIsPhysical?(type) && @battle.FE != :DEEPEARTH
      when :GORILLATACTICS then atkmult*=1.5 if pbIsPhysical?(type)
      when :QUARKDRIVE then atkmult*=1.3 if (attacker.effects[:Quarkdrive][0] == PBStats::ATTACK && pbIsPhysical?(type)) || (attacker.effects[:Quarkdrive][0] == PBStats::SPATK && pbIsSpecial?(type))
      # Gen 9 Mod - Added Protosynthesis, Hadron Engine and Orichalcum Pulse
      when :PROTOSYNTHESIS then atkmult*=1.3 if (attacker.effects[:Protosynthesis][0] == PBStats::ATTACK && pbIsPhysical?(type)) || (attacker.effects[:Protosynthesis][0] == PBStats::SPATK && pbIsSpecial?(type))
      when :ORICHALCUMPULSE then atkmult*=(5461/4096.to_f) if (@battle.pbWeather== :SUNNYDAY && pbIsPhysical?(type)) &&  @battle.FE != :FROZENDIMENSION
      when :HADRONENGINE then atkmult*=(5461/4096.to_f) if ((@battle.FE == :ELECTERRAIN || @battle.state.effects[:ELECTERRAIN] > 0) && pbIsSpecial?(type)) &&  @battle.FE != :FROZENDIMENSION
    end
    # Mid Battle stat multiplying crests; Spiritomb Crest, Castform Crest
    case attacker.crested
      when :CASTFORM then atkmult*=1.5 if attacker.form == 1 && (@battle.pbWeather== :SUNNYDAY && !(attitemworks && attacker.item == :UTILITYUMBRELLA)) && pbIsSpecial?(type) && (@battle.FE != :GLITCH &&  @battle.FE != :FROZENDIMENSION)
      when :SPIRITOMB
          allyfainted = attacker.pbFaintedPokemonCount
          modifier = (allyfainted * 0.2) + 1.0
          atkmult=(atkmult*modifier).round
    end
    # Gen 9 Mod - Added Supreme Overlord
    if attacker.ability == :SUPREMEOVERLORD
      allyfainted = attacker.effects[:SupremeOverlord]
      modifier = (allyfainted * 0.1) + 1.0
      atkmult *= modifier
    end
    if ((@battle.pbWeather== :SUNNYDAY && !(attitemworks && attacker.item == :UTILITYUMBRELLA)) || @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN) || @battle.FE == :BEWITCHED) && pbIsPhysical?(type)
      atkmult*=1.5 if attacker.ability == :FLOWERGIFT || attacker.pbPartner.ability == :FLOWERGIFT
    end
    if (@battle.pbWeather== :SUNNYDAY) && pbIsPhysical?(type)
      atkmult*=1.5 if attacker.ability == :SOLARIDOL
    end
    if (@battle.pbWeather== :HAIL) && pbIsSpecial?(type)
      atkmult*=1.5 if attacker.ability == :LUNARIDOL
    end
    if attacker.pbPartner.ability == (:BATTERY) && pbIsSpecial?(type) && @battle.FE != :GLITCH
      if Rejuv && @battle.FE == :ELECTERRAIN
        atkmult*=1.5
      else
        atkmult*=1.3
      end
    end
    if @battle.FE == :FAIRYTALE
      atkmult*=2.0 if (attacker.pbPartner.ability == :STEELYSPIRIT || attacker.ability == :STEELYSPIRIT) && type == :STEEL
    else
      atkmult*=1.5 if (attacker.pbPartner.ability == :STEELYSPIRIT || attacker.ability == :STEELYSPIRIT) && type == :STEEL
    end
    atkmult*=1.5 if attacker.effects[:FlashFire] && type == :FIRE && @battle.FE != :FROZENDIMENSION

    if attitemworks
      case attacker.item
        when :THICKCLUB then atkmult*=2.0 if attacker.pokemon.species == :CUBONE || attacker.pokemon.species == :MAROWAK && pbIsPhysical?(type)
        when :DEEPSEATOOTH then atkmult*=2.0 if attacker.pokemon.species == :CLAMPERL && pbIsSpecial?(type) && @battle.FE != :GLITCH
        when :LIGHTBALL then atkmult*=2.0 if attacker.pokemon.species == :PIKACHU && @battle.FE != :GLITCH
        when :CHOICEBAND then atkmult*=1.5 if pbIsPhysical?(type)
        when :CHOICESPECS then atkmult*=1.5 if pbIsSpecial?(type) && @battle.FE != :GLITCH
        # Gen 9 Mod - Added Punching Glove
        when :PUNCHINGGLOVE then basemult*=1.1 if punchMove?
      end
    end
    if @battle.FE != :INDOOR
      if @battle.FE == :STARLIGHT || @battle.FE == :NEWWORLD
        if attacker.ability == :VICTORYSTAR
          atkmult*=1.5
        end
        partner=attacker.pbPartner
        if partner && partner.ability == :VICTORYSTAR
          atkmult*=1.5
        end
      end
      if @battle.FE == :WATERSURFACE
        atkmult*=1.5 if attacker.ability == :PROPELLERTAIL && @priority >= 1 && @basedamage > 0
      end
      if @battle.FE == :UNDERWATER
        atkmult*=0.5 if (!Rejuv || !attacker.hasType?(:WATER)) && pbIsPhysical?(type) && type != :WATER && attacker.ability != :STEELWORKER && attacker.ability != :SWIFTSWIM
        atkmult*=1.5 if attacker.ability == :PROPELLERTAIL && @priority >= 1 && @basedamage > 0
      end
      if Rejuv && @battle.FE == :CHESS
        atkmult*=1.2 if attacker.ability == :GORILLATACTICS || attacker.ability == :RECKLESS
        atkmult*=1.2 if attacker.ability == :ILLUSION && attacker.effects[:Illusion]!=nil
        if attacker.ability == :COMPETITIVE
          frac = (1.0*attacker.hp)/(1.0*attacker.totalhp)
          multiplier = 1.0
          multiplier += ((1.0-frac)/0.8)
          if frac < 0.2
            multiplier = 2.0
          end
          atkmult=(atkmult*multiplier)
        end
      end
      case attacker.ability
        when :QUEENLYMAJESTY then atkmult*=1.5 if @battle.FE == :FAIRYTALE
        when :LONGREACH then atkmult*=1.5 if (@battle.FE == :MOUNTAIN || @battle.FE == :SNOWYMOUNTAIN || @battle.FE == :SKY)
        when :CORROSION then atkmult*=1.5 if (@battle.FE == :CORROSIVE || @battle.FE == :CORROSIVEMIST || @battle.FE == :CORRUPTED)
        when :SKILLLINK then atkmult*=1.2 if (@battle.FE == :COLOSSEUM && (@function == 0xC0 || @function == 0x307 || (attacker.crested == :CINCCINO && !pbIsMultiHit))) #0xC0: 2-5 hits; 0x307: Scale Shot
      end
    end
    atkmult*=0.5 if opponent.ability == :THICKFAT && (type == :ICE || type == :FIRE) && !(opponent.moldbroken)

    ##### Calculate opponent's defense stat #####
    defense = opponent.defense
    defstage = opponent.stages[PBStats::DEFENSE] + 6
    # TODO: Wonder Room should apply around here

    applysandstorm = false
    if pbHitsSpecialStat?(type)
      defense = opponent.spdef
      defstage = opponent.stages[PBStats::SPDEF] + 6
      applysandstorm = true
      if @battle.FE == :GLITCH
        defense = opponent.getSpecialStat(attacker.ability == :UNAWARE, attacker: false, crit: opponent.damagestate.critical)
        defstage = 6 # getspecialstat handles unaware
        applysandstorm = false # getSpecialStat handles sandstorm
      end
    end
    if attacker.ability != :UNAWARE
      defstage = 6 if @function == 0xA9 # Chip Away (ignore stat stages)
      defstage = 6 if opponent.damagestate.critical && defstage > 6
      defense = (defense * PBStats::StageMul[defstage]).floor
    end
    if @battle.pbWeather == :SANDSTORM && opponent.hasType?(:ROCK) && applysandstorm
      defense = (defense * 1.5).round
    end
    defmult = 1.0
    defmult *= 0.5 if @battle.FE == :GLITCH && @function == 0xE0
    defmult *= 0.5 if attacker.crested == :ELECTRODE && pbHitsPhysicalStat?(type)
    # Field Effect defense boost
    defmult *= fieldDefenseBoost(type, opponent)

    # Abilities defense boost
    case opponent.ability
      when :ICESCALES then defmult *= 2.0 if pbIsSpecial?(type) && !opponent.moldbroken
      when :MARVELSCALE then defmult *= 1.5 if (pbIsPhysical?(type) && (!opponent.status.nil? || ([:MISTY, :RAINBOW, :FAIRYTALE, :DRAGONSDEN, :STARLIGHT].include?(@battle.FE) || @battle.state.effects[:MISTY] > 0))) && !opponent.moldbroken
      when :GRASSPELT then defmult *= 1.5 if pbIsPhysical?(type) && (@battle.FE == :GRASSY || @battle.FE == :FOREST || @battle.state.effects[:GRASSY] > 0) # Grassy Field
      when :FURCOAT then defmult *= 2.0 if pbIsPhysical?(type) && !opponent.moldbroken
      when :PUNKROCK then defmult *= 2.0 if isSoundBased? && !opponent.moldbroken
      when :QUARKDRIVE then defmult *= 1.3 if (opponent.effects[:Quarkdrive][0] == PBStats::DEFENSE && pbIsPhysical?(type)) || (opponent.effects[:Quarkdrive][0] == PBStats::SPDEF && pbIsSpecial?(type))
      # Gen 9 Mod - Added Protosynthesis
      when :PROTOSYNTHESIS then defmult *= 1.3 if (opponent.effects[:Protosynthesis][0] == PBStats::DEFENSE && pbIsPhysical?(type)) || (opponent.effects[:Protosynthesis][0] == PBStats::SPDEF && pbIsSpecial?(type))
      when :FLUFFY
        defmult *= 2.0 if contactMove? && attacker.ability != :LONGREACH && !opponent.moldbroken
        defmult *= 4.0 if contactMove? && attacker.ability != :LONGREACH && @battle.FE == :CLOUDS && !opponent.moldbroken
        defmult *= 0.5 if type == :FIRE && !opponent.moldbroken
    end
    if ((@battle.pbWeather == :SUNNYDAY && !opponent.hasWorkingItem(:UTILITYUMBRELLA)) || @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN) || @battle.FE == :BEWITCHED) && !opponent.moldbroken && pbIsSpecial?(type)
      if opponent.ability == :FLOWERGIFT && opponent.species == :CHERRIM
        defmult *= 1.5
      end
      if opponent.pbPartner.ability == :FLOWERGIFT && opponent.pbPartner.species == :CHERRIM
        defmult *= 1.5
      end
    end
    # Item defense boost
    if opponent.hasWorkingItem(:EVIOLITE) && !(@battle.FE == :GLITCH && pbIsSpecial?(type))
      evos = pbGetEvolvedFormData(opponent.pokemon.species, opponent.pokemon)
      if evos && evos.length > 0
        defmult *= 1.5
      end
    end
    if opponent.item == :PIKANIUMZ && opponent.pokemon.species == :PIKACHU && !(@battle.FE == :GLITCH && pbIsSpecial?(type))
      defmult *= 1.5
    end
    if opponent.item == :LIGHTBALL && opponent.pokemon.species == :PIKACHU && !(@battle.FE == :GLITCH && pbIsSpecial?(type))
      defmult *= 1.5
    end
    if opponent.hasWorkingItem(:ASSAULTVEST) && pbIsSpecial?(type) && @battle.FE != :GLITCH
      defmult *= 1.5
    end
    if opponent.hasWorkingItem(:DEEPSEASCALE) && @battle.FE != :GLITCH && opponent.pokemon.species == :CLAMPERL && pbIsSpecial?(type)
      defmult *= 2.0
    end
    if opponent.hasWorkingItem(:METALPOWDER) && opponent.pokemon.species == :DITTO && !opponent.effects[:Transform] && pbIsPhysical?(type)
      defmult *= 2.0
    end

    # General damage modifiers
    # variable "damage" used from here on out
    # damage at this point is generaly 1 ; unless it's a spread move in which case it's 0.75 normally or 1.25 for knight pieces on chess

    # Field Effects
    fieldBoost = typeFieldBoost(type,attacker,opponent)
    overlayBoost, overlay = typeOverlayBoost(type,attacker,opponent)
    if fieldBoost != 1 || overlayBoost != 1
      if fieldBoost > 1 && overlayBoost > 1
        boost = [fieldBoost,overlayBoost].max
        if $game_variables[:DifficultyModes]==1 && !$game_switches[:FieldFrenzy]
          boost = 1.25 if boost < 1.25
        elsif $game_variables[:DifficultyModes]!=1 && $game_switches[:FieldFrenzy]
          boost = 2.0 if boost < 2.0
        else
          boost = 1.5 if boost < 1.5
        end
      else
        boost = fieldBoost*overlayBoost
      end
      damage*=boost
      fieldmessage = typeFieldMessage(type) if fieldBoost != 1
      overlaymessage = typeOverlayMessage(type,overlay) if overlay
      if overlaymessage && !fieldmessage
        @battle.pbDisplay(_INTL(overlaymessage)) if !@fieldmessageshown_type
      else
        @battle.pbDisplay(_INTL(fieldmessage)) if fieldmessage && !@fieldmessageshown_type
      end
      @fieldmessageshown_type = true
    end
    case @battle.FE
      when :MOUNTAIN,:SNOWYMOUNTAIN
        if type == :FLYING && !pbIsPhysical?(type) && @battle.pbWeather== :STRONGWINDS
          provimult=1.5
          provimult=1.25 if $game_variables[:DifficultyModes]==1
          provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
          damage*=provimult
        end
      when :DEEPEARTH
        if type == :GROUND && opponent.hasType?(:GROUND)
          provimult=0.5
          provimult=0.75 if $game_variables[:DifficultyModes]==1 && !$game_switches[:FieldFrenzy]
          provimult=0.25 if $game_variables[:DifficultyModes]!=1 && $game_switches[:FieldFrenzy]
          damage*=provimult
          @battle.pbDisplay(_INTL("The dense earth is difficult to mold...")) if !@fieldmessageshown_type
          @fieldmessageshown_type = true
        end
    end
    case @battle.pbWeather
      when :SUNNYDAY
        if @battle.state.effects[:HarshSunlight] && type == :WATER
          @battle.pbDisplay(_INTL("The Water-type attack evaporated in the harsh sunlight!"))
          @battle.scene.pbUnVanishSprite(attacker) if @function==0xCB #Dive
          return 0
        end
      when :RAINDANCE
        if @battle.state.effects[:HeavyRain] && type == :FIRE
          @battle.pbDisplay(_INTL("The Fire-type attack fizzled out in the heavy rain!"))
          return 0
        end
    end
    # FIELD TRANSFORMATIONS
    fieldmove = @battle.field.moveData(@move)
    if fieldmove && fieldmove[:fieldchange]
      change_conditions = @battle.field.fieldChangeData
      handled = change_conditions[fieldmove[:fieldchange]] ? eval(change_conditions[fieldmove[:fieldchange]]) : true
      #don't continue if conditions to change are not met or if a multistage field changes to a different stage of itself
      if handled  && !(@battle.ProgressiveFieldCheck("All") && (PBFields::CONCERT.include?(fieldmove[:fieldchange]) || PBFields::FLOWERGARDEN.include?(fieldmove[:fieldchange]) || PBFields::DARKNESS.include?(fieldmove[:fieldchange])))
        provimult=1.3
        provimult=1.15 if $game_variables[:DifficultyModes]==1
        provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
        damage*=provimult
      end
    end
    case @battle.FE
      when :FACTORY
        if (@move == :DISCHARGE) || (@move == :OVERDRIVE)
          @battle.setField(:SHORTCIRCUIT)
          @battle.pbDisplay(_INTL("The field shorted out!"))
          provimult=1.3
          provimult=1.15 if $game_variables[:DifficultyModes]==1
          provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
          damage*=provimult
        end
      when :SHORTCIRCUIT
        if (@move == :DISCHARGE) || (@move == :OVERDRIVE)
          @battle.setField(:FACTORY)
          @battle.pbDisplay(_INTL("SYSTEM ONLINE."))
          provimult=1.3
          provimult=1.15 if $game_variables[:DifficultyModes]==1
          provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
          damage*=provimult
        end
    end

    # Gen 9 Mod - Added Hydro Steam's Damage Calc in Sunny Weather
    case type
      when :FIRE
        damage*=1.5 if @battle.pbWeather == :SUNNYDAY
        damage*=0.5 if @battle.pbWeather == :RAINDANCE
        damage*=0.5 if opponent.ability == :WATERBUBBLE
      when :WATER
        damage*=1.5 if @battle.pbWeather == :RAINDANCE || (@battle.pbWeather == :SUNNYDAY && @move == :HYDROSTEAM)
        damage*=0.5 if @battle.pbWeather == :SUNNYDAY && !@move == :HYDROSTEAM
        damage*=2 if attacker.ability == :WATERBUBBLE
    end
    # Critical hits
    if opponent.damagestate.critical
      damage*=1.5
      damage*=1.5 if attacker.ability == :SNIPER
    end
    # STAB-addition from Crests
    typecrest = false
    case attacker.crested
      when :EMPOLEON then typecrest = true if type == :ICE
      when :LUXRAY then typecrest = true if type == :DARK
      when :SAMUROTT then typecrest = true if type == :FIGHTING
      when :SIMISEAR then typecrest = true if type == :WATER
      when :SIMIPOUR then typecrest = true if type == :GRASS
      when :SIMISAGE then typecrest = true if type == :FIRE
      when :ZOROARK
        party = @battle.pbPartySingleOwner(attacker.index)
        party=party.find_all {|item| item && !item.egg? && item.hp>0 }
        if party[party.length-1] != attacker.pokemon
          typecrest = true if party[party.length-1].hasType?(type)
        end
      end
    # STAB
    # Gen 9 Mod - Added Rocky Payload, Embody Aspect
    if (attacker.hasType?(type) && (!attacker.effects[:DesertsMark])|| (attacker.ability == :STEELWORKER && type == :STEEL)  || (attacker.ability == :SOLARIDOL && type == :FIRE) || (attacker.ability == :LUNARIDOL && type == :ICE) || (attacker.ability == :ROCKYPAYLOAD && type == :ROCK) || typecrest==true)
      if attacker.ability == :ADAPTABILITY ||
          # Gen 9 Mod - Mega (Terastalized) Ogerpon gets a Tera Boost on it's STAB moves based on it's mask.
          (((attacker.form == 8 && type == :GRASS) ||
          (attacker.form == 9 && type == :WATER) ||
          (attacker.form == 10 && type == :FIRE) ||
          (attacker.form == 11 && type == :ROCK)) && attacker.species == :OGERPON)
        damage*=2.0
      elsif (attacker.ability == :STEELWORKER && type == :STEEL) && @battle.FE == :FACTORY # Factory Field
        damage*=2.0
      else
        damage*=1.5
      end
      if attacker.crested == :SILVALLY
        damage*=1.2
      end
    end
    # Gen 9 Mod - Mega (Terastalized) Ogerpon still get's STAB on it's grass type moves.
    if (((attacker.ability == :EMBODYASPECTWELLSPRING) || (attacker.ability == :EMBODYASPECTHEARTHFLAME) || (attacker.ability == :EMBODYASPECTCORNERSTONE)) && type == :GRASS)
      damage*=1.5
    end
    # Gen 9 Mod - Moves of each type used by Mega (Terastalized) Terapagos will get a boost.
    if (attacker.species == :TERAPAGOS && attacker.form == 2)
      # Gen 9 Mod - Normal moves will get 2x boost (this includes STAB).
      if (type == :NORMAL)
        damage*=2
      # Gen 9 Mod - Moves of other types will get a 1.2x boost.
      else
        damage*=1.2
      end
    end
    # Type Effectiveness (typemod has been calced earlier)
    damage = (damage * typemod / 4.0)

    damage *= 0.5 if attacker.status == :BURN && pbIsPhysical?(type) && ![:GUTS,:ORN_ATTUNEMENT].include?(attacker.ability) && @move != :FACADE
    # Random Variance
    if !$game_switches[:No_Damage_Rolls] || @battle.isOnline?
      random = 85 + @battle.pbRandom(16)
    elsif $game_switches[:No_Damage_Rolls] || !@battle.isOnline?
      random = 93
    end
    random = 85 if @battle.FE == :CONCERT1
    random = 100 if @battle.FE == :CONCERT4
    damage = (damage * (random / 100.0))
    # Final damage modifiers
    finalmult = 1.0
    if !opponent.damagestate.critical && attacker.ability != :INFILTRATOR
      # Screens
      if @category != :status && opponent.pbOwnSide.screenActive?(betterCategory(type))
        finalmult *= (!opponent.pbPartner.isFainted? || attacker.midwayThroughMove) ? 0.66 : 0.5
      end
      if opponent.pbOwnSide.effects[:AreniteWall] > 0 && opponent.damagestate.typemod > 4
        finalmult *= 0.5
      end
    end
    
    # Warden Abilities
    case attacker.ability
      when :ORN_REQUIEM       then basemult *= 1.5 if type == :DARK
      when :ORN_AFFECTION     then basemult *= 1.5 if type == :FAIRY
      when :ORN_ARSONIST      then basemult *= 1.5 if type == :FIRE
      when :ORN_VIRTUOSO      then basemult *= 1.5 if type == :SOUND
      when :ORN_HIVEMIND      then basemult *= 1.5 if type == :BUG
      when :ORN_BONECOLLECTOR then basemult *= 1.5 if type == :GROUND
      when :ORN_HAUNTED       then basemult *= 1.5 if type == :GHOST
      when :ORN_BLACKLIGHT    then basemult *= 1.2 if type == :DARK
      when :ORN_WHITEOUT      then basemult *= 1.2 if type == :LIGHT
      when :ORN_DARKMATTER    then basemult *= 1.2 if type == :COSMIC
      when :ORN_CANNONFIRE    then basemult *= 1.5 if pbStuff::BULLETMOVE.include?(@move)
      when :ORN_ICYVEINS      then basemult *= 1.3 if @battle.pbWeather == :HAIL && [:WATER,:ICE].include?(type)
      when :ORN_ATTUNEMENT    then atkmult *= 1.5  if !attacker.status.nil? && pbIsSpecial?(type)
      when :ORN_TORMENTED     then atkmult *= 1.5  if pbIsSpecial?(type)
      when :ORN_GENIUS        then atkmult *= 2.0  if pbIsSpecial?(type)
    end
    atkmult*=0.5 if opponent.ability == :ORN_REALISM && [:GHOST,:FAIRY].include?(type) && !(opponent.moldbroken)
    atkmult*=0.5 if opponent.ability == :ORN_ASTRALMAJESTY && [:LIGHT,:DRGON].include?(type) && !(opponent.moldbroken)
    atkmult*=0.5 if opponent.ability == :ORN_IRREDEEMABLE && [:LIGHT,:FAIRY].include?(type) && !(opponent.moldbroken)
    atkmult*=0.5 if opponent.ability == :ORN_TROPICALHIDE && [:GRASS,:WATER].include?(type) && !(opponent.moldbroken)
    atkmult*=0.5 if opponent.ability == :ORN_LIGHTBULB && [:DARK].include?(type) && !(opponent.moldbroken)
    atkmult*=0.5 if opponent.ability == :ORN_TERRORIZE && [:BUG].include?(type) && !(opponent.moldbroken)
    atkmult*=0.5 if opponent.ability == :ORN_WINDFURY && pbStuff::WINDMOVE.include?(@move) && !(opponent.moldbroken)
    atkmult*=1.5 if attacker.ability == :ORN_WINTERGIFT || attacker.pbPartner.ability == :ORN_WINTERGIFT
    defmult*=1.5 if attacker.ability == :ORN_WINTERGIFT || attacker.pbPartner.ability == :ORN_WINTERGIFT
    if type == :LIGHT && @battle.pbCheckGlobalAbility(:ORN_LIGHTAURA)
      auramult = 1.33
      basemult *= @battle.pbCheckGlobalAbility(:AURABREAK) ? 2 - auramult : auramult
    end
    finalmult *= 0.75 if (((opponent.ability == :ORN_PACKEDSNOW) && !opponent.moldbroken)) && pbWeather == :HAIL && opponent.damagestate.typemod > 4
    # Warden Abilities

    # Warden Crests
    atkmult*=0.25 if opponent.crested == :ORN_TYPHLOSION && [:FIGHTING,:COSMIC].include?(type)
    atkmult*=1.1 if attacker.crested==:ORN_KABUTOPS
    basemult *= 1.2 if @recoil > 0 || [0x130, 0x10B, 0x506].include?(@function) && user.crested == :ORN_TALONFLAME
    # Warden Crests

    # Final damage modifiers
    finalmult *= 0.67 if opponent.crested == :BEHEEYEM && (!opponent.hasMovedThisRound? || @battle.switchedOut[opponent.index])
    secondtypes = self.getSecondaryType(attacker)
    finalmult *= 0.5 if opponent.effects[:Shelter] && @battle.FE != :INDOOR && (type == @battle.field.mimicry || !secondtypes.nil? && secondtypes.include?(@battle.field.mimicry))
    # Gen 9 Mod - Added Purifying Salt
    finalmult *= 0.5 if opponent.ability == :PURIFYINGSALT && type == :GHOST
    finalmult *= 0.5 if (opponent.ability == :MULTISCALE && !opponent.moldbroken) && opponent.hp == opponent.totalhp
    finalmult *= 0.5 if opponent.ability == :SHADOWSHIELD && (opponent.hp == opponent.totalhp || @battle.FE == :DIMENSIONAL)
    finalmult *= 0.33 if opponent.ability == :SHADOWSHIELD && (opponent.hp == opponent.totalhp && (@battle.FE == :DARKNESS2 || @battle.FE == :DARKNESS3))
    finalmult *= 2.0 if attacker.ability == :TINTEDLENS && opponent.damagestate.typemod < 4
    finalmult *= 2.0 if attacker.ability == :EXECUTION && (opponent.hp <= (opponent.totalhp / 2).floor)
    finalmult *= 0.75 if opponent.pbPartner.ability == :FRIENDGUARD && !opponent.moldbroken
    finalmult *= 0.5 if (opponent.ability == :PASTELVEIL || opponent.pbPartner.ability == :PASTELVEIL) && @type == :POISON && (@battle.FE == :MISTY || @battle.FE == :RAINBOW || (@battle.state.effects[:MISTY] > 0))
    if @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN, 3, 5)
      if (opponent.pbPartner.ability == :FLOWERVEIL && opponent.hasType?(:GRASS)) || (opponent.ability == :FLOWERVEIL && !opponent.moldbroken)
        finalmult *= 0.75
        @battle.pbDisplay(_INTL("The Flower Veil softened the attack!"))
      end
    end
    finalmult *= 0.75 if (((opponent.ability == :SOLIDROCK || opponent.ability == :FILTER) && !opponent.moldbroken) || opponent.ability == :PRISMARMOR) && opponent.damagestate.typemod > 4
    finalmult *= 0.75 if opponent.ability == :SHADOWSHIELD && [:STARLIGHT, :NEWWORLD, :DARKCRYSTALCAVERN].include?(@battle.FE) && opponent.damagestate.typemod
    finalmult *= 0.70 if opponent.crested == :AMPHAROS && opponent.damagestate.typemod > 4
    finalmult *= 2.0 if attacker.ability == :STAKEOUT && @battle.switchedOut[opponent.index]
    finalmult *= [1.0 + attacker.effects[:Metronome] * 0.2, 2.0].min if (attitemworks && attacker.item == :METRONOME) && attacker.movesUsed[-2] == attacker.movesUsed[-1]
    finalmult *= [1.0 + attacker.effects[:Metronome] * 0.2, 2.0].min if @battle.FE == :CONCERT4 && attacker.movesUsed[-2] == attacker.movesUsed[-1]
    finalmult *= 1.2 if attitemworks && attacker.item == :EXPERTBELT && opponent.damagestate.typemod > 4
    finalmult *= 1.25 if attacker.ability == :NEUROFORCE && opponent.damagestate.typemod > 4
    finalmult *= 1.3 if attitemworks && attacker.item == :LIFEORB
    # Gen 9 Mod - Moves will deal double damage to an opponent that last used Glaive Rush. Also includes Electro Drift and Collision Course.
    finalmult *= 2.0 if opponent.effects[:GlaiveRush] == true
    finalmult *= (5461 / 4096.to_f) if [:ELECTRODRIFT, :COLLISIONCOURSE].include?(@move) && opponent.damagestate.typemod > 4
    if opponent.damagestate.typemod > 4 && opponent.itemWorks?
      hasberry = false
      case type
        when :FIGHTING   then hasberry = opponent.item == :CHOPLEBERRY
        when :FLYING     then hasberry = opponent.item == :COBABERRY
        when :POISON     then hasberry = opponent.item == :KEBIABERRY
        when :GROUND     then hasberry = opponent.item == :SHUCABERRY
        when :ROCK       then hasberry = opponent.item == :CHARTIBERRY
        when :BUG        then hasberry = opponent.item == :TANGABERRY
        when :GHOST      then hasberry = opponent.item == :KASIBBERRY
        when :STEEL      then hasberry = opponent.item == :BABIRIBERRY
        when :FIRE       then hasberry = opponent.item == :OCCABERRY
        when :WATER      then hasberry = opponent.item == :PASSHOBERRY
        when :GRASS      then hasberry = opponent.item == :RINDOBERRY
        when :ELECTRIC   then hasberry = opponent.item == :WACANBERRY
        when :PSYCHIC    then hasberry = opponent.item == :PAYAPABERRY
        when :ICE        then hasberry = opponent.item == :YACHEBERRY
        when :DRAGON     then hasberry = opponent.item == :HABANBERRY
        when :DARK       then hasberry = opponent.item == :COLBURBERRY
        when :FAIRY      then hasberry = opponent.item == :ROSELIBERRY
        when :COSMIC     then hasberry = opponent.item == :ORN_OLIBERRY
        when :LIGHT      then hasberry = opponent.item == :ORN_PATOTOBERRY
        when :SOUND      then hasberry = opponent.item == :ORN_AVOCABERRY
      end
    end
    hasberry = true if opponent.hasWorkingItem(:CHILANBERRY) && type == :NORMAL
    if hasberry && !([:UNNERVE, :ASONECHILLING, :ASONEGRIM].include?(attacker.ability) || [:UNNERVE, :ASONECHILLING, :ASONEGRIM].include?(attacker.pbPartner.ability))
      finalmult *= 0.5
      finalmult *= 0.5 if opponent.ability == :RIPEN
      opponent.pbDisposeItem(true, true, true, true)
      if !@battle.pbIsOpposing?(attacker.index)
        @battle.pbDisplay(_INTL("{2}'s {1} weakened the damage from the attack!", getItemName(opponent.pokemon.itemRecycle), opponent.pbThis))
      else
        @battle.pbDisplay(_INTL("The {1} weakened the damage to {2}!", getItemName(opponent.pokemon.itemRecycle), opponent.pbThis))
      end
    end
    finalmult *= 0.8 if opponent.crested == :MEGANIUM || opponent.pbPartner.crested == :MEGANIUM
    if attacker.crested == :SEVIPER
      multiplier = 0.5 * (opponent.pokemon.hp * 1.0) / (opponent.pokemon.totalhp * 1.0)
      multiplier += 1.0
      finalmult = (finalmult * multiplier)
    end
    if @zmove
      if opponent.pbOwnSide.effects[:MatBlock] || opponent.effects[:Protect] ||
         opponent.pbOwnSide.effects[:WideGuard] && [:AllOpposing, :AllNonUsers].include?(attacker.pbTarget(self))
        if @move == :UNLEASHEDPOWER
          @battle.pbDisplay(_INTL("The Interceptor's power broke through {1}'s Protect!", opponent.pbThis))
        elsif !opponent.effects[:ProtectNegation]
          @battle.pbDisplay(_INTL("{1} couldn't fully protect itself!", opponent.pbThis))
          finalmult /= 4
        end
      end
    end
    # Gen 9 Mod - Added Ruinous Abilities (This is scuffed imo) --> prolly should do it in finalmult instead
    if (attacker.pbOpposing1.ability == :VESSELOFRUIN || attacker.pbOpposing2.ability == :VESSELOFRUIN || attacker.pbPartner.ability == :VESSELOFRUIN) && attacker.ability != :VESSELOFRUIN && pbIsSpecial?(type) 
      atkmult *= 0.75
    end
    if (attacker.pbOpposing1.ability == :TABLETSOFRUIN || attacker.pbOpposing2.ability == :TABLETSOFRUIN || attacker.pbPartner.ability == :TABLETSOFRUIN) && attacker.ability != :TABLETSOFRUIN && pbIsPhysical?(type)
      atkmult *= 0.75
    end
    if ((opponent.pbOpposing1.ability == :SWORDOFRUIN || opponent.pbOpposing2.ability == :SWORDOFRUIN || opponent.pbPartner.ability == :SWORDOFRUIN) && opponent.ability != :SWORDOFRUIN)
      if @battle.state.effects[:WonderRoom] != 0 && pbIsSpecial?(type)
        defmult *= 0.75
      elsif @battle.state.effects[:WonderRoom] == 0 && pbIsPhysical?(type)
        defmult *= 0.75
      end
    end
    if ((opponent.pbOpposing1.ability == :BEADSOFRUIN || opponent.pbOpposing2.ability == :BEADSOFRUIN || opponent.pbPartner.ability == :BEADSOFRUIN) && opponent.ability != :BEADSOFRUIN) 
      if @battle.state.effects[:WonderRoom] != 0 && pbIsPhysical?(type)
        defmult *= 0.75
      elsif @battle.state.effects[:WonderRoom] == 0 && pbIsSpecial?(type)
        defmult *= 0.75
      end
    end

    # O.Kabutops Crest #
    finalmult *= 1.2 if attacker.crested == :ORN_KABUTOPS && opponent.damagestate.typemod > 4
    basemult *= 1.5 if attacker.crested == :ORN_KABUTOPS && sharpMove?

    # O.Kabutops Crest #

    finalmult = pbModifyDamage(finalmult, attacker, opponent)
    ##### Main damage calculation #####
    basedmg *= basemult
    atk *= atkmult
    defense *= defmult
    totaldamage = (((((2.0 * attacker.level / 5 + 2).floor * basedmg * atk / defense).floor / 50.0).floor + 1) * damage * finalmult).round
    totaldamage = 1 if totaldamage < 1
    opponent.damagestate.calcdamage = totaldamage
    return totaldamage
  end
end

class PokeBattle_Move_086 < PokeBattle_Move # Power is doubled if the user has no held item. (Acrobatics)
  def pbBaseDamage(basedmg,attacker,opponent)
    movetype = pbType(attacker)
    gem = false
    if attacker.itemWorks?
      case attacker.item
        when :NORMALGEM     then gem = true if movetype == :NORMAL
        when :FIGHTINGGEM   then gem = true if movetype == :FIGHTING
        when :FLYINGGEM     then gem = true if movetype == :FLYING
        when :POISONGEM     then gem = true if movetype == :POISON
        when :GROUNDGEM     then gem = true if movetype == :GROUND
        when :ROCKGEM       then gem = true if movetype == :ROCK
        when :BUGGEM        then gem = true if movetype == :BUG
        when :GHOSTGEM      then gem = true if movetype == :GHOST
        when :STEELGEM      then gem = true if movetype == :STEEL
        when :FIREGEM       then gem = true if movetype == :FIRE
        when :WATERGEM      then gem = true if movetype == :WATER
        when :GRASSGEM      then gem = true if movetype == :GRASS
        when :ELECTRICGEM   then gem = true if movetype == :ELECTRIC
        when :PSYCHICGEM    then gem = true if movetype == :PSYCHIC
        when :ICEGEM        then gem = true if movetype == :ICE
        when :DRAGONGEM     then gem = true if movetype == :DRAGON
        when :DARKGEM       then gem = true if movetype == :DARK
        when :FAIRYGEM      then gem = true if movetype == :FAIRY
        when :ORN_COSMICGEM then gem = true if movetype == :COSMIC
        when :ORN_LIGHTGEM  then gem = true if movetype == :LIGHT
        when :ORN_SOUNDGEM  then gem = true if movetype == :SOUND
      end
    end
    return basedmg*2 if attacker.item.nil? || @battle.FE == :BIGTOP || gem
    return basedmg
  end
end

class PokeBattle_Move_134 < PokeBattle_Move # Electric Terrain Updated for Teleface Eiscue
  def pbEffect(attacker, opponent, hitnum = 0, alltargets = nil, showanimation = true)
    if !((!Rejuv && @battle.canChangeFE?(:ELECTERRAIN)) || (@battle.canChangeFE?([:ELECTERRAIN, :DRAGONSDEN]) && !(@battle.state.effects[:ELECTERRAIN] > 0)))
      @battle.pbDisplay(_INTL("But it failed!"))
      return -1
    end
    pbShowAnimation(@move, attacker, opponent, hitnum, alltargets, showanimation)
    duration = 5
    duration = 8 if attacker.hasWorkingItem(:AMPLIFIELDROCK)
    @battle.setField(:ELECTERRAIN, duration)
    @battle.pbDisplay(_INTL("The terrain became electrified!"))

    for facemon in @battle.battlers
      if facemon.species==:ORN_EISCUE && facemon.form==1 # Eiscue
        facemon.pbRegenTele
        @battle.pbDisplay(_INTL("{1} transformed!",facemon.name))
      end
    end
    return 0
  end
end

class PokeBattle_Move_16E < PokeBattle_Move
  def pbEffect(attacker, opponent, hitnum = 0, alltargets = nil, showanimation = true)
    totalboost = 0
    if pbTypeModifier(@type, attacker, opponent) != 0
      for i in [PBStats::ATTACK, PBStats::DEFENSE, PBStats::SPEED, PBStats::SPATK, PBStats::SPDEF, PBStats::ACCURACY, PBStats::EVASION]
        if opponent.stages[i] > 0
          oppboost = opponent.stages[i]
          oppboost *= -1 if attacker.ability == :CONTRARY
          oppboost *= 2 if attacker.ability == :SIMPLE || attacker.crested == :ORN_FERALIGATR
          attacker.stages[i] += oppboost
          attacker.stages[i] = attacker.stages[i].clamp(-6, 6)
          totalboost += oppboost
          opponent.stages[i] = 0
        end
      end
    end
    if totalboost > 0
      @battle.pbCommonAnimation("StatUp", attacker, nil)
      @battle.pbDisplay(_INTL("{1} stole {2}'s stat boosts!", attacker.pbThis, opponent.pbThis))
    end
    return super(attacker, opponent, hitnum, alltargets, showanimation)
  end
end

class PokeBattle_Move
  def pbEffectsOnDealingDamage(move, user, target, damage, innards)
    movetypes = [move.pbType(user), *move.getSecondaryType(user)]
    # Gen 9 Mod - Store that target was hit for calculating Rage Fist damage.
    if target.damagestate.calcdamage > 0 && !target.damagestate.substitute
      @battle.addBattlerHit(target)
    end
    return if target.nil?
    return if move.basedamage == 0

    # Make the target flinch
    # needs to be checked before mummy/wandering spirit stench is check before ability change
    if target.damagestate.calcdamage > 0 && !target.damagestate.substitute
      # Gen 9 Mod - Added Covert Cloak
      if (target.ability != :SHIELDDUST || target.moldbroken) && !target.hasWorkingItem(:COVERTCLOAK)
        if (user.hasWorkingItem(:KINGSROCK) || user.hasWorkingItem(:RAZORFANG)) && !move.canFlinch?
          if @battle.pbRandom(10) == 0
            target.effects[:Flinch] = true
          end
        elsif user.ability == :STENCH && !move.canFlinch?
          if @battle.pbRandom(10) == 0 || ([:WASTELAND, :MURKWATERSURFACE, :BACKALLEY, :CITY].include?(@battle.FE) && @battle.pbRandom(10) < 2)
            target.effects[:Flinch] = true
          end
        end
      end
    end
    # Gen 9 Mod - Added Punching Glove
    if target.damagestate.calcdamage > 0 && !target.damagestate.substitute && !move.zmove && move.contactMove? && user.ability != :LONGREACH && !(user.hasWorkingItem(:PUNCHINGGLOVE) && move.punchMove?)
      eschance = 3
      eschance = 6 if @battle.FE == :CORRUPTED
      if user.ability == :POISONTOUCH && @battle.pbRandom(10) < eschance && target.pbCanPoison?(false)
        target.pbPoison(user)
        @battle.pbDisplay(_INTL("{1}'s {2} poisoned {3}!", user.pbThis, getAbilityName(user.ability), target.pbThis(true)))
      end
      # Gen 9 Mod - Added Toxic Chain
      if user.ability == :TOXICCHAIN && @battle.pbRandom(10) < eschance && target.pbCanPoison?(false)
        target.pbPoison(user, true)
        @battle.pbDisplay(_INTL("{1}'s {2} badly poisoned {3}!", user.pbThis, getAbilityName(user.ability), target.pbThis(true)))
      end
      if user.ability == :CORROSION && @battle.FE == :WASTELAND
        if @battle.pbRandom(10) == 0
          case @battle.pbRandom(4)
            when 0 then target.pbBurn(user)       if target.pbCanBurn?(false)
            when 1 then target.pbPoison(user)     if target.pbCanPoison?(false)
            when 2 then target.pbParalyze(user)   if target.pbCanParalyze?(false)
            when 3 then target.pbFreeze           if target.pbCanFreeze?(false)
          end
        end
      end
      if !user.hasWorkingItem(:PROTECTIVEPADS)
        if target.effects[:BeakBlast] && user.ability != :MAGICGUARD && !(user.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM) && user.pbCanBurn?(false)
          user.pbBurn(target)
          @battle.pbDisplay(_INTL("{1} was burned by the heat!", user.pbThis))
        end
        if target.ability == :AFTERMATH && !user.isFainted? && target.hp <= 0 && !@battle.pbCheckGlobalAbility(:DAMP) && user.ability != :MAGICGUARD && !(user.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
          PBDebug.log("[#{user.pbThis} hurt by Aftermath]")
          @battle.scene.pbDamageAnimation(user, 0)
          if @battle.FE == :CORROSIVEMIST
            user.pbReduceHP((user.totalhp / 2.0).floor)
            @battle.pbDisplay(_INTL("{1} was caught in the toxic aftermath!", user.pbThis))
          else
            user.pbReduceHP((user.totalhp / 4.0).floor)
            @battle.pbDisplay(_INTL("{1} was caught in the aftermath!", user.pbThis))
          end
        end
        if [:IRONBARBS, :ROUGHSKIN].include?(target.ability) && !user.isFainted? && user.ability != :MAGICGUARD && !(user.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
          @battle.scene.pbDamageAnimation(user, 0)
          user.pbReduceHP((user.totalhp / 8.0).floor)
          @battle.pbDisplay(_INTL("{1}'s {2} hurt {3}!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
        end
        if target.hasWorkingItem(:ROCKYHELMET, true) && !user.isFainted? && user.ability != :MAGICGUARD && !(user.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
          @battle.scene.pbDamageAnimation(user, 0)
          user.pbReduceHP((user.totalhp / 6.0).floor)
          @battle.pbDisplay(_INTL("{1} was hurt by the {2}!", user.pbThis, getItemName(target.item)))
        end
        eschance = 3
        eschance = 6 if [:FOREST, :WASTELAND, :BEWITCHED].include?(@battle.FE)
        # Effect Spore
        if !user.hasType?(:GRASS) && user.ability != :OVERCOAT && target.ability == :EFFECTSPORE && @battle.pbRandom(10) < eschance
          rnd = @battle.pbRandom(3)
          if rnd == 0 && user.pbCanPoison?(false)
            user.pbPoison(target)
            @battle.pbDisplay(_INTL("{1}'s {2} poisoned {3}!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
          elsif rnd == 1 && user.pbCanSleep?(false)
            user.pbSleep
            @battle.pbDisplay(_INTL("{1}'s {2} made {3} sleep!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
          elsif rnd == 2 && user.pbCanParalyze?(false)
            user.pbParalyze(target)
            @battle.pbDisplay(_INTL("{1}'s {2} paralyzed {3}! It may be unable to move!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
          end
        end
        if target.ability == :FLAMEBODY && @battle.pbRandom(10) < 3 && user.pbCanBurn?(false) && @battle.FE != :FROZENDIMENSION
          user.pbBurn(target)
          @battle.pbDisplay(_INTL("{1}'s {2} burned {3}!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
        end
        eschance = 3
        eschance = 6 if @battle.FE == :WASTELAND || @battle.FE == :CORRUPTED
        if target.ability == :POISONPOINT && @battle.pbRandom(10) < eschance && user.pbCanPoison?(false)
          user.pbPoison(target)
          @battle.pbDisplay(_INTL("{1}'s {2} poisoned {3}!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
        end
        eschance = 3
        eschance = 6 if @battle.FE == :SHORTCIRCUIT || (Rejuv && @battle.FE == :ELECTERRAIN)
        if target.ability == :STATIC && @battle.pbRandom(10) < eschance && user.pbCanParalyze?(false)
          user.pbParalyze(target)
          @battle.pbDisplay(_INTL("{1}'s {2} paralyzed {3}! It may be unable to move!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
        end
        if target.ability == :CUTECHARM && @battle.pbRandom(10) < 3
          if user.ability != :OBLIVIOUS &&
             ((user.gender == 1 && target.gender == 0) || (user.gender == 0 && target.gender == 1)) && user.effects[:Attract] < 0 && !user.isFainted?
            user.effects[:Attract] = target.index
            @battle.pbDisplay(_INTL("{1}'s {2} infatuated {3}!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
            if user.hasWorkingItem(:DESTINYKNOT) && target.ability != :OBLIVIOUS && target.effects[:Attract] < 0
              target.effects[:Attract] = user.index
              @battle.pbDisplay(_INTL("{1}'s {2} infatuated {3}!", user.pbThis, getItemName(user.item), target.pbThis(true)))
            end
          end
        end
        if target.ability == :PERISHBODY && user.effects[:PerishSong] == 0 && target.effects[:PerishSong] == 0 && @battle.FE != :HOLY
          if @battle.FE == :INFERNAL
            @battle.pbDisplay(_INTL("Both Pokémon will faint in one turn!"))
            user.effects[:PerishSong] = 2
            user.effects[:PerishSongUser] = target.index
            target.effects[:PerishSong] = 2
            target.effects[:PerishSongUser] = target.index
          else
            @battle.pbDisplay(_INTL("Both Pokémon will faint in three turns!"))
            user.effects[:PerishSong] = 4
            user.effects[:PerishSongUser] = target.index
            target.effects[:PerishSong] = 4
            target.effects[:PerishSongUser] = target.index
          end
          if @battle.FE == :DIMENSIONAL || @battle.FE == :HAUNTED || @battle.FE == :INFERNAL
            target.effects[:MeanLook] = user.index
            @battle.pbDisplay(_INTL("{1} can't escape now!", target.pbThis))
          end
        end
        if target.ability == :GOOEY
          if user.ability == :CONTRARY
            if @battle.FE == :SWAMP || @battle.FE == :MURKWATERSURFACE
              user.pbReduceStat(PBStats::SPEED, 2, statmessage: false, ignoreContrary: true)
              @battle.pbDisplay(_INTL("{1}'s {2} sharply boosted {3}'s Speed!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
            else
              user.pbReduceStat(PBStats::SPEED, 1, statmessage: false, ignoreContrary: true)
              @battle.pbDisplay(_INTL("{1}'s {2} boosted {3}'s Speed!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
            end
          elsif [:WHITESMOKE, :CLEARBODY, :FULLMETALBODY].include?(user.ability)
            @battle.pbDisplay(_INTL("{1}'s {2} prevents stat loss!", user.pbThis, getAbilityName(user.ability)))
          elsif @battle.FE == :SWAMP || @battle.FE == :MURKWATERSURFACE
            user.pbReduceStat(PBStats::SPEED, 2, statmessage: false, ignoreContrary: true)
            @battle.pbDisplay(_INTL("{1}'s {2} harshly lowered {3}'s Speed!", target.pbThis, getAbilityName(target.ability), user.pbThis(true))) if user.ability != :MIRRORARMOR
          else
            user.pbReduceStat(PBStats::SPEED, 1, statmessage: false, ignoreContrary: true)
            @battle.pbDisplay(_INTL("{1}'s {2} lowered {3}'s Speed!", target.pbThis, getAbilityName(target.ability), user.pbThis(true))) if user.ability != :MIRRORARMOR
          end
          if @battle.FE == :WASTELAND && user.pbCanPoison?(false)
            user.pbPoison(target)
            @battle.pbDisplay(_INTL("{1}'s {2} poisoned {3}!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
          end
        end
        if target.ability == :TANGLINGHAIR
          if user.ability == :CONTRARY
            user.pbReduceStat(PBStats::SPEED, 1, statmessage: false, ignoreContrary: true)
            @battle.pbDisplay(_INTL("{1}'s {2} boosted {3}'s Speed!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
          elsif user.ability == :WHITESMOKE || user.ability == :CLEARBODY || user.ability == :FULLMETALBODY
            @battle.pbDisplay(_INTL("{1}'s {2} prevents stat loss!", user.pbThis, getAbilityName(user.ability)))
          else
            user.pbReduceStat(PBStats::SPEED, 1, statmessage: false, ignoreContrary: true)
            @battle.pbDisplay(_INTL("{1}'s {2} lowered {3}'s Speed!", target.pbThis, getAbilityName(target.ability), user.pbThis(true))) if user.ability != :MIRRORARMOR
          end
        end
        if target.hasWorkingItem(:STICKYBARB, true) && user.item.nil? && !user.isFainted?
          user.item = target.item
          target.item = nil
          if !@battle.opponent && !@battle.pbIsOpposing?(user.index)
            if user.pokemon.itemInitial.nil? && target.pokemon.itemInitial == user.item
              user.pokemon.itemInitial = user.item
              target.pokemon.itemInitial = nil
            end
          end
          @battle.pbDisplay(_INTL("{1}'s {2} was transferred to {3}!", target.pbThis, getItemName(user.item), user.pbThis(true)))
        end
        if target.ability == :MUMMY && !user.isFainted?
          if user.ability != :MUMMY && !PBStuff::FIXEDABILITIES.include?(user.ability)
            neutralgas = true if user.ability == :NEUTRALIZINGGAS
            user.ability = :MUMMY
            user.effects[:GorillaLock] = nil
            @battle.pbDisplay(_INTL("{1} was mummified by {2}!", user.pbThis, target.pbThis(true)))
            @battle.neutralizingGasDisable(user.index) if neutralgas
          end
        end
        if target.ability == :WANDERINGSPIRIT && !user.isFainted? # && !@user.isBoss
          if ![:WANDERINGSPIRIT, :NEUTRALIZINGGAS].include?(user.ability) && !PBStuff::FIXEDABILITIES.include?(user.ability)
            tmp = user.ability
            user.ability = target.ability
            target.ability = tmp
            user.effects[:GorillaLock] = nil
            @battle.pbDisplay(_INTL("{1} swapped its {2} Ability with its target!", target.pbThis, getAbilityName(target.ability)))
            user.pbAbilitiesOnSwitchIn(true)
            target.pbAbilitiesOnSwitchIn(true)
          end
        end
        # Gen 9 Mod - Added Lingering Aroma
        if target.ability == :LINGERINGAROMA && !user.isFainted?
          if user.ability != :LINGERINGAROMA && !PBStuff::FIXEDABILITIES.include?(user.ability) && !user.hasWorkingItem(:ABILITYSHIELD) # Gen 9 Mod - Added Ability Shield
            neutralgas = true if user.ability == :NEUTRALIZINGGAS
            user.ability = :LINGERINGAROMA
            user.effects[:GorillaLock] = nil
            @battle.pbDisplay(_INTL("A lingering aroma clings to {1}!", user.pbThis))
            @battle.neutralizingGasDisable(user.index) if neutralgas
          end
        end
      end
    end
    if target.damagestate.calcdamage > 0
      if @battle.FE == :GLITCH # Glitch Field Hyper Beam Reset
        if user.hp > 0 && target.hp <= 0
          user.effects[:HyperBeam] = 0
        end
      end
      pbRecoilCalc
      # Bastiodon Crest
      if target.crested == :BASTIODON && !target.damagestate.disguise &&
         user.ability != :MAGICGUARD && !(user.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
        user.pbReduceHP([1, (damage / 2).floor].max)
        target.pbRecoverHP([1, (damage / 2).floor].max) if !target.isFainted?
        @battle.pbDisplay(_INTL("{1}'s crest causes {2} to take recoil damage and {3} to recover!", target.pbThis, user.pbThis(true), target.pbThis))
      end
      if target.ability == :INNARDSOUT && !user.isFainted? &&
         target.hp <= 0 && user.ability != :MAGICGUARD && !(user.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
        PBDebug.log("[#{user.pbThis} hurt by Innards Out]")
        @battle.scene.pbDamageAnimation(user, 0)
        user.pbReduceHP(innards)
        @battle.pbDisplay(_INTL("{2}'s innards hurt {1}!", user.pbThis, target.pbThis))
      end
      if !target.damagestate.substitute
        if target.effects[:ShellTrap] && move.pbIsPhysical?(movetypes[0]) && user.pbOwnSide != target.pbOwnSide && !(user.ability == :SHEERFORCE && move.effect > 0)
          target.effects[:ShellTrap] = false
        end
        if (target.ability == :CURSEDBODY && @battle.FE != :HOLY && (@battle.pbRandom(10) < 3 || (target.isFainted? && @battle.FE == :HAUNTED))) || target.crested == :BEHEEYEM
          if user.effects[:Disable] <= 0 && move.pp > 0 && !user.isFainted?
            user.effects[:Disable] = 4
            user.effects[:DisableMove] = move.move
            @battle.pbDisplay(_INTL("{1}'s {2} disabled {3}!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
          end
        end
        if target.ability == :GULPMISSILE && target.species == :CRAMORANT && !user.isFainted? && target.form != 0
          @battle.scene.pbDamageAnimation(user, 0)
          if user.ability != :MAGICGUARD && !(user.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
            if @battle.FE == :UNDERWATER
              eff = PBTypes.twoTypeEff(:WATER, user.type1, user.type2)
              user.pbReduceHP((user.totalhp * eff / 16.0).floor)
            else
              user.pbReduceHP((user.totalhp / 4.0).floor)
            end
          end
          if target.form == 1 # Gulping Form
            if user.pbReduceStat(PBStats::DEFENSE, 1, abilitymessage: false, statdropper: target)
              if user.ability == :CONTRARY
                @battle.pbDisplay(_INTL("{1}'s {2} raised {3}'s Defense!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
              else
                @battle.pbDisplay(_INTL("{1}'s {2} lowered {3}'s Defense!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
              end
            end
          elsif target.form == 2 # Gorging Form
            if user.pbCanParalyze?(false)
              user.pbParalyze(target)
              @battle.pbDisplay(_INTL("{1}'s {2} paralyzed {3}! It may be unable to move!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
            end
          end
          @battle.pbDisplay(_INTL("{1}'s {2} hurt {3}!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
          target.form = 0
          target.pbUpdate(false)
          @battle.scene.pbChangePokemon(target, target.pokemon)
          @battle.pbDisplay(_INTL("{1} returned to normal!", target.pbThis))
        end
        if target.effects[:Illusion] != nil
          target.effects[:Illusion] = nil
          @battle.pbAnimation(:TRANSFORM, target, target) if !target.isFainted?
          @battle.scene.pbChangePokemon(target, target.pokemon)
          @battle.pbDisplay(_INTL("{1}'s {2} was broken!", target.pbThis, getAbilityName(:ILLUSION)))
        end
        if target.ability == :JUSTIFIED && movetypes.include?(:DARK)
          if target.pbCanIncreaseStatStage?(PBStats::ATTACK)
            stat = @battle.FE == :HOLY ? 2 : 1
            target.pbIncreaseStatBasic(PBStats::ATTACK, stat)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s {2} raised its Attack!", target.pbThis, getAbilityName(target.ability)))
          end
        end
        if target.ability == :RATTLED && [:BUG, :DARK, :GHOST].intersect?(movetypes)
          if target.pbCanIncreaseStatStage?(PBStats::SPEED)
            target.pbIncreaseStatBasic(PBStats::SPEED, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s {2} raised its Speed!", target.pbThis, getAbilityName(target.ability)))
          end
        end
        if target.ability == :WEAKARMOR && move.pbIsPhysical?(movetypes[0])
          if target.pbCanReduceStatStage?(PBStats::DEFENSE, false, true)
            target.pbReduceStatBasic(PBStats::DEFENSE, 1)
            @battle.pbCommonAnimation("StatDown", target, nil)
            @battle.pbDisplay(_INTL("{1}'s {2} lowered its Defense!", target.pbThis, getAbilityName(target.ability)))
          end
          if target.pbCanIncreaseStatStage?(PBStats::SPEED)
            target.pbIncreaseStatBasic(PBStats::SPEED, 2)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s {2} sharply raised its Speed!", target.pbThis, getAbilityName(target.ability)))
          end
        end
        # Gen 9 Mod - Added Toxic Debris.
        if target.ability == (:TOXICDEBRIS) && target.pbOpposingSide.effects[:ToxicSpikes] < 2 && move.pbIsPhysical?(movetypes) && !(@battle.FE == :WATERS || @battle.FE == :MURKWATERS)
           target.pbOpposingSide.effects[:ToxicSpikes] += 1
          if !@battle.pbIsOpposing?(target.index)
             @battle.pbDisplay(_INTL("Poison spikes were scattered all around the foe's team's feet!"))
          else
             @battle.pbDisplay(_INTL("Poison spikes were scattered all around your team's feet!"))
          end
        end
        if target.ability == :STAMINA
          if target.pbCanIncreaseStatStage?(PBStats::DEFENSE)
            target.pbIncreaseStatBasic(PBStats::DEFENSE, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s {2} raised its Defense!", target.pbThis, getAbilityName(target.ability)))
          end
        end
        if target.crested == :NOCTOWL
          if target.pbCanIncreaseStatStage?(PBStats::SPDEF)
            target.pbIncreaseStatBasic(PBStats::SPDEF, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s Crest raised its Special Defense!", target.pbThis))
          end
        end
        if target.ability == :WATERCOMPACTION && movetypes.include?(:WATER)
          if @battle.FE != :ASHENBEACH
            if target.pbCanIncreaseStatStage?(PBStats::DEFENSE)
              target.pbIncreaseStatBasic(PBStats::DEFENSE, 2)
              @battle.pbCommonAnimation("StatUp", target, nil)
              @battle.pbDisplay(_INTL("{1}'s Water Compaction sharply raised its Defense!", target.pbThis, getAbilityName(target.ability)))
            end
          else
            boost = false
            if target.pbCanIncreaseStatStage?(PBStats::DEFENSE)
              target.pbIncreaseStatBasic(PBStats::DEFENSE, 2)
              @battle.pbCommonAnimation("StatUp", target, nil) if !boost
              boost = true
            end
            if target.pbCanIncreaseStatStage?(PBStats::SPDEF)
              target.pbIncreaseStatBasic(PBStats::SPDEF, 2)
              @battle.pbCommonAnimation("StatUp", target, nil) if !boost
              boost = true
            end
            @battle.pbDisplay(_INTL("{1}'s {2} sharply raised its Defense and Special Defense!", target.pbThis, getAbilityName(target.ability))) if boost
          end
        end
        # Cotton Down
        if target.ability == :COTTONDOWN
          @battle.pbDisplay(_INTL("{1}'s {2} scatters cotton around!", target.pbThis, getAbilityName(target.ability)))
          for i in @battle.battlers
            next if i == target
            statdrop = 1
            statdrop = 2 if @battle.FE == :BEWITCHED || @battle.FE == :GRASSY
            if i.pbReduceStat(PBStats::SPEED, statdrop, abilitymessage: false)
              @battle.pbDisplay(_INTL("The cotton reduces {1}'s Speed!", i.pbThis)) if i.ability != :MIRRORARMOR
            end
          end
        end
        # Sand Spit
        if target.ability == :SANDSPIT
          if !(@battle.state.effects[:HeavyRain] || @battle.state.effects[:HarshSunlight] ||
             @battle.weather == :STRONGWINDS || @battle.weather == :SANDSTORM || [:NEWWORLD, :UNDERWATER, :DIMENSIONAL].include?(@battle.FE))
            @battle.pbAnimation(:SANDSTORM, self, nil)
            @battle.weather = :SANDSTORM
            @battle.weatherduration = 5
            @battle.weatherduration = 8 if target.hasWorkingItem(:SMOOTHROCK) || [:DESERT, :ASHENBEACH, :SKY].include?(@battle.FE)
            @battle.pbCommonAnimation("Sandstorm")
            @battle.pbDisplay(_INTL("A sandstorm brewed!"))
            if [:DESERT, :ASHENBEACH].include?(@battle.FE) && user.pbCanReduceStatStage?(PBStats::ACCURACY)
              user.pbReduceStatBasic(PBStats::ACCURACY, 1)
              @battle.pbCommonAnimation("StatDown", user, nil)
              @battle.pbDisplay(_INTL("{1}'s accuracy fell!", user.pbThis))
            end
          end
        end
        # Steam Engine
        if target.ability == :STEAMENGINE && [:WATER, :FIRE].intersect?(movetypes)
          if target.pbCanIncreaseStatStage?(PBStats::SPEED)
            target.pbIncreaseStatBasic(PBStats::SPEED, 6)
            @battle.pbCommonAnimation("StatUp", target)
            @battle.pbDisplay(_INTL("{1}'s {2} drastically raised its Speed!", target.pbThis, getAbilityName(target.ability)))
          end
        end
        if target.hasWorkingItem(:ABSORBBULB) && movetypes.include?(:WATER)
          if target.pbIncreaseStat(PBStats::SPATK, 1, statmessage: false, statsource: target)
            if target.ability == :CONTRARY && !target.moldbroken
              @battle.pbDisplay(_INTL("{1}'s {2} lowered its Special Attack!", target.pbThis, getItemName(target.item)))
            else
              @battle.pbDisplay(_INTL("{1}'s {2} raised its Special Attack!", target.pbThis, getItemName(target.item)))
            end
            target.pbDisposeItem(false)
          end
        end
        if (target.hasWorkingItem(:SNOWBALL) && movetypes.include?(:ICE)) || (target.hasWorkingItem(:CELLBATTERY) && movetypes.include?(:ELECTRIC))
          if target.pbIncreaseStat(PBStats::ATTACK, 1, statmessage: false, statsource: target)
            if target.ability == :CONTRARY && !target.moldbroken
              @battle.pbDisplay(_INTL("{1}'s {2} lowered its Attack!", target.pbThis, getItemName(target.item)))
            else
              @battle.pbDisplay(_INTL("{1}'s {2} raised its Attack!", target.pbThis, getItemName(target.item)))
            end
            target.pbDisposeItem(false)
          end
        end
        if target.hasWorkingItem(:LUMINOUSMOSS) && movetypes.include?(:WATER)
          if target.pbIncreaseStat(PBStats::SPDEF, 1, statmessage: false, statsource: target)
            if target.ability == :CONTRARY && !target.moldbroken
              @battle.pbDisplay(_INTL("{1}'s {2} lowered its Special Defense!", target.pbThis, getItemName(target.item)))
            else
              @battle.pbDisplay(_INTL("{1}'s {2} raised its Special Defense!", target.pbThis, getItemName(target.item)))
            end
            target.pbDisposeItem(false)
          end
        end
        if !([:UNNERVE, :ASONECHILLING, :ASONEGRIM].include?(user.ability) || [:UNNERVE, :ASONECHILLING, :ASONEGRIM].include?(user.pbPartner.ability))
          if target.hasWorkingItem(:KEEBERRY) && move.pbIsPhysical?(movetypes[0]) && user.ability != :SHEERFORCE
            if target.pbCanIncreaseStatStage?(PBStats::DEFENSE)
              @battle.pbCommonAnimation("Nom", target)
              target.pbIncreaseStat(PBStats::DEFENSE, 1, statmessage: false, statsource: target)
              if target.ability == :CONTRARY && !target.moldbroken
                @battle.pbDisplay(_INTL("{1}'s {2} lowered its Defense!", target.pbThis, getItemName(target.item)))
              else
                @battle.pbDisplay(_INTL("{1}'s {2} raised its Defense!", target.pbThis, getItemName(target.item)))
              end
              target.pbDisposeItem(true)
            end
          end

          if target.hasWorkingItem(:MARANGABERRY) && move.pbIsSpecial?(movetypes[0]) && user.ability != :SHEERFORCE
            if target.pbCanIncreaseStatStage?(PBStats::SPDEF)
              @battle.pbCommonAnimation("Nom", target)
              target.pbIncreaseStat(PBStats::SPDEF, 1, statmessage: false, statsource: target)
              if target.ability == :CONTRARY && !target.moldbroken
                @battle.pbDisplay(_INTL("{1}'s {2} lowered its Special Defense!", target.pbThis, getItemName(target.item)))
              else
                @battle.pbDisplay(_INTL("{1}'s {2} raised its Special Defense!", target.pbThis, getItemName(target.item)))
              end
              target.pbDisposeItem(true)
            end
          end

          if target.hasWorkingItem(:JABOCABERRY, true) && !user.isFainted? && move.pbIsPhysical?(movetypes[0])
            @battle.pbCommonAnimation("Nom", target)
            @battle.scene.pbDamageAnimation(user, 0)
            user.pbReduceHP((user.totalhp / 8.0).floor)
            @battle.pbDisplay(_INTL("{1} was hurt by the {2}!", user.pbThis, getItemName(target.item)))
            target.pbDisposeItem(true)
          end
          if target.hasWorkingItem(:ROWAPBERRY, true) && !user.isFainted? && move.pbIsSpecial?(movetypes[0])
            @battle.pbCommonAnimation("Nom", target)
            @battle.scene.pbDamageAnimation(user, 0)
            user.pbReduceHP((user.totalhp / 8.0).floor)
            @battle.pbDisplay(_INTL("{1} was hurt by the {2}!", user.pbThis, getItemName(target.item)))
            target.pbDisposeItem(true)
          end
        end
        if target.hasWorkingItem(:WEAKNESSPOLICY) && target.damagestate.typemod > 4
          if target.pbIncreaseStat(PBStats::ATTACK, 2, statmessage: false, statsource: target)
            if target.ability == :CONTRARY && !target.moldbroken
              @battle.pbDisplay(_INTL("{1}'s {2} harshly lowered its Attack!", target.pbThis, getItemName(:WEAKNESSPOLICY)))
            else
              @battle.pbDisplay(_INTL("{1}'s {2} sharply raised its Attack!", target.pbThis, getItemName(:WEAKNESSPOLICY)))
            end
            target.pbDisposeItem(false)
          end
          if target.pbIncreaseStat(PBStats::SPATK, 2, statmessage: false, statsource: target)
            if target.ability == :CONTRARY && !target.moldbroken
              @battle.pbDisplay(_INTL("{1}'s {2} harshly lowered its Special Attack!", target.pbThis, getItemName(:WEAKNESSPOLICY)))
            else
              @battle.pbDisplay(_INTL("{1}'s {2} sharply raised its Special Attack!", target.pbThis, getItemName(:WEAKNESSPOLICY)))
            end
            target.pbDisposeItem(false)
          end
        end
        if target.ability == :ANGERPOINT
          if target.pbCanIncreaseStatStage?(PBStats::ATTACK) && target.damagestate.critical
            target.stages[PBStats::ATTACK] = 6
            @battle.pbCommonAnimation("StatUp", target)
            @battle.pbDisplay(_INTL("{1}'s {2} maxed its Attack!", target.pbThis, getAbilityName(target.ability)))
          end
        end
        if target.effects[:Rage] && target.pbIsOpposing?(user.index)
          # TODO: Apparently triggers if opposing Pokémon uses Future Sight after a Future Sight attack
          if target.pbCanIncreaseStatStage?(PBStats::ATTACK)
            target.pbIncreaseStatBasic(PBStats::ATTACK, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s rage is building!", target.pbThis))
          end
        end
      end
      # Gen 9 Mod - Thermal Exchange
      if !target.damagestate.substitute
        if target.ability == (:THERMALEXCHANGE) && (movetypes == :FIRE)
          if target.pbCanIncreaseStatStage?(PBStats::ATTACK)
            target.pbIncreaseStatBasic(PBStats::ATTACK, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s {2} raised its Attack!", target.pbThis, getAbilityName(target.ability)))
          end
        end
      end
      # Gen 9 Mod - Wind Power
      if target.ability == (:WINDPOWER) && move.windMove?
        # Gen 9 Mod - Charge lasts until the user uses an electric move.
        if target.effects[:Charge] == false
          target.effects[:Charge] = true
          @battle.pbCommonAnimation("Charge", target, nil)
        end
        @battle.pbDisplay(_INTL("Being hit by {1} charged {2} with power!",move.name, target.pbThis))
      end
      # Gen 9 Mod - Electromorphosis
      # Gen 9 Mod - Charge lasts until the user uses an electric move.
      if target.ability == (:ELECTROMORPHOSIS)
        if target.effects[:Charge] == false
          target.effects[:Charge] = true
          @battle.pbCommonAnimation("Charge", target, nil)
        end
        @battle.pbDisplay(_INTL("Being hit by {1} charged {2} with power!", move.name, target.pbThis))
      end
      # Gen 9 Mod - Seed Sower
      if target.ability == (:SEEDSOWER)
        if ((@battle.canChangeFE?(:GRASSY)) || @battle.canChangeFE?([:GRASSY,:DRAGONSDEN])) && !(@battle.state.effects[:GRASSY] > 0)
          if @battle.FE == :FROZENDIMENSION
            @battle.pbDisplay(_INTL("The frozen dimension remains unchanged."))
          else
            duration = 5
            duration = 8 if self.hasWorkingItem(:AMPLIFIELDROCK)
            @battle.pbAnimation(:GRASSYTERRAIN, self, nil)
            @battle.setField(:GRASSY, duration)
            @battle.pbDisplay(_INTL("The terrain became grassy!"))
          end
        end
      end
      if target.hasWorkingItem(:AIRBALLOON, true)
        target.pbDisposeItem(false, true, false)
        @battle.pbDisplay(_INTL("{1}'s Air Balloon popped!", target.pbThis))
      end
    end
    if !target.effects[:ItemRemoval].nil?
      if target.item
        if target.ability == :STICKYHOLD && !target.moldbroken
          abilityname = getAbilityName(target.ability)
          @battle.pbDisplay(_INTL("{1}'s {2} made {3} ineffective!", target.pbThis, abilityname, basemove.name))
        elsif target.effects[:ItemRemoval] == :Remove && !@battle.pbIsUnlosableItem(target, target.item)
          target.effects[:ChoiceBand] = nil
          # Knocking of the item
          itemname = getItemName(target.item)
          target.item = nil
          target.pokemon.corrosiveGas = false
          @battle.pbDisplay(_INTL("{1} knocked off {2}'s {3}!", user.pbThis, target.pbThis(true), itemname))
        elsif target.effects[:ItemRemoval] == :Steal && !@battle.pbIsUnlosableItem(target, target.item) && !@battle.pbIsUnlosableItem(user, target.item) && user.item.nil?
          itemname = getItemName(target.item)
          user.item = target.item
          target.item = nil
          if target.pokemon.corrosiveGas
            target.pokemon.corrosiveGas = false
            user.pokemon.corrosiveGas = true
          end
          target.effects[:ChoiceBand] = nil
          # In a wild battle
          if !@battle.opponent && user.pokemon.itemInitial.nil? && target != user.pbPartner && target.pokemon.itemInitial == user.item && !target.isbossmon && !user.isbossmon
            user.pokemon.itemInitial = user.item
            user.pokemon.itemReallyInitialHonestlyIMeanItThisTime = user.item
            target.pokemon.itemInitial = nil
          end
          if @move == :THIEF
            @battle.pbCommonAnimation("Thief", user, target)
          else
            @battle.pbCommonAnimation("Covet", user, target)
          end
          @battle.pbDisplay(_INTL("{1} stole {2}'s {3}!", user.pbThis, target.pbThis(true), itemname))
        end
      end
      target.effects[:ItemRemoval] = nil
    end
  end

  def pbRecoilCalc
    if move.recoil > 0 && !target.damagestate.disguise && user.item != :ORN_BODYARMOR && 
      ![:ORN_RAPIDASH,:ORN_ARCANINE,:ORN_TALONFLAME].include?(user.crested)
       user.ability != :ROCKHEAD && user.crested != :RAMPARDOS && user.ability != :MAGICGUARD &&
       !(move.move == :WILDCHARGE && @battle.FE == :ELECTERRAIN) && !(user.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
      recoilmultiplier = move.recoil
      recoilmultiplier = 0.25 if move.move == :WAVECRASH && (@battle.FE == :WATERSURFACE || @battle.FE == :UNDERWATER)
      recoildamage = [1, (damage * recoilmultiplier).floor].max
      user.pbReduceHP(recoildamage)
      @battle.pbDisplay(_INTL("{1} is damaged by the recoil!", user.pbThis))
    end
    if move.recoil > 0 && user.crested == :ORN_RAPIDASH
      recoilmultiplier = move.recoil
      recoilmultiplier = 0.25 if move.move == :WAVECRASH && (@battle.FE == :WATERSURFACE || @battle.FE == :UNDERWATER)
      recoildamage = [1, (damage * recoilmultiplier).floor].max
      user.pbRecoverHP(recoildamage)
      @battle.pbDisplay(_INTL("{1}'s crest has turned recoil damage into health!", user.pbThis))
      
    end
  end
end

##==============##
## Warden Codes ##
##==============##
class PokeBattle_Move_1000 < PokeBattle_Move 
  def pbType(attacker,type=@type)
    type_id = [attacker.moves[0].type,attacker.moves[1].type,attacker.moves[2].type,attacker.moves[3].type]
    if [:ORN_ORIGINALGENESIS,:ORN_ORIGINALGENESIS1,:ORN_ORIGINALGENESIS2,:ORN_ORIGINALGENESIS3].include?(@move)
      type=((@move == :ORN_ORIGINALGENESIS) ? type_id[0] : ((@move == :ORN_ORIGINALGENESIS1) ? type_id[1] : ((@move == :ORN_ORIGINALGENESIS2) ? type_id[2] : ((@move == :ORN_ORIGINALGENESIS3) ? type_id[3] : nil))))
      type=super(attacker,type)
      return type
    else
      return @type
    end
  end

  def pbEffect(attacker, opponent, hitnum = 0, alltargets = nil, showanimation = true)
    moves = [[:ORN_ASTRALTERRAIN,:ORN_ASTRALSTARSTORM],
             [:ORN_ACRLIGHTTERRAIN,:ORN_ARCLIGHTBARRAGE],
             [:ORN_ACOUSTICTERRAIN,:ORN_ACOUSTICOVERLOAD],
             [:ORN_ORIGINALGENESIS,:ORN_ORIGINALGENESIS1,:ORN_ORIGINALGENESIS2,:ORN_ORIGINALGENESIS3]]
    terrain = ((moves[0].include?(@move)) ? [:ASTRAL,"astronomical"] : 
              ((moves[1].include?(@move)) ? [:ARCLIGHT,"brimming with light"] : 
              ((moves[2].include?(@move)) ? [:ACOUSTIC,"acoustic"] : 
              ((moves[3].include?(@move)) ? [:ORIGIN, "filled with creation energy"] : nil))))
    if terrain != nil
      zmove = [moves[0][1],moves[1][1],moves[2][1],moves[3][0],moves[3][1],moves[3][2],moves[3][3]]
      duration = ((zmove.include?(@move)) ? 50 : ((attacker.hasWorkingItem(:AMPLIFIELDROCK)) ? 8 : 5))
      @battle.setField(terrain[0], duration)
      @battle.pbDisplay(_INTL("The terrain became {1}!",terrain[1]))
      ret = super(attacker, opponent, hitnum, alltargets, showanimation)
      return ret
    else
      ret = super(attacker, opponent, hitnum, alltargets, showanimation)
      @battle.pbDisplay(_INTL("But it failed"))
    end
  end
end

class PokeBattle_Move_1001 < PokeBattle_Move # AlwaysHitsInSandstorm < Battle::Move
  def pbAccuracyCheck(attacker, opponent, precheckedacc: nil)
    return true if @battle.weather == :SANDSTORM
  end
end

class PokeBattle_Move_1002 < PokeBattle_Move # ExtendWeatherTerrainIfTargetFaints < Battle::Move
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    if opponent.isFainted?
      if @battle.weatherduration > 0
        @battle.weatherduration += 1
        @battle.pbDisplay(_INTL("The weather's duration has been extended for an extra turn!"))
      end
      if @battle.field.duration > 0
        @battle.field.duration += 1
        @battle.pbDisplay(_INTL("The terrain's duration has been extended for an extra turn!"))
      end
    end
    return super(attacker,opponent,hitnum,alltargets,showanimation)
  end
end

class PokeBattle_Move_1003 < PokeBattle_Move #ExtraPowerIfEvasion < Battle::Move
  def pbBaseDamage(basedmg,attacker,opponent)
    if opponent.stages[PBStats::EVASION] > 0
      return basedmg*1.5
    end
    return basedmg
  end
end

class PokeBattle_Move_1004 < PokeBattle_Move # HealUserByHalfOfDamageDoneIfTargetAsleep < Battle::Move
  def pbBaseDamage(basedmg,attacker,opponent)
    return basedmg*2 if opponent.status==:SLEEP
    return basedmg
  end

  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    damage = super(attacker,opponent,hitnum,alltargets,showanimation)
    br_effect = (attacker.hasWorkingItem(:BIGROOT) || attacker.crested==:ORN_MEGANIUM) ? true : false
    if opponent.damagestate.calcdamage>0
      hpgain = ((damage + 1) / 2).floor
      if (opponent.ability == :LIQUIDOOZE)
        hpgain*=2 if @battle.FE == :WASTELAND || @battle.FE == :MURKWATERSURFACE || @battle.FE == :CORRUPTED
        attacker.pbReduceHP(hpgain,true)
        @battle.pbDisplay(_INTL("{1} sucked up the liquid ooze!",attacker.pbThis))
      else
        if Rejuv && @battle.FE == :GRASSY
          hpgain=(hpgain*1.6).floor if br_effect
        else
          hpgain=(hpgain*1.3).floor if br_effect
        end
        attacker.pbRecoverHP(hpgain,true)
        @battle.pbDisplay(_INTL("{1} had its energy drained!",opponent.pbThis))
      end
    end
    return damage
  end
end

class PokeBattle_Move_1005 < PokeBattle_Move # InflictRandomStatus < Battle::Move
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
      rnd=@battle.pbRandom(13)
      case rnd
        when 0, 1, 2
          return false if !opponent.pbCanBurn?(false)
          opponent.pbBurn(attacker)
          @battle.pbDisplay(_INTL("{1} was burned!",opponent.pbThis))
        when 3
          return false if !opponent.pbCanFreeze?(false)
          opponent.pbFreeze
          @battle.pbDisplay(_INTL("{1} was frozen solid!",opponent.pbThis))
        when 4, 5, 6
          return false if !opponent.pbCanParalyze?(false)
          opponent.pbParalyze(attacker)
          @battle.pbDisplay(_INTL("{1} is paralyzed! It may be unable to move!",opponent.pbThis))
        when 7, 8, 9, 10
          return false if !opponent.pbCanPoison?(false)
          opponent.pbPoison(attacker)
          @battle.pbDisplay(_INTL("{1} was poisoned!",opponent.pbThis))
        when 11, 12
          return false if !opponent.pbCanSleep?(false)
          opponent.pbSleep
          @battle.pbDisplay(_INTL("{1} fell asleep!",opponent.pbThis))
      end
  end
end

class PokeBattle_Move_1006 < PokeBattle_Move # LowerTargetDefSpDef1 < Battle::Move::TargetMultiStatDownMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    ret=-1; prevented=false
    if opponent.effects[:Protect] && !opponent.effects[:ProtectNegation]
      @battle.pbDisplay(_INTL("{1} protected itself!",opponent.pbThis))
      prevented=true
    end
    if !prevented && opponent.pbOwnSide.effects[:Mist]>0
      @battle.pbDisplay(_INTL("{1} is protected by Mist!",opponent.pbThis))
      prevented=true
    end
    if !prevented && ((((opponent.ability == :CLEARBODY) ||
       (opponent.ability == :WHITESMOKE)) && !(opponent.moldbroken)) || opponent.ability == :FULLMETALBODY)
      @battle.pbDisplay(_INTL("{1}'s {2} prevents stat loss!",opponent.pbThis,
         getAbilityName(opponent.ability)))
      prevented=true
    end
    if !prevented && opponent.pbTooLow?(PBStats::DEFENSE) &&
       opponent.pbTooLow?(PBStats::SPDEF)
      @battle.pbDisplay(_INTL("{1}'s stats won't go any lower!",opponent.pbThis))
      prevented=true
    end
    if !prevented
      pbShowAnimation(@move,attacker,opponent,hitnum,alltargets,showanimation)
      showanim=true
      if (@battle.FE == :FAIRYTALE || @battle.FE == :DRAGONSDEN)  && (@move == :NOBLEROAR)
        if opponent.pbReduceStat(PBStats::DEFENSE,2,false, statdropper: attacker)
          ret=0; showanim=false
        end
        if opponent.pbReduceStat(PBStats::SPDEF,2,false, statdropper: attacker)
          ret=0; showanim=false
        end
      else
        if opponent.pbReduceStat(PBStats::DEFENSE,1,false, statdropper: attacker)
          ret=0; showanim=false
        end
        if opponent.pbReduceStat(PBStats::SPDEF,1,false, statdropper: attacker)
          ret=0; showanim=false
        end
      end
    end
    return ret
  end
end

class PokeBattle_Move_1006 < PokeBattle_Move # LowerTargetDefSpDef1 < Battle::Move::TargetMultiStatDownMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    ret=-1; prevented=false
    if opponent.effects[:Protect] && !opponent.effects[:ProtectNegation]
      @battle.pbDisplay(_INTL("{1} protected itself!",opponent.pbThis))
      prevented=true
    end
    if !prevented && opponent.pbOwnSide.effects[:Mist]>0
      @battle.pbDisplay(_INTL("{1} is protected by Mist!",opponent.pbThis))
      prevented=true
    end
    if !prevented && ((((opponent.ability == :CLEARBODY) ||
       (opponent.ability == :WHITESMOKE)) && !(opponent.moldbroken)) || opponent.ability == :FULLMETALBODY)
      @battle.pbDisplay(_INTL("{1}'s {2} prevents stat loss!",opponent.pbThis,
         getAbilityName(opponent.ability)))
      prevented=true
    end
    if !prevented && opponent.pbTooLow?(PBStats::DEFENSE) &&
       opponent.pbTooLow?(PBStats::SPDEF)
      @battle.pbDisplay(_INTL("{1}'s stats won't go any lower!",opponent.pbThis))
      prevented=true
    end
    if !prevented
      pbShowAnimation(@move,attacker,opponent,hitnum,alltargets,showanimation)
      showanim=true
      if (@battle.FE == :FAIRYTALE || @battle.FE == :DRAGONSDEN)  && (@move == :NOBLEROAR)
        if opponent.pbReduceStat(PBStats::DEFENSE,2,false, statdropper: attacker)
          ret=0; showanim=false
        end
        if opponent.pbReduceStat(PBStats::SPDEF,2,false, statdropper: attacker)
          ret=0; showanim=false
        end
      else
        if opponent.pbReduceStat(PBStats::DEFENSE,1,false, statdropper: attacker)
          ret=0; showanim=false
        end
        if opponent.pbReduceStat(PBStats::SPDEF,1,false, statdropper: attacker)
          ret=0; showanim=false
        end
      end
    end
    return ret
  end
end

class PokeBattle_Move_1007 < PokeBattle_Move # LowerTargetDefSpDef1SwitchOutUser < Battle::Move::TargetMultiStatDownMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    ret=super(attacker,opponent,hitnum,alltargets,showanimation)
    if @battle.FE == :FROZENDIMENSION
      if opponent.pbTooLow?(PBStats::DEFENSE) && opponent.pbTooLow?(PBStats::SPDEF) && opponent.pbTooLow?(PBStats::SPEED)
        @battle.pbDisplay(_INTL("{1}'s stats won't go any lower!",opponent.pbThis))
        return -1
      end
    else
      if opponent.pbTooLow?(PBStats::DEFENSE) && opponent.pbTooLow?(PBStats::SPDEF)
        @battle.pbDisplay(_INTL("{1}'s stats won't go any lower!",opponent.pbThis))
        return -1
      end
    end
    if opponent.pbOwnSide.effects[:Mist]>0
      @battle.pbDisplay(_INTL("{1} is protected by Mist!",opponent.pbThis))
      return -1
    end
    if (((opponent.ability == :CLEARBODY) ||
       (opponent.ability == :WHITESMOKE)) && !(opponent.moldbroken)) || opponent.ability == :FULLMETALBODY
      @battle.pbDisplay(_INTL("{1}'s {2} prevents stat loss!",opponent.pbThis,getAbilityName(opponent.ability)))
      return -1
    end
    pbShowAnimation(@move,attacker,opponent,hitnum,alltargets,showanimation)
    ret=-1; showanim=true
    statdrop = 1
    statdrop = 2 if (@battle.ProgressiveFieldCheck(PBFields::CONCERT) || @battle.FE == :BACKALLEY)
    if opponent.pbReduceStat(PBStats::DEFENSE,statdrop,false, statdropper: attacker)
      ret=0; showanim=false
    end
    if opponent.pbReduceStat(PBStats::SPDEF,statdrop,false, statdropper: attacker)
      ret=0; showanim=false
    end
    if @battle.FE == :FROZENDIMENSION
      if opponent.pbReduceStat(PBStats::SPEED,1,false, statdropper: attacker)
        ret=0; showanim=false
      end
    end
    if attacker.hp>0 && @battle.pbCanChooseNonActive?(attacker.index) && !@battle.pbAllFainted?(@battle.pbParty(opponent.index)) && @battle.FE != :COLOSSEUM
      @battle.pbDisplay(_INTL("{1} went back to {2}!",attacker.pbThis,@battle.pbGetOwner(attacker.index).name))
      #Going to switch, check for pursuit
      newpoke=0
      newpoke=@battle.pbSwitchInBetween(attacker.index,true,false)
      for j in @battle.priority
        next if !attacker.pbIsOpposing?(j.index)
        # if Pursuit and this target was chosen
        if !j.hasMovedThisRound? && @battle.pbChoseMoveFunctionCode?(j.index,0x88) && !j.effects[:Pursuit] && (@battle.choices[j.index][3]!=j.pbPartner.index)
          attacker.vanished=false
          @battle.pbCommonAnimation("Fade in",attacker,nil)
          @battle.pbPursuitInterrupt(j,attacker)
        end
        break if attacker.isFainted?
      end
      @battle.pbMessagesOnReplace(attacker.index,newpoke)
      attacker.pbResetForm
      @battle.pbClearChoices(attacker.index) if attacker.effects[:MagicBounced]
      @battle.pbReplace(attacker.index,newpoke)
      @battle.pbOnActiveOne(attacker)
      attacker.pbAbilitiesOnSwitchIn(true)
    else
      attacker.vanished=false
      @battle.pbCommonAnimation("Fade in",attacker,nil)
    end
    return ret
  end
end

class PokeBattle_Move_1008 < PokeBattle_Move # LowerTargetMainStats1 < Battle::Move::TargetMultiStatDownMove
  def pbAdditionalEffect(attacker,opponent)
    for stat in 1..5
      if attacker.pbCanReduceStatStage?(stat,false)
        attacker.pbReduceStat(stat,1)
      end
    end
    return true
  end
end

class PokeBattle_Move_1009 < PokeBattle_Move # LowerTargetSpAtkSpDef1 < Battle::Move::TargetMultiStatDownMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    ret=-1; prevented=false
    if opponent.effects[:Protect] && !opponent.effects[:ProtectNegation]
      @battle.pbDisplay(_INTL("{1} protected itself!",opponent.pbThis))
      prevented=true
    end
    if !prevented && opponent.pbOwnSide.effects[:Mist]>0
      @battle.pbDisplay(_INTL("{1} is protected by Mist!",opponent.pbThis))
      prevented=true
    end
    if !prevented && ((((opponent.ability == :CLEARBODY) ||
       (opponent.ability == :WHITESMOKE)) && !(opponent.moldbroken)) || opponent.ability == :FULLMETALBODY)
      @battle.pbDisplay(_INTL("{1}'s {2} prevents stat loss!",opponent.pbThis,
         getAbilityName(opponent.ability)))
      prevented=true
    end
    if !prevented && opponent.pbTooLow?(PBStats::SPATK) &&
       opponent.pbTooLow?(PBStats::SPDEF)
      @battle.pbDisplay(_INTL("{1}'s stats won't go any lower!",opponent.pbThis))
      prevented=true
    end
    if !prevented
      pbShowAnimation(@move,attacker,opponent,hitnum,alltargets,showanimation)
      showanim=true
      if (@battle.FE == :FAIRYTALE || @battle.FE == :DRAGONSDEN)  && (@move == :NOBLEROAR)
        if opponent.pbReduceStat(PBStats::SPATK,2,false, statdropper: attacker)
          ret=0; showanim=false
        end
        if opponent.pbReduceStat(PBStats::SPDEF,2,false, statdropper: attacker)
          ret=0; showanim=false
        end
      else
        if opponent.pbReduceStat(PBStats::SPATK,1,false, statdropper: attacker)
          ret=0; showanim=false
        end
        if opponent.pbReduceStat(PBStats::SPDEF,1,false, statdropper: attacker)
          ret=0; showanim=false
        end
      end
    end
    return ret
  end
end

class PokeBattle_Move_100A < PokeBattle_Move # LowerUserAtkSpd1 < Battle::Move::StatDownMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    ret=super(attacker,opponent,hitnum,alltargets,showanimation)
    if opponent.damagestate.calcdamage>0
      for stat in [PBStats::ATTACK,PBStats::SOEED]
        if attacker.pbCanReduceStatStage?(stat,false,true)
          attacker.pbReduceStat(stat,1,false, statdropper: attacker)
        end
      end
    end
    return ret
  end
end

class PokeBattle_Move_100B < PokeBattle_Move # LowerUserAttack2 < Battle::Move::StatDownMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    ret=super(attacker,opponent,hitnum,alltargets,showanimation)
    if opponent.damagestate.calcdamage>0
      if attacker.pbCanReduceStatStage?(PBStats::ATTACK,false,true)
        attacker.pbReduceStat(PBStats::ATTACK,2,false, statdropper: attacker)
      end
    end
    return ret
  end
end

class PokeBattle_Move_100C < PokeBattle_Move # MaxUserSpecialAttackLoseHalfOfTotalHP < Battle::Move
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    showanim=showanimation
    if attacker.hp<=(attacker.totalhp/2.0).floor || !attacker.pbCanIncreaseStatStage?(PBStats::ATTACK,false)
      @battle.pbDisplay(_INTL("But it failed!"))
      return -1
    end
    pbShowAnimation(@move,attacker,nil,hitnum,alltargets,showanimation)
    attacker.pbReduceHP((attacker.totalhp/2.0).floor, false, false)
    attacker.stages[PBStats::SPATK]=6
    @battle.pbCommonAnimation("StatUp",attacker,nil)
    @battle.pbDisplay(_INTL("{1} cut its own HP and maximized its Special Attack!",attacker.pbThis))
    if @battle.FE == :BIGTOP
       if attacker.pbCanIncreaseStatStage?(PBStats::DEFENSE,false)
        attacker.pbIncreaseStat(PBStats::DEFENSE,1,false)
        attacker.effects[:StockpileDef]+=1
      end
      if attacker.pbCanIncreaseStatStage?(PBStats::SPDEF,false)
        attacker.pbIncreaseStat(PBStats::SPDEF,1,false)
        attacker.effects[:StockpileSpDef]+=1
      end
    end
    return 0
  end
end

class PokeBattle_Move_100D < PokeBattle_Move # RaiseMinMaxStat1 < Battle::Move
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    if attacker.index!=opponent.index && opponent.effects[:Substitute]>0
      @battle.pbDisplay(_INTL("{1}'s attack missed!",attacker.pbThis))
      return -1
    end
    array=[]
    for i in [PBStats::ATTACK,PBStats::DEFENSE,PBStats::SPEED,
              PBStats::SPATK,PBStats::SPDEF,PBStats::ACCURACY,PBStats::EVASION]
      array.push(i) if opponent.pbCanIncreaseStatStage?(i)
    end
    if array.length==0
      @battle.pbDisplay(_INTL("{1}'s stats won't go any higher!",opponent.pbThis))
      return -1
    end
    stat=array[@battle.pbRandom(array.length)]
    pbShowAnimation(@move,attacker,opponent,hitnum,alltargets,showanimation)
    ret=opponent.pbIncreaseStat(stat,1,false)
    return 0
  end
end

class PokeBattle_Move_100E < PokeBattle_Move # RaisePlusMinusUserAndAlliesAtkSpAtk1 < Battle::Move
  def pbEffect(attacker, opponent, hitnum = 0, alltargets = nil, showanimation = true)
    if ([:ELECTRIC, :STEEL].include?(attacker.pbPartner.type1) || [:ELECTRIC, :STEEL].include?(attacker.pbPartner.type2))
      partnerfail = false
      if attacker.pbPartner.pbCanIncreaseStatStage?(PBStats::ATTACK, false) || attacker.pbPartner.pbCanIncreaseStatStage?(PBStats::SPATK, false)
        pbShowAnimation(@move, attacker, nil, hitnum, alltargets, showanimation)
        statboost = 1
        statboost = 2 if @battle.FE == :FACTORY
        attacker.pbPartner.pbIncreaseStat(PBStats::ATTACK, statboost, abilitymessage: false, statsource: attacker)
        attacker.pbPartner.pbIncreaseStat(PBStats::SPATK, statboost, abilitymessage: false, statsource: attacker)
      else # partner cannot increase stats, check next attacker
        @battle.pbDisplay(_INTL("{1}'s stats won't go any higher!", attacker.pbPartner.pbThis))
      end
    else
      # partner does not have Plus/Minus
      partnerfail = true
    end
    if ([:ELECTRIC, :STEEL].include?(attacker.type1) || [:ELECTRIC, :STEEL].include?(attacker.type2))
      if attacker.pbCanIncreaseStatStage?(PBStats::ATTACK, false) || attacker.pbCanIncreaseStatStage?(PBStats::SPATK, false)
        pbShowAnimation(@move, attacker, nil, hitnum, alltargets, partnerfail)
        statboost = 1
        statboost = 2 if @battle.FE == :FACTORY
        attacker.pbIncreaseStat(PBStats::ATTACK, statboost, abilitymessage: false, statsource: attacker)
        attacker.pbIncreaseStat(PBStats::SPATK, statboost, abilitymessage: false, statsource: attacker)
      else # attacker cannot increase stats
        @battle.pbDisplay(_INTL("{1}'s stats won't go any higher!", attacker.pbThis))
      end
    else
      # attacker does not have Plus/Minus
      if partnerfail
        @battle.pbDisplay(_INTL("But it failed!"))
        return -1
      end
    end

    return 0
  end
end

class PokeBattle_Move_100F < PokeBattle_Move # RaisePlusMinusUserAndAlliesDefSpDef1 < Battle::Move
  def pbEffect(attacker, opponent, hitnum = 0, alltargets = nil, showanimation = true)
    if ([:ELECTRIC, :STEEL].include?(attacker.pbPartner.type1) || [:ELECTRIC, :STEEL].include?(attacker.pbPartner.type2)) || (Rejuv && @battle.FE == :ELECTERRAIN)
      partnerfail = false
      if attacker.pbPartner.pbCanIncreaseStatStage?(PBStats::DEFENSE, false) || attacker.pbPartner.pbCanIncreaseStatStage?(PBStats::SPDEF, false)
        pbShowAnimation(@move, attacker, nil, hitnum, alltargets, showanimation)
        statboost = 1
        statboost = 2 if @battle.FE == :DEEPEARTH || (Rejuv && @battle.FE == :ELECTERRAIN && ([:ELECTRIC, :STEEL].include?(attacker.pbPartner.type1) || [:ELECTRIC, :STEEL].include?(attacker.pbPartner.type2)))
        attacker.pbPartner.pbIncreaseStat(PBStats::DEFENSE, statboost, abilitymessage: false, statsource: attacker)
        attacker.pbPartner.pbIncreaseStat(PBStats::SPDEF, statboost, abilitymessage: false, statsource: attacker)
      else # partner cannot increase stats, check next attacker
        @battle.pbDisplay(_INTL("{1}'s stats won't go any higher!", attacker.pbPartner.pbThis))
      end
    else
      # partner does not have Plus/Minus
      partnerfail = true
    end
    if ([:ELECTRIC, :STEEL].include?(attacker.type1) || [:ELECTRIC, :STEEL].include?(attacker.type2)) || (Rejuv && @battle.FE == :ELECTERRAIN)
      if attacker.pbCanIncreaseStatStage?(PBStats::DEFENSE, false) || attacker.pbCanIncreaseStatStage?(PBStats::SPDEF, false)
        pbShowAnimation(@move, attacker, nil, hitnum, alltargets, partnerfail)
        statboost = 1
        statboost = 2 if @battle.FE == :DEEPEARTH || (Rejuv && @battle.FE == :ELECTERRAIN && ([:ELECTRIC, :STEEL].include?(attacker.type1) || [:ELECTRIC, :STEEL].include?(attacker.type2)))
        attacker.pbIncreaseStat(PBStats::DEFENSE, statboost, abilitymessage: false, statsource: attacker)
        attacker.pbIncreaseStat(PBStats::SPDEF, statboost, abilitymessage: false, statsource: attacker)
      else # attacker cannot increase stats
        @battle.pbDisplay(_INTL("{1}'s stats won't go any higher!", attacker.pbThis))
      end
    else
      # attacker does not have Plus/Minus
      if partnerfail
        @battle.pbDisplay(_INTL("But it failed!"))
        return -1
      end
    end
    return 0
  end
end

class PokeBattle_Move_1010 < PokeBattle_Move # RaiseUserAtkSpAtkSpd1 < Battle::Move::MultiStatUpMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    if !attacker.pbCanIncreaseStatStage?(PBStats::ATTACK,false) &&
       !attacker.pbCanIncreaseStatStage?(PBStats::SPATK,false) &&
       !attacker.pbCanIncreaseStatStage?(PBStats::SPEED,false)
      @battle.pbDisplay(_INTL("{1}'s stats won't go any higher!",attacker.pbThis))
      return -1
    end
    pbShowAnimation(@move,attacker,nil,hitnum,alltargets,showanimation)
    boost_amount=1
    if ((@battle.FE == :MISTY || @battle.FE == :RAINBOW || @battle.FE == :HOLY ||
      @battle.FE == :STARLIGHT || @battle.FE == :NEWWORLD || @battle.FE == :PSYTERRAIN) &&
      (@move == :COSMICPOWER)) || (@battle.FE == :FOREST && (@move == :DEFENDORDER))
      boost_amount=2
    end
    for stat in [PBStats::ATTACK,PBStats::SPATK,PBStats::SPEED]
      if attacker.pbCanIncreaseStatStage?(stat,false)
        attacker.pbIncreaseStat(stat,boost_amount,false)
      end
    end
    return 0
  end
end

class PokeBattle_Move_1011 < PokeBattle_Move # RaiseUserAtkSpDef1 < Battle::Move::MultiStatUpMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    if !attacker.pbCanIncreaseStatStage?(PBStats::ATTACK,false) &&
       !attacker.pbCanIncreaseStatStage?(PBStats::SPDEF,false)
      @battle.pbDisplay(_INTL("{1}'s stats won't go any higher!",attacker.pbThis))
      return -1
    end
    pbShowAnimation(@move,attacker,nil,hitnum,alltargets,showanimation)
    boost_amount=1
    if ((@battle.FE == :MISTY || @battle.FE == :RAINBOW || @battle.FE == :HOLY ||
      @battle.FE == :STARLIGHT || @battle.FE == :NEWWORLD || @battle.FE == :PSYTERRAIN) &&
      (@move == :COSMICPOWER)) || (@battle.FE == :FOREST && (@move == :DEFENDORDER))
      boost_amount=2
    end
    for stat in [PBStats::ATTACK,PBStats::SPDEF]
      if attacker.pbCanIncreaseStatStage?(stat,false)
        attacker.pbIncreaseStat(stat,boost_amount,false)
      end
    end
    return 0
  end
end

class PokeBattle_Move_1012 < PokeBattle_Move # RaiseUserDefSpDef1Ingrain < Battle::Move::MultiStatUpMove
  def pbTwoTurnAttack(attacker)
    @immediate=false
    if @battle.FE == :STARLIGHT || @battle.FE == :DEEPEARTH
      @immediate=true
      @battle.pbDisplay(_INTL("{1} absorbed the starlight!",attacker.pbThis)) if @battle.FE == :STARLIGHT
    elsif !@immediate && attacker.hasWorkingItem(:POWERHERB)
      itemname=getItemName(attacker.item)
      @immediate=true
      attacker.pbDisposeItem(false)
      @battle.pbDisplay(_INTL("{1} consumed its {2}!",attacker.pbThis,itemname))
    end
    return false if @immediate
    return attacker.effects[:TwoTurnAttack]==0
  end

  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    if @immediate || attacker.effects[:TwoTurnAttack]!=0
      @battle.pbCommonAnimation("Geomancy",attacker)
      @battle.pbDisplay(_INTL("{1} became one with nature!",attacker.pbThis))
    end
    if attacker.effects[:TwoTurnAttack]==0
      @battle.pbAnimation(@move,attacker,opponent,hitnum)
      for stat in [PBStats::SPATK,PBStats::SPDEF]
        if attacker.pbCanIncreaseStatStage?(stat,false)
          attacker.pbIncreaseStat(stat,1)
          attacker.effects[:Ingrain]=true
        end
      end
    end
    return 0 if attacker.effects[:TwoTurnAttack]!=0
    return super
  end
end

class PokeBattle_Move_1013 < PokeBattle_Move # RaiseUserSpAtk2IfTargetFaints < Battle::Move
  def pbAdditionalEffect(attacker,opponent)
    attacker.pbIncreaseStat(PBStats::SPATK,3,false) if opponent.isFainted? && attacker.pbCanIncreaseStatStage?(PBStats::SPATK,false)
  end
end

class PokeBattle_Move_1014 < PokeBattle_Move # RaiseUserSpAtkAcc1 < Battle::Move::MultiStatUpMove
  def pbEffect(attacker, opponent, hitnum = 0, alltargets = nil, showanimation = true)
    if !attacker.pbCanIncreaseStatStage?(PBStats::SPATK, false) &&
       !attacker.pbCanIncreaseStatStage?(PBStats::ACCURACY, false)
      @battle.pbDisplay(_INTL("{1}'s stats won't go any higher!", attacker.pbThis))
      return -1
    end
    pbShowAnimation(@move, attacker, nil, hitnum, alltargets, showanimation)
    boost_amount = 1
    for stat in [PBStats::SPATK, PBStats::ACCURACY]
      attacker.pbIncreaseStat(stat, boost_amount, abilitymessage: false, statsource: attacker)
    end
    return 0
  end
end

class PokeBattle_Move_1015 < PokeBattle_Move # RaiseUserSpAtkSpd1 < Battle::Move::MultiStatUpMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    if !attacker.pbCanIncreaseStatStage?(PBStats::SPATK,false) &&
       !attacker.pbCanIncreaseStatStage?(PBStats::SPEED,false)
      @battle.pbDisplay(_INTL("{1}'s stats won't go any higher!",attacker.pbThis))
      return -1
    end
    pbShowAnimation(@move,attacker,nil,hitnum,alltargets,showanimation)
    boost_amount=1
    if ((@battle.FE == :MISTY || @battle.FE == :RAINBOW || @battle.FE == :HOLY ||
      @battle.FE == :STARLIGHT || @battle.FE == :NEWWORLD || @battle.FE == :PSYTERRAIN) &&
      (@move == :COSMICPOWER)) || (@battle.FE == :FOREST && (@move == :DEFENDORDER))
      boost_amount=2
    end
    for stat in [PBStats::SPATK,PBStats::SPEED]
      if attacker.pbCanIncreaseStatStage?(stat,false)
        attacker.pbIncreaseStat(stat,boost_amount,false)
      end
    end
    return 0
  end
end

class PokeBattle_Move_1016 < PokeBattle_Move # RaiseUserSpDef1 < Battle::Move::StatUpMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    return super(attacker,opponent,hitnum,alltargets,showanimation) if @basedamage>0
    return -1 if !attacker.pbCanIncreaseStatStage?(PBStats::SPDEF,true)
    pbShowAnimation(@move,attacker,opponent,hitnum,alltargets,showanimation)
    ret=attacker.pbIncreaseStat(PBStats::SPDEF,1,false)
    return ret ? 0 : -1
  end

  def pbAdditionalEffect(attacker,opponent)
    increment = 1
    increment = 2 if @battle.FE == :PSYTERRAIN && @move == :MYSTICALPOWER
    if attacker.pbCanIncreaseStatStage?(PBStats::SPDEF,false)
      attacker.pbIncreaseStat(PBStats::SPDEF,increment,false)
    end
    return true
  end
end

class PokeBattle_Move_1017 < PokeBattle_Move
  def pbEffect(attacker, opponent, hitnum = 0, alltargets = nil, showanimation = true)
    return super(attacker, opponent, hitnum, alltargets, showanimation) if @basedamage > 0
    return -1 if !attacker.pbCanIncreaseStatStage?(PBStats::SPDEF, true)

    pbShowAnimation(@move, attacker, opponent, hitnum, alltargets, showanimation)
    ret = attacker.pbIncreaseStat(PBStats::SPDEF, 3, abilitymessage: false)
    return ret ? 0 : -1
  end

  def pbAdditionalEffect(attacker, opponent)
    attacker.pbIncreaseStat(PBStats::SPDEF, 3, abilitymessage: false, statsource: attacker)
    return true
  end
end

class PokeBattle_Move_1018 < PokeBattle_Move # SetTargetTypesToFairy < Battle::Move
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    if opponent.effects[:Substitute]>0
      @battle.pbDisplay(_INTL("But it failed!"))
      return -1
    end
    if (opponent.ability == :MULTITYPE) ||
      (opponent.ability == :RKSSYSTEM) || attacker.crested == :SILVALLY
      @battle.pbDisplay(_INTL("But it failed!"))
      return -1
    end
    pbShowAnimation(@move,attacker,opponent,hitnum,alltargets,showanimation)
    opponent.type1=(:FAIRY)
    opponent.type2=nil
    typename=getTypeName((:FAIRY))
    @battle.pbDisplay(_INTL("{1} transformed into the {2} type!",opponent.pbThis,typename))
    return 0
  end
end

class PokeBattle_Move_1019 < PokeBattle_Move # SleepTargetSuperEffectiveAgainstFairy < Battle::Move
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    return super(attacker,opponent,hitnum,alltargets,showanimation) if @basedamage>0
    return -1 if !opponent.pbCanSleep?(true)
    pbShowAnimation(@move,attacker,opponent,hitnum,alltargets,showanimation)
    opponent.pbSleep
    @battle.pbDisplay(_INTL("{1} went to sleep!",opponent.pbThis))
    return 0
  end

  def pbAdditionalEffect(attacker,opponent)
    if opponent.pbCanSleep?(false)
      opponent.pbSleep
      @battle.pbDisplay(_INTL("{1} went to sleep!",opponent.pbThis))
      return true
    end
    return false
  end
end

class PokeBattle_Move_101A < PokeBattle_Move # StartWeakenLightMoves < Battle::Move
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    if @battle.state.effects[:Blackout]>0
      @battle.pbDisplay(_INTL("But it failed!"))
      return -1
    end
    pbShowAnimation(@move,attacker,opponent,hitnum,alltargets,showanimation)
    @battle.state.effects[:Blackout]=5
    @battle.pbDisplay(_INTL("Light's power was weakened!"))
    return 0
  end
end

class PokeBattle_Move_101B < PokeBattle_Move # StealStatsAndPassToAlly < Battle::Move
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    totalboost = 0
    if pbTypeModifier(@type,attacker,opponent) != 0
      for i in [PBStats::ATTACK,PBStats::DEFENSE,PBStats::SPEED,
                PBStats::SPATK,PBStats::SPDEF,PBStats::ACCURACY,PBStats::EVASION]
        if opponent.stages[i]>0
          oppboost = opponent.stages[i]
          oppboost *= -1 if attacker.ability == :CONTRARY
          oppboost *= 2 if attacker.ability == :SIMPLE
          attacker.stages[i]+=oppboost
          attacker.stages[i] = attacker.stages[i].clamp(-6, 6)
          totalboost += oppboost
          opponent.stages[i]=0
        end
      end
    end
    if totalboost>0
      @battle.pbCommonAnimation("StatUp",attacker,nil)
      @battle.pbDisplay(_INTL("{1} stole {2}'s stat boosts!",attacker.pbThis,opponent.pbThis))
    end
    if !@battle.pbCanChooseNonActive?(attacker.index)
      @battle.pbDisplay(_INTL("But it failed!"))
      return -1
    end
    newpoke=0
    pbShowAnimation(@move,attacker,nil,hitnum,alltargets,showanimation)
    newpoke=@battle.pbSwitchInBetween(attacker.index,true,false)
    @battle.pbMessagesOnReplace(attacker.index,newpoke)
    attacker.pbResetForm
    @battle.pbReplace(attacker.index,newpoke,true)
    @battle.pbOnActiveOne(attacker)
    attacker.pbAbilitiesOnSwitchIn(true)
    return super(attacker,opponent,hitnum,alltargets,showanimation)
  end
end

class PokeBattle_Move_101C < PokeBattle_Move # SuperEffectiveAgainstRock < Battle::Move
  # Handled in superclass
end

class PokeBattle_Move_101D < PokeBattle_Move # SuperEffectiveAgainstBug < Battle::Move
  # Handled in superclass
end

class PokeBattle_Move_101E < PokeBattle_Move # SuperEffectiveAgainstGhost < Battle::Move
  # Handled in superclass
end

class PokeBattle_Move_101F < PokeBattle_Move # SuperEffectiveAgainstSteel < Battle::Move
  # Handled in superclass
end

class PokeBattle_Move_1020 < PokeBattle_Move # SuperEffectiveAgainstPsychic < Battle::Move
  # Handled in superclass
end

class PokeBattle_Move_1021 < PokeBattle_Move # SuperEffectiveAgainstCosmic < Battle::Move
  # Handled in superclass
end

class PokeBattle_Move_1022 < PokeBattle_Move # SuperEffectiveAgainstWater < Battle::Move
  # Handled in superclass
end

class PokeBattle_Move_1023 < PokeBattle_Move # GlitchMove < Battle::Move
  # Handled in superclass
end

class PokeBattle_Move_1024 < PokeBattle_Move # UseTargetSpDefInsteadOfTargetDefense < Battle::Move
  # Handled in superclass, do not edit!

  def pbGetDefenseStats(user, target)
    return target.spdef, target.stages[:SPECIAL_DEFENSE] + 6
  end
end
