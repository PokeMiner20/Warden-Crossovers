class PokeBattle_Move_086 < PokeBattle_Move # Power is doubled if the user has no held item. (Acrobatics)
  def pbBaseDamage(basedmg,attacker,opponent)
    movetype = pbType(attacker)
    gem = false
    if attacker.itemWorks?
      case attacker.item
        when :NORMALGEM     then gem = true if movetype == :NORMAL
        when :FIGHTINGGEM   then gem = true if movetype == :FIGHTING
        when :FLYINGGEM     then gem = true if movetype == :FLYING
        when :POISONGEM     then gem = true if movetype == :POISON
        when :GROUNDGEM     then gem = true if movetype == :GROUND
        when :ROCKGEM       then gem = true if movetype == :ROCK
        when :BUGGEM        then gem = true if movetype == :BUG
        when :GHOSTGEM      then gem = true if movetype == :GHOST
        when :STEELGEM      then gem = true if movetype == :STEEL
        when :FIREGEM       then gem = true if movetype == :FIRE
        when :WATERGEM      then gem = true if movetype == :WATER
        when :GRASSGEM      then gem = true if movetype == :GRASS
        when :ELECTRICGEM   then gem = true if movetype == :ELECTRIC
        when :PSYCHICGEM    then gem = true if movetype == :PSYCHIC
        when :ICEGEM        then gem = true if movetype == :ICE
        when :DRAGONGEM     then gem = true if movetype == :DRAGON
        when :DARKGEM       then gem = true if movetype == :DARK
        when :FAIRYGEM      then gem = true if movetype == :FAIRY
        when :ORN_COSMICGEM then gem = true if movetype == :COSMIC
        when :ORN_LIGHTGEM  then gem = true if movetype == :LIGHT
        when :ORN_SOUNDGEM  then gem = true if movetype == :SOUND
      end
    end
    return basedmg*2 if attacker.item.nil? || @battle.FE == :BIGTOP || gem
    return basedmg
  end
end

class PokeBattle_Move_134 < PokeBattle_Move # Electric Terrain Updated for Teleface Eiscue
  def pbEffect(attacker, opponent, hitnum = 0, alltargets = nil, showanimation = true)
    if !((!Rejuv && @battle.canChangeFE?(:ELECTERRAIN)) || (@battle.canChangeFE?([:ELECTERRAIN, :DRAGONSDEN]) && !(@battle.state.effects[:ELECTERRAIN] > 0)))
      @battle.pbDisplay(_INTL("But it failed!"))
      return -1
    end
    pbShowAnimation(@move, attacker, opponent, hitnum, alltargets, showanimation)
    duration = 5
    duration = 8 if attacker.hasWorkingItem(:AMPLIFIELDROCK)
    @battle.setField(:ELECTERRAIN, duration)
    @battle.pbDisplay(_INTL("The terrain became electrified!"))

    for facemon in @battle.battlers
      if facemon.species==:ORN_EISCUE && facemon.form==1 # Eiscue
        facemon.pbRegenTele
        @battle.pbDisplay(_INTL("{1} transformed!",facemon.name))
      end
    end
    return 0
  end
end

class PokeBattle_Move_16E < PokeBattle_Move
  def pbEffect(attacker, opponent, hitnum = 0, alltargets = nil, showanimation = true)
    totalboost = 0
    if pbTypeModifier(@type, attacker, opponent) != 0
      for i in [PBStats::ATTACK, PBStats::DEFENSE, PBStats::SPEED, PBStats::SPATK, PBStats::SPDEF, PBStats::ACCURACY, PBStats::EVASION]
        if opponent.stages[i] > 0
          oppboost = opponent.stages[i]
          oppboost *= -1 if attacker.ability == :CONTRARY
          oppboost *= 2 if attacker.ability == :SIMPLE || attacker.crested == :ORN_FERALIGATR
          attacker.stages[i] += oppboost
          attacker.stages[i] = attacker.stages[i].clamp(-6, 6)
          totalboost += oppboost
          opponent.stages[i] = 0
        end
      end
    end
    if totalboost > 0
      @battle.pbCommonAnimation("StatUp", attacker, nil)
      @battle.pbDisplay(_INTL("{1} stole {2}'s stat boosts!", attacker.pbThis, opponent.pbThis))
    end
    return super(attacker, opponent, hitnum, alltargets, showanimation)
  end
end

##==============##
## Warden Codes ##
##==============##
class PokeBattle_Move_1000 < PokeBattle_Move 
  def pbType(attacker,type=@type)
    type_id = [attacker.moves[0].type,attacker.moves[1].type,attacker.moves[2].type,attacker.moves[3].type]
    if [:ORN_ORIGINALGENESIS,:ORN_ORIGINALGENESIS1,:ORN_ORIGINALGENESIS2,:ORN_ORIGINALGENESIS3].include?(@move)
      type=((@move == :ORN_ORIGINALGENESIS) ? type_id[0] : ((@move == :ORN_ORIGINALGENESIS1) ? type_id[1] : ((@move == :ORN_ORIGINALGENESIS2) ? type_id[2] : ((@move == :ORN_ORIGINALGENESIS3) ? type_id[3] : nil))))
      type=super(attacker,type)
      return type
    else
      return @type
    end
  end

  def pbEffect(attacker, opponent, hitnum = 0, alltargets = nil, showanimation = true)
    moves = [[:ORN_ASTRALTERRAIN,:ORN_ASTRALSTARSTORM],
             [:ORN_ACRLIGHTTERRAIN,:ORN_ARCLIGHTBARRAGE],
             [:ORN_ACOUSTICTERRAIN,:ORN_ACOUSTICOVERLOAD],
             [:ORN_ORIGINALGENESIS,:ORN_ORIGINALGENESIS1,:ORN_ORIGINALGENESIS2,:ORN_ORIGINALGENESIS3]]
    terrain = ((moves[0].include?(@move)) ? [:ASTRAL,"astronomical"] : 
              ((moves[1].include?(@move)) ? [:ARCLIGHT,"brimming with light"] : 
              ((moves[2].include?(@move)) ? [:ACOUSTIC,"acoustic"] : 
              ((moves[3].include?(@move)) ? [:ORIGIN, "filled with creation energy"] : nil))))
    if terrain != nil
      zmove = [moves[0][1],moves[1][1],moves[2][1],moves[3][0],moves[3][1],moves[3][2],moves[3][3]]
      duration = ((zmove.include?(@move)) ? 50 : ((attacker.hasWorkingItem(:AMPLIFIELDROCK)) ? 8 : 5))
      @battle.setField(terrain[0], duration)
      @battle.pbDisplay(_INTL("The terrain became {1}!",terrain[1]))
      ret = super(attacker, opponent, hitnum, alltargets, showanimation)
      return ret
    else
      ret = super(attacker, opponent, hitnum, alltargets, showanimation)
      @battle.pbDisplay(_INTL("But it failed"))
    end
  end
end

class PokeBattle_Move_1001 < PokeBattle_Move # AlwaysHitsInSandstorm < Battle::Move
  def pbAccuracyCheck(attacker, opponent, precheckedacc: nil)
    return true if @battle.weather == :SANDSTORM
  end
end

class PokeBattle_Move_1002 < PokeBattle_Move # ExtendWeatherTerrainIfTargetFaints < Battle::Move
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    if opponent.isFainted?
      if @battle.weatherduration > 0
        @battle.weatherduration += 1
        @battle.pbDisplay(_INTL("The weather's duration has been extended for an extra turn!"))
      end
      if @battle.field.duration > 0
        @battle.field.duration += 1
        @battle.pbDisplay(_INTL("The terrain's duration has been extended for an extra turn!"))
      end
    end
    return super(attacker,opponent,hitnum,alltargets,showanimation)
  end
end

class PokeBattle_Move_1003 < PokeBattle_Move #ExtraPowerIfEvasion < Battle::Move
  def pbBaseDamage(basedmg,attacker,opponent)
    if opponent.stages[PBStats::EVASION] > 0
      return basedmg*1.5
    end
    return basedmg
  end
end

class PokeBattle_Move_1004 < PokeBattle_Move # HealUserByHalfOfDamageDoneIfTargetAsleep < Battle::Move
  def pbBaseDamage(basedmg,attacker,opponent)
    return basedmg*2 if opponent.status==:SLEEP
    return basedmg
  end

  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    damage = super(attacker,opponent,hitnum,alltargets,showanimation)
    br_effect = (attacker.hasWorkingItem(:BIGROOT) || attacker.crested==:ORN_MEGANIUM) ? true : false
    if opponent.damagestate.calcdamage>0
      hpgain = ((damage + 1) / 2).floor
      if (opponent.ability == :LIQUIDOOZE)
        hpgain*=2 if @battle.FE == :WASTELAND || @battle.FE == :MURKWATERSURFACE || @battle.FE == :CORRUPTED
        attacker.pbReduceHP(hpgain,true)
        @battle.pbDisplay(_INTL("{1} sucked up the liquid ooze!",attacker.pbThis))
      else
        if Rejuv && @battle.FE == :GRASSY
          hpgain=(hpgain*1.6).floor if br_effect
        else
          hpgain=(hpgain*1.3).floor if br_effect
        end
        attacker.pbRecoverHP(hpgain,true)
        @battle.pbDisplay(_INTL("{1} had its energy drained!",opponent.pbThis))
      end
    end
    return damage
  end
end

class PokeBattle_Move_1005 < PokeBattle_Move # InflictRandomStatus < Battle::Move
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
      rnd=@battle.pbRandom(13)
      case rnd
        when 0, 1, 2
          return false if !opponent.pbCanBurn?(false)
          opponent.pbBurn(attacker)
          @battle.pbDisplay(_INTL("{1} was burned!",opponent.pbThis))
        when 3
          return false if !opponent.pbCanFreeze?(false)
          opponent.pbFreeze
          @battle.pbDisplay(_INTL("{1} was frozen solid!",opponent.pbThis))
        when 4, 5, 6
          return false if !opponent.pbCanParalyze?(false)
          opponent.pbParalyze(attacker)
          @battle.pbDisplay(_INTL("{1} is paralyzed! It may be unable to move!",opponent.pbThis))
        when 7, 8, 9, 10
          return false if !opponent.pbCanPoison?(false)
          opponent.pbPoison(attacker)
          @battle.pbDisplay(_INTL("{1} was poisoned!",opponent.pbThis))
        when 11, 12
          return false if !opponent.pbCanSleep?(false)
          opponent.pbSleep
          @battle.pbDisplay(_INTL("{1} fell asleep!",opponent.pbThis))
      end
  end
end

class PokeBattle_Move_1006 < PokeBattle_Move # LowerTargetDefSpDef1 < Battle::Move::TargetMultiStatDownMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    ret=-1; prevented=false
    if opponent.effects[:Protect] && !opponent.effects[:ProtectNegation]
      @battle.pbDisplay(_INTL("{1} protected itself!",opponent.pbThis))
      prevented=true
    end
    if !prevented && opponent.pbOwnSide.effects[:Mist]>0
      @battle.pbDisplay(_INTL("{1} is protected by Mist!",opponent.pbThis))
      prevented=true
    end
    if !prevented && ((((opponent.ability == :CLEARBODY) ||
       (opponent.ability == :WHITESMOKE)) && !(opponent.moldbroken)) || opponent.ability == :FULLMETALBODY)
      @battle.pbDisplay(_INTL("{1}'s {2} prevents stat loss!",opponent.pbThis,
         getAbilityName(opponent.ability)))
      prevented=true
    end
    if !prevented && opponent.pbTooLow?(PBStats::DEFENSE) &&
       opponent.pbTooLow?(PBStats::SPDEF)
      @battle.pbDisplay(_INTL("{1}'s stats won't go any lower!",opponent.pbThis))
      prevented=true
    end
    if !prevented
      pbShowAnimation(@move,attacker,opponent,hitnum,alltargets,showanimation)
      showanim=true
      if (@battle.FE == :FAIRYTALE || @battle.FE == :DRAGONSDEN)  && (@move == :NOBLEROAR)
        if opponent.pbReduceStat(PBStats::DEFENSE,2,false, statdropper: attacker)
          ret=0; showanim=false
        end
        if opponent.pbReduceStat(PBStats::SPDEF,2,false, statdropper: attacker)
          ret=0; showanim=false
        end
      else
        if opponent.pbReduceStat(PBStats::DEFENSE,1,false, statdropper: attacker)
          ret=0; showanim=false
        end
        if opponent.pbReduceStat(PBStats::SPDEF,1,false, statdropper: attacker)
          ret=0; showanim=false
        end
      end
    end
    return ret
  end
end

class PokeBattle_Move_1006 < PokeBattle_Move # LowerTargetDefSpDef1 < Battle::Move::TargetMultiStatDownMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    ret=-1; prevented=false
    if opponent.effects[:Protect] && !opponent.effects[:ProtectNegation]
      @battle.pbDisplay(_INTL("{1} protected itself!",opponent.pbThis))
      prevented=true
    end
    if !prevented && opponent.pbOwnSide.effects[:Mist]>0
      @battle.pbDisplay(_INTL("{1} is protected by Mist!",opponent.pbThis))
      prevented=true
    end
    if !prevented && ((((opponent.ability == :CLEARBODY) ||
       (opponent.ability == :WHITESMOKE)) && !(opponent.moldbroken)) || opponent.ability == :FULLMETALBODY)
      @battle.pbDisplay(_INTL("{1}'s {2} prevents stat loss!",opponent.pbThis,
         getAbilityName(opponent.ability)))
      prevented=true
    end
    if !prevented && opponent.pbTooLow?(PBStats::DEFENSE) &&
       opponent.pbTooLow?(PBStats::SPDEF)
      @battle.pbDisplay(_INTL("{1}'s stats won't go any lower!",opponent.pbThis))
      prevented=true
    end
    if !prevented
      pbShowAnimation(@move,attacker,opponent,hitnum,alltargets,showanimation)
      showanim=true
      if (@battle.FE == :FAIRYTALE || @battle.FE == :DRAGONSDEN)  && (@move == :NOBLEROAR)
        if opponent.pbReduceStat(PBStats::DEFENSE,2,false, statdropper: attacker)
          ret=0; showanim=false
        end
        if opponent.pbReduceStat(PBStats::SPDEF,2,false, statdropper: attacker)
          ret=0; showanim=false
        end
      else
        if opponent.pbReduceStat(PBStats::DEFENSE,1,false, statdropper: attacker)
          ret=0; showanim=false
        end
        if opponent.pbReduceStat(PBStats::SPDEF,1,false, statdropper: attacker)
          ret=0; showanim=false
        end
      end
    end
    return ret
  end
end

class PokeBattle_Move_1007 < PokeBattle_Move # LowerTargetDefSpDef1SwitchOutUser < Battle::Move::TargetMultiStatDownMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    ret=super(attacker,opponent,hitnum,alltargets,showanimation)
    if @battle.FE == :FROZENDIMENSION
      if opponent.pbTooLow?(PBStats::DEFENSE) && opponent.pbTooLow?(PBStats::SPDEF) && opponent.pbTooLow?(PBStats::SPEED)
        @battle.pbDisplay(_INTL("{1}'s stats won't go any lower!",opponent.pbThis))
        return -1
      end
    else
      if opponent.pbTooLow?(PBStats::DEFENSE) && opponent.pbTooLow?(PBStats::SPDEF)
        @battle.pbDisplay(_INTL("{1}'s stats won't go any lower!",opponent.pbThis))
        return -1
      end
    end
    if opponent.pbOwnSide.effects[:Mist]>0
      @battle.pbDisplay(_INTL("{1} is protected by Mist!",opponent.pbThis))
      return -1
    end
    if (((opponent.ability == :CLEARBODY) ||
       (opponent.ability == :WHITESMOKE)) && !(opponent.moldbroken)) || opponent.ability == :FULLMETALBODY
      @battle.pbDisplay(_INTL("{1}'s {2} prevents stat loss!",opponent.pbThis,getAbilityName(opponent.ability)))
      return -1
    end
    pbShowAnimation(@move,attacker,opponent,hitnum,alltargets,showanimation)
    ret=-1; showanim=true
    statdrop = 1
    statdrop = 2 if (@battle.ProgressiveFieldCheck(PBFields::CONCERT) || @battle.FE == :BACKALLEY)
    if opponent.pbReduceStat(PBStats::DEFENSE,statdrop,false, statdropper: attacker)
      ret=0; showanim=false
    end
    if opponent.pbReduceStat(PBStats::SPDEF,statdrop,false, statdropper: attacker)
      ret=0; showanim=false
    end
    if @battle.FE == :FROZENDIMENSION
      if opponent.pbReduceStat(PBStats::SPEED,1,false, statdropper: attacker)
        ret=0; showanim=false
      end
    end
    if attacker.hp>0 && @battle.pbCanChooseNonActive?(attacker.index) && !@battle.pbAllFainted?(@battle.pbParty(opponent.index)) && @battle.FE != :COLOSSEUM
      @battle.pbDisplay(_INTL("{1} went back to {2}!",attacker.pbThis,@battle.pbGetOwner(attacker.index).name))
      #Going to switch, check for pursuit
      newpoke=0
      newpoke=@battle.pbSwitchInBetween(attacker.index,true,false)
      for j in @battle.priority
        next if !attacker.pbIsOpposing?(j.index)
        # if Pursuit and this target was chosen
        if !j.hasMovedThisRound? && @battle.pbChoseMoveFunctionCode?(j.index,0x88) && !j.effects[:Pursuit] && (@battle.choices[j.index][3]!=j.pbPartner.index)
          attacker.vanished=false
          @battle.pbCommonAnimation("Fade in",attacker,nil)
          @battle.pbPursuitInterrupt(j,attacker)
        end
        break if attacker.isFainted?
      end
      @battle.pbMessagesOnReplace(attacker.index,newpoke)
      attacker.pbResetForm
      @battle.pbClearChoices(attacker.index) if attacker.effects[:MagicBounced]
      @battle.pbReplace(attacker.index,newpoke)
      @battle.pbOnActiveOne(attacker)
      attacker.pbAbilitiesOnSwitchIn(true)
    else
      attacker.vanished=false
      @battle.pbCommonAnimation("Fade in",attacker,nil)
    end
    return ret
  end
end

class PokeBattle_Move_1008 < PokeBattle_Move # LowerTargetMainStats1 < Battle::Move::TargetMultiStatDownMove
  def pbAdditionalEffect(attacker,opponent)
    for stat in 1..5
      if attacker.pbCanReduceStatStage?(stat,false)
        attacker.pbReduceStat(stat,1)
      end
    end
    return true
  end
end

class PokeBattle_Move_1009 < PokeBattle_Move # LowerTargetSpAtkSpDef1 < Battle::Move::TargetMultiStatDownMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    ret=-1; prevented=false
    if opponent.effects[:Protect] && !opponent.effects[:ProtectNegation]
      @battle.pbDisplay(_INTL("{1} protected itself!",opponent.pbThis))
      prevented=true
    end
    if !prevented && opponent.pbOwnSide.effects[:Mist]>0
      @battle.pbDisplay(_INTL("{1} is protected by Mist!",opponent.pbThis))
      prevented=true
    end
    if !prevented && ((((opponent.ability == :CLEARBODY) ||
       (opponent.ability == :WHITESMOKE)) && !(opponent.moldbroken)) || opponent.ability == :FULLMETALBODY)
      @battle.pbDisplay(_INTL("{1}'s {2} prevents stat loss!",opponent.pbThis,
         getAbilityName(opponent.ability)))
      prevented=true
    end
    if !prevented && opponent.pbTooLow?(PBStats::SPATK) &&
       opponent.pbTooLow?(PBStats::SPDEF)
      @battle.pbDisplay(_INTL("{1}'s stats won't go any lower!",opponent.pbThis))
      prevented=true
    end
    if !prevented
      pbShowAnimation(@move,attacker,opponent,hitnum,alltargets,showanimation)
      showanim=true
      if (@battle.FE == :FAIRYTALE || @battle.FE == :DRAGONSDEN)  && (@move == :NOBLEROAR)
        if opponent.pbReduceStat(PBStats::SPATK,2,false, statdropper: attacker)
          ret=0; showanim=false
        end
        if opponent.pbReduceStat(PBStats::SPDEF,2,false, statdropper: attacker)
          ret=0; showanim=false
        end
      else
        if opponent.pbReduceStat(PBStats::SPATK,1,false, statdropper: attacker)
          ret=0; showanim=false
        end
        if opponent.pbReduceStat(PBStats::SPDEF,1,false, statdropper: attacker)
          ret=0; showanim=false
        end
      end
    end
    return ret
  end
end

class PokeBattle_Move_100A < PokeBattle_Move # LowerUserAtkSpd1 < Battle::Move::StatDownMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    ret=super(attacker,opponent,hitnum,alltargets,showanimation)
    if opponent.damagestate.calcdamage>0
      for stat in [PBStats::ATTACK,PBStats::SOEED]
        if attacker.pbCanReduceStatStage?(stat,false,true)
          attacker.pbReduceStat(stat,1,false, statdropper: attacker)
        end
      end
    end
    return ret
  end
end

class PokeBattle_Move_100B < PokeBattle_Move # LowerUserAttack2 < Battle::Move::StatDownMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    ret=super(attacker,opponent,hitnum,alltargets,showanimation)
    if opponent.damagestate.calcdamage>0
      if attacker.pbCanReduceStatStage?(PBStats::ATTACK,false,true)
        attacker.pbReduceStat(PBStats::ATTACK,2,false, statdropper: attacker)
      end
    end
    return ret
  end
end

class PokeBattle_Move_100C < PokeBattle_Move # MaxUserSpecialAttackLoseHalfOfTotalHP < Battle::Move
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    showanim=showanimation
    if attacker.hp<=(attacker.totalhp/2.0).floor || !attacker.pbCanIncreaseStatStage?(PBStats::ATTACK,false)
      @battle.pbDisplay(_INTL("But it failed!"))
      return -1
    end
    pbShowAnimation(@move,attacker,nil,hitnum,alltargets,showanimation)
    attacker.pbReduceHP((attacker.totalhp/2.0).floor, false, false)
    attacker.stages[PBStats::SPATK]=6
    @battle.pbCommonAnimation("StatUp",attacker,nil)
    @battle.pbDisplay(_INTL("{1} cut its own HP and maximized its Special Attack!",attacker.pbThis))
    if @battle.FE == :BIGTOP
       if attacker.pbCanIncreaseStatStage?(PBStats::DEFENSE,false)
        attacker.pbIncreaseStat(PBStats::DEFENSE,1,false)
        attacker.effects[:StockpileDef]+=1
      end
      if attacker.pbCanIncreaseStatStage?(PBStats::SPDEF,false)
        attacker.pbIncreaseStat(PBStats::SPDEF,1,false)
        attacker.effects[:StockpileSpDef]+=1
      end
    end
    return 0
  end
end

class PokeBattle_Move_100D < PokeBattle_Move # RaiseMinMaxStat1 < Battle::Move
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    if attacker.index!=opponent.index && opponent.effects[:Substitute]>0
      @battle.pbDisplay(_INTL("{1}'s attack missed!",attacker.pbThis))
      return -1
    end
    array=[]
    for i in [PBStats::ATTACK,PBStats::DEFENSE,PBStats::SPEED,
              PBStats::SPATK,PBStats::SPDEF,PBStats::ACCURACY,PBStats::EVASION]
      array.push(i) if opponent.pbCanIncreaseStatStage?(i)
    end
    if array.length==0
      @battle.pbDisplay(_INTL("{1}'s stats won't go any higher!",opponent.pbThis))
      return -1
    end
    stat=array[@battle.pbRandom(array.length)]
    pbShowAnimation(@move,attacker,opponent,hitnum,alltargets,showanimation)
    ret=opponent.pbIncreaseStat(stat,1,false)
    return 0
  end
end

class PokeBattle_Move_100E < PokeBattle_Move # RaisePlusMinusUserAndAlliesAtkSpAtk1 < Battle::Move
  def pbEffect(attacker, opponent, hitnum = 0, alltargets = nil, showanimation = true)
    if ([:ELECTRIC, :STEEL].include?(attacker.pbPartner.type1) || [:ELECTRIC, :STEEL].include?(attacker.pbPartner.type2))
      partnerfail = false
      if attacker.pbPartner.pbCanIncreaseStatStage?(PBStats::ATTACK, false) || attacker.pbPartner.pbCanIncreaseStatStage?(PBStats::SPATK, false)
        pbShowAnimation(@move, attacker, nil, hitnum, alltargets, showanimation)
        statboost = 1
        statboost = 2 if @battle.FE == :FACTORY
        attacker.pbPartner.pbIncreaseStat(PBStats::ATTACK, statboost, abilitymessage: false, statsource: attacker)
        attacker.pbPartner.pbIncreaseStat(PBStats::SPATK, statboost, abilitymessage: false, statsource: attacker)
      else # partner cannot increase stats, check next attacker
        @battle.pbDisplay(_INTL("{1}'s stats won't go any higher!", attacker.pbPartner.pbThis))
      end
    else
      # partner does not have Plus/Minus
      partnerfail = true
    end
    if ([:ELECTRIC, :STEEL].include?(attacker.type1) || [:ELECTRIC, :STEEL].include?(attacker.type2))
      if attacker.pbCanIncreaseStatStage?(PBStats::ATTACK, false) || attacker.pbCanIncreaseStatStage?(PBStats::SPATK, false)
        pbShowAnimation(@move, attacker, nil, hitnum, alltargets, partnerfail)
        statboost = 1
        statboost = 2 if @battle.FE == :FACTORY
        attacker.pbIncreaseStat(PBStats::ATTACK, statboost, abilitymessage: false, statsource: attacker)
        attacker.pbIncreaseStat(PBStats::SPATK, statboost, abilitymessage: false, statsource: attacker)
      else # attacker cannot increase stats
        @battle.pbDisplay(_INTL("{1}'s stats won't go any higher!", attacker.pbThis))
      end
    else
      # attacker does not have Plus/Minus
      if partnerfail
        @battle.pbDisplay(_INTL("But it failed!"))
        return -1
      end
    end

    return 0
  end
end

class PokeBattle_Move_100F < PokeBattle_Move # RaisePlusMinusUserAndAlliesDefSpDef1 < Battle::Move
  def pbEffect(attacker, opponent, hitnum = 0, alltargets = nil, showanimation = true)
    if ([:ELECTRIC, :STEEL].include?(attacker.pbPartner.type1) || [:ELECTRIC, :STEEL].include?(attacker.pbPartner.type2)) || (Rejuv && @battle.FE == :ELECTERRAIN)
      partnerfail = false
      if attacker.pbPartner.pbCanIncreaseStatStage?(PBStats::DEFENSE, false) || attacker.pbPartner.pbCanIncreaseStatStage?(PBStats::SPDEF, false)
        pbShowAnimation(@move, attacker, nil, hitnum, alltargets, showanimation)
        statboost = 1
        statboost = 2 if @battle.FE == :DEEPEARTH || (Rejuv && @battle.FE == :ELECTERRAIN && ([:ELECTRIC, :STEEL].include?(attacker.pbPartner.type1) || [:ELECTRIC, :STEEL].include?(attacker.pbPartner.type2)))
        attacker.pbPartner.pbIncreaseStat(PBStats::DEFENSE, statboost, abilitymessage: false, statsource: attacker)
        attacker.pbPartner.pbIncreaseStat(PBStats::SPDEF, statboost, abilitymessage: false, statsource: attacker)
      else # partner cannot increase stats, check next attacker
        @battle.pbDisplay(_INTL("{1}'s stats won't go any higher!", attacker.pbPartner.pbThis))
      end
    else
      # partner does not have Plus/Minus
      partnerfail = true
    end
    if ([:ELECTRIC, :STEEL].include?(attacker.type1) || [:ELECTRIC, :STEEL].include?(attacker.type2)) || (Rejuv && @battle.FE == :ELECTERRAIN)
      if attacker.pbCanIncreaseStatStage?(PBStats::DEFENSE, false) || attacker.pbCanIncreaseStatStage?(PBStats::SPDEF, false)
        pbShowAnimation(@move, attacker, nil, hitnum, alltargets, partnerfail)
        statboost = 1
        statboost = 2 if @battle.FE == :DEEPEARTH || (Rejuv && @battle.FE == :ELECTERRAIN && ([:ELECTRIC, :STEEL].include?(attacker.type1) || [:ELECTRIC, :STEEL].include?(attacker.type2)))
        attacker.pbIncreaseStat(PBStats::DEFENSE, statboost, abilitymessage: false, statsource: attacker)
        attacker.pbIncreaseStat(PBStats::SPDEF, statboost, abilitymessage: false, statsource: attacker)
      else # attacker cannot increase stats
        @battle.pbDisplay(_INTL("{1}'s stats won't go any higher!", attacker.pbThis))
      end
    else
      # attacker does not have Plus/Minus
      if partnerfail
        @battle.pbDisplay(_INTL("But it failed!"))
        return -1
      end
    end
    return 0
  end
end

class PokeBattle_Move_1010 < PokeBattle_Move # RaiseUserAtkSpAtkSpd1 < Battle::Move::MultiStatUpMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    if !attacker.pbCanIncreaseStatStage?(PBStats::ATTACK,false) &&
       !attacker.pbCanIncreaseStatStage?(PBStats::SPATK,false) &&
       !attacker.pbCanIncreaseStatStage?(PBStats::SPEED,false)
      @battle.pbDisplay(_INTL("{1}'s stats won't go any higher!",attacker.pbThis))
      return -1
    end
    pbShowAnimation(@move,attacker,nil,hitnum,alltargets,showanimation)
    boost_amount=1
    if ((@battle.FE == :MISTY || @battle.FE == :RAINBOW || @battle.FE == :HOLY ||
      @battle.FE == :STARLIGHT || @battle.FE == :NEWWORLD || @battle.FE == :PSYTERRAIN) &&
      (@move == :COSMICPOWER)) || (@battle.FE == :FOREST && (@move == :DEFENDORDER))
      boost_amount=2
    end
    for stat in [PBStats::ATTACK,PBStats::SPATK,PBStats::SPEED]
      if attacker.pbCanIncreaseStatStage?(stat,false)
        attacker.pbIncreaseStat(stat,boost_amount,false)
      end
    end
    return 0
  end
end

class PokeBattle_Move_1011 < PokeBattle_Move # RaiseUserAtkSpDef1 < Battle::Move::MultiStatUpMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    if !attacker.pbCanIncreaseStatStage?(PBStats::ATTACK,false) &&
       !attacker.pbCanIncreaseStatStage?(PBStats::SPDEF,false)
      @battle.pbDisplay(_INTL("{1}'s stats won't go any higher!",attacker.pbThis))
      return -1
    end
    pbShowAnimation(@move,attacker,nil,hitnum,alltargets,showanimation)
    boost_amount=1
    if ((@battle.FE == :MISTY || @battle.FE == :RAINBOW || @battle.FE == :HOLY ||
      @battle.FE == :STARLIGHT || @battle.FE == :NEWWORLD || @battle.FE == :PSYTERRAIN) &&
      (@move == :COSMICPOWER)) || (@battle.FE == :FOREST && (@move == :DEFENDORDER))
      boost_amount=2
    end
    for stat in [PBStats::ATTACK,PBStats::SPDEF]
      if attacker.pbCanIncreaseStatStage?(stat,false)
        attacker.pbIncreaseStat(stat,boost_amount,false)
      end
    end
    return 0
  end
end

class PokeBattle_Move_1012 < PokeBattle_Move # RaiseUserDefSpDef1Ingrain < Battle::Move::MultiStatUpMove
  def pbTwoTurnAttack(attacker)
    @immediate=false
    if @battle.FE == :STARLIGHT || @battle.FE == :DEEPEARTH
      @immediate=true
      @battle.pbDisplay(_INTL("{1} absorbed the starlight!",attacker.pbThis)) if @battle.FE == :STARLIGHT
    elsif !@immediate && attacker.hasWorkingItem(:POWERHERB)
      itemname=getItemName(attacker.item)
      @immediate=true
      attacker.pbDisposeItem(false)
      @battle.pbDisplay(_INTL("{1} consumed its {2}!",attacker.pbThis,itemname))
    end
    return false if @immediate
    return attacker.effects[:TwoTurnAttack]==0
  end

  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    if @immediate || attacker.effects[:TwoTurnAttack]!=0
      @battle.pbCommonAnimation("Geomancy",attacker)
      @battle.pbDisplay(_INTL("{1} became one with nature!",attacker.pbThis))
    end
    if attacker.effects[:TwoTurnAttack]==0
      @battle.pbAnimation(@move,attacker,opponent,hitnum)
      for stat in [PBStats::SPATK,PBStats::SPDEF]
        if attacker.pbCanIncreaseStatStage?(stat,false)
          attacker.pbIncreaseStat(stat,1)
          attacker.effects[:Ingrain]=true
        end
      end
    end
    return 0 if attacker.effects[:TwoTurnAttack]!=0
    return super
  end
end

class PokeBattle_Move_1013 < PokeBattle_Move # RaiseUserSpAtk2IfTargetFaints < Battle::Move
  def pbAdditionalEffect(attacker,opponent)
    attacker.pbIncreaseStat(PBStats::SPATK,3,false) if opponent.isFainted? && attacker.pbCanIncreaseStatStage?(PBStats::SPATK,false)
  end
end

class PokeBattle_Move_1014 < PokeBattle_Move # RaiseUserSpAtkAcc1 < Battle::Move::MultiStatUpMove
  def pbEffect(attacker, opponent, hitnum = 0, alltargets = nil, showanimation = true)
    if !attacker.pbCanIncreaseStatStage?(PBStats::SPATK, false) &&
       !attacker.pbCanIncreaseStatStage?(PBStats::ACCURACY, false)
      @battle.pbDisplay(_INTL("{1}'s stats won't go any higher!", attacker.pbThis))
      return -1
    end
    pbShowAnimation(@move, attacker, nil, hitnum, alltargets, showanimation)
    boost_amount = 1
    for stat in [PBStats::SPATK, PBStats::ACCURACY]
      attacker.pbIncreaseStat(stat, boost_amount, abilitymessage: false, statsource: attacker)
    end
    return 0
  end
end

class PokeBattle_Move_1015 < PokeBattle_Move # RaiseUserSpAtkSpd1 < Battle::Move::MultiStatUpMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    if !attacker.pbCanIncreaseStatStage?(PBStats::SPATK,false) &&
       !attacker.pbCanIncreaseStatStage?(PBStats::SPEED,false)
      @battle.pbDisplay(_INTL("{1}'s stats won't go any higher!",attacker.pbThis))
      return -1
    end
    pbShowAnimation(@move,attacker,nil,hitnum,alltargets,showanimation)
    boost_amount=1
    if ((@battle.FE == :MISTY || @battle.FE == :RAINBOW || @battle.FE == :HOLY ||
      @battle.FE == :STARLIGHT || @battle.FE == :NEWWORLD || @battle.FE == :PSYTERRAIN) &&
      (@move == :COSMICPOWER)) || (@battle.FE == :FOREST && (@move == :DEFENDORDER))
      boost_amount=2
    end
    for stat in [PBStats::SPATK,PBStats::SPEED]
      if attacker.pbCanIncreaseStatStage?(stat,false)
        attacker.pbIncreaseStat(stat,boost_amount, abilitymessage: false)
      end
    end
    return 0
  end
end

class PokeBattle_Move_1016 < PokeBattle_Move # RaiseUserSpDef1 < Battle::Move::StatUpMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    return super(attacker,opponent,hitnum,alltargets,showanimation) if @basedamage>0
    return -1 if !attacker.pbCanIncreaseStatStage?(PBStats::SPDEF,true)
    pbShowAnimation(@move,attacker,opponent,hitnum,alltargets,showanimation)
    ret=attacker.pbIncreaseStat(PBStats::SPDEF,1, abilitymessage: false)
    return ret ? 0 : -1
  end

  def pbAdditionalEffect(attacker,opponent)
    increment = 1
    increment = 2 if @battle.FE == :PSYTERRAIN && @move == :MYSTICALPOWER
    if attacker.pbCanIncreaseStatStage?(PBStats::SPDEF,false)
      attacker.pbIncreaseStat(PBStats::SPDEF,increment, abilitymessage: false)
    end
    return true
  end
end

class PokeBattle_Move_1017 < PokeBattle_Move
  def pbEffect(attacker, opponent, hitnum = 0, alltargets = nil, showanimation = true)
    return super(attacker, opponent, hitnum, alltargets, showanimation) if @basedamage > 0
    return -1 if !attacker.pbCanIncreaseStatStage?(PBStats::SPDEF, true)

    pbShowAnimation(@move, attacker, opponent, hitnum, alltargets, showanimation)
    ret = attacker.pbIncreaseStat(PBStats::SPDEF, 3, abilitymessage: false)
    return ret ? 0 : -1
  end

  def pbAdditionalEffect(attacker, opponent)
    attacker.pbIncreaseStat(PBStats::SPDEF, 3, abilitymessage: false, statsource: attacker)
    return true
  end
end

class PokeBattle_Move_1018 < PokeBattle_Move # SetTargetTypesToFairy < Battle::Move
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    if opponent.effects[:Substitute]>0
      @battle.pbDisplay(_INTL("But it failed!"))
      return -1
    end
    if (opponent.ability == :MULTITYPE) ||
      (opponent.ability == :RKSSYSTEM) || attacker.crested == :SILVALLY
      @battle.pbDisplay(_INTL("But it failed!"))
      return -1
    end
    pbShowAnimation(@move,attacker,opponent,hitnum,alltargets,showanimation)
    opponent.type1=(:FAIRY)
    opponent.type2=nil
    typename=getTypeName((:FAIRY))
    @battle.pbDisplay(_INTL("{1} transformed into the {2} type!",opponent.pbThis,typename))
    return 0
  end
end

class PokeBattle_Move_1019 < PokeBattle_Move # SleepTargetSuperEffectiveAgainstFairy < Battle::Move
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    return super(attacker,opponent,hitnum,alltargets,showanimation) if @basedamage>0
    return -1 if !opponent.pbCanSleep?(true)
    pbShowAnimation(@move,attacker,opponent,hitnum,alltargets,showanimation)
    opponent.pbSleep
    @battle.pbDisplay(_INTL("{1} went to sleep!",opponent.pbThis))
    return 0
  end

  def pbAdditionalEffect(attacker,opponent)
    if opponent.pbCanSleep?(false)
      opponent.pbSleep
      @battle.pbDisplay(_INTL("{1} went to sleep!",opponent.pbThis))
      return true
    end
    return false
  end
end

class PokeBattle_Move_101A < PokeBattle_Move # StartWeakenLightMoves < Battle::Move
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    if @battle.state.effects[:Blackout]>0
      @battle.pbDisplay(_INTL("But it failed!"))
      return -1
    end
    pbShowAnimation(@move,attacker,opponent,hitnum,alltargets,showanimation)
    @battle.state.effects[:Blackout]=5
    @battle.pbDisplay(_INTL("Light's power was weakened!"))
    return 0
  end
end

class PokeBattle_Move_101B < PokeBattle_Move # StealStatsAndPassToAlly < Battle::Move
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    totalboost = 0
    if pbTypeModifier(@type,attacker,opponent) != 0
      for i in [PBStats::ATTACK,PBStats::DEFENSE,PBStats::SPEED,
                PBStats::SPATK,PBStats::SPDEF,PBStats::ACCURACY,PBStats::EVASION]
        if opponent.stages[i]>0
          oppboost = opponent.stages[i]
          oppboost *= -1 if attacker.ability == :CONTRARY
          oppboost *= 2 if attacker.ability == :SIMPLE
          attacker.stages[i]+=oppboost
          attacker.stages[i] = attacker.stages[i].clamp(-6, 6)
          totalboost += oppboost
          opponent.stages[i]=0
        end
      end
    end
    if totalboost>0
      @battle.pbCommonAnimation("StatUp",attacker,nil)
      @battle.pbDisplay(_INTL("{1} stole {2}'s stat boosts!",attacker.pbThis,opponent.pbThis))
    end
    if !@battle.pbCanChooseNonActive?(attacker.index)
      @battle.pbDisplay(_INTL("But it failed!"))
      return -1
    end
    newpoke=0
    pbShowAnimation(@move,attacker,nil,hitnum,alltargets,showanimation)
    newpoke=@battle.pbSwitchInBetween(attacker.index,true,false)
    @battle.pbMessagesOnReplace(attacker.index,newpoke)
    attacker.pbResetForm
    @battle.pbReplace(attacker.index,newpoke,true)
    @battle.pbOnActiveOne(attacker)
    attacker.pbAbilitiesOnSwitchIn(true)
    return super(attacker,opponent,hitnum,alltargets,showanimation)
  end
end

class PokeBattle_Move_101C < PokeBattle_Move # SuperEffectiveAgainstRock < Battle::Move
  # Handled in superclass
end

class PokeBattle_Move_101D < PokeBattle_Move # SuperEffectiveAgainstBug < Battle::Move
  # Handled in superclass
end

class PokeBattle_Move_101E < PokeBattle_Move # SuperEffectiveAgainstGhost < Battle::Move
  # Handled in superclass
end

class PokeBattle_Move_101F < PokeBattle_Move # SuperEffectiveAgainstSteel < Battle::Move
  # Handled in superclass
end

class PokeBattle_Move_1020 < PokeBattle_Move # SuperEffectiveAgainstPsychic < Battle::Move
  # Handled in superclass
end

class PokeBattle_Move_1021 < PokeBattle_Move # SuperEffectiveAgainstCosmic < Battle::Move
  # Handled in superclass
end

class PokeBattle_Move_1022 < PokeBattle_Move # SuperEffectiveAgainstWater < Battle::Move
  # Handled in superclass
end

class PokeBattle_Move_1023 < PokeBattle_Move # GlitchMove < Battle::Move
  # Handled in superclass
end

class PokeBattle_Move_1024 < PokeBattle_Move # UseTargetSpDefInsteadOfTargetDefense < Battle::Move
  # Handled in superclass, do not edit!

  def pbGetDefenseStats(user, target)
    return target.spdef, target.stages[:SPECIAL_DEFENSE] + 6
  end
end

class PokeBattle_Move_1025 < PokeBattle_Move; end # UseUserBaseSpDefInsteadOfUserBaseSpAtk< Battle::Move

class PokeBattle_Move_1026 < PokeBattle_Move # LowerUserSpecialAttack1 < Battle::Move::StatDownMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    ret=super(attacker,opponent,hitnum,alltargets,showanimation)
    if opponent.damagestate.calcdamage>0
      if attacker.pbCanReduceStatStage?(PBStats::SPATK,false,true)
        attacker.pbReduceStat(PBStats::SPATK,1,false, statdropper: attacker)
      end
    end
    return ret
  end
end
