def wardenEncounters
  return {
    # Normal Dens
    :ORN_FERROSEED => {
      :Form => 0,
      :ShinyChance => 1,
      :Moves => [:ORN_VENOMDRAIN, :PETALBLIZZARD, :POISONJAB, :POWERWHIP],
      :IVs => [31,31,31,31,31,31],
      :EVs => [40,40,40,40,40,40],
    },
    :ORN_DRILBUR => {
      :Form => 0,
      :ShinyChance => 1,
      :Moves => [:DRILLRUN, :SANDSTORM, :EARTHQUAKE, :ORN_SONICCRASH],
      :IVs => [31,31,31,31,31,31],
      :EVs => [40,40,40,40,40,40],
    },
    :ORN_FUECOCO => {
      :Form => 0,
      :ShinyChance => 1,
      :Moves => [:ORN_BATTLEOFWITS, :ORN_THORNPRISON, :ORN_VEXINGVINES, :ORN_CATAPULT],
      :IVs => [31,31,31,31,31,31],
      :EVs => [40,40,40,40,40,40],
    },
    :ORN_PAWMI => {
      :Form => 0,
      :ShinyChance => 1,
      :Moves => [:ORN_COUPDEGRACE, :ORN_DEAFEN, :POWERUPPUNCH, :MACHPUNCH],
      :IVs => [31,31,31,31,31,31],
      :EVs => [40,40,40,40,40,40],
    },
    :ORN_WATTREL => {
      :Form => 0,
      :ShinyChance => 1,
      :Moves => [:ORN_JETDIVE,:DRILLPECK,:ACROBATICS,:STONEEDGE],
      :IVs => [31,31,31,31,31,31],
      :EVs => [40,40,40,40,40,40],
    },
    # Rare Dens
    :ORN_DREEPY => {
      :Form => 0,
      :ShinyChance => 1,
      :Moves => [:ORN_NOISEPOLLUTION, :ORN_TORNADO, :ORN_BOMBARDMENT, :HURRICANE],
      :IVs => [31,31,31,31,31,31],
      :EVs => [40,40,40,40,40,40],
    },
    :ORN_HONEDGE => {
      :Form => 0,
      :ShinyChance => 1,
      :Moves => [:ORN_QUICKSPELL,:ORN_STRAFE,:ORN_MAIM,:STEAMROLLER],
      :IVs => [31,31,31,31,31,31],
      :EVs => [40,40,40,40,40,40],
    },
    :ORN_DRILBUR2 => {
      :Form => 0,
      :ShinyChance => 1,
      :Moves => [:ICEBEAM, :PURIFY, :FLASHCANNON, :ORN_MOONSTONERAY],
      :IVs => [31,31,31,31,31,31],
      :EVs => [40,40,40,40,40,40],
    },
    :ORN_TINKATINK => {
      :Form => 0,
      :ShinyChance => 1,
      :Moves => [:ORN_ANCIENTGLARE,:ATTRACT,:ORN_BATTLEOFWITS,:ORN_BLOODRITUAL],
      :IVs => [31,31,31,31,31,31],
      :EVs => [40,40,40,40,40,40],
    },
    :ORN_FINIZEN => {
      :Form => 0,
      :ShinyChance => 1,
      :Moves => [:WATERGUN,:ORN_BATTLEOFWITS,:BLIZZARD,:BODYSLAM],
      :IVs => [31,31,31,31,31,31],
      :EVs => [40,40,40,40,40,40],
    },
    :ORN_GIMMIGHOUL => {
      :Form => 0,
      :ShinyChance => 1,
      :Moves => [:POISONFANG, :PROTECT, :RETURN, :ROCKTOMB],
      :IVs => [31,31,31,31,31,31],
      :EVs => [40,40,40,40,40,40],
    },

    #LEGENDARY Den
	:ORN_MELOETTA => {
      :Form => 0,
      :ShinyChance => 1,
      :Moves => [:ORN_HYPERVOICE,:INSTRUCT,:PERISHSONG,:ORN_BOOMINGBEATS],
      :IVs => [31,31,31,31,31,31],
      :EVs => [40,40,40,40,40,40],
	},
    :ORN_PHIONE2 => {
      :Form => 0,
	  :ShinyChance => 1,
	  :Moves => [:ORN_DAZZLINGGLEAM, :ORN_TITANIASLAW, :ORN_AURASPHERE, :ORN_SKYBLESSING],
      :IVs => [31,31,31,31,31,31],
      :EVs => [40,40,40,40,40,40],
	},
    :ORN_HOOPA => {
      :Form => 0,
	  :ShinyChance => 1,
	  :Moves => [:ORN_FRENZY, :NASTYPLOT, :ORN_ARCANEENERGY, :ORN_CHAKRABLAST],
      :IVs => [31,31,31,31,31,31],
      :EVs => [40,40,40,40,40,40],
	},
  }
end

def checkWardenStar(level)
    return 5 if level >= 90
    return 4 if level >= 75
    return 3 if level >= 60
    return 2 if level >= 45
    return 1 if level >= 30
end

def warden_encounterTable(den)
  case den
    when "Warden"
      return {
        :ORN_FERROSEED => {
          :encounter => wardenEncounters[:ORN_FERROSEED],
          :weight => 2.0 #float of instances. divided by encounter table length
        },
        :ORN_DRILBUR2 => {
          :encounter => wardenEncounters[:ORN_DRILBUR2],
          :weight => 2.0 #float of instances. divided by encounter table length
        },
        :ORN_FUECOCO => {
          :encounter => wardenEncounters[:ORN_FUECOCO],
          :weight => 2.0 #float of instances. divided by encounter table length
        },
        :ORN_PAWMI => {
          :encounter => wardenEncounters[:ORN_PAWMI],
          :weight => 2.0 #float of instances. divided by encounter table length
        },
        :ORN_WATTREL => {
          :encounter => wardenEncounters[:ORN_WATTREL],
          :weight => 2.0 #float of instances. divided by encounter table length
        },
      }
    when "WardenRare"
      return {
        :ORN_DREEPY => {
          :encounter => wardenEncounters[:ORN_DREEPY],
          :weight => 2.0 #float of instances. divided by encounter table length
        },
        :ORN_HONEDGE => {
          :encounter => wardenEncounters[:ORN_HONEDGE],
          :weight => 2.0 #float of instances. divided by encounter table length
        },
        :ORN_DRILBUR => {
          :encounter => wardenEncounters[:ORN_DRILBUR],
          :weight => 2.0 #float of instances. divided by encounter table length
        },
        :ORN_TINKATINK => {
          :encounter => wardenEncounters[:ORN_TINKATINK],
          :weight => 2.0 #float of instances. divided by encounter table length
        },
        :ORN_FINIZEN => {
          :encounter => wardenEncounters[:ORN_FINIZEN],
          :weight => 2.0 #float of instances. divided by encounter table length
        },
        :ORN_GIMMIGHOUL => {
          :encounter => wardenEncounters[:ORN_GIMMIGHOUL],
          :weight => 2.0 #float of instances. divided by encounter table length
        },
      }
    when "WardenLegend"
	  return {
        :ORN_MELOETTA => {
          :encounter => wardenEncounters[:ORN_MELOETTA],
          :weight => 2.0 #float of instances. divided by encounter table length
        },
        :ORN_PHIONE2 => {
          :encounter => wardenEncounters[:ORN_PHIONE2],
          :weight => 2.0 #float of instances. divided by encounter table length
        },
        :ORN_HOOPA => {
          :encounter => wardenEncounters[:ORN_HOOPA],
          :weight => 2.0 #float of instances. divided by encounter table length
        },
      }
    else
      raise "Raid Den #{den} not defined! Please report this!"
      return
    end
end

def WardenDen(den)
    den = den.to_s if den.is_a?(Symbol)
    encTable = warden_encounterTable(den)
    

    baseLevel = 0
    baseLevel = 30 if $game_switches[:Gym_4]
    baseLevel = 45 if $game_switches[:Gym_8]
    baseLevel = 60 if $game_switches[:Gym_12]
    baseLevel = 75 if $game_switches[:Gym_16]
    baseLevel = 90 if $game_switches[:Gym_18]
	
	baseLevel = 90 if den == "WardenLegend"

    encTableLength = 0
    encTable.each{|enc,data| encTableLength += data[:weight]}
    
    arr = []
    encTable.each{|enc,data| 
        w = data[:weight]
        while w >= 1
            arr.push(enc)
            w -= 1
        end
    }
    species =  arr[rand(0...encTableLength)]

    level = baseLevel + rand(-5..5)
	level = 90 if den == "WardenLegend"
    encdata = encTable[species]

    Kernel.pbMessage("This den contains a #{checkWardenStar(level)}-star #{$cache.pkmn[species].name}!")
    canescape = true
    canlose = false
    variable=Variables[:BattleResult]
    $game_switches[:Raid] = true
    if Kernel.pbConfirmMessage("Would you like to fight it?")
        mon = pbGenerateWildPokemon(species,level)
        mon.form = encdata[:encounter][:Form]
        mon.makeShiny if rand(100) <= (encdata[:encounter][:ShinyChance] * 10)
        if encdata[:encounter][:Moves].length > 0
            encdata[:encounter][:Moves].each{|move|
                mon.pbLearnMove(move)
            }
        end
        mon.setAbility(encdata[:encounter][:Ability]) if encdata[:encounter][:Ability] != nil
        mon.iv = encdata[:encounter][:IVs].clone if encdata[:encounter][:IVs].length > 0
        mon.ev = encdata[:encounter][:EVs].clone if encdata[:encounter][:EVs].length > 0
        mon.iv = Array.new(6,31) if ($game_switches[:Full_IVs])
		den_id = ((den == "WardenLegend") ? :WARDENDEN_4 : ((den == "WardenRare") ? :WARDENDEN_2 : :WARDENDEN_1))
        bossFunction($cache.bosses[den_id],den_id,mon)
        
        ret = pbWildBattleObject(mon,variable)

        $game_switches[:Raid] = false
        return ret
    else
        $game_switches[:Raid] = false
        $PokemonGlobal.nextBattleBGM=nil
        $PokemonGlobal.nextBattleME=nil
        $PokemonGlobal.nextBattleBack=nil
        if Kernel.pbConfirmMessage("Would you like to clear the den?")
            $game_variables[:BattleResult]=1
            return true
        end
        $game_variables[:BattleResult]=3
        return false
    end
end

def wardenHandler(decision, pokemon)
    return if !$game_switches[:Raid]
    pokemon.makeShadow
    pokemon.isbossmon = false
    pokemon.shieldCount = nil
    pokemon.bossId = nil
    if decision == 4
        if !$Trainer.pokedex.nil?
            $Trainer.pokedex.dexList[pokemon.species][:shadowCaught?] = true
        end
    end
end
