def getNGPData
    $Unidata[:fieldNotes] = checkSeenFields
    saveClientData
end