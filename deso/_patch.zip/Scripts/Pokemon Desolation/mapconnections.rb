MAPCONNECTIONSHASH = {
106 => {  #Route 1
 	:connections => [
	[106, 0, 0, 111, 0, 0], # to Route 1 (Old)
	[106, 0, 0, 115, 0, 0] # to Top Route 1
	],
},
26 => {  #Silver Forest
 	:connections => [
	[26, 0, 0, 27, 0, 83] # to Silver Rise
	],
},
}