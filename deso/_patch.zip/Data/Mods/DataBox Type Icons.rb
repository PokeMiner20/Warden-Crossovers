## In-Battle Type Icon Mod ##
class PokemonDataBox < SpriteWrapper
  def refresh(loopstop=false)
    self.bitmap.clear
    return if !@battler.pokemon
    self.bitmap.blt(0,0,@databox.bitmap,Rect.new(0,0,@databox.width,@databox.height))
    base=PBScene::BOXBASE
    shadow=PBScene::BOXSHADOW
    pokename=@battler.name
    pbSetSystemFont(self.bitmap)
    textpos=[
       [pokename,@spritebaseX+8,@spritebaseY+6,false,base,shadow]
    ]
    genderX=self.bitmap.text_size(pokename).width
    genderX+=@spritebaseX+14
    if genderX > 165 && !@doublebattle && (@battler.index&1)==1 #opposing pokemon
      genderX = 224
    end
    if @battler.gender==0 # Male
      textpos.push([_INTL("♂"),genderX,@spritebaseY+6,false,Color.new(48,96,216),shadow])
    elsif @battler.gender==1 # Female
      textpos.push([_INTL("♀"),genderX,@spritebaseY+6,false,Color.new(248,88,40),shadow])
    end
    pbDrawTextPositions(self.bitmap,textpos)
    pbSetSmallFont(self.bitmap)
    textpos=[[_INTL("Lv{1}",$game_switches[:Level_999] && (@battler.index%2)==1 ? 999 : @battler.level),@spritebaseX+202,@spritebaseY+12,true,base,shadow]]
    if @showhp
      hpstring=_ISPRINTF("{1: 2d}/{2: 2d}",self.hp,@battler.totalhp)
      textpos.push([hpstring,@spritebaseX+188,@spritebaseY+52,true,base,shadow])
    end
    pbDrawTextPositions(self.bitmap,textpos)
    imagepos=[]

    typetarget = @battler.effects[:Illusion] ? @battler.effects[:Illusion] : @battler
    type1 = typetarget.type1
    type2 = (typetarget.type2 != nil) ? typetarget.type2 : nil
    typeX = ((@battler.index & 1) == 0) ? 500 : 202
    typeY = ((@battler.index & 1) == 0) ? 0 : 6
    imagepos.push(["Graphics/Icons/minitype#{type1.to_s}.png",@spritebaseX + typeX, @spritebaseY + typeY, 0, 0, -1, -1])
    imagepos.push(["Graphics/Icons/minitype#{type2.to_s}.png",@spritebaseX + typeX+14, @spritebaseY + typeY, 14, 0, -1, -1]) if type2 != nil


    if @battler.pokemon.isShiny?
      shinyX=206
      shinyX=6 if (@battler.index&1)==0 # If player's Pokémon
      imagepos.push(["Graphics/Pictures/shiny.png",@spritebaseX+shinyX,@spritebaseY+36,0,0,-1,-1])
    end
    megaY=34
    megaY=38 if (@battler.index&1)==0 # If player's Pokémon
    megaX=8
    megaX=-8 if (@battler.index&1)==0 # If player's Pokémon
    if @battler.pokemon.isPulse?
      imagepos.push(["Graphics/Pictures/Battle/battlePulseEvoBox.png",@spritebaseX+megaX,@spritebaseY+megaY,0,0,-1,-1])
    elsif @battler.pokemon.isRift?
      imagepos.push(["Graphics/Pictures/Battle/battleRiftEvoBox.png",@spritebaseX+megaX,@spritebaseY+megaY,0,0,-1,-1])
    elsif @battler.pokemon.isPerfection?
      imagepos.push(["Graphics/Pictures/Battle/battlePerfectionEvoBox.png",@spritebaseX+megaX,@spritebaseY+megaY,0,0,-1,-1])
    elsif @battler.isMega?
      imagepos.push(["Graphics/Pictures/Battle/battleMegaEvoBox.png",@spritebaseX+megaX,@spritebaseY+megaY,0,0,-1,-1])
    elsif @battler.isUltra? # Maybe temporary until new icon
      imagepos.push(["Graphics/Pictures/Battle/battleMegaEvoBox.png",@spritebaseX+megaX,@spritebaseY+megaY,0,0,-1,-1])
    end
    if @battler.owned && (@battler.index&1)==1
      imagepos.push(["Graphics/Pictures/Battle/battleBoxOwned.png",@spritebaseX+8,@spritebaseY+36,0,0,-1,-1])
    end
    pbDrawImagePositions(self.bitmap,imagepos)
    if !@battler.status.nil?
      imagepos=[]
      imagepos.push([sprintf("Graphics/Pictures/Battle/BattleStatuses%s",@battler.status),@spritebaseX+24,@spritebaseY+36,0,0,64,28])
      pbDrawImagePositions(self.bitmap,imagepos)
    end
    hpGaugeSize=PBScene::HPGAUGESIZE
    hpgauge=@battler.totalhp==0 ? 0 : (self.hp*hpGaugeSize/@battler.totalhp)
    hpgauge=2 if hpgauge==0 && self.hp>0
    hpzone=0
    hpzone=1 if self.hp<=(@battler.totalhp/2.0).floor
    hpzone=2 if self.hp<=(@battler.totalhp/4.0).floor
    hpcolors=[
       PBScene::HPGREENDARK,
       PBScene::HPGREEN,
       PBScene::HPYELLOWDARK,
       PBScene::HPYELLOW,
       PBScene::HPREDDARK,
       PBScene::HPRED
    ]
    # fill with black (shows what the HP used to be)
    hpGaugeX=PBScene::HPGAUGE_X
    hpGaugeY=PBScene::HPGAUGE_Y
    if @animatingHP && self.hp>0
      self.bitmap.fill_rect(@spritebaseX+hpGaugeX,@spritebaseY+hpGaugeY,
         @starthp*hpGaugeSize/@battler.totalhp,6,Color.new(0,0,0))
    end
    # fill with HP color
    self.bitmap.fill_rect(@spritebaseX+hpGaugeX,@spritebaseY+hpGaugeY,hpgauge,2,hpcolors[hpzone*2])
    self.bitmap.fill_rect(@spritebaseX+hpGaugeX,@spritebaseY+hpGaugeY+2,hpgauge,4,hpcolors[hpzone*2+1])
    if @showexp
      # fill with EXP color
      expGaugeX=PBScene::EXPGAUGE_X
      expGaugeY=PBScene::EXPGAUGE_Y
      self.bitmap.fill_rect(@spritebaseX+expGaugeX,@spritebaseY+expGaugeY,self.exp,2,
         PBScene::EXPCOLORSHADOW)
      self.bitmap.fill_rect(@spritebaseX+expGaugeX,@spritebaseY+expGaugeY+2,self.exp,2,
         PBScene::EXPCOLORBASE)
    end
    pbShowStatsBoosts if loopstop==false
  end
end
## In-Battle Type Icon Mod ##
