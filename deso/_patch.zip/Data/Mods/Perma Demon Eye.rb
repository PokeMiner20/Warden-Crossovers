class PokemonEncounters
  def pbShouldFilterKnownPkmnFromEncounter?
    # Should also check for $Trainer.party[0].hp > 0 by logic, but then
    #  it wouldn't be in line with the other overworld party leader checks
    return false if $Trainer.party[0].egg?
    return true if $Trainer.party[0].item == :MAGNETICLURE
    return true if $PokemonBag.pbQuantity(:ORN_OPENDEMONEYE)>0
    return false
  end
end