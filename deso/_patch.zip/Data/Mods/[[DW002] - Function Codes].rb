class PokeBattle_Move
  alias warden_pbHitsSpecialStat? pbHitsSpecialStat?
  alias warden_pbHitsPhysicalStat? pbHitsPhysicalStat?
  alias warden_pbTypeModifier pbTypeModifier
  alias warden_pbTypeModifierNonBattler pbTypeModifierNonBattler

  def pbHitsSpecialStat?(type = @type)
    return true if @function == 0x1024
    return warden_pbHitsSpecialStat?(type = @type)
  end

  def pbHitsPhysicalStat?(type = @type)
    return true if @function == 0x122
    return warden_pbHitsPhysicalStat?(type = @type)
  end

  def pbTypeModifier(type, attacker, opponent, zorovar = false)
    atype = type # attack type
    otype1 = opponent.type1
    otype2 = opponent.type2
    mod1 = PBTypes.oneTypeEff(atype, otype1)
    mod2 = otype1 == otype2 || otype2.nil? ? 2 : PBTypes.oneTypeEff(atype, otype2)
    warden_functions = [0x101C,0x101D,0x101E,0x101F,0x1020,0x1021,0x1022,0x1023]
	warden_ability = [:ORN_CONDUCTOR,:ORN_ANTIGRAVITY,:ORN_OPAQUENESS,:ORN_CACOPHONY]
    if warden_functions.include?(@function)
      case @function
        when 0x101C # Fly Trap
          mod1 = 4 if otype1 == :BUG
          mod2 = 4 if otype2 == :BUG
        when 0X101D # Satelite Ray
          mod1 = 4 if otype1 == :COSMIC
          mod2 = 4 if otype2 == :COSMIC
        when 0X101E # Fantasy Seal
          mod1 = 4 if otype1 == :GHOST
          mod2 = 4 if otype2 == :GHOST
        when 0x101F # Battle of Wits
          mod1 = 4 if otype1 == :PSYCHIC
          mod2 = 4 if otype2 == :PSYCHIC
        when 0x1020 # Erosion
          mod1 = 4 if otype1 == :ROCK
          mod2 = 4 if otype2 == :ROCK
        when 0x1021 # Corrode
          mod1 = 4 if otype1 == :STEEL
          mod2 = 4 if otype2 == :STEEL
        when 0x1022 # Boil
          mod1 = 4 if otype1 == :WATER
          mod2 = 4 if otype2 == :WATER
        when 0x1023 # Glitch
          glitch_type = [[:FIRE, :FLYING, :STEEL, :FAIRY, :SOUND],[:GRASS, :PSYCHIC, :DARK]]
		  mod1 = 1 if glitch_type[0].include?(otype1)
		  mod2 = 1 if glitch_type[0].include?(otype2)
		  mod1 = 4 if glitch_type[1].include?(otype1)
		  mod2 = 4 if glitch_type[1].include?(otype2)
      end
      return mod1 * mod2
    elsif warden_ability.include?(attacker.ability)
      case attacker.ability
	    when :ORN_CONDUCTOR
		  mod1 = 2 if [:GROUND,:ELECTRIC].include?(otype1) && atype == :ELECTRIC
		  mod2 = 2 if [:GROUND,:ELECTRIC].include?(otype2) && atype == :ELECTRIC
        when :ORN_ANTIGRAVITY
		  mod1 = 2 if [:SOUND,:GROUND].include?(atype) && otype1 == :COSMIC
		  mod2 = 2 if [:SOUND,:GROUND].include?(atype) && otype2 == :COSMIC
        when :ORN_OPAQUENESS
		  mod1 = 0 if atype == :LIGHT
		  mod2 = 0 if atype == :LIGHT
        when :ORN_CACOPHONY
		  mod1 = 0 if atype == :SOUND
		  mod2 = 0 if atype == :SOUND
        when :ORN_COMETSTORM
		  mod1 = 0 if atype == :ROCK
		  mod2 = 0 if atype == :ROCK
	  end
      return mod1 * mod2
    else
      return warden_pbTypeModifier(type, attacker, opponent, zorovar = false)
    end
  end

  def pbTypeModifierNonBattler(type, attacker, opponent)
    atype = type # attack type
    otype1 = opponent.type1
    otype2 = opponent.type2
    mod1 = PBTypes.oneTypeEff(atype, otype1)
    mod2 = otype1 == otype2 ? 2 : PBTypes.oneTypeEff(atype, otype2)
    warden_functions = [0x101C,0x101D,0x101E,0x101F,0x1020,0x1021,0x1022]
	warden_ability = [:ORN_CONDUCTOR,:ORN_ANTIGRAVITY]
    if warden_functions.include?(@function)
      case @function
        when 0x101C # Fly Trap
          mod1 = 4 if otype1 == :BUG
          mod2 = 4 if otype2 == :BUG
        when 0X101D # Satelite Ray
          mod1 = 4 if otype1 == :COSMIC
          mod2 = 4 if otype2 == :COSMIC
        when 0X101E # Fantasy Seal
          mod1 = 4 if otype1 == :GHOST
          mod2 = 4 if otype2 == :GHOST
        when 0x101F # Battle of Wits
          mod1 = 4 if otype1 == :PSYCHIC
          mod2 = 4 if otype2 == :PSYCHIC
        when 0x1020 # Erosion
          mod1 = 4 if otype1 == :ROCK
          mod2 = 4 if otype2 == :ROCK
        when 0x1021 # Corrode
          mod1 = 4 if otype1 == :STEEL
          mod2 = 4 if otype2 == :STEEL
        when 0x1022 # Boil
          mod1 = 4 if otype1 == :WATER
          mod2 = 4 if otype2 == :WATER
        when 0x0123 # Glitch
          glitch_type = [[:FIRE, :FLYING, :STEEL, :FAIRY, :SOUND],[:GRASS, :PSYCHIC, :DARK]]
		  mod1 = 1 if glitch_type[0].include?(otype1)
		  mod2 = 1 if glitch_type[0].include?(otype2)
		  mod1 = 4 if glitch_type[1].include?(otype1)
		  mod2 = 4 if glitch_type[1].include?(otype2)
      end
      return mod1 * mod2
    elsif warden_ability.include?(attacker.ability)
      case attacker.ability
	    when :ORN_CONDUCTOR
		  mod1 = 2 if [:GROUND,:ELECTRIC].include?(otype1) && atype == :ELECTRIC
		  mod2 = 2 if [:GROUND,:ELECTRIC].include?(otype2) && atype == :ELECTRIC
        when :ORN_ANTIGRAVITY
		  mod1 = 2 if [:SOUND,:GROUND].include?(atype) && otype1 == :COSMIC
		  mod2 = 2 if [:SOUND,:GROUND].include?(atype) && otype2 == :COSMIC
	  end
      return mod1 * mod2
    else
	  return warden_pbTypeModifierNonBattler(type, attacker, opponent)
	end
  end

  def pbCalcDamage(attacker,opponent,options=0, hitnum: 0)
    opponent.damagestate.critical=false
    opponent.damagestate.typemod=0
    opponent.damagestate.calcdamage=0
    opponent.damagestate.hplost=0
    basedmg=@basedamage # From PBS file
    basedmg=pbBaseDamage(basedmg,attacker,opponent) # Some function codes alter base power
    return 0 if basedmg==0
    critchance = pbCritRate?(attacker,opponent)
    if critchance >= 0
      ratios=[24,8,2,1]
      opponent.damagestate.critical= @battle.pbRandom(ratios[critchance])==0
    end
    stagemul=[2,2,2,2,2,2,2,3,4,5,6,7,8]
    stagediv=[8,7,6,5,4,3,2,2,2,2,2,2,2]
    type=pbType(attacker)
    ##### Calcuate base power of move #####
   
    basemult=1.0
    #classic prep stuff
    attitemworks = attacker.itemWorks?(true)
    oppitemworks = opponent.itemWorks?(true)
    case attacker.ability
      when :TECHNICIAN
        if basedmg<=60
          basemult*=1.5
        elsif (@battle.FE == :FACTORY || @battle.ProgressiveFieldCheck(PBFields::CONCERT)) && basedmg<=80
          basemult*=1.5
        end
      when :STRONGJAW     then basemult*=1.5 if (PBStuff::BITEMOVE).include?(@move)
      when :SHARPNESS     then basemult*=1.5 if sharpMove?
      when :ORN_SHARPNESS     then basemult*=1.5 if sharpMove?
      when :TRUESHOT      then basemult*=1.3 if (PBStuff::BULLETMOVE).include?(@move)
      when :TOUGHCLAWS    then basemult*=1.3 if contactMove?
      when :IRONFIST
        if @battle.FE == :CROWD
          basemult*=1.2 if punchMove?
        else
          basemult*=1.2 if punchMove?
        end
      when :RECKLESS      then basemult*=1.2 if [0xFA,0xFA,0xFA,0xFA,0xFA].include?(@function)
      when :FLAREBOOST    then basemult*=1.5 if (attacker.status== :BURN || @battle.FE == :BURNING || @battle.FE == :VOLCANIC || @battle.FE == :INFERNAL) && pbIsSpecial?(type) && @battle.FE != :FROZENDIMENSION
      when :TOXICBOOST    
        if (attacker.status== :POISON || @battle.FE == :CORROSIVE || @battle.FE == :CORROSIVEMIST || @battle.FE == :WASTELAND || @battle.FE == :MURKWATERSURFACE) && pbIsPhysical?(type)
          if @battle.FE == :CORRUPTED
            basemult*=2.0
          else
            basemult*=1.5
          end
        end
      when :PUNKROCK
        if isSoundBased?
          case @battle.FE
            when :BIGTOP then basemult*=1.5
            when :CAVE then basemult*=1.5
            else
              basemult*=1.3 
          end
        end
      when :RIVALRY       then basemult*= attacker.gender==opponent.gender ? 1.25 : 0.75 if attacker.gender!=2
      when :MEGALAUNCHER  then basemult*=1.5 if [:AURASPHERE,:DRAGONPULSE,:DARKPULSE,:WATERPULSE,:ORIGINPULSE,:TERRAINPULSE].include?(@move)
      when :SANDFORCE     then basemult*=1.3 if (@battle.pbWeather== :SANDSTORM || @battle.FE == :DESERT || @battle.FE == :ASHENBEACH) && (type == :ROCK || type == :GROUND || type == :STEEL)
      when :ANALYTIC      then basemult*=1.3 if (@battle.battlers.find_all {|battler| battler && battler.hp > 0 && !battler.hasMovedThisRound? }).length == 0
      when :SHEERFORCE    then basemult*=1.3 if effect > 0
      when :AERILATE 
        if @type == :NORMAL && type == :FLYING
          case @battle.FE
            when :MOUNTAIN,:SNOWYMOUNTAIN,:SKY then basemult*=1.5
            else
              basemult*=1.2
          end
        end
      when :GALVANIZE
        if @type == :NORMAL && type == :ELECTRIC
          case @battle.FE
            when :ELECTERRAIN,:FACTORY then basemult*=1.5
            when :SHORTCIRCUIT then basemult*=2
            else
              if @battle.state.effects[:ELECTERRAIN] > 0
                basemult*=1.5
              else 
                basemult*=1.2
              end
          end
        end
      when :REFRIGERATE 
        if @type == :NORMAL && type == :ICE
          case @battle.FE
            when :ICY,:SNOWYMOUNTAIN,:FROZENDIMENSION then basemult*=1.5
            else
              basemult*=1.2
          end
        end
      when :PIXILATE 
        if @type == :NORMAL && (type == :FAIRY || (type == :NORMAL && @battle.FE == :GLITCH))
          case @battle.FE
            when :MISTY then basemult*=1.5
            else
              if @battle.state.effects[:MISTY] > 0
                basemult*=1.5
              else 
                basemult*=1.2
              end
          end
        end
      when :DUSKILATE     then basemult*=1.2 if @type == :NORMAL && (type == :DARK || (type == :NORMAL && @battle.FE == :GLITCH))
      when :NORMALIZE     then basemult*=1.2
      when :TRANSISTOR    then basemult*=1.5 if type == :ELECTRIC
      when :DRAGONSMAW    then basemult*=1.5 if type == :DRAGON
      when :TERAVOLT      then basemult*=1.5 if (Rejuv && @battle.FE == :ELECTERRAIN && type == :ELECTRIC)
      when :INEXORABLE    then basemult*=1.5 if type == :DRAGON && (!opponent.hasMovedThisRound? || @battle.switchedOut[opponent.index])
    end
    case opponent.ability
      when :HEATPROOF     then basemult*=0.5 if !(opponent.moldbroken) && type == :FIRE
      when :DRYSKIN       then basemult*=1.25 if !(opponent.moldbroken) && type == :FIRE
      when :TRANSISTOR    then basemult*=0.5 if (@battle.FE == :ELECTERRAIN && type == :GROUND) && !(opponent.moldbroken)
    end
    if attitemworks
      if $cache.items[attacker.item].checkFlag?(:typeboost) == type
        basemult*=1.2
        if $cache.items[attacker.item].checkFlag?(:gem)
          basemult*=1.0833 #gems are 1.3; 1.2 * 1.0833 = 1.3
          attacker.takegem=true
          @battle.pbDisplay(_INTL("The {1} strengthened {2}'s power!",getItemName(attacker.item),self.name))
        end
      else
        case attacker.item
          when :MUSCLEBAND then basemult*=1.1 if pbIsPhysical?(type)
          when :WISEGLASSES then basemult*=1.1 if pbIsSpecial?(type)
          when :LUSTROUSORB then basemult*=1.2 if (attacker.pokemon.species == :PALKIA) && (type == :DRAGON || type == :WATER)
          when :ADAMANTORB then basemult*=1.2 if (attacker.pokemon.species == :DIALGA) && (type == :DRAGON || type == :STEEL)
          when :GRISEOUSORB then basemult*=1.2 if (attacker.pokemon.species == :GIRATINA) && (type == :DRAGON || type == :GHOST)
          when :SOULDEW then basemult*=1.2 if (attacker.pokemon.species == :LATIAS || attacker.pokemon.species == :LATIOS) && (type == :DRAGON || type == :PSYCHIC)
        end
      end
    end
    basemult=pbBaseDamageMultiplier(basemult,attacker,opponent)
    # standard crest damage multipliers
    if attacker.crested
      case attacker.species
      when :FERALIGATR then basemult*=1.5 if (PBStuff::BITEMOVE).include?(@move) 
      when :CLAYDOL then basemult*=1.5 if isBeamMove?
      when :DRUDDIGON then basemult*=1.3 if (type == :DRAGON || type == :FIRE)
      when :BOLTUND then basemult*=1.5 if (PBStuff::BITEMOVE).include?(@move) && (!(opponent.hasMovedThisRound?) || @battle.switchedOut[opponent.index])
      when :DUSKNOIR
        basemult*=1.5 if (basedmg<=60 || @battle.FE == :FACTORY && basedmg<=80)
      end
    end
    #type mods
    case type
      when :FIRE then basemult*=0.33 if @battle.state.effects[:WaterSport]>0
      when :ELECTRIC 
        basemult*=0.33 if @battle.state.effects[:MudSport]>0
        basemult*=2.0 if attacker.effects[:Charge]>0
      when :DARK 
        basemult*= (@battle.pbCheckGlobalAbility(:AURABREAK) ? 0.66 : 1.33) if @battle.pbCheckGlobalAbility(:DARKAURA)
        basemult*= (@battle.pbCheckGlobalAbility(:AURABREAK) ? 0.6 : 1.4) if @battle.pbCheckGlobalAbility(:DARKAURA) && @battle.FE==:DARKNESS1
        basemult*= (@battle.pbCheckGlobalAbility(:AURABREAK) ? 0.5 : 1.5) if @battle.pbCheckGlobalAbility(:DARKAURA) && @battle.FE==:DARKNESS2
        basemult*= (@battle.pbCheckGlobalAbility(:AURABREAK) ? 0.33 : 1.66) if @battle.pbCheckGlobalAbility(:DARKAURA) && @battle.FE==:DARKNESS3
      when :FAIRY 
        basemult*= (@battle.pbCheckGlobalAbility(:AURABREAK) ? 0.66 : 1.33) if @battle.pbCheckGlobalAbility(:FAIRYAURA)
        basemult*= (@battle.pbCheckGlobalAbility(:AURABREAK) ? 0.7 : 1.30) if @battle.pbCheckGlobalAbility(:FAIRYAURA)&& @battle.FE==:DARKNESS1
        basemult*= (@battle.pbCheckGlobalAbility(:AURABREAK) ? 0.8 : 1.2) if @battle.pbCheckGlobalAbility(:FAIRYAURA)&& @battle.FE==:DARKNESS2
        basemult*= (@battle.pbCheckGlobalAbility(:AURABREAK) ? 0.9 : 1.1) if @battle.pbCheckGlobalAbility(:FAIRYAURA)&& @battle.FE==:DARKNESS3
    end
    basemult*=1.5 if attacker.effects[:HelpingHand]
    basemult*=1.5 if @move == :KNOCKOFF && !opponent.item.nil? && !@battle.pbIsUnlosableItem(opponent,opponent.item)
    basemult*=2.0 if opponent.effects[:Minimize] && @move == :MALICIOUSMOONSAULT # Minimize for z-move
    #Specific Field Effects
    if @battle.field.isFieldEffect?
      fieldmult = moveFieldBoost
      if fieldmult != 1
        basemult*=fieldmult
        fieldmessage =moveFieldMessage
        if fieldmessage && !@fieldmessageshown
          if [:LIGHTTHATBURNSTHESKY,:ICEHAMMER,:HAMMERARM,:CRABHAMMER].include?(@move) #some moves have a {1} in them and we gotta deal.
            @battle.pbDisplay(_INTL(fieldmessage,attacker.pbThis))
          elsif [:SMACKDOWN,:THOUSANDARROWS,:VITALTHROW,:CIRCLETHROW,:STORMTHROW,:DOOMDUMMY,:BLACKHOLEECLIPSE,:TECTONICRAGE,:CONTINENTALCRUSH,:WHIRLWIND,:CUT].include?(@move)
            @battle.pbDisplay(_INTL(fieldmessage,opponent.pbThis))
          else
            @battle.pbDisplay(_INTL(fieldmessage))
          end
          @fieldmessageshown = true
        end
      end
    end
    case @battle.FE
      when :CHESS
        if (CHESSMOVES).include?(@move)
          basemult*=0.5 if [:ADAPTABILITY,:ANTICIPATION,:SYNCHRONIZE,:TELEPATHY].include?(opponent.ability)
          basemult*=2.0 if [:OBLIVIOUS,:KLUTZ,:UNAWARE,:SIMPLE].include?(opponent.ability) || opponent.effects[:Confusion]>0 || (Rejuv && opponent.ability == :DEFEATIST)
          @battle.pbDisplay("The chess piece slammed forward!") if !@fieldmessageshown
          @fieldmessageshown = true
        end
        # Queen piece boost
        if attacker.pokemon.piece==:QUEEN || attacker.ability == :QUEENLYMAJESTY
          basemult*=1.5
          if attacker.pokemon.piece==:QUEEN
            @battle.pbDisplay("The Queen is dominating the board!")  && !@fieldmessageshown
            @fieldmessageshown = true
          end
        end

        #Knight piece boost
        if attacker.pokemon.piece==:KNIGHT && opponent.pokemon.piece==:QUEEN
          basemult=(basemult*3.0).round
          @battle.pbDisplay("An unblockable attack on the Queen!") if !@fieldmessageshown
          @fieldmessageshown = true
        end
      when :BIGTOP
        if ((type == :FIGHTING && pbIsPhysical?(type)) || (PBFields::STRIKERMOVES).include?(@move)) # Continental Crush
          striker = 1+@battle.pbRandom(14)
          @battle.pbDisplay("WHAMMO!") if !@fieldmessageshown
          @fieldmessageshown = true
          if attacker.ability == :HUGEPOWER || attacker.ability == :GUTS || attacker.ability == :PUREPOWER || attacker.ability == :SHEERFORCE
            if striker >=9
              striker = 15
            else
              striker = 14
            end
          end
          strikermod = attacker.stages[PBStats::ATTACK]
          striker = striker + strikermod
          if striker >= 15
            @battle.pbDisplay("...OVER 9000!!!")
            provimult=3.0
          elsif striker >=13
            @battle.pbDisplay("...POWERFUL!")
            provimult=2.0
          elsif striker >=9
            @battle.pbDisplay("...NICE!")
            provimult=1.5
          elsif striker >=3
            @battle.pbDisplay("...OK!")
            provimult=1
          else
            @battle.pbDisplay("...WEAK!")
            provimult=0.5
          end
          provimult = ((provimult-1.0)/2.0)+1.0 if $game_variables[:DifficultyModes]==:EASY
          basemult*=provimult
        end
        if isSoundBased?
          provimult=1.5
          provimult=1.25 if $game_variables[:DifficultyModes]==:EASY
          basemult*=provimult
          @battle.pbDisplay("Loud and clear!") if !@fieldmessageshown
          @fieldmessageshown = true
        end
      when :ICY
        if (@priority >= 1 && @basedamage > 0 && contactMove? && attacker.ability != :LONGREACH) || (@move == :FEINT || @move == :ROLLOUT || @move == :DEFENSECURL || @move == :STEAMROLLER || @move == :LUNGE)
          if !attacker.isAirborne?
            if attacker.pbCanIncreaseStatStage?(PBStats::SPEED)
              attacker.pbIncreaseStatBasic(PBStats::SPEED,1)
              @battle.pbCommonAnimation("StatUp",attacker,nil)
              @battle.pbDisplay(_INTL("{1} gained momentum on the ice!",attacker.pbThis)) if !@fieldmessageshown
              @fieldmessageshown = true
            end
          end
        end
      when :SHORTCIRCUIT
        if type == :ELECTRIC
          damageroll = @battle.field.getRoll(maximize_roll:(@battle.state.effects[:ELECTERRAIN] > 0))
          messageroll = ["Bzzt.", "Bzzapp!" , "Bzt...", "Bzap!", "BZZZAPP!"][PBStuff::SHORTCIRCUITROLLS.index(damageroll)]

          @battle.pbDisplay(messageroll) if !@fieldmessageshown
          damageroll = ((damageroll-1.0)/2.0)+1.0 if $game_variables[:DifficultyModes]==:EASY
          basemult*=damageroll

          @fieldmessageshown = true
        end
      when :CAVE
        if isSoundBased?
          provimult=1.5
          provimult=1.25 if $game_variables[:DifficultyModes]==:EASY
          basemult*=provimult
          @battle.pbDisplay(_INTL("ECHO-Echo-echo!",opponent.pbThis)) if !@fieldmessageshown
          @fieldmessageshown = true
        end
      when :MOUNTAIN
        if (PBFields::WINDMOVES).include?(@move) && @battle.pbWeather== :STRONGWINDS
          provimult=1.5
          provimult=1.25 if $game_variables[:DifficultyModes]==:EASY
          basemult*=provimult
          @battle.pbDisplay(_INTL("The wind strengthened the attack!",opponent.pbThis)) if !@fieldmessageshown
          @fieldmessageshown = true
        end
      when :SNOWYMOUNTAIN
        if (PBFields::WINDMOVES).include?(@move) && @battle.pbWeather== :STRONGWINDS
          provimult=1.5
          provimult=1.25 if $game_variables[:DifficultyModes]==:EASY
          basemult*=provimult
          @battle.pbDisplay(_INTL("The wind strengthened the attack!",opponent.pbThis)) if !@fieldmessageshown
          @fieldmessageshown = true
        end
      when :MIRROR
        if (PBFields::MIRRORMOVES).include?(@move) && opponent.stages[PBStats::EVASION]>0
          provimult=2.0
          provimult=1.5 if $game_variables[:DifficultyModes]==:EASY
          basemult*=provimult
          @battle.pbDisplay(_INTL("The beam was focused from the reflection!",opponent.pbThis)) if !@fieldmessageshown
          @fieldmessageshown = true
        end
        @battle.field.counter = 0
      when :DEEPEARTH
        if (priorityCheck(user) > 0) && @basedamage > 0
          provimult=0.7
          provimult=0.85 if $game_variables[:DifficultyModes]==:EASY
          basemult*=provimult
          @battle.pbDisplay(_INTL("The intense pull slowed the attack...")) if !@fieldmessageshown
          @fieldmessageshown = true
        end
        if (priorityCheck(user) < 0) && @basedamage > 0
          provimult=1.3
          provimult=1.15 if $game_variables[:DifficultyModes]==:EASY
          basemult*=provimult
          @battle.pbDisplay(_INTL("Slow and heavy!")) if !@fieldmessageshown
          @fieldmessageshown = true
        end
      when :CONCERT1,:CONCERT2,:CONCERT3,:CONCERT4
        if isSoundBased?
          provimult=1.5
          provimult=1.25 if $game_variables[:DifficultyModes]==:EASY
          basemult*=provimult
          @battle.pbDisplay(_INTL("Loud and clear!")) if !@fieldmessageshown
          @fieldmessageshown = true
        end
      when :DARKNESS3,:DARKNESS2
        if [:LIGHTTHATBURNSTHESKY].include?(@move)
          @battle.pbDisplay(_INTL("One brings Shadow, One brings the Light!")) if !@fieldmessageshown
          @fieldmessageshown = true
        end
    end
    if Rejuv
      for terrain in [:ELECTERRAIN,:GRASSY,:MISTY,:PSYTERRAIN]
        if @battle.state.effects[terrain] > 0
          overlaymult = moveOverlayBoost(terrain)
          if overlaymult != 1
            basemult*=overlaymult
            overlaymessage = moveOverlayMessage(terrain)
            @battle.pbDisplay(_INTL(overlaymessage)) if overlaymessage
          end
        end
      end
    end
    #End S.Field Effects
    ##### Calculate attacker's attack stat #####
    case @function
      when 0x121 # Foul Play
        atk=opponent.attack
        atkstage=opponent.stages[PBStats::ATTACK]+6
      when 0x184 # Body Press
        atk=attacker.defense
        atkstage=attacker.stages[PBStats::DEFENSE]+6
      else
        atk=attacker.attack
        atkstage=attacker.stages[PBStats::ATTACK]+6
    end
    if pbIsSpecial?(type)
      atk=attacker.spatk
      atkstage=attacker.stages[PBStats::SPATK]+6
      if @function==0x121 # Foul Play
        atk=opponent.spatk
        atkstage=opponent.stages[PBStats::SPATK]+6
      end
      if @battle.FE == :GLITCH
				atk = attacker.getSpecialStat(opponent.ability == :UNAWARE)
				atkstage = 6 #getspecialstat handles unaware
			end
    end
    if opponent.ability != :UNAWARE || opponent.moldbroken
      atkstage=6 if opponent.damagestate.critical && atkstage<6
      atk=(atk*1.0*stagemul[atkstage]/stagediv[atkstage]).floor
    end
    if attacker.ability == :UNAWARE 
       atkstage=attacker.stages[PBStats::ATTACK]+6
       atk=(atk*1.0*stagemul[atkstage]/stagediv[atkstage]).floor
    end
    # Stat-Copy Crests, ala Claydol//Dedenne
    if attacker.crested 
      case attacker.species 
      when :CLAYDOL then atkstage=attacker.stages[PBStats::DEFENSE]+6 if pbIsSpecial?(type)
      when :DEDENNE then atkstage=attacker.stages[PBStats::SPEED]+6 if !pbIsSpecial?(type)
      end
    end
    if attacker.ability == :HUSTLE && pbIsPhysical?(type)
      atk=(atk*1.5).round
    end
    atkmult=1.0
    if @battle.FE == :HAUNTED || @battle.FE == :BEWITCHED || @battle.FE == :HOLY || @battle.FE == :PSYTERRAIN || @battle.FE == :DEEPEARTH
      atkmult*=1.5 if attacker.pbPartner.ability == :POWERSPOT
    else
      atkmult*=1.3 if attacker.pbPartner.ability == :POWERSPOT
    end
    #pinch abilities
    if (@battle.FE == :BURNING || @battle.FE == :VOLCANIC || @battle.FE == :INFERNAL) && (attacker.ability == :BLAZE && type == :FIRE)
      atkmult*=1.5
    elsif @battle.FE == :VOLCANICTOP && (attacker.ability == :BLAZE && type == :FIRE) && attacker.effects[:Blazed]
      atkmult*=1.5
    elsif (@battle.FE == :FOREST || (Rejuv && @battle.FE == :GRASSY)) && (attacker.ability == :OVERGROW && type == :GRASS)
      atkmult*=1.5
    elsif @battle.FE == :FOREST && (attacker.ability == :SWARM && type == :BUG)
      atkmult*=1.5
    elsif (@battle.FE == :WATERSURFACE || @battle.FE == :UNDERWATER) && (attacker.ability == :TORRENT && type == :WATER)
      atkmult*=1.5
    elsif @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN) && (attacker.ability == :SWARM && type == :BUG)
      atkmult*=1.5 if @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN,1,2)
      atkmult*=1.8 if @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN,3,4)
      atkmult*=2.0 if @battle.FE == :FLOWERGARDEN5
    elsif @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN,2,5) && (attacker.ability == :OVERGROW && type == :GRASS)
      case @battle.FE
        when :FLOWERGARDEN2 then atkmult*=1.5 if attacker.hp<=(attacker.totalhp*0.67).floor
        when :FLOWERGARDEN3 then atkmult*=1.6
        when :FLOWERGARDEN4 then atkmult*=1.8
        when :FLOWERGARDEN5 then atkmult*=2.0
      end
    elsif attacker.hp<=(attacker.totalhp/3.0).floor
      if (attacker.ability == :OVERGROW && type == :GRASS) || (attacker.ability == :BLAZE && type == :FIRE && @battle.FE != :FROZENDIMENSION) ||
        (attacker.ability == :TORRENT && type == :WATER) || (attacker.ability == :SWARM && type == :BUG)
        atkmult*=1.5
      end
	  # Warden Pinch Abilities #
	  ward_combo = [[:ORN_STARSTRUCK,:COSMIC],[:ORN_IRRADIATE,:LIGHT],[:ORN_MAESTRO,:SOUND],[:ORN_SPELLCASTER,:PSYCHIC]]
	  for w in 0...ward_combo.length
	    atkmult *= 1.5 if attacker.ability == ward_combo[w][0] && type == ward_combo[w][1]
	  end
	  # Warden Pinch Abilities #
    end
    case attacker.ability
      when :GUTS then atkmult*=1.5 if !attacker.status.nil? && pbIsPhysical?(type)
      when :PLUS, :MINUS
        if pbIsSpecial?(type) && @battle.FE != :GLITCH
          partner=attacker.pbPartner
          if partner.ability == :PLUS || partner.ability == :MINUS
            atkmult*=1.5
          elsif @battle.FE == :SHORTCIRCUIT || (Rejuv && @battle.FE == :ELECTERRAIN) || @battle.state.effects[:ELECTERRAIN] > 0
            atkmult*=1.5
          end
        end
      when :DEFEATIST then atkmult*=0.5 if attacker.hp<=(attacker.totalhp/2.0).floor
      when :HUGEPOWER then atkmult*=2.0 if pbIsPhysical?(type)
      when :PUREPOWER
        if @battle.FE == :PSYTERRAIN || @battle.state.effects[:PSYTERRAIN] > 0
          atkmult*=2.0 if pbIsSpecial?(type)
        else
          atkmult*=2.0 if pbIsPhysical?(type)
        end
      when :SOLARPOWER then atkmult*=1.5 if (@battle.pbWeather== :SUNNYDAY && !(attitemworks && attacker.item == :UTILITYUMBRELLA)) && pbIsSpecial?(type) && (@battle.FE != :GLITCH &&  @battle.FE != :FROZENDIMENSION)
      when :SLOWSTART then atkmult*=0.5 if attacker.turncount<5 && pbIsPhysical?(type) && !@battle.FE == :DEEPEARTH
      when :GORILLATACTICS then atkmult*=1.5 if pbIsPhysical?(type)
      # Gen 9 Mod - Added Protosynthesis, Hadron Engine and Orichalcum Pulse
      when :ORN_PROTOSYNTHESIS then atkmult*=1.3 if (attacker.effects[:Protosynthesis][0] == PBStats::ATTACK && pbIsPhysical?(type)) || (attacker.effects[:Protosynthesis][0] == PBStats::SPATK && pbIsSpecial?(type))
      when :ORN_ORICHALCUMPULSE then atkmult*=(5461/4096.to_f) if (@battle.pbWeather== :SUNNYDAY && pbIsPhysical?(type)) &&  @battle.FE != :FROZENDIMENSION
      when :ORN_HADRONENGINE then atkmult*=(5461/4096.to_f) if ((@battle.FE == :ELECTERRAIN || @battle.state.effects[:ELECTERRAIN] > 0) && pbIsSpecial?(type)) &&  @battle.FE != :FROZENDIMENSION
    end
    # Mid Battle stat multiplying crests; Spiritomb Crest, Castform Crest
    if attacker.crested
      case attacker.species
      when :CASTFORM then atkmult*=1.5 if (@battle.pbWeather== :SUNNYDAY && !(attitemworks && attacker.item == :UTILITYUMBRELLA)) && pbIsSpecial?(type) && (@battle.FE != :GLITCH &&  @battle.FE != :FROZENDIMENSION)
      when :SPIRITOMB
          allyfainted = attacker.pbFaintedPokemonCount
          modifier = (allyfainted * 0.2) + 1.0
          atkmult=(atkmult*modifier).round
      end
    end
    if ((@battle.pbWeather== :SUNNYDAY && !(attitemworks && attacker.item == :UTILITYUMBRELLA)) || @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN) || @battle.FE == :BEWITCHED) && pbIsPhysical?(type)
      atkmult*=1.5 if attacker.ability == :FLOWERGIFT || attacker.pbPartner.ability == :FLOWERGIFT
    end
    if (@battle.pbWeather== :SUNNYDAY) && pbIsPhysical?(type)
      atkmult*=1.5 if attacker.ability == :SOLARIDOL 
    end
    if (@battle.pbWeather== :HAIL) && pbIsSpecial?(type)
      atkmult*=1.5 if attacker.ability == :LUNARIDOL
    end
    if attacker.pbPartner.ability == (:BATTERY) && pbIsSpecial?(type) && @battle.FE != :GLITCH
      if Rejuv && @battle.FE == :ELECTERRAIN
        atkmult*=1.5
      else
        atkmult*=1.3
      end
    end
    if @battle.FE == :FAIRYTALE
      atkmult*=2.0 if (attacker.pbPartner.ability == :STEELYSPIRIT || attacker.ability == :STEELYSPIRIT) && type == :STEEL
    else
      atkmult*=1.5 if (attacker.pbPartner.ability == :STEELYSPIRIT || attacker.ability == :STEELYSPIRIT) && type == :STEEL
    end
    atkmult*=1.5 if attacker.effects[:FlashFire] && type == :FIRE && @battle.FE != :FROZENDIMENSION

    if attitemworks
      case attacker.item
        when :THICKCLUB then atkmult*=2.0 if attacker.pokemon.species == :CUBONE || attacker.pokemon.species == :MAROWAK && pbIsPhysical?(type)
        when :DEEPSEATOOTH then atkmult*=2.0 if attacker.pokemon.species == :CLAMPERL && pbIsSpecial?(type) && @battle.FE != :GLITCH
        when :LIGHTBALL then atkmult*=2.0 if attacker.pokemon.species == :PIKACHU && @battle.FE != :GLITCH
        when :CHOICEBAND then atkmult*=1.5 if pbIsPhysical?(type)
        when :CHOICESPECS then atkmult*=1.5 if pbIsSpecial?(type) && @battle.FE != :GLITCH
      end
    end
    if @battle.FE != :INDOOR
      if @battle.FE == :STARLIGHT || @battle.FE == :NEWWORLD
        if attacker.ability == :VICTORYSTAR
          atkmult*=1.5
        end
        partner=attacker.pbPartner
        if partner && partner.ability == :VICTORYSTAR
          atkmult*=1.5
        end
      end
      if @battle.FE == :WATERSURFACE
        atkmult*=1.5 if attacker.ability == :PROPELLERTAIL && @priority >= 1 && @basedamage > 0
      end
      if @battle.FE == :UNDERWATER 
        atkmult*=0.5 if pbIsPhysical?(type) && type != :WATER && attacker.ability != :STEELWORKER && attacker.ability != :SWIFTSWIM
        atkmult*=1.5 if attacker.ability == :PROPELLERTAIL && @priority >= 1 && @basedamage > 0
      end
      if Rejuv && @battle.FE == :CHESS
        atkmult*=1.2 if attacker.ability == :GORILLATACTICS || attacker.ability == :RECKLESS
        atkmult*=1.2 if attacker.ability == :ILLUSION && attacker.effect[:Illusion]!=nil
        if attacker.ability == :COMPETITIVE
          frac = (1.0*attacker.hp)/(1.0*attacker.totalhp)
          multiplier = 1.0  
          multiplier += ((1.0-frac)/0.8)  
          if frac < 0.2  
            multiplier = 2.0  
          end  
          atkmult=(atkmult*multiplier)
        end
      end
      case attacker.ability
        when :QUEENLYMAJESTY then atkmult*=1.5 if @battle.FE == :FAIRYTALE
        when :LONGREACH then atkmult*=1.5 if (@battle.FE == :MOUNTAIN || @battle.FE == :SNOWYMOUNTAIN || @battle.FE == :SKY)
        when :CORROSION then atkmult*=1.5 if (@battle.FE == :CORROSIVE || @battle.FE == :CORROSIVEMIST || @battle.FE == :CORRUPTED)
        when :SKILLLINK then atkmult*=1.2 if (@battle.FE == :COLOSSEUM && (@function == 0xC0 || @function == 0x307 || (attacker.species == :CINCCINO && attacker.crested && !pbIsMultiHit))) #0xC0: 2-5 hits; 0x307: Scale Shot
      end
    end
    atkmult*=0.5 if opponent.ability == :THICKFAT && (type == :ICE || type == :FIRE) && !(opponent.moldbroken)

    ##### Calculate opponent's defense stat #####
    defense=opponent.defense
    defstage=opponent.stages[PBStats::DEFENSE]+6
    # TODO: Wonder Room should apply around here
    
    applysandstorm=false
    if pbHitsSpecialStat?(type)
      defense=opponent.spdef
      defstage=opponent.stages[PBStats::SPDEF]+6
      applysandstorm=true
      if @battle.FE == :GLITCH
        defense = opponent.getSpecialStat(attacker.ability == :UNAWARE)
        defstage = 6 # getspecialstat handles unaware
        applysandstorm=false # getSpecialStat handles sandstorm
      end
    end
    if attacker.ability != :UNAWARE
      defstage=6 if @function==0xA9 # Chip Away (ignore stat stages)
      defstage=6 if opponent.damagestate.critical && defstage>6
      defense=(defense*1.0*stagemul[defstage]/stagediv[defstage]).floor
    end
    if @battle.pbWeather== :SANDSTORM && opponent.hasType?(:ROCK) && applysandstorm
      defense=(defense*1.5).round
    end
    defmult=1.0
    defmult*=0.5 if @battle.FE == :GLITCH && @function==0xE0
    # Field Effect defense boost
    defmult*=fieldDefenseBoost(type,opponent)

    #Abilities defense boost
    case opponent.ability
      when :ICESCALES then defmult*=2.0 if pbIsSpecial?(type) && !(opponent.moldbroken)
      when :MARVELSCALE then defmult*=1.5 if (pbIsPhysical?(type) && (!opponent.status.nil? || ([:MISTY,:RAINBOW,:FAIRYTALE,:DRAGONSDEN,:STARLIGHT].include?(@battle.FE) || @battle.state.effects[:MISTY] > 0))) && !(opponent.moldbroken)
      when :GRASSPELT then defmult*=1.5 if pbIsPhysical?(type) && (@battle.FE == :GRASSY || @battle.FE == :FOREST || @battle.state.effects[:GRASSY] > 0) # Grassy Field
      when :FURCOAT then defmult*=2.0 if pbIsPhysical?(type) && !(opponent.moldbroken)
      when :PUNKROCK then defmult*=2.0 if isSoundBased? && !(opponent.moldbroken)
      when :FLUFFY
        defmult*=2.0 if contactMove? && attacker.ability != :LONGREACH && !(opponent.moldbroken)
        defmult*=4.0 if contactMove? && attacker.ability != :LONGREACH && @battle.FE == :CLOUDS  && !(opponent.moldbroken)
        defmult*=0.5 if type == :FIRE && !(opponent.moldbroken)
    end
    if ((@battle.pbWeather== :SUNNYDAY && !opponent.hasWorkingItem(:UTILITYUMBRELLA)) || @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN) || @battle.FE == :BEWITCHED) && !(opponent.moldbroken) && pbIsSpecial?(type)
      if opponent.ability == :FLOWERGIFT && opponent.species == :CHERRIM
        defmult*=1.5
      end
      if opponent.pbPartner.ability == :FLOWERGIFT  && opponent.pbPartner.species == :CHERRIM
        defmult*=1.5
      end
    end
    #Item defense boost
    if opponent.hasWorkingItem(:EVIOLITE) && !(@battle.FE == :GLITCH && pbIsSpecial?(type)) 
      evos=pbGetEvolvedFormData(opponent.pokemon.species)
      if evos && evos.length>0
        defmult*=1.5
      end
    end
    if opponent.item == :PIKANIUMZ && opponent.pokemon.species == :PIKACHU && !(@battle.FE == :GLITCH && pbIsSpecial?(type)) 
      defmult*=1.5
    end
    if opponent.item == :LIGHTBALL && opponent.pokemon.species == :PIKACHU && !(@battle.FE == :GLITCH && pbIsSpecial?(type)) 
      defmult*=1.5
    end
    if opponent.hasWorkingItem(:ASSAULTVEST) && pbIsSpecial?(type) && @battle.FE != :GLITCH
      defmult*=1.5
    end
    if opponent.hasWorkingItem(:DEEPSEASCALE) && @battle.FE != :GLITCH && (opponent.pokemon.species == :CLAMPERL) && pbIsSpecial?(type)
      defmult*=2.0
    end
    if opponent.hasWorkingItem(:METALPOWDER) && (opponent.pokemon.species == :DITTO) && !opponent.effects[:Transform] && pbIsPhysical?(type)
      defmult*=2.0
    end

    #General damage modifiers
    damage = 1.0
    # Multi-targeting attacks
    if pbTargetsAll?(attacker) || attacker.midwayThroughMove
      if attacker.pokemon.piece == :KNIGHT && battle.FE == :CHESS && @target==:AllOpposing
        @battle.pbDisplay(_INTL("The knight forked the opponents!")) if !attacker.midwayThroughMove
        damage*=1.25
      else
        damage*=0.75
      end
      attacker.midwayThroughMove = true
    end
    # Field Effects
    fieldBoost = typeFieldBoost(type,attacker,opponent)
    overlayBoost, overlay = typeOverlayBoost(type,attacker,opponent)
    if fieldBoost != 1 || overlayBoost != 1
      if fieldBoost > 1 && overlayBoost > 1
        boost = [fieldBoost,overlayBoost].max
        if $game_variables[:DifficultyModes]==:EASY
          boost = 1.25 if boost < 1.25
        else
          boost = 1.5 if boost < 1.5
        end
      else
        boost = fieldBoost*overlayBoost
      end
      damage*=boost
      fieldmessage = typeFieldMessage(type) if fieldBoost != 1
      overlaymessage = typeOverlayMessage(type,overlay) if overlay
      if overlaymessage && !fieldmessage
        @battle.pbDisplay(_INTL(overlaymessage)) if !@fieldmessageshown_type
      else
        @battle.pbDisplay(_INTL(fieldmessage)) if fieldmessage && !@fieldmessageshown_type
      end
      @fieldmessageshown_type = true
    end
    case @battle.FE
      when :MOUNTAIN,:SNOWYMOUNTAIN
        if type == :FLYING && !pbIsPhysical?(type) && @battle.pbWeather== :STRONGWINDS
          provimult=1.5 
          provimult=1.25 if $game_variables[:DifficultyModes]==:EASY
          damage*=provimult
        end
      when :DEEPEARTH
        if type == :GROUND && opponent.hasType?(:GROUND)
          provimult=0.5
          provimult=0.75 if $game_variables[:DifficultyModes]==:EASY
          damage*=provimult
          @battle.pbDisplay(_INTL("The dense earth is difficult to mold...")) if !@fieldmessageshown_type
          @fieldmessageshown_type = true
        end
    end
    case @battle.pbWeather
      when :SUNNYDAY
        if @battle.state.effects[:HarshSunlight] && type == :WATER
          @battle.pbDisplay(_INTL("The Water-type attack evaporated in the harsh sunlight!"))
          @battle.scene.pbUnVanishSprite(attacker) if @function==0xCB #Dive
          return 0
        end
      when :RAINDANCE
        if @battle.state.effects[:HeavyRain] && type == :FIRE
          @battle.pbDisplay(_INTL("The Fire-type attack fizzled out in the heavy rain!"))
          return 0
        end
    end
    # FIELD TRANSFORMATIONS
    fieldmove = @battle.field.moveData(@move)
    if fieldmove && fieldmove[:fieldchange]
      change_conditions = @battle.field.fieldChangeData
      handled = change_conditions[fieldmove[:fieldchange]] ? eval(change_conditions[fieldmove[:fieldchange]]) : true
      #don't continue if conditions to change are not met or if a multistage field changes to a different stage of itself
      if handled  && !(@battle.ProgressiveFieldCheck("All") && (PBFields::CONCERT.include?(fieldmove[:fieldchange]) || PBFields::FLOWERGARDEN.include?(fieldmove[:fieldchange]) || PBFields::DARKNESS.include?(fieldmove[:fieldchange])))
        provimult=1.3 
        provimult=1.15 if $game_variables[:DifficultyModes]==:EASY
        damage*=provimult
      end
    end
    case @battle.FE
      when :FACTORY
        if (@move == :DISCHARGE) || (@move == :OVERDRIVE)
          @battle.setField(:SHORTCIRCUIT)
          @battle.pbDisplay(_INTL("The field shorted out!"))
          provimult=1.3 
          provimult=1.15 if $game_variables[:DifficultyModes]==:EASY
          damage*=provimult
        end
      when :SHORTCIRCUIT
        if (@move == :DISCHARGE) || (@move == :OVERDRIVE)
          @battle.setField(:FACTORY)
          @battle.pbDisplay(_INTL("SYSTEM ONLINE."))
          provimult=1.3 
          provimult=1.15 if $game_variables[:DifficultyModes]==:EASY
          damage*=provimult
        end
    end

    case type
      when :FIRE
        damage*=1.5 if @battle.weather == :SUNNYDAY
        damage*=0.5 if @battle.weather == :RAINDANCE
        damage*=0.5 if opponent.ability == :WATERBUBBLE
      when :WATER
        damage*=1.5 if @battle.weather == :RAINDANCE
        damage*=0.5 if @battle.weather == :SUNNYDAY
        damage*=2 if attacker.ability == :WATERBUBBLE
    end
    if attacker.species == :FEAROW && attacker.crested # fearow crest
      if attacker.ability == (:SNIPER)
        damage=(damage*1.5).round
      end
    end
    # Critical hits
    if opponent.damagestate.critical
      damage*=1.5
      damage*=1.5 if attacker.ability == :SNIPER && !(attacker.species == :FEAROW && attacker.crested)
    end
    # STAB-addition from Crests 
    typecrest = false
    if attacker.crested
      case attacker.species
      when :EMPOLEON then typecrest = true if type == :ICE
      when :LUXRAY then typecrest = true if type == :DARK
      when :SAMUROTT then typecrest = true if type == :FIGHTING
      when :NOCTOWL then typecrest = true if type == :PSYCHIC
      end
    end
    # STAB
    if (attacker.hasType?(type) || (attacker.ability == :STEELWORKER && type == :STEEL)  || (attacker.ability == :SOLARIDOL && type == :FIRE) || (attacker.ability == :LUNARIDOL && type == :ICE) || (attacker.ability == :ORN_ROCKYPAYLOAD && type == :ROCK) || typecrest==true) 
      if attacker.ability == :ADAPTABILITY
        damage*=2.0
      elsif (attacker.ability == :STEELWORKER && type == :STEEL) && @battle.FE == :FACTORY # Factory Field
        damage*=2.0
      else
        damage*=1.5
      end
    end
    # Type effectiveness
    typemod=pbTypeModMessages(type,attacker,opponent)
    damage=(damage*typemod/4.0)
    opponent.damagestate.typemod=typemod
    if typemod==0
      opponent.damagestate.calcdamage=0
      opponent.damagestate.critical=false
      return 0
    end
    damage*=0.5 if attacker.status== :BURN && pbIsPhysical?(type) && attacker.ability != :GUTS && @move != :FACADE
    # Random Variance
    if !$game_switches[:No_Damage_Rolls] || @battle.isOnline?
      random = 85+@battle.pbRandom(16)
    elsif $game_switches[:No_Damage_Rolls] || !@battle.isOnline?
      random = 93
    end
    random = 85 if @battle.FE == :CONCERT1
    random = 100 if @battle.FE == :CONCERT4
    damage = (damage*(random/100.0))

    # Final damage modifiers
    finalmult=1.0
    if !opponent.damagestate.critical && attacker.ability != :INFILTRATOR
      # Screens
      if @category!=:status && opponent.pbOwnSide.screenActive?(betterCategory(type))
        finalmult*= (!opponent.pbPartner.isFainted? || attacker.midwayThroughMove) ? 0.66 : 0.5
      end
      if opponent.pbOwnSide.effects[:AreniteWall] > 0 && opponent.damagestate.typemod>4
        finalmult*= 0.5
      end
    end
	
	# Warden Abilities #
	case attacker.ability
      when :ORN_REQUIEM       then basemult *= 1.5 if type == :DARK
      when :ORN_AFFECTION     then basemult *= 1.5 if type == :FAIRY
      when :ORN_ARSONIST      then basemult *= 1.5 if type == :FIRE
      when :ORN_VIRTUOSO      then basemult *= 1.5 if type == :SOUND
      when :ORN_HIVEMIND      then basemult *= 1.5 if type == :BUG
      when :ORN_BONECOLLECTOR then basemult *= 1.5 if type == :GROUND
      when :ORN_HAUNTED       then basemult *= 1.5 if type == :GHOST
	  when :ORN_BLACKLIGHT    then basemult *= 1.2 if type == :DARK
	  when :ORN_WHITEOUT      then basemult *= 1.2 if type == :LIGHT
	  when :ORN_DARKMATTER    then basemult *= 1.2 if type == :COSMIC
      when :ORN_CANNONFIRE    then basemult *= 1.5 if pbStuff::BULLETMOVE.include?(@move)
      when :ORN_ICYVEINS      then basemult *= 1.3 if @battle.pbWeather == :HAIL && [:WATER,:ICE].include?(type)
      when :ORN_ATTUNEMENT    then atkmult *= 1.5  if !attacker.status.nil? && pbIsSpecial?(type)
      when :ORN_TORMENTED     then atkmult *= 1.5  if pbIsSpecial?(type)
      when :ORN_GENIUS        then atkmult *= 2.0  if pbIsSpecial?(type)
	end
    atkmult*=0.5 if opponent.ability == :ORN_REALISM && [:GHOST,:FAIRY].include?(type) && !(opponent.moldbroken)
    atkmult*=0.5 if opponent.ability == :ORN_ASTRALMAJESTY && [:LIGHT,:DRGON].include?(type) && !(opponent.moldbroken)
    atkmult*=0.5 if opponent.ability == :ORN_IRREDEEMABLE && [:LIGHT,:FAIRY].include?(type) && !(opponent.moldbroken)
    atkmult*=0.5 if opponent.ability == :ORN_TROPICALHIDE && [:GRASS,:WATER].include?(type) && !(opponent.moldbroken)
    atkmult*=0.5 if opponent.ability == :ORN_LIGHTBULB && [:DARK].include?(type) && !(opponent.moldbroken)
    atkmult*=0.5 if opponent.ability == :ORN_TERRORIZE && [:BUG].include?(type) && !(opponent.moldbroken)
    atkmult*=0.5 if opponent.ability == :ORN_WINDFURY && pbStuff::WINDMOVE.include?(@move) && !(opponent.moldbroken)
	atkmult*=1.5 if attacker.ability == :ORN_WINTERGIFT || attacker.pbPartner.ability == :ORN_WINTERGIFT
	defmult*=1.5 if attacker.ability == :ORN_WINTERGIFT || attacker.pbPartner.ability == :ORN_WINTERGIFT
    if type == :LIGHT && @battle.pbCheckGlobalAbility(:ORN_LIGHTAURA)
      auramult = 1.33
      basemult *= @battle.pbCheckGlobalAbility(:AURABREAK) ? 2 - auramult : auramult
    end
    finalmult *= 0.75 if (((opponent.ability == :ORN_PACKEDSNOW) && !opponent.moldbroken)) && pbWeather == :HAIL && opponent.damagestate.typemod > 4
	# Warden Abilities #

    # Final damage modifiers
    finalmult*=0.5 if ((opponent.ability == :MULTISCALE && !(opponent.moldbroken)) && opponent.hp==opponent.totalhp)
    finalmult*=0.5 if opponent.ability == :SHADOWSHIELD && (opponent.hp==opponent.totalhp || @battle.FE == :DIMENSIONAL)
    finalmult*=0.33 if opponent.ability == :SHADOWSHIELD && (opponent.hp==opponent.totalhp && (@battle.FE == :DARKNESS2 || @battle.FE == :DARKNESS3 ))
    finalmult*=2.0 if attacker.ability == :TINTEDLENS && opponent.damagestate.typemod<4
    finalmult*=2.0 if attacker.ability == :EXECUTION && (opponent.hp <= (opponent.totalhp/2).floor)
    finalmult*=0.75 if opponent.pbPartner.ability == :FRIENDGUARD && !(opponent.moldbroken)
    finalmult*=0.5 if (opponent.ability == :PASTELVEIL || opponent.pbPartner.ability == :PASTELVEIL) && @type == :POISON && (@battle.FE == :MISTY || @battle.FE == :RAINBOW || (@battle.state.effects[:MISTY] > 0))
    if @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN,3,5)
      if (opponent.pbPartner.ability == :FLOWERVEIL && opponent.hasType?(:GRASS)) || (opponent.ability == :FLOWERVEIL && !(opponent.moldbroken))
        finalmult*=0.5
        @battle.pbDisplay(_INTL("The Flower Veil softened the attack!"))
      end
      if opponent.hasType?(:GRASS)
        case @battle.FE
          when :FLOWERGARDEN3 then finalmult*=0.75
          when :FLOWERGARDEN4 then finalmult*=0.66
          when :FLOWERGARDEN5 then finalmult*=0.5
        end
      end
    end
    finalmult*=0.75 if (((opponent.ability == :SOLIDROCK || opponent.ability == :FILTER) && !opponent.moldbroken) || opponent.ability == :PRISMARMOR) && opponent.damagestate.typemod>4
    finalmult*=0.75 if opponent.ability == :SHADOWSHIELD && [:STARLIGHT, :NEWWORLD, :DARKCRYSTALCAVERN].include?(@battle.FE)
    finalmult*=2.0 if attacker.ability == :STAKEOUT && @battle.switchedOut[opponent.index]
    finalmult*=[1.0+attacker.effects[:Metronome]*0.2,2.0].min if (attitemworks && attacker.item == :METRONOME) && attacker.movesUsed[-2] == attacker.movesUsed[-1]
    finalmult*=[1.0+attacker.effects[:ConcertMetronome]*0.2,2.0].min if @battle.FE == :CONCERT4 && attacker.movesUsed[-2] == attacker.movesUsed[-1]
    finalmult*=1.2 if (attitemworks && attacker.item == :EXPERTBELT) && opponent.damagestate.typemod > 4
    finalmult*=1.25 if (attacker.ability == :NEUROFORCE) && opponent.damagestate.typemod > 4
    finalmult*=1.3 if (attitemworks && attacker.item == :LIFEORB)
    if opponent.damagestate.typemod>4 && opponent.itemWorks?
      hasberry = false
      case type
        when :FIGHTING   then hasberry = (opponent.item == :CHOPLEBERRY)
        when :FLYING     then hasberry = (opponent.item == :COBABERRY)
        when :POISON     then hasberry = (opponent.item == :KEBIABERRY)
        when :GROUND     then hasberry = (opponent.item == :SHUCABERRY)
        when :ROCK       then hasberry = (opponent.item == :CHARTIBERRY)
        when :BUG        then hasberry = (opponent.item == :TANGABERRY)
        when :GHOST      then hasberry = (opponent.item == :KASIBBERRY)
        when :STEEL      then hasberry = (opponent.item == :BABIRIBERRY)
        when :FIRE       then hasberry = (opponent.item == :OCCABERRY)
        when :WATER      then hasberry = (opponent.item == :PASSHOBERRY)
        when :GRASS      then hasberry = (opponent.item == :RINDOBERRY)
        when :ELECTRIC   then hasberry = (opponent.item == :WACANBERRY)
        when :PSYCHIC    then hasberry = (opponent.item == :PAYAPABERRY)
        when :ICE        then hasberry = (opponent.item == :YACHEBERRY)
        when :DRAGON     then hasberry = (opponent.item == :HABANBERRY)
        when :DARK       then hasberry = (opponent.item == :COLBURBERRY)
        when :FAIRY      then hasberry = (opponent.item == :ROSELIBERRY)
        when :COSMIC     then hasberry = (opponent.item == :ORN_OLIBERRY)
        when :LIGHT      then hasberry = (opponent.item == :ORN_PATOTOBERRY)
        when :SOUND      then hasberry = (opponent.item == :ORN_AVOCABERRY)
      end
    end
    hasberry = true if opponent.hasWorkingItem(:CHILANBERRY) && type == :NORMAL
    if hasberry && !([:UNNERVE,:ASONE].include?(attacker.ability) || [:UNNERVE,:ASONE].include?(attacker.pbPartner.ability))
      finalmult*=0.5
      finalmult*=0.5 if opponent.ability == :RIPEN
      opponent.pbDisposeItem(true)
      if !@battle.pbIsOpposing?(attacker.index)
        @battle.pbDisplay(_INTL("{2}'s {1} weakened the damage from the attack!",getItemName(opponent.pokemon.itemRecycle),opponent.pbThis))
      else
        @battle.pbDisplay(_INTL("The {1} weakened the damage to {2}!",getItemName(opponent.pokemon.itemRecycle),opponent.pbThis))
      end
    end
    finalmult*=0.8 if (opponent.crested && opponent.species == :MEGANIUM || opponent.pbPartner.crested && opponent.pbPartner.species == :MEGANIUM)
    if attacker.crested && attacker.species == :SEVIPER
      multiplier = 0.5*(opponent.pokemon.hp*1.0)/(opponent.pokemon.totalhp*1.0)
      multiplier += 1.0
      finalmult=(finalmult*multiplier).round
    end
    finalmult=pbModifyDamage(finalmult,attacker,opponent)
    ##### Main damage calculation #####
    basedmg*=basemult
    atk*=atkmult
    defense*=defmult
    totaldamage=(((((2.0*attacker.level/5+2).floor*basedmg*atk/defense).floor/50.0).floor+1)*damage*finalmult).round
    totaldamage=1 if totaldamage < 1
    opponent.damagestate.calcdamage=totaldamage
    return totaldamage
  end
end

## Cannon Code Overwrite ##
################################################################################
# For 4 more rounds, doubles the Speed of all battlers on the user's side. (Tailwind)
################################################################################
class PokeBattle_Move_05B < PokeBattle_Move
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    if attacker.pbOwnSide.effects[:Tailwind]>0
      @battle.pbDisplay(_INTL("But it failed!"))
      return -1
    end
    pbShowAnimation(@move,attacker,nil,hitnum,alltargets,showanimation)
    attacker.pbOwnSide.effects[:Tailwind]=4
    attacker.pbOwnSide.effects[:Tailwind]=6 if (@battle.FE == :MOUNTAIN || @battle.FE == :SNOWYMOUNTAIN || @battle.FE == :VOLCANICTOP || @battle.FE == :CLOUDS)
    attacker.pbOwnSide.effects[:Tailwind]=8 if @battle.FE == :SKY
    if !@battle.pbIsOpposing?(attacker.index)
      @battle.pbDisplay(_INTL("The tailwind blew from behind your team!"))
    else
      @battle.pbDisplay(_INTL("The tailwind blew from behind the opposing team!"))
    end
    # Gen 9 Mod - Added Wind Power and Wind Rider
    if attacker.pbOwnSide.effects[:Tailwind]>0
      # Gen 9 Mod - Charge lasts until the user uses an electric move.
      if attacker.ability == :WINDPOWER && attacker.effects[:Charge] == false
        attacker.effects[:Charge] = true
        @battle.pbCommonAnimation("Charge",attacker,nil)
        @battle.pbDisplay(_INTL("Being hit by Tailwind charged {1} with power!", attacker.pbThis))
      end
      # Gen 9 Mod - Charge lasts until the user uses an electric move.
      if attacker.pbPartner.ability == :WINDPOWER && attacker.pbPartner.effects[:Charge] == false
        attacker.pbPartner.effects[:Charge] = true
        @battle.pbCommonAnimation("Charge",attacker.pbPartner,nil)
        @battle.pbDisplay(_INTL("Being hit by Tailwind charged {1} with power!", attacker.pbPartner.pbThis))
      end
      if attacker.ability == :ORN_WINDRIDER && attacker.pbCanIncreaseStatStage?(PBStats::ATTACK,false)
        attacker.pbIncreaseStat(PBStats::ATTACK,1)
      end
      if attacker.pbPartner.ability == :ORN_WINDRIDER && attacker.pbPartner.pbCanIncreaseStatStage?(PBStats::ATTACK,false)
        attacker.pbPartner.pbIncreaseStat(PBStats::ATTACK,1)
      end
    end
    if (@battle.FE == :MOUNTAIN || @battle.FE == :SNOWYMOUNTAIN || @battle.FE == :VOLCANICTOP || @battle.FE == :SKY) && !@battle.state.effects[:HeavyRain] && !@battle.state.effects[:HarshSunlight]
      @battle.weather=:STRONGWINDS
      @battle.weatherduration=6
      @battle.weatherduration=8 if @battle.FE == :SKY
      @battle.pbCommonAnimation("Wind",nil,nil)
      @battle.pbDisplay(_INTL("Strong winds kicked up around the field!"))
    end
    return 0
  end
end

class PokeBattle_Move_0FA < PokeBattle_Move # User takes recoil damage equal to the amount specified by the recoil flag.
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    ret=super(attacker,opponent,hitnum,alltargets,showanimation)
    if opponent.damagestate.calcdamage>0 && !opponent.damagestate.substitute && attacker.hasWorkingItem(:ORN_BODYARMOR) &&
       attacker.ability != :ROCKHEAD && !(attacker.species == :RAMPARDOS && attacker.crested) && attacker.ability != :MAGICGUARD &&
       !(@move == :WILDCHARGE && @battle.FE == :ELECTERRAIN) && !(attacker.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
      attacker.pbReduceHP([1,(opponent.damagestate.hplost*hasFlag?(:recoil)).floor].max)
      @battle.pbDisplay(_INTL("{1} is damaged by the recoil!",attacker.pbThis))
    end
    return ret
  end
end

class PokeBattle_Move_0FD < PokeBattle_Move # User takes recoil damage equal to the amount specified by the recoil flag. May paralyze the target. (Volt Tackle)
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    ret=super(attacker,opponent,hitnum,alltargets,showanimation)
    if opponent.damagestate.calcdamage>0 && !opponent.damagestate.substitute && attacker.hasWorkingItem(:ORN_BODYARMOR) &&
       attacker.ability != :ROCKHEAD && !(attacker.species == :RAMPARDOS && attacker.crested) &&
       attacker.ability != :MAGICGUARD && !(attacker.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
       attacker.pbReduceHP([1,(opponent.damagestate.hplost*hasFlag?(:recoil)).floor].max)
      @battle.pbDisplay(_INTL("{1} is damaged by the recoil!",attacker.pbThis))
    end
    return ret
  end
end

class PokeBattle_Move_0FE < PokeBattle_Move # User takes recoil damage equal to the amount specified by the recoil flag. May burn the target. (Flare Blitz)
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    ret=super(attacker,opponent,hitnum,alltargets,showanimation)
    if opponent.damagestate.calcdamage>0 && !opponent.damagestate.substitute && attacker.hasWorkingItem(:ORN_BODYARMOR) &&
       attacker.ability != :ROCKHEAD && !(attacker.species == :RAMPARDOS && attacker.crested) &&
       attacker.ability != :MAGICGUARD && !(attacker.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
      attacker.pbReduceHP([1,(opponent.damagestate.hplost*hasFlag?(:recoil)).floor].max)
      @battle.pbDisplay(_INTL("{1} is damaged by the recoil!",attacker.pbThis))
    end
    return ret
  end
end
## Cannon Code Overwrite ##

##==============##
## Warden Codes ##
##==============##
class PokeBattle_Move_1000 < PokeBattle_Move 
  def pbType(attacker,type=@type)
    type_id = [attacker.moves[0].type,attacker.moves[1].type,attacker.moves[2].type,attacker.moves[3].type]
    if [:ORN_ORIGINALGENESIS,:ORN_ORIGINALGENESIS1,:ORN_ORIGINALGENESIS2,:ORN_ORIGINALGENESIS3].include?(@move)
      type=((@move == :ORN_ORIGINALGENESIS) ? type_id[0] : ((@move == :ORN_ORIGINALGENESIS1) ? type_id[1] : ((@move == :ORN_ORIGINALGENESIS2) ? type_id[2] : ((@move == :ORN_ORIGINALGENESIS3) ? type_id[3] : nil))))
      type=super(attacker,type)
      return type
    else
	  return @type
	end
  end

  def pbEffect(attacker, opponent, hitnum = 0, alltargets = nil, showanimation = true)
    moves = [[:ORN_ASTRALTERRAIN,:ORN_ASTRALSTARSTORM],
             [:ORN_ACRLIGHTTERRAIN,:ORN_ARCLIGHTBARRAGE],
             [:ORN_ACOUSTICTERRAIN,:ORN_ACOUSTICOVERLOAD],
             [:ORN_ORIGINALGENESIS,:ORN_ORIGINALGENESIS1,:ORN_ORIGINALGENESIS2,:ORN_ORIGINALGENESIS3]]
    terrain = ((moves[0].include?(@move)) ? [:ASTRAL,"astronomical"] : 
              ((moves[1].include?(@move)) ? [:ARCLIGHT,"brimming with light"] : 
              ((moves[2].include?(@move)) ? [:ACOUSTIC,"acoustic"] : 
              ((moves[3].include?(@move)) ? [:ORIGIN, "filled with creation energy"] : nil))))
    if terrain != nil
      zmove = [moves[0][1],moves[1][1],moves[2][1],moves[3][0],moves[3][1],moves[3][2],moves[3][3]]
      duration = ((zmove.include?(@move)) ? 50 : ((attacker.hasWorkingItem(:AMPLIFIELDROCK)) ? 8 : 5))
      @battle.setField(terrain[0], duration)
      @battle.pbDisplay(_INTL("The terrain became {1}!",terrain[1]))
      ret = super(attacker, opponent, hitnum, alltargets, showanimation)
      return ret
    else
      ret = super(attacker, opponent, hitnum, alltargets, showanimation)
      @battle.pbDisplay(_INTL("But it failed"))
    end
  end
end

class PokeBattle_Move_1001 < PokeBattle_Move # AlwaysHitsInSandstorm < Battle::Move
  def pbAccuracyCheck(attacker, opponent, precheckedacc: nil)
    return true if @battle.weather == :SANDSTORM
  end
end

class PokeBattle_Move_1002 < PokeBattle_Move # ExtendWeatherTerrainIfTargetFaints < Battle::Move
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    if opponent.isFainted?
      if @battle.weatherduration > 0
        @battle.weatherduration += 1
        @battle.pbDisplay(_INTL("The weather's duration has been extended for an extra turn!"))
      end
      if @battle.field.duration > 0
        @battle.field.duration += 1
        @battle.pbDisplay(_INTL("The terrain's duration has been extended for an extra turn!"))
      end
    end
    return super(attacker,opponent,hitnum,alltargets,showanimation)
  end
end

class PokeBattle_Move_1003 < PokeBattle_Move #ExtraPowerIfEvasion < Battle::Move
  def pbBaseDamage(basedmg,attacker,opponent)
    if opponent.stages[PBStats::EVASION] > 0
      return basedmg*1.5
    end
    return basedmg
  end
end

class PokeBattle_Move_1004 < PokeBattle_Move # HealUserByHalfOfDamageDoneIfTargetAsleep < Battle::Move
  def pbBaseDamage(basedmg,attacker,opponent)
    return basedmg*2 if opponent.status==:SLEEP
    return basedmg
  end

  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    damage = super(attacker,opponent,hitnum,alltargets,showanimation)
    br_effect = (attacker.hasWorkingItem(:BIGROOT) || attacker.crested==:ORN_MEGANIUM) ? true : false
    if opponent.damagestate.calcdamage>0
      hpgain = ((damage + 1) / 2).floor
      if (opponent.ability == :LIQUIDOOZE)
        hpgain*=2 if @battle.FE == :WASTELAND || @battle.FE == :MURKWATERSURFACE || @battle.FE == :CORRUPTED
        attacker.pbReduceHP(hpgain,true)
        @battle.pbDisplay(_INTL("{1} sucked up the liquid ooze!",attacker.pbThis))
      else
        if Rejuv && @battle.FE == :GRASSY
          hpgain=(hpgain*1.6).floor if br_effect
        else
          hpgain=(hpgain*1.3).floor if br_effect
        end
        attacker.pbRecoverHP(hpgain,true)
        @battle.pbDisplay(_INTL("{1} had its energy drained!",opponent.pbThis))
      end
    end
    return damage
  end
end

class PokeBattle_Move_1005 < PokeBattle_Move # InflictRandomStatus < Battle::Move
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
      rnd=@battle.pbRandom(13)
      case rnd
        when 0, 1, 2
          return false if !opponent.pbCanBurn?(false)
          opponent.pbBurn(attacker)
          @battle.pbDisplay(_INTL("{1} was burned!",opponent.pbThis))
        when 3
          return false if !opponent.pbCanFreeze?(false)
          opponent.pbFreeze
          @battle.pbDisplay(_INTL("{1} was frozen solid!",opponent.pbThis))
        when 4, 5, 6
          return false if !opponent.pbCanParalyze?(false)
          opponent.pbParalyze(attacker)
          @battle.pbDisplay(_INTL("{1} is paralyzed! It may be unable to move!",opponent.pbThis))
        when 7, 8, 9, 10
          return false if !opponent.pbCanPoison?(false)
          opponent.pbPoison(attacker)
          @battle.pbDisplay(_INTL("{1} was poisoned!",opponent.pbThis))
        when 11, 12
          return false if !opponent.pbCanSleep?(false)
          opponent.pbSleep
          @battle.pbDisplay(_INTL("{1} fell asleep!",opponent.pbThis))
      end
  end
end

class PokeBattle_Move_1006 < PokeBattle_Move # LowerTargetDefSpDef1 < Battle::Move::TargetMultiStatDownMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    ret=-1; prevented=false
    if opponent.effects[:Protect] && !opponent.effects[:ProtectNegation]
      @battle.pbDisplay(_INTL("{1} protected itself!",opponent.pbThis))
      prevented=true
    end
    if !prevented && opponent.pbOwnSide.effects[:Mist]>0
      @battle.pbDisplay(_INTL("{1} is protected by Mist!",opponent.pbThis))
      prevented=true
    end
    if !prevented && ((((opponent.ability == :CLEARBODY) ||
       (opponent.ability == :WHITESMOKE)) && !(opponent.moldbroken)) || opponent.ability == :FULLMETALBODY)
      @battle.pbDisplay(_INTL("{1}'s {2} prevents stat loss!",opponent.pbThis,
         getAbilityName(opponent.ability)))
      prevented=true
    end
    if !prevented && opponent.pbTooLow?(PBStats::DEFENSE) &&
       opponent.pbTooLow?(PBStats::SPDEF)
      @battle.pbDisplay(_INTL("{1}'s stats won't go any lower!",opponent.pbThis))
      prevented=true
    end
    if !prevented
      pbShowAnimation(@move,attacker,opponent,hitnum,alltargets,showanimation)
      showanim=true
      if (@battle.FE == :FAIRYTALE || @battle.FE == :DRAGONSDEN)  && (@move == :NOBLEROAR)
        if opponent.pbReduceStat(PBStats::DEFENSE,2,false, statdropper: attacker)
          ret=0; showanim=false
        end
        if opponent.pbReduceStat(PBStats::SPDEF,2,false, statdropper: attacker)
          ret=0; showanim=false
        end
      else
        if opponent.pbReduceStat(PBStats::DEFENSE,1,false, statdropper: attacker)
          ret=0; showanim=false
        end
        if opponent.pbReduceStat(PBStats::SPDEF,1,false, statdropper: attacker)
          ret=0; showanim=false
        end
      end
    end
    return ret
  end
end

class PokeBattle_Move_1006 < PokeBattle_Move # LowerTargetDefSpDef1 < Battle::Move::TargetMultiStatDownMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    ret=-1; prevented=false
    if opponent.effects[:Protect] && !opponent.effects[:ProtectNegation]
      @battle.pbDisplay(_INTL("{1} protected itself!",opponent.pbThis))
      prevented=true
    end
    if !prevented && opponent.pbOwnSide.effects[:Mist]>0
      @battle.pbDisplay(_INTL("{1} is protected by Mist!",opponent.pbThis))
      prevented=true
    end
    if !prevented && ((((opponent.ability == :CLEARBODY) ||
       (opponent.ability == :WHITESMOKE)) && !(opponent.moldbroken)) || opponent.ability == :FULLMETALBODY)
      @battle.pbDisplay(_INTL("{1}'s {2} prevents stat loss!",opponent.pbThis,
         getAbilityName(opponent.ability)))
      prevented=true
    end
    if !prevented && opponent.pbTooLow?(PBStats::DEFENSE) &&
       opponent.pbTooLow?(PBStats::SPDEF)
      @battle.pbDisplay(_INTL("{1}'s stats won't go any lower!",opponent.pbThis))
      prevented=true
    end
    if !prevented
      pbShowAnimation(@move,attacker,opponent,hitnum,alltargets,showanimation)
      showanim=true
      if (@battle.FE == :FAIRYTALE || @battle.FE == :DRAGONSDEN)  && (@move == :NOBLEROAR)
        if opponent.pbReduceStat(PBStats::DEFENSE,2,false, statdropper: attacker)
          ret=0; showanim=false
        end
        if opponent.pbReduceStat(PBStats::SPDEF,2,false, statdropper: attacker)
          ret=0; showanim=false
        end
      else
        if opponent.pbReduceStat(PBStats::DEFENSE,1,false, statdropper: attacker)
          ret=0; showanim=false
        end
        if opponent.pbReduceStat(PBStats::SPDEF,1,false, statdropper: attacker)
          ret=0; showanim=false
        end
      end
    end
    return ret
  end
end

class PokeBattle_Move_1007 < PokeBattle_Move # LowerTargetDefSpDef1SwitchOutUser < Battle::Move::TargetMultiStatDownMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    ret=super(attacker,opponent,hitnum,alltargets,showanimation)
    if @battle.FE == :FROZENDIMENSION
      if opponent.pbTooLow?(PBStats::DEFENSE) && opponent.pbTooLow?(PBStats::SPDEF) && opponent.pbTooLow?(PBStats::SPEED)
        @battle.pbDisplay(_INTL("{1}'s stats won't go any lower!",opponent.pbThis))
        return -1
      end
    else
      if opponent.pbTooLow?(PBStats::DEFENSE) && opponent.pbTooLow?(PBStats::SPDEF)
        @battle.pbDisplay(_INTL("{1}'s stats won't go any lower!",opponent.pbThis))
        return -1
      end
    end
    if opponent.pbOwnSide.effects[:Mist]>0
      @battle.pbDisplay(_INTL("{1} is protected by Mist!",opponent.pbThis))
      return -1
    end
    if (((opponent.ability == :CLEARBODY) ||
       (opponent.ability == :WHITESMOKE)) && !(opponent.moldbroken)) || opponent.ability == :FULLMETALBODY
      @battle.pbDisplay(_INTL("{1}'s {2} prevents stat loss!",opponent.pbThis,getAbilityName(opponent.ability)))
      return -1
    end
    pbShowAnimation(@move,attacker,opponent,hitnum,alltargets,showanimation)
    ret=-1; showanim=true
    statdrop = 1
    statdrop = 2 if (@battle.ProgressiveFieldCheck(PBFields::CONCERT) || @battle.FE == :BACKALLEY)
    if opponent.pbReduceStat(PBStats::DEFENSE,statdrop,false, statdropper: attacker)
      ret=0; showanim=false
    end
    if opponent.pbReduceStat(PBStats::SPDEF,statdrop,false, statdropper: attacker)
      ret=0; showanim=false
    end
    if @battle.FE == :FROZENDIMENSION
      if opponent.pbReduceStat(PBStats::SPEED,1,false, statdropper: attacker)
        ret=0; showanim=false
      end
    end
    if attacker.hp>0 && @battle.pbCanChooseNonActive?(attacker.index) && !@battle.pbAllFainted?(@battle.pbParty(opponent.index)) && @battle.FE != :COLOSSEUM
      @battle.pbDisplay(_INTL("{1} went back to {2}!",attacker.pbThis,@battle.pbGetOwner(attacker.index).name))
      #Going to switch, check for pursuit
      newpoke=0
      newpoke=@battle.pbSwitchInBetween(attacker.index,true,false)
      for j in @battle.priority
        next if !attacker.pbIsOpposing?(j.index)
        # if Pursuit and this target was chosen
        if !j.hasMovedThisRound? && @battle.pbChoseMoveFunctionCode?(j.index,0x88) && !j.effects[:Pursuit] && (@battle.choices[j.index][3]!=j.pbPartner.index)
          attacker.vanished=false
          @battle.pbCommonAnimation("Fade in",attacker,nil)
          @battle.pbPursuitInterrupt(j,attacker)
        end
        break if attacker.isFainted?
      end
      @battle.pbMessagesOnReplace(attacker.index,newpoke)
      attacker.pbResetForm
      @battle.pbClearChoices(attacker.index) if attacker.effects[:MagicBounced]
      @battle.pbReplace(attacker.index,newpoke)
      @battle.pbOnActiveOne(attacker)
      attacker.pbAbilitiesOnSwitchIn(true)
    else
      attacker.vanished=false
      @battle.pbCommonAnimation("Fade in",attacker,nil)
    end
    return ret
  end
end

class PokeBattle_Move_1008 < PokeBattle_Move # LowerTargetMainStats1 < Battle::Move::TargetMultiStatDownMove
  def pbAdditionalEffect(attacker,opponent)
    for stat in 1..5
      if attacker.pbCanReduceStatStage?(stat,false)
        attacker.pbReduceStat(stat,1)
      end
    end
    return true
  end
end

class PokeBattle_Move_1009 < PokeBattle_Move # LowerTargetSpAtkSpDef1 < Battle::Move::TargetMultiStatDownMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    ret=-1; prevented=false
    if opponent.effects[:Protect] && !opponent.effects[:ProtectNegation]
      @battle.pbDisplay(_INTL("{1} protected itself!",opponent.pbThis))
      prevented=true
    end
    if !prevented && opponent.pbOwnSide.effects[:Mist]>0
      @battle.pbDisplay(_INTL("{1} is protected by Mist!",opponent.pbThis))
      prevented=true
    end
    if !prevented && ((((opponent.ability == :CLEARBODY) ||
       (opponent.ability == :WHITESMOKE)) && !(opponent.moldbroken)) || opponent.ability == :FULLMETALBODY)
      @battle.pbDisplay(_INTL("{1}'s {2} prevents stat loss!",opponent.pbThis,
         getAbilityName(opponent.ability)))
      prevented=true
    end
    if !prevented && opponent.pbTooLow?(PBStats::SPATK) &&
       opponent.pbTooLow?(PBStats::SPDEF)
      @battle.pbDisplay(_INTL("{1}'s stats won't go any lower!",opponent.pbThis))
      prevented=true
    end
    if !prevented
      pbShowAnimation(@move,attacker,opponent,hitnum,alltargets,showanimation)
      showanim=true
      if (@battle.FE == :FAIRYTALE || @battle.FE == :DRAGONSDEN)  && (@move == :NOBLEROAR)
        if opponent.pbReduceStat(PBStats::SPATK,2,false, statdropper: attacker)
          ret=0; showanim=false
        end
        if opponent.pbReduceStat(PBStats::SPDEF,2,false, statdropper: attacker)
          ret=0; showanim=false
        end
      else
        if opponent.pbReduceStat(PBStats::SPATK,1,false, statdropper: attacker)
          ret=0; showanim=false
        end
        if opponent.pbReduceStat(PBStats::SPDEF,1,false, statdropper: attacker)
          ret=0; showanim=false
        end
      end
    end
    return ret
  end
end

class PokeBattle_Move_100A < PokeBattle_Move # LowerUserAtkSpd1 < Battle::Move::StatDownMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    ret=super(attacker,opponent,hitnum,alltargets,showanimation)
    if opponent.damagestate.calcdamage>0
      for stat in [PBStats::ATTACK,PBStats::SOEED]
        if attacker.pbCanReduceStatStage?(stat,false,true)
          attacker.pbReduceStat(stat,1,false, statdropper: attacker)
        end
      end
    end
    return ret
  end
end

class PokeBattle_Move_100B < PokeBattle_Move # LowerUserAttack2 < Battle::Move::StatDownMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    ret=super(attacker,opponent,hitnum,alltargets,showanimation)
    if opponent.damagestate.calcdamage>0
      if attacker.pbCanReduceStatStage?(PBStats::ATTACK,false,true)
        attacker.pbReduceStat(PBStats::ATTACK,2,false, statdropper: attacker)
      end
    end
    return ret
  end
end

class PokeBattle_Move_100C < PokeBattle_Move # MaxUserSpecialAttackLoseHalfOfTotalHP < Battle::Move
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    showanim=showanimation
    if attacker.hp<=(attacker.totalhp/2.0).floor || !attacker.pbCanIncreaseStatStage?(PBStats::ATTACK,false)
      @battle.pbDisplay(_INTL("But it failed!"))
      return -1
    end
    pbShowAnimation(@move,attacker,nil,hitnum,alltargets,showanimation)
    attacker.pbReduceHP((attacker.totalhp/2.0).floor, false, false)
    attacker.stages[PBStats::SPATK]=6
    @battle.pbCommonAnimation("StatUp",attacker,nil)
    @battle.pbDisplay(_INTL("{1} cut its own HP and maximized its Special Attack!",attacker.pbThis))
    if @battle.FE == :BIGTOP
       if attacker.pbCanIncreaseStatStage?(PBStats::DEFENSE,false)
        attacker.pbIncreaseStat(PBStats::DEFENSE,1)
        attacker.effects[:StockpileDef]+=1
      end
      if attacker.pbCanIncreaseStatStage?(PBStats::SPDEF,false)
        attacker.pbIncreaseStat(PBStats::SPDEF,1)
        attacker.effects[:StockpileSpDef]+=1
      end
    end
    return 0
  end
end

class PokeBattle_Move_100D < PokeBattle_Move # RaiseMinMaxStat1 < Battle::Move
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    if attacker.index!=opponent.index && opponent.effects[:Substitute]>0
      @battle.pbDisplay(_INTL("{1}'s attack missed!",attacker.pbThis))
      return -1
    end
    array=[]
    for i in [PBStats::ATTACK,PBStats::DEFENSE,PBStats::SPEED,
              PBStats::SPATK,PBStats::SPDEF,PBStats::ACCURACY,PBStats::EVASION]
      array.push(i) if opponent.pbCanIncreaseStatStage?(i)
    end
    if array.length==0
      @battle.pbDisplay(_INTL("{1}'s stats won't go any higher!",opponent.pbThis))
      return -1
    end
    stat=array[@battle.pbRandom(array.length)]
    pbShowAnimation(@move,attacker,opponent,hitnum,alltargets,showanimation)
    ret=opponent.pbIncreaseStat(stat,1)
    return 0
  end
end

class PokeBattle_Move_100E < PokeBattle_Move # RaisePlusMinusUserAndAlliesAtkSpAtk1 < Battle::Move
  def pbEffect(attacker, opponent, hitnum = 0, alltargets = nil, showanimation = true)
    if ([:ELECTRIC, :STEEL].include?(attacker.pbPartner.type1) || [:ELECTRIC, :STEEL].include?(attacker.pbPartner.type2))
      partnerfail = false
      if attacker.pbPartner.pbCanIncreaseStatStage?(PBStats::ATTACK, false) || attacker.pbPartner.pbCanIncreaseStatStage?(PBStats::SPATK, false)
        pbShowAnimation(@move, attacker, nil, hitnum, alltargets, showanimation)
        statboost = 1
        statboost = 2 if @battle.FE == :FACTORY
        attacker.pbPartner.pbIncreaseStat(PBStats::ATTACK, statboost, abilitymessage: false, statsource: attacker)
        attacker.pbPartner.pbIncreaseStat(PBStats::SPATK, statboost, abilitymessage: false, statsource: attacker)
      else # partner cannot increase stats, check next attacker
        @battle.pbDisplay(_INTL("{1}'s stats won't go any higher!", attacker.pbPartner.pbThis))
      end
    else
      # partner does not have Plus/Minus
      partnerfail = true
    end
    if ([:ELECTRIC, :STEEL].include?(attacker.type1) || [:ELECTRIC, :STEEL].include?(attacker.type2))
      if attacker.pbCanIncreaseStatStage?(PBStats::ATTACK, false) || attacker.pbCanIncreaseStatStage?(PBStats::SPATK, false)
        pbShowAnimation(@move, attacker, nil, hitnum, alltargets, partnerfail)
        statboost = 1
        statboost = 2 if @battle.FE == :FACTORY
        attacker.pbIncreaseStat(PBStats::ATTACK, statboost, abilitymessage: false, statsource: attacker)
        attacker.pbIncreaseStat(PBStats::SPATK, statboost, abilitymessage: false, statsource: attacker)
      else # attacker cannot increase stats
        @battle.pbDisplay(_INTL("{1}'s stats won't go any higher!", attacker.pbThis))
      end
    else
      # attacker does not have Plus/Minus
      if partnerfail
        @battle.pbDisplay(_INTL("But it failed!"))
        return -1
      end
    end

    return 0
  end
end

class PokeBattle_Move_100F < PokeBattle_Move # RaisePlusMinusUserAndAlliesDefSpDef1 < Battle::Move
  def pbEffect(attacker, opponent, hitnum = 0, alltargets = nil, showanimation = true)
    if ([:ELECTRIC, :STEEL].include?(attacker.pbPartner.type1) || [:ELECTRIC, :STEEL].include?(attacker.pbPartner.type2)) || (Rejuv && @battle.FE == :ELECTERRAIN)
      partnerfail = false
      if attacker.pbPartner.pbCanIncreaseStatStage?(PBStats::DEFENSE, false) || attacker.pbPartner.pbCanIncreaseStatStage?(PBStats::SPDEF, false)
        pbShowAnimation(@move, attacker, nil, hitnum, alltargets, showanimation)
        statboost = 1
        statboost = 2 if @battle.FE == :DEEPEARTH || (Rejuv && @battle.FE == :ELECTERRAIN && ([:ELECTRIC, :STEEL].include?(attacker.pbPartner.type1) || [:ELECTRIC, :STEEL].include?(attacker.pbPartner.type2)))
        attacker.pbPartner.pbIncreaseStat(PBStats::DEFENSE, statboost, abilitymessage: false, statsource: attacker)
        attacker.pbPartner.pbIncreaseStat(PBStats::SPDEF, statboost, abilitymessage: false, statsource: attacker)
      else # partner cannot increase stats, check next attacker
        @battle.pbDisplay(_INTL("{1}'s stats won't go any higher!", attacker.pbPartner.pbThis))
      end
    else
      # partner does not have Plus/Minus
      partnerfail = true
    end
    if ([:ELECTRIC, :STEEL].include?(attacker.type1) || [:ELECTRIC, :STEEL].include?(attacker.type2)) || (Rejuv && @battle.FE == :ELECTERRAIN)
      if attacker.pbCanIncreaseStatStage?(PBStats::DEFENSE, false) || attacker.pbCanIncreaseStatStage?(PBStats::SPDEF, false)
        pbShowAnimation(@move, attacker, nil, hitnum, alltargets, partnerfail)
        statboost = 1
        statboost = 2 if @battle.FE == :DEEPEARTH || (Rejuv && @battle.FE == :ELECTERRAIN && ([:ELECTRIC, :STEEL].include?(attacker.type1) || [:ELECTRIC, :STEEL].include?(attacker.type2)))
        attacker.pbIncreaseStat(PBStats::DEFENSE, statboost, abilitymessage: false, statsource: attacker)
        attacker.pbIncreaseStat(PBStats::SPDEF, statboost, abilitymessage: false, statsource: attacker)
      else # attacker cannot increase stats
        @battle.pbDisplay(_INTL("{1}'s stats won't go any higher!", attacker.pbThis))
      end
    else
      # attacker does not have Plus/Minus
      if partnerfail
        @battle.pbDisplay(_INTL("But it failed!"))
        return -1
      end
    end
    return 0
  end
end

class PokeBattle_Move_1010 < PokeBattle_Move # RaiseUserAtkSpAtkSpd1 < Battle::Move::MultiStatUpMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    if !attacker.pbCanIncreaseStatStage?(PBStats::ATTACK,false) &&
       !attacker.pbCanIncreaseStatStage?(PBStats::SPATK,false) &&
       !attacker.pbCanIncreaseStatStage?(PBStats::SPEED,false)
      @battle.pbDisplay(_INTL("{1}'s stats won't go any higher!",attacker.pbThis))
      return -1
    end
    pbShowAnimation(@move,attacker,nil,hitnum,alltargets,showanimation)
    boost_amount=1
    if ((@battle.FE == :MISTY || @battle.FE == :RAINBOW || @battle.FE == :HOLY ||
      @battle.FE == :STARLIGHT || @battle.FE == :NEWWORLD || @battle.FE == :PSYTERRAIN) &&
      (@move == :COSMICPOWER)) || (@battle.FE == :FOREST && (@move == :DEFENDORDER))
      boost_amount=2
    end
    for stat in [PBStats::ATTACK,PBStats::SPATK,PBStats::SPEED]
      if attacker.pbCanIncreaseStatStage?(stat,false)
        attacker.pbIncreaseStat(stat,boost_amount)
      end
    end
    return 0
  end
end

class PokeBattle_Move_1011 < PokeBattle_Move # RaiseUserAtkSpDef1 < Battle::Move::MultiStatUpMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    if !attacker.pbCanIncreaseStatStage?(PBStats::ATTACK,false) &&
       !attacker.pbCanIncreaseStatStage?(PBStats::SPDEF,false)
      @battle.pbDisplay(_INTL("{1}'s stats won't go any higher!",attacker.pbThis))
      return -1
    end
    pbShowAnimation(@move,attacker,nil,hitnum,alltargets,showanimation)
    boost_amount=1
    if ((@battle.FE == :MISTY || @battle.FE == :RAINBOW || @battle.FE == :HOLY ||
      @battle.FE == :STARLIGHT || @battle.FE == :NEWWORLD || @battle.FE == :PSYTERRAIN) &&
      (@move == :COSMICPOWER)) || (@battle.FE == :FOREST && (@move == :DEFENDORDER))
      boost_amount=2
    end
    for stat in [PBStats::ATTACK,PBStats::SPDEF]
      if attacker.pbCanIncreaseStatStage?(stat,false)
        attacker.pbIncreaseStat(stat,boost_amount)
      end
    end
    return 0
  end
end

class PokeBattle_Move_1012 < PokeBattle_Move # RaiseUserDefSpDef1Ingrain < Battle::Move::MultiStatUpMove
  def pbTwoTurnAttack(attacker)
    @immediate=false
    if @battle.FE == :STARLIGHT || @battle.FE == :DEEPEARTH
      @immediate=true
      @battle.pbDisplay(_INTL("{1} absorbed the starlight!",attacker.pbThis)) if @battle.FE == :STARLIGHT
    elsif !@immediate && attacker.hasWorkingItem(:POWERHERB)
      itemname=getItemName(attacker.item)
      @immediate=true
      attacker.pbDisposeItem(false)
      @battle.pbDisplay(_INTL("{1} consumed its {2}!",attacker.pbThis,itemname))
    end
    return false if @immediate
    return attacker.effects[:TwoTurnAttack]==0
  end

  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    if @immediate || attacker.effects[:TwoTurnAttack]!=0
      @battle.pbCommonAnimation("Geomancy",attacker)
      @battle.pbDisplay(_INTL("{1} became one with nature!",attacker.pbThis))
    end
    if attacker.effects[:TwoTurnAttack]==0
      @battle.pbAnimation(@move,attacker,opponent,hitnum)
      for stat in [PBStats::SPATK,PBStats::SPDEF]
        if attacker.pbCanIncreaseStatStage?(stat,false)
          attacker.pbIncreaseStat(stat,1)
          attacker.effects[:Ingrain]=true
        end
      end
    end
    return 0 if attacker.effects[:TwoTurnAttack]!=0
    return super
  end
end

class PokeBattle_Move_1013 < PokeBattle_Move # RaiseUserSpAtk2IfTargetFaints < Battle::Move
  def pbAdditionalEffect(attacker,opponent)
    attacker.pbIncreaseStat(PBStats::SPATK,3) if opponent.isFainted? && attacker.pbCanIncreaseStatStage?(PBStats::SPATK,false)
  end
end

class PokeBattle_Move_1014 < PokeBattle_Move # RaiseUserSpAtkAcc1 < Battle::Move::MultiStatUpMove
  def pbEffect(attacker, opponent, hitnum = 0, alltargets = nil, showanimation = true)
    if !attacker.pbCanIncreaseStatStage?(PBStats::SPATK, false) &&
       !attacker.pbCanIncreaseStatStage?(PBStats::ACCURACY, false)
      @battle.pbDisplay(_INTL("{1}'s stats won't go any higher!", attacker.pbThis))
      return -1
    end
    pbShowAnimation(@move, attacker, nil, hitnum, alltargets, showanimation)
    boost_amount = 1
    for stat in [PBStats::SPATK, PBStats::ACCURACY]
      attacker.pbIncreaseStat(stat, boost_amount, abilitymessage: false, statsource: attacker)
    end
    return 0
  end
end

class PokeBattle_Move_1015 < PokeBattle_Move # RaiseUserSpAtkSpd1 < Battle::Move::MultiStatUpMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    if !attacker.pbCanIncreaseStatStage?(PBStats::SPATK,false) &&
       !attacker.pbCanIncreaseStatStage?(PBStats::SPEED,false)
      @battle.pbDisplay(_INTL("{1}'s stats won't go any higher!",attacker.pbThis))
      return -1
    end
    pbShowAnimation(@move,attacker,nil,hitnum,alltargets,showanimation)
    boost_amount=1
    if ((@battle.FE == :MISTY || @battle.FE == :RAINBOW || @battle.FE == :HOLY ||
      @battle.FE == :STARLIGHT || @battle.FE == :NEWWORLD || @battle.FE == :PSYTERRAIN) &&
      (@move == :COSMICPOWER)) || (@battle.FE == :FOREST && (@move == :DEFENDORDER))
      boost_amount=2
    end
    for stat in [PBStats::SPATK,PBStats::SPEED]
      if attacker.pbCanIncreaseStatStage?(stat,false)
        attacker.pbIncreaseStat(stat,boost_amount)
      end
    end
    return 0
  end
end

class PokeBattle_Move_1016 < PokeBattle_Move # RaiseUserSpDef1 < Battle::Move::StatUpMove
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    return super(attacker,opponent,hitnum,alltargets,showanimation) if @basedamage>0
    return -1 if !attacker.pbCanIncreaseStatStage?(PBStats::SPDEF,true)
    pbShowAnimation(@move,attacker,opponent,hitnum,alltargets,showanimation)
    ret=attacker.pbIncreaseStat(PBStats::SPDEF,1)
    return ret ? 0 : -1
  end

  def pbAdditionalEffect(attacker,opponent)
    increment = 1
    increment = 2 if @battle.FE == :PSYTERRAIN && @move == :MYSTICALPOWER
    if attacker.pbCanIncreaseStatStage?(PBStats::SPDEF,false)
      attacker.pbIncreaseStat(PBStats::SPDEF,increment)
    end
    return true
  end
end

class PokeBattle_Move_1017 < PokeBattle_Move
  def pbEffect(attacker, opponent, hitnum = 0, alltargets = nil, showanimation = true)
    return super(attacker, opponent, hitnum, alltargets, showanimation) if @basedamage > 0
    return -1 if !attacker.pbCanIncreaseStatStage?(PBStats::SPDEF, true)

    pbShowAnimation(@move, attacker, opponent, hitnum, alltargets, showanimation)
    ret = attacker.pbIncreaseStat(PBStats::SPDEF, 3, abilitymessage: false)
    return ret ? 0 : -1
  end

  def pbAdditionalEffect(attacker, opponent)
    attacker.pbIncreaseStat(PBStats::SPDEF, 3, abilitymessage: false, statsource: attacker)
    return true
  end
end

class PokeBattle_Move_1018 < PokeBattle_Move # SetTargetTypesToFairy < Battle::Move
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    if opponent.effects[:Substitute]>0
      @battle.pbDisplay(_INTL("But it failed!"))
      return -1
    end
    if (opponent.ability == :MULTITYPE) ||
      (opponent.ability == :RKSSYSTEM) || attacker.crested == :SILVALLY
      @battle.pbDisplay(_INTL("But it failed!"))
      return -1
    end
    pbShowAnimation(@move,attacker,opponent,hitnum,alltargets,showanimation)
    opponent.type1=(:FAIRY)
    opponent.type2=nil
    typename=getTypeName((:FAIRY))
    @battle.pbDisplay(_INTL("{1} transformed into the {2} type!",opponent.pbThis,typename))
    return 0
  end
end

class PokeBattle_Move_1019 < PokeBattle_Move # SleepTargetSuperEffectiveAgainstFairy < Battle::Move
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    return super(attacker,opponent,hitnum,alltargets,showanimation) if @basedamage>0
    return -1 if !opponent.pbCanSleep?(true)
    pbShowAnimation(@move,attacker,opponent,hitnum,alltargets,showanimation)
    opponent.pbSleep
    @battle.pbDisplay(_INTL("{1} went to sleep!",opponent.pbThis))
    return 0
  end

  def pbAdditionalEffect(attacker,opponent)
    if opponent.pbCanSleep?(false)
      opponent.pbSleep
      @battle.pbDisplay(_INTL("{1} went to sleep!",opponent.pbThis))
      return true
    end
    return false
  end
end

class PokeBattle_Move_101A < PokeBattle_Move # StartWeakenLightMoves < Battle::Move
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    if @battle.state.effects[:Blackout]>0
      @battle.pbDisplay(_INTL("But it failed!"))
      return -1
    end
    pbShowAnimation(@move,attacker,opponent,hitnum,alltargets,showanimation)
    @battle.state.effects[:Blackout]=5
    @battle.pbDisplay(_INTL("Light's power was weakened!"))
    return 0
  end
end

class PokeBattle_Move_101B < PokeBattle_Move # StealStatsAndPassToAlly < Battle::Move
  def pbEffect(attacker,opponent,hitnum=0,alltargets=nil,showanimation=true)
    totalboost = 0
    if pbTypeModifier(@type,attacker,opponent) != 0
      for i in [PBStats::ATTACK,PBStats::DEFENSE,PBStats::SPEED,
                PBStats::SPATK,PBStats::SPDEF,PBStats::ACCURACY,PBStats::EVASION]
        if opponent.stages[i]>0
          oppboost = opponent.stages[i]
          oppboost *= -1 if attacker.ability == :CONTRARY
          oppboost *= 2 if attacker.ability == :SIMPLE
          attacker.stages[i]+=oppboost
          attacker.stages[i] = attacker.stages[i].clamp(-6, 6)
          totalboost += oppboost
          opponent.stages[i]=0
        end
      end
    end
    if totalboost>0
      @battle.pbCommonAnimation("StatUp",attacker,nil)
      @battle.pbDisplay(_INTL("{1} stole {2}'s stat boosts!",attacker.pbThis,opponent.pbThis))
    end
    if !@battle.pbCanChooseNonActive?(attacker.index)
      @battle.pbDisplay(_INTL("But it failed!"))
      return -1
    end
    newpoke=0
    pbShowAnimation(@move,attacker,nil,hitnum,alltargets,showanimation)
    newpoke=@battle.pbSwitchInBetween(attacker.index,true,false)
    @battle.pbMessagesOnReplace(attacker.index,newpoke)
    attacker.pbResetForm
    @battle.pbReplace(attacker.index,newpoke,true)
    @battle.pbOnActiveOne(attacker)
    attacker.pbAbilitiesOnSwitchIn(true)
    return super(attacker,opponent,hitnum,alltargets,showanimation)
  end
end

class PokeBattle_Move_101C < PokeBattle_Move # SuperEffectiveAgainstRock < Battle::Move
  # Handled in superclass
end

class PokeBattle_Move_101D < PokeBattle_Move # SuperEffectiveAgainstBug < Battle::Move
  # Handled in superclass
end

class PokeBattle_Move_101E < PokeBattle_Move # SuperEffectiveAgainstGhost < Battle::Move
  # Handled in superclass
end

class PokeBattle_Move_101F < PokeBattle_Move # SuperEffectiveAgainstSteel < Battle::Move
  # Handled in superclass
end

class PokeBattle_Move_1020 < PokeBattle_Move # SuperEffectiveAgainstPsychic < Battle::Move
  # Handled in superclass
end

class PokeBattle_Move_1021 < PokeBattle_Move # SuperEffectiveAgainstCosmic < Battle::Move
  # Handled in superclass
end

class PokeBattle_Move_1022 < PokeBattle_Move # SuperEffectiveAgainstWater < Battle::Move
  # Handled in superclass
end

class PokeBattle_Move_1023 < PokeBattle_Move # GlitchMove < Battle::Move
  # Handled in superclass
end

class PokeBattle_Move_1024 < PokeBattle_Move # UseTargetSpDefInsteadOfTargetDefense < Battle::Move
  # Handled in superclass, do not edit!

  def pbGetDefenseStats(user, target)
    return target.spdef, target.stages[:SPECIAL_DEFENSE] + 6
  end
end
