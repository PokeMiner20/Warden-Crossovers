## Move Effectiveness Mod ##
class FightMenuButtons < BitmapSprite
  def initialize(index = 0, moves = nil, viewport = nil)
    super(Graphics.width,96+UPPERGAP,viewport)
    self.x=0
    self.y=Graphics.height-96-UPPERGAP
    pbSetNarrowFont(self.bitmap)
    @typebitmap=AnimatedBitmap.new(_INTL("Graphics/Pictures/types"))
    @megaevobitmap=AnimatedBitmap.new(_INTL("Graphics/Pictures/Battle/battleMegaEvo"))
    @ultraburstbitmap=AnimatedBitmap.new(_INTL("Graphics/Pictures/Battle/battleMegaEvo"))
    @zmovebitmap=AnimatedBitmap.new(_INTL("Graphics/Pictures/Battle/battleZMove"))
    @goodmovebitmap=AnimatedBitmap.new(_INTL("Graphics/Pictures/Battle/fieldUp"))
    @badmovebitmap=AnimatedBitmap.new(_INTL("Graphics/Pictures/Battle/fieldDown"))
    ### MOD ###
    @nullmovebitmap = AnimatedBitmap.new(_INTL("Graphics/Pictures/Battle/mod_fieldNullDam"))
    @moveNotEffectivebitmap=AnimatedBitmap.new(_INTL("Graphics/Pictures/Battle/mod_NotEffective"))
    @moveNotSuperEffectiveDoublebitmap=AnimatedBitmap.new(_INTL("Graphics/Pictures/Battle/mod_NotSuperEffectiveDouble"))
    @moveNotSuperEffectivebitmap=AnimatedBitmap.new(_INTL("Graphics/Pictures/Battle/mod_NotSuperEffective"))
    @moveSuperEffectivebitmap=AnimatedBitmap.new(_INTL("Graphics/Pictures/Battle/mod_SuperEffective"))
    @moveSuperEffectiveDoublebitmap=AnimatedBitmap.new(_INTL("Graphics/Pictures/Battle/mod_SuperEffectiveDouble"))
    @moveNotEffective_Leftbitmap=AnimatedBitmap.new(_INTL("Graphics/Pictures/Battle/mod_NotEffective_Left"))
    @moveNotSuperEffectiveDouble_Leftbitmap=AnimatedBitmap.new(_INTL("Graphics/Pictures/Battle/mod_NotSuperEffectiveDouble_Left"))
    @moveNotSuperEffective_Leftbitmap=AnimatedBitmap.new(_INTL("Graphics/Pictures/Battle/mod_NotSuperEffective_Left"))
    @moveSuperEffective_Leftbitmap=AnimatedBitmap.new(_INTL("Graphics/Pictures/Battle/mod_SuperEffective_Left"))
    @moveSuperEffectiveDouble_Leftbitmap=AnimatedBitmap.new(_INTL("Graphics/Pictures/Battle/mod_SuperEffectiveDouble_Left"))
    @moveNotEffective_Rightbitmap=AnimatedBitmap.new(_INTL("Graphics/Pictures/Battle/mod_NotEffective_Right"))
    @moveNotSuperEffectiveDouble_Rightbitmap=AnimatedBitmap.new(_INTL("Graphics/Pictures/Battle/mod_NotSuperEffectiveDouble_Right"))
    @moveNotSuperEffective_Rightbitmap=AnimatedBitmap.new(_INTL("Graphics/Pictures/Battle/mod_NotSuperEffective_Right"))
    @moveSuperEffective_Rightbitmap=AnimatedBitmap.new(_INTL("Graphics/Pictures/Battle/mod_SuperEffective_Right"))
    @moveSuperEffectiveDouble_Rightbitmap=AnimatedBitmap.new(_INTL("Graphics/Pictures/Battle/mod_SuperEffectiveDouble_Right"))
    ### MOD ###
    refresh(index,moves,0,0,0)
  end

  def dispose
    @typebitmap.dispose
    @megaevobitmap.dispose
    @ultraburstbitmap.dispose
    @zmovebitmap.dispose
    @goodmovebitmap.dispose
    @badmovebitmap.dispose
    ### MOD ###
    @nullmovebitmap.dispose
    @moveNotEffectivebitmap.dispose
    @moveNotSuperEffectiveDoublebitmap.dispose
    @moveNotSuperEffectivebitmap.dispose
    @moveSuperEffectivebitmap.dispose
    @moveSuperEffectiveDoublebitmap.dispose
    @moveNotEffective_Leftbitmap.dispose
    @moveNotSuperEffectiveDouble_Leftbitmap.dispose
    @moveNotSuperEffective_Leftbitmap.dispose
    @moveSuperEffective_Leftbitmap.dispose
    @moveSuperEffectiveDouble_Leftbitmap.dispose
    @moveNotEffective_Rightbitmap.dispose
    @moveNotSuperEffectiveDouble_Rightbitmap.dispose
    @moveNotSuperEffective_Rightbitmap.dispose
    @moveSuperEffective_Rightbitmap.dispose
    @moveSuperEffectiveDouble_Rightbitmap.dispose
    ### MOD ###
    super
  end

  def refresh(index, battler, megaButton, zButton, ultraButton)
    return if !battler
    moves = nil
    if battler.moves
      moves = []
      for move in battler.moves
        moves.push(move)
      end
    end
    if zButton == 2 && !battler.zmoves.nil?
      for i in 0...battler.zmoves.length
        next if battler.zmoves[i].nil?

        moves[i] = battler.zmoves[i]
      end
    end
    return if !moves
    self.bitmap.clear
    textpos = []
    for i in 0...4
      next if i == index
      next if !moves[i]

      x = ((i % 2) == 0) ? 4 : 192
      y = ((i / 2) == 0) ? 6 : 48
      y += UPPERGAP
      imagepos = []
      movetype = moves[i].pbType(battler, moves[i].type)
      imagepos.push([sprintf("Graphics/Pictures/Battle/battleFightButtons%s", movetype), x, y, 0, 0, 192, 46])
      pbDrawImagePositions(self.bitmap, imagepos)
      textpos.push([_INTL("{1}", moves[i].name), x + 96, y + 12, 2, PBScene::MENUBASE, PBScene::MENUSHADOW])
    end
    ppcolors = [
      PBScene::PPBASE, PBScene::PPSHADOW,
      PBScene::PPBASE, PBScene::PPSHADOW,
      PBScene::PPBASEYELLOW, PBScene::PPSHADOWYELLOW,
      PBScene::PPBASEORANGE, PBScene::PPSHADOWORANGE,
      PBScene::PPBASERED, PBScene::PPSHADOWRED
    ]
    for i in 0...4
      next if i != index
      next if !moves[i]

      x = ((i % 2) == 0) ? 4 : 192
      y = ((i / 2) == 0) ? 6 : 48
      y += UPPERGAP
      imagepos = []
      movetype = moves[i].pbType(battler, moves[i].type)
      secondtype = moves[i].getSecondaryType(battler)
      secondtype = [:RAINBOW] if !secondtype.nil? && moves[i].move != :FLYINGPRESS && moves[i].battle.FE == :RAINBOW
      secondtype = [:CRYSTAL] if !secondtype.nil? && moves[i].move != :FLYINGPRESS && moves[i].battle.FE == :CRYSTALCAVERN
      if secondtype.nil? || secondtype.include?(movetype)
        imagepos.push([sprintf("Graphics/Icons/type%s", movetype), 416, 20 + UPPERGAP, 0, 0, 64, 28])
      elsif secondtype.length == 1
        imagepos.push([sprintf("Graphics/Icons/type%s", movetype), 402, 20 + UPPERGAP, 0, 0, 64, 28])
        imagepos.push([sprintf("Graphics/Icons/minitype%s", secondtype[0]), 466, 20 + UPPERGAP, 0, 0, 28, 28])
      else
        imagepos.push([sprintf("Graphics/Icons/minitype%s", movetype), 404, 20 + UPPERGAP, 0, 0, 64, 28])
        imagepos.push([sprintf("Graphics/Icons/minitype%s", secondtype[0]), 432, 20 + UPPERGAP, 0, 0, 28, 28])
        imagepos.push([sprintf("Graphics/Icons/minitype%s", secondtype[1]), 460, 20 + UPPERGAP, 0, 0, 28, 28])
      end
      imagepos.push([sprintf("Graphics/Pictures/Battle/battleFightButtons%s", movetype), x, y, 192, 0, 192, 46])
      textpos.push([_INTL("{1}", moves[i].name), x + 96, y + 12, 2, PBScene::MENUBASE, PBScene::MENUSHADOW])
      if moves[i].totalpp > 0
        ppfraction = (4.0 * moves[i].pp / moves[i].totalpp).ceil
        textpos.push([_INTL("PP: {1}/{2}", moves[i].pp, moves[i].totalpp), 448, 50 + UPPERGAP, 2, ppcolors[(4 - ppfraction) * 2], ppcolors[(4 - ppfraction) * 2 + 1]])
      end
    end
    pbDrawImagePositions(self.bitmap, imagepos)
    for i in 0...4
      next if !moves[i]

      x = ((i % 2) == 0) ? 4 : 192
      y = ((i / 2) == 0) ? 6 : 48
      y += UPPERGAP
      y -= 2 if Rejuv
      ### MOD ###
      movetype = moves[i].pbType(battler, moves[i].type)
      typemod = 4
      typemod1 = typemod
      typemod2 = typemod
      twoOpponents = false
      if battler.battle.doublebattle && !(battler.pbOpposing1.isFainted? || battler.pbOpposing2.isFainted?)
        twoOpponents = true
      end
      opponent = battler.pbOpposing1
      opponent = battler.pbOpposing2 if battler.pbOpposing1.isFainted? && !battler.pbOpposing2.isFainted?
      if moves[i].category != :status
        if twoOpponents
          typemod1 = moves[i].showMoveEffectiveness(movetype, battler, battler.pbOpposing1)
          typemod2 = moves[i].showMoveEffectiveness(movetype, battler, battler.pbOpposing2)
        else
          typemod = moves[i].showMoveEffectiveness(movetype, battler, opponent)
        end
      else
        if battler.effects[:Taunt] > 0 ||
          (battler.effects[:HealBlock] > 0 && (moves[i].isHealingMove? || (moves[i].function == 0xDD || moves[i].function == 0x139 || moves[i].function == 0x158))) # Healing and Absorbtion Moves fail on HealBlock
          typemod = 0
        elsif moves[i].target != :User && moves[i].target != :Partner
          if twoOpponents
            typemod1 = showMoveEffectivenessStatus(moves[i], battler, battler.pbOpposing1, movetype, typemod)
            typemod2 = showMoveEffectivenessStatus(moves[i], battler, battler.pbOpposing2, movetype, typemod)
          else
            typemod = showMoveEffectivenessStatus(moves[i], battler, opponent, movetype, typemod)
          end
        end
      end
      case typemod
        when 0 # Innefective
          self.bitmap.blt(x + 2, y + 2, @moveNotEffectivebitmap.bitmap, Rect.new(0, 0, @moveNotEffectivebitmap.bitmap.width, @moveNotEffectivebitmap.bitmap.height))
        when 1 # 1/4
          self.bitmap.blt(x + 2, y + 2, @moveNotSuperEffectiveDoublebitmap.bitmap, Rect.new(0, 0, @moveNotSuperEffectiveDoublebitmap.bitmap.width, @moveNotSuperEffectiveDoublebitmap.bitmap.height))
        when 2 # 1/2
          self.bitmap.blt(x + 2, y + 2, @moveNotSuperEffectivebitmap.bitmap, Rect.new(0, 0, @moveNotSuperEffectivebitmap.bitmap.width, @moveNotSuperEffectivebitmap.bitmap.height))
        when 8 # x2
          self.bitmap.blt(x + 2, y + 2, @moveSuperEffectivebitmap.bitmap, Rect.new(0, 0, @moveSuperEffectivebitmap.bitmap.width, @moveSuperEffectivebitmap.bitmap.height))
        when 16 # x4
          self.bitmap.blt(x + 2, y + 2, @moveSuperEffectiveDoublebitmap.bitmap, Rect.new(0, 0, @moveSuperEffectiveDoublebitmap.bitmap.width, @moveSuperEffectiveDoublebitmap.bitmap.height))
      end
      case typemod1
        when 0 # Innefective
          self.bitmap.blt(x + 2, y + 2, @moveNotEffective_Rightbitmap.bitmap, Rect.new(0, 0, @moveNotEffective_Rightbitmap.bitmap.width, @moveNotEffective_Rightbitmap.bitmap.height))
        when 1 # 1/4
          self.bitmap.blt(x + 2, y + 2, @moveNotSuperEffectiveDouble_Rightbitmap.bitmap, Rect.new(0, 0, @moveNotSuperEffectiveDouble_Rightbitmap.bitmap.width, @moveNotSuperEffectiveDouble_Rightbitmap.bitmap.height))
        when 2 # 1/2
          self.bitmap.blt(x + 2, y + 2, @moveNotSuperEffective_Rightbitmap.bitmap, Rect.new(0, 0, @moveNotSuperEffective_Rightbitmap.bitmap.width, @moveNotSuperEffective_Rightbitmap.bitmap.height))
        when 8 # x2
          self.bitmap.blt(x + 2, y + 2, @moveSuperEffective_Rightbitmap.bitmap, Rect.new(0, 0, @moveSuperEffective_Rightbitmap.bitmap.width, @moveSuperEffective_Rightbitmap.bitmap.height))
        when 16 # x4
          self.bitmap.blt(x + 2, y + 2, @moveSuperEffectiveDouble_Rightbitmap.bitmap, Rect.new(0, 0, @moveSuperEffectiveDouble_Rightbitmap.bitmap.width, @moveSuperEffectiveDouble_Rightbitmap.bitmap.height))
      end
      case typemod2
        when 0 # Innefective
          self.bitmap.blt(x + 2, y + 2, @moveNotEffective_Leftbitmap.bitmap, Rect.new(0, 0, @moveNotEffective_Leftbitmap.bitmap.width, @moveNotEffective_Leftbitmap.bitmap.height))
        when 1 # 1/4
          self.bitmap.blt(x + 2, y + 2, @moveNotSuperEffectiveDouble_Leftbitmap.bitmap, Rect.new(0, 0, @moveNotSuperEffectiveDouble_Leftbitmap.bitmap.width, @moveNotSuperEffectiveDouble_Leftbitmap.bitmap.height))
        when 2 # 1/2
          self.bitmap.blt(x + 2, y + 2, @moveNotSuperEffective_Leftbitmap.bitmap, Rect.new(0, 0, @moveNotSuperEffective_Leftbitmap.bitmap.width, @moveNotSuperEffective_Leftbitmap.bitmap.height))
        when 8 # x2
          self.bitmap.blt(x + 2, y + 2, @moveSuperEffective_Leftbitmap.bitmap, Rect.new(0, 0, @moveSuperEffective_Leftbitmap.bitmap.width, @moveSuperEffective_Leftbitmap.bitmap.height))
        when 16 # x4
          self.bitmap.blt(x + 2, y + 2, @moveSuperEffectiveDouble_Leftbitmap.bitmap, Rect.new(0, 0, @moveSuperEffectiveDouble_Leftbitmap.bitmap.width, @moveSuperEffectiveDouble_Leftbitmap.bitmap.height))
      end
      case pbFieldNotesBattle(moves[i])
        when 1 then self.bitmap.blt(x + 2, y + 2, @goodmovebitmap.bitmap, Rect.new(0, 0, @goodmovebitmap.bitmap.width, @goodmovebitmap.bitmap.height))
        when 2 then self.bitmap.blt(x + 2, y + 2, @badmovebitmap.bitmap, Rect.new(0, 0, @badmovebitmap.bitmap.width, @badmovebitmap.bitmap.height))
        when 3 then self.bitmap.blt(x + 2, y + 2, @nullmovebitmap.bitmap, Rect.new(0, 0, @nullmovebitmap.bitmap.width, @nullmovebitmap.bitmap.height))
      end
    end
    pbDrawTextPositions(self.bitmap, textpos)
    if megaButton > 0
      self.bitmap.blt(146, 0, @megaevobitmap.bitmap, Rect.new(0, (megaButton - 1) * 46, 96, 46))
    end
    if ultraButton > 0
      self.bitmap.blt(146, 0, @megaevobitmap.bitmap, Rect.new(0, (ultraButton - 1) * 46, 96, 46))
    end
    if zButton > 0
      self.bitmap.blt(146, 0, @zmovebitmap.bitmap, Rect.new(0, (zButton - 1) * 46, 96, 46))
    end
  end

  def showMoveEffectivenessStatus(move, battler, opponent, movetype, typemod = 4)
    if (move.move == :THUNDERWAVE && (move.pbTypeModifier(movetype, battler, opponent) == 0 || !opponent.pbCanParalyze?(false) ||
    (opponent.nullsElec? && movetype == :ELECTRIC))) || (!opponent.pbCanPoison?(false) && (move.move == :POISONGAS || move.move == :POISONPOWDER || move.move == :TOXIC)) ||
    (opponent.status != :POISON && move.move == :VENOMDRENCH) || (move.powderMove? && (opponent.hasType?(:GRASS) || opponent.ability == :OVERCOAT || (opponent.itemWorks? && opponent.item == :SAFETYGOGGLES))) ||
    (move.move == :WILLOWISP && (!opponent.pbCanBurn?(false) || opponent.ability == :FLASHFIRE)) || (PBStuff::SLEEPMOVE.include?(move.move) && !opponent.pbCanSleep?(false)) ||
    (PBStuff::PARAMOVE.include?(move.move) && !opponent.pbCanParalyze?(false)) || (opponent.ability == :SOUNDPROOF && move.isSoundBased?) ||
    ((opponent.effects[:MagicCoat] || (opponent.ability == (:MAGICBOUNCE) && !(opponent.moldbroken))) && move.canMagicCoat?) || (battler.ability == :PRANKSTER && (opponent.type1 == :DARK || opponent.type2 == :DARK))
      typemod = 0
    end
    return typemod
  end
end

class PokeBattle_Move
  def windMove?
    return hasFlag?(:windmove)
  end

  def powderMove?
    return hasFlag?(:powdermove)
  end

  def showMoveEffectiveness(type, attacker, opponent)
    secondtype = getSecondaryType(attacker)
    if opponent.ability == :SAPSIPPER && !opponent.moldbroken && (type == :GRASS || (!secondtype.nil? && secondtype.include?(:GRASS)))
      return 0
    end
    if ((opponent.ability == :STORMDRAIN && (type == :WATER || (!secondtype.nil? && secondtype.include?(:WATER)))) ||
       (opponent.ability == :LIGHTNINGROD && (type == :ELECTRIC || (!secondtype.nil? && secondtype.include?(:ELECTRIC))))) && !opponent.moldbroken
      return 0
    end
    if ((opponent.ability == :MOTORDRIVE && !opponent.moldbroken) ||
       (Rejuv && @battle.FE == :GLITCH && opponent.species == :GENESECT && opponent.hasWorkingItem(:SHOCKDRIVE))) &&
       (type == :ELECTRIC || (!secondtype.nil? && secondtype.include?(:ELECTRIC)))
      return 0
    end
    if ((opponent.ability == :DRYSKIN && !opponent.moldbroken) && (type == :WATER || (!secondtype.nil? && secondtype.include?(:WATER)))) ||
       (opponent.ability == :VOLTABSORB && !opponent.moldbroken && (type == :ELECTRIC || (!secondtype.nil? && secondtype.include?(:ELECTRIC)))) ||
       (opponent.ability == :WATERABSORB && !opponent.moldbroken && (type == :WATER || (!secondtype.nil? && secondtype.include?(:WATER)))) ||
       ((Rejuv && @battle.FE == :GLITCH && opponent.species == :GENESECT && opponent.hasWorkingItem(:DOUSEDRIVE)) && (type == :WATER || (!secondtype.nil? && secondtype.include?(:WATER)))) ||
       ((Rejuv && @battle.FE == :GLITCH && opponent.species == :GENESECT && opponent.hasWorkingItem(:CHILLDRIVE)) && (type == :ICE || (!secondtype.nil? && secondtype.include?(:ICE)))) ||
       ((Rejuv && @battle.FE == :DESERT) && (opponent.hasType?(:GRASS) || opponent.hasType?(:WATER)) && @battle.pbWeather == :SUNNYDAY && (type == :WATER || (!secondtype.nil? && secondtype.include?(:WATER))))
      if opponent.effects[:HealBlock] == 0
        return 0
      end
    end
    if opponent.ability == :ORN_CACOPHONY && !opponent.moldbroken && (type == :SOUND || (!secondtype.nil? && secondtype.include?(:SOUND)))
      return 0
    elsif opponent.ability == :ORN_COMETSTORM && !opponent.moldbroken && (type == :ROCK || (!secondtype.nil? && secondtype.include?(:ROCK)))
      return 0
    end
    # Immunity Crests
    case opponent.crested
      when :SKUNTANK
        if type == :GROUND || (!secondtype.nil? && secondtype.include?(:GROUND))
          return 0
        end
      when :DRUDDIGON
        if type == :FIRE || (!secondtype.nil? && secondtype.include?(:FIRE))
          if opponent.effects[:HealBlock] == 0
            return 0
          end
        end
      when :WHISCASH
        if type == :GRASS || (!secondtype.nil? && secondtype.include?(:GRASS))
          return 0
        end
    end
    if opponent.ability == :BULLETPROOF && !opponent.moldbroken
      if PBStuff::BULLETMOVE.include?(@move)
        return 0
      end
    end
    if @battle.FE == :ROCKY && (opponent.effects[:Substitute] > 0 || opponent.stages[PBStats::DEFENSE] > 0)
      if PBStuff::BULLETMOVE.include?(@move)
        return 0
      end
    end
    if ((opponent.ability == :FLASHFIRE && !opponent.moldbroken) ||
       (Rejuv && @battle.FE == :GLITCH && opponent.species == :GENESECT && opponent.hasWorkingItem(:BURNDRIVE))) &&
       (type == :FIRE || (!secondtype.nil? && secondtype.include?(:FIRE))) && @battle.FE != :FROZENDIMENSION
      return 0
    end
    if opponent.ability == :MAGMAARMOR && (type == :FIRE || (!secondtype.nil? && secondtype.include?(:FIRE))) &&
       (@battle.FE == :DRAGONSDEN || @battle.FE == :VOLCANICTOP || @battle.FE == :INFERNAL) && !opponent.moldbroken
      return 0
    end
    # Telepathy
    if ((opponent.ability == :TELEPATHY && !opponent.moldbroken) || @battle.FE == :HOLY) && @basedamage > 0
      if opponent.index == attacker.pbPartner.index
        return 0
      end
    end
    typemod = pbTypeModifier(type, attacker, opponent)
    # Resistance-changing Crests
    #typemod = irregularTypeMods(attacker, opponent, typemod, type)
    if @move == :FLYINGPRESS
      if @battle.FE == :SKY
        typemod *= 2 if $game_switches[:Inversemode] && !@battle.isOnline? ? PBTypes.oneTypeEff(:FLYING, opponent.type1) > 2 : PBTypes.oneTypeEff(:FLYING, opponent.type1) < 2
        typemod *= 2 if $game_switches[:Inversemode] && !@battle.isOnline? ? PBTypes.oneTypeEff(:FLYING, opponent.type2) > 2 : PBTypes.oneTypeEff(:FLYING, opponent.type2) < 2
      else
        typemod2 = pbTypeModifier(:FLYING, attacker, opponent)
        #typemod2 = irregularTypeMods(attacker, opponent, typemod2, :FLYING)
        typemod = (typemod * typemod2) / 4
      end
    end
    # Field Effect second type changes
    typemod = fieldTypeChange(attacker, opponent, typemod, false)
    #typemod = overlayTypeChange(attacker, opponent, typemod, false)

    if typemod == 0
      if @function == 0x111
        return 1
      end
    end
    return typemod
  end
end
## Move Effectiveness Mod ##
