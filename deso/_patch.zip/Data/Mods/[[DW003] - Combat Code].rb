class PBStuff
  BITEMOVE     = [:BITE,:CRUNCH,:THUNDERFANG,:FIREFANG,:ICEFANG,:POISONFANG,:HYPERFANG,:PSYCHICFANGS,:FISHIOUSREND,:ORN_VISEGRIP,:ORN_STRAFE,:ORN_DRAGONGNAW,:ORN_NECROPHAGY,:ORN_FLYTRAP,:ORN_FROSTBITE,:ORN_VENOMDRAIN,:ORN_MINDDRAIN,:ORN_AQUAFANG,:ORN_SLURP,:ORN_SUCKBLOOD]
  BULLETMOVE   = [:ACIDSPRAY,:AURASPHERE,:BARRAGE,:BULLETSEED,:EGGBOMB,:ELECTROBALL,:ENERGYBALL,:FOCUSBLAST,:GYROBALL,:ICEBALL,:MAGNETBOMB,:MISTBALL,:MUDBOMB,:OCTAZOOKA,:ROCKWRECKER,:SEARINGSHOT,:SEEDBOMB,:SHADOWBALL,:SLUDGEBOMB,:WEATHERBALL,:ZAPCANNON,:BEAKBLAST,:PYROBALL,:ORN_LOVEBURST,:ORN_CHAKRABLAST,:ORN_CHIORB,:ORN_FIREBALL,:ORN_CATAPULT,:ORN_HELLBULLET,:ORN_TIMEBOMB,:ORN_CORALBOMB,:ORN_ALKALINEBOMB,:ORN_BOMBARDMENT,:ORN_SHRAPNEL,:ORN_CLUSTERROCKETS,:ORN_SONICBLAST,:ORN_MUDBLAST,:ORN_DIRTYBOMB,:ORN_MANABLAST]
  NOCOPYMOVE   = [:ASSIST,:COPYCAT,:MEFIRST,:METRONOME,:MIMIC,:MIRRORMOVE,:NATUREPOWER,:SHELLTRAP,:SKETCH,:SLEEPTALK,:STRUGGLE,:BEAKBLAST,:FOCUSPUNCH,:TRANSFORM,:BELCH,:CHATTER,:KINGSSHIELD,:BANEFULBUNKER,:BESTOW,:COUNTER,:COVET,:DESTINYBOND,:DETECT,:ENDURE,:FEINT,:FOLLOWME,:HELPINGHAND,:MATBLOCK,:MIRRORCOAT,:PROTECT,:RAGEPOWDER,:SNATCH,:SPIKYSHIELD,:SPOTLIGHT,:SWITCHEROO,:THIEF,:TRICK,:ORN_GOLDRUSH,:ORN_RAYOFLIGHT,:ORN_GRABANDGO]
  DANCEMOVE    = [:QUIVERDANCE,:DRAGONDANCE,:FIERYDANCE,:FEATHERDANCE,:PETALDANCE,:SWORDSDANCE,:TEETERDANCE,:LUNARDANCE,:REVELATIONDANCE,:ORN_DEATHWALTZ,:ORN_MACABREDANCE,:ORN_LOVELOOP,:ORN_WEAPONMASTERY]
  POWDERMOVES  = [:COTTONSPORE,:SLEEPPOWDER,:STUNSPORE,:SPORE,:RAGEPOWDER,:POISONPOWDER,:POWDER,:MAGICPOWDER,:ORN_STARDUST]
  PULSEMOVES   = [:AURASPHERE,:DRAGONPULS,:DARKPULSE,:WATERPULSE,:ORIGINPULSE,:ORN_ETHEREALBURST,:ORN_MYSTICPULSE,:ORN_SHADOWRAY,:ORN_GAIAPULSE,:ORN_RAINBOWBEAM,:ORN_PRIMALWAVE,:ORN_PULSE,:ORN_MAGNETICCANNON,:ORN_AERIALPULSE,:ORN_WRAITHPULSE]
  UNFREEZEMOVE = [:FLAMEWHEEL,:SACREDFIRE,:FLAREBLITZ,:FUSIONFLARE,:SCALD,:STEAMERUPTION,:BURNUP,:PYROBALL,:SCORCHINGSANDS,:ORN_SOLARFLARE,:ORN_SOLARMETEOR,:ORN_CHIDORI,:ORN_ANCIENTFIRE,:ORN_CRIMSONGATE,:ORN_FIREBALL,:ORN_FLAMEVOLLEY,:ORN_FLARESWEEP,:ORN_HEATSIPHON,:ORN_INFERNALBLADE,:ORN_MELTINGHORN,:ORN_SIZZLE,:ORN_BURNINGOFUDA,:ORN_LIGHTSABER,:ORN_SPARKLE,:ORN_PYROKINESIS,:ORN_STONESURGE,:ORN_RASENGAN]
  SLICINGMOVES = [:SACREDSWORD,:AERIALACE,:SOLARBLADE,:LEAFBLADE,:CUT,:SMARTSTRIKE,:BEHEMOTHBLADE,:RAZORSHELL,:FURYCUTTER,:XSCISSOR,:NIGHTSLASH,:AIRCUTTER,:AIRSLASH,:SHADOWCLAW,:RAZORLEAF,:SLASH,:CROSSPOISON,:PSYCHOCUT,:ORN_DEATHREAP,:ORN_WYVERNSLASH,:ORN_EXCALIBUR,:ORN_EDGESTRIKE,:ORN_INFERNALBLADE,:ORN_GRIMREAPER,:ORN_COUPDEGRACE,:ORN_LIGHTSABER,:ORN_LUMINOUSBLADE,:ORN_SHINYPLUMES,:ORN_SLICINGTAIL,:ORN_DIAMONDBLADE,:ORN_SMARTBLADE,:ORN_SWORDSTRIKE,:ORN_SWEEPINGTALON,:ORN_ICICLESTRIKE]
  WINDMOVE     = [:HEATWAVE,:HURRICANE,:TAILWIND,:PETALBLIZZARD,:BLIZZARD,:ICYWIND,:RAZORWIND,:WHIRLWIND,:SANDSTORM,:SILVERWIND,:TWISTER,:FAIRYWIND,:AIRCUTTER,:AEROBLAST,:GUST,:OMINOUSWIND,:ORN_DRAGONGALE,:ORN_SWEEPINGWIND,:ORN_BOREASBREATH,:ORN_DEATHVORTEX,:ORN_GALEHOLD,:ORN_TORNADO,:ORN_TURBULENCE,:ORN_TYPHOON,:ORN_ICEVORTEX,:ORN_ASTRALWIND,:ORN_TEMPESTFLARE,:ORN_AERIALPULSE,:ORN_DRACOTEMPEST,:ORN_PETALTEMPEST,:ORN_DUSTDEVILS,:ORN_NUMBINGWIND,:ORN_MIASMA]
end

EVOSTONES = [:FIRESTONE,:THUNDERSTONE,:WATERSTONE,:LEAFSTONE,:MOONSTONE,:SUNSTONE,:DUSKSTONE,:DAWNSTONE,:SHINYSTONE,:LINKSTONE,:ICESTONE,:SWEETAPPLE,:TARTAPPLE,:CHIPPEDPOT,:CRACKEDPOT,:NIGHTMAREFUEL,:XENWASTE,:GALARICACUFF,:GALARICAWREATH,:BLACKAUGURITE,:PEATBLOCK,:ORN_FIRESTONE,:ORN_THUNDERSTONE,:ORN_WATERSTONE,:ORN_LEAFSTONE,:ORN_MOONSTONE,:ORN_SUNSTONE,:ORN_DUSKSTONE,:ORN_DAWNSTONE,:ORN_SHINYSTONE,:ORN_ICESTONE,:ORN_LINKSTONE,:ORN_HUMMINGSTONE,:ORN_SANDSTONE,:ORN_WINDSTONE,:ORN_IRONSTONE,:ORN_NOXIOUSSTONE,:ORN_POWERSTONE,:ORN_SWARMSTONE,:ORN_GEMSTONE,:ORN_ROYALSTONE]
GEMS = [:FIREGEM,:WATERGEM,:ELECTRICGEM,:GRASSGEM,:ICEGEM,:FIGHTINGGEM,:POISONGEM,:GROUNDGEM,:FLYINGGEM,:PSYCHICGEM,:BUGGEM,:ROCKGEM,:GHOSTGEM,:DRAGONGEM,:DARKGEM,:STEELGEM,:NORMALGEM,:FAIRYGEM,:ORN_COSMICGEM,:ORN_LIGHTGEM,:ORN_SOUNDGEM]
ItemHandlers::UseOnPokemon.copy(:FIRESTONE,:ORN_FIRESTONE,:ORN_THUNDERSTONE,:ORN_WATERSTONE,:ORN_LEAFSTONE,:ORN_MOONSTONE,:ORN_SUNSTONE,:ORN_DUSKSTONE,:ORN_DAWNSTONE,:ORN_SHINYSTONE,:ORN_ICESTONE,:ORN_LINKSTONE,:ORN_HUMMINGSTONE,:ORN_SANDSTONE,:ORN_WINDSTONE,:ORN_IRONSTONE,:ORN_NOXIOUSSTONE,:ORN_POWERSTONE,:ORN_SWARMSTONE,:ORN_GEMSTONE,:ORN_ROYALSTONE)

class PokeBattle_Move
  alias warden_pbStatusMoveAbsorption pbStatusMoveAbsorption
  alias warden_pbTypeModMessages pbTypeModMessages
  alias warden_pbReduceHPDamage pbReduceHPDamage
  alias warden_pbAccuracyCheck pbAccuracyCheck
  alias warden_pbType pbType
  # Warden Abilities #
  def pbStatusMoveAbsorption(type,attacker,opponent)
    secondtype = getSecondaryType(attacker)
    if opponent.ability == :ORN_EARTHEATER && !opponent.moldbroken && (type == :GROUND || (!secondtype.nil? && secondtype.include?(:GROUND)))
      if opponent.effects[:HealBlock]==0
        negator = getAbilityName(opponent.ability)
        if opponent.pbRecoverHP((opponent.totalhp/4.0).floor,true)>0
          @battle.pbDisplay(_INTL("{1}'s {2} restored its HP!",opponent.pbThis,negator))
        else
          @battle.pbDisplay(_INTL("{1}'s {2} made {3} useless!", opponent.pbThis,negator,@name))
        end
        return 0
      end
    end
	return warden_pbStatusMoveAbsorption(type,attacker,opponent)
  end

  def pbTypeModMessages(type, attacker, opponent)
    secondtype = getSecondaryType(attacker)
    if opponent.ability == :ORN_CACOPHONY && !opponent.moldbroken && (type == :SOUND || (!secondtype.nil? && secondtype.include?(:SOUND)))
      if opponent.pbCanIncreaseStatStage?(PBStats::SPATK)
        opponent.pbIncreaseStatBasic(PBStats::SPATK, 1)
        @battle.pbCommonAnimation("StatUp", opponent, nil)
        @battle.pbDisplay(_INTL("{1}'s {2} raised its Special Attack!", opponent.pbThis, getAbilityName(opponent.ability)))
      else
        @battle.pbDisplay(_INTL("{1}'s {2} made {3} ineffective!", opponent.pbThis, getAbilityName(opponent.ability), self.name))
      end
      return 0
    elsif opponent.ability == :ORN_COMETSTORM && !opponent.moldbroken && (type == :ROCK || (!secondtype.nil? && secondtype.include?(:ROCK)))
      if opponent.pbCanIncreaseStatStage?(PBStats::SPATK)
        opponent.pbIncreaseStatBasic(PBStats::SPATK, 1)
        @battle.pbCommonAnimation("StatUp", opponent, nil)
        @battle.pbDisplay(_INTL("{1}'s {2} raised its Special Attack!", opponent.pbThis, getAbilityName(opponent.ability)))
      else
        @battle.pbDisplay(_INTL("{1}'s {2} made {3} ineffective!", opponent.pbThis, getAbilityName(opponent.ability), self.name))
      end
      if opponent.pbCanIncreaseStatStage?(PBStats::SPEED)
        opponent.pbIncreaseStatBasic(PBStats::SPEED, 1)
        @battle.pbCommonAnimation("StatUp", opponent, nil)
        @battle.pbDisplay(_INTL("{1}'s {2} raised its Speed!", opponent.pbThis, getAbilityName(opponent.ability)))
      else
        @battle.pbDisplay(_INTL("{1}'s {2} made {3} ineffective!", opponent.pbThis, getAbilityName(opponent.ability), self.name))
      end
      return 0
    else
      return warden_pbTypeModMessages(type, attacker, opponent)
    end
  end

  def pbAccuracyCheck(attacker, opponent)
    return true if attacker.ability == :ORN_SHARPSHOOTER && !@move.contactMove?
    accstage = attacker.stages[PBStats::ACCURACY]
    accstage = 0 if opponent.ability == :UNAWARE && !opponent.moldbroken
    evastage = opponent.stages[PBStats::EVASION]
    evastage = 0 if opponent.effects[:Foresight] || opponent.effects[:MiracleEye] || @function == 0xA9 || ([:UNAWARE, :KEENEYE, :MINDSEYE].include?(attacker.ability) && !opponent.moldbroken) # Gen 9 Mod - Added Mind's Eye
    accstage -= evastage
    accstage = accstage.clamp(-6, 6)
    accuracy = accstage >= 0 ? (accstage + 3) * 100.0 / 3 : 300.0 / (3 - accstage)
    if attacker.ability == :HUSTLE && @basedamage > 0 && pbIsSpecial?(pbType(attacker))
      accuracy *= 0.8
      return @battle.pbRandom(100) < (baseaccuracy * accuracy / 100.0).floor
    elsif attacker.ability == :ORN_PRECISION
      accuracy *= 1.3
      return @battle.pbRandom(100) < (baseaccuracy * accuracy / 100.0).floor
    end
    return warden_pbAccuracyCheck(attacker, opponent)
  end

  def pbType(attacker, type = @type)
    old_type = type
    if !PBStuff::ZMOVES.include?(@move)
      case attacker.ability
        when :ORN_BLACKLIGHT then type = :DARK   if type == :LIGHT
        when :ORN_WHITEOUT   then type = :LIGHT  if type == :DARK
        when :ORN_DARKMATTER then type = :COSMIC if type == :NORMAL
      end
    end
    return type if old_type != type
    return warden_pbType(attacker, type = @type)
  end

  def pbReduceHPDamage(damage, attacker, opponent)
    ward_abils = [:ORN_ETHEREAL,:ORN_TELEFACE,:ORN_DESTRUCTIVECORE]
    if ward_abils.include?(opponent.ability)
      if opponent.effects[:Ethereal] && (!attacker || attacker.index != opponent.index) && contactMove?
          opponent.effects[:Substitute] <= 0 && opponent.damagestate.typemod != 0 && !opponent.moldbroken
        @battle.pbDisplay(_INTL("The attack phased through {1}'s Ethereal form.", opponent.name))
        opponent.effects[:Ethereal] = false
        damage = 0
        @battle.pbDisplay(_INTL("{1} became corporeal.", opponent.name))
      end
      if opponent.effects[:Teleface] && (!attacker || attacker.index != opponent.index) && opponent.effects[:Substitute] <= 0 && opponent.damagestate.typemod != 0 && !opponent.moldbroken && move.pbIsPhysical?
        @battle.pbDisplay(_INTL("{1}'s TV was busted!", opponent.name))
        opponent.effects[:Teleface] = false
        damage = 0
      end
      return damage
    else
      return warden_pbReduceHPDamage(damage, attacker, opponent)
    end
  end
end

class PokeBattle_Battle
  alias warden_pbEndOfRoundPhase pbEndOfRoundPhase
  alias warden_pbIsUnlosableItem pbIsUnlosableItem

  def pbIsUnlosableItem(pkmn,item)
    return true if PBStuff::WARDEN_MEGASTONE[pkmn.species].include?(item)
    return warden_pbIsUnlosableItem(pkmn,item)
  end

  def pbEndOfRoundPhase
    priority = pbPriority
    for i in priority
      # Pure Heart
      if i.ability == :ORN_PUREHEART
        i.pbRecoverHP((i.totalhp / 16.0).floor, true)
        pbDisplay(_INTL("{1}'s Pure Heart restored its health!", i.pbThis))
      elsif i.ability == :ORN_CLAYFORM && pbWeather == :SANDSTORM
        i.pbRecoverHP((i.totalhp / 8.0).floor, true)
        pbDisplay(_INTL("{1}'s Clay Form restored its health!", i.pbThis))
      elsif i.ability == :ORN_SYNTHESIZE && pbWeather == :SUNNYDAY
        i.pbRecoverHP((i.totalhp / 8.0).floor, true)
        pbDisplay(_INTL("{1}'s Synthesize restored its health!", i.pbThis))
      end
      if @battle.state.effects[:ELECTERRAIN] > 0 || @battle.FE == :ELECTERRAIN
        for facemon in @battlers
          if facemon.species == :ORN_EISCUE && facemon.form == 1   # Eiscue
            facemon.pbRegenTele
            pbDisplayPaused(_INTL("{1} transformed!", facemon.name))
          end
        end
      end
    end
    warden_pbEndOfRoundPhase
  end
end

class PokeBattle_Battler
  attr_accessor :statsRaisedSinceLastCheck # Gen 9 Mod - Used for Opportunist


  alias warden_pbProcessMoveAgainstTarget pbProcessMoveAgainstTarget
  alias warden_pbCompatibleZMoveFromMove? pbCompatibleZMoveFromMove?
  alias warden_pbEffectsOnDealingDamage pbEffectsOnDealingDamage
  alias warden_pbCanReduceStatStage? pbCanReduceStatStage?
  alias warden_pbAbilitiesOnSwitchIn pbAbilitiesOnSwitchIn
  alias warden_pbCheckFormRoundEnd pbCheckFormRoundEnd
  alias warden_pbSuccessCheck pbSuccessCheck
  alias warden_pbInitEffects pbInitEffects
  alias warden_pbCanStatus? pbCanStatus?
  alias warden_pbCheckForm pbCheckForm
  alias wardens_initialize initialize

  def initialize(btl,index,fakebattler=false)
     @statsRaisedSinceLastCheck = {}; @statsRaisedSinceLastCheck.default = 0 # Gen 9 Mod - Used for Opportunist
     wardens_initialize(btl,index,fakebattler=false)
  end
  
  def pbInitEffects(batonpass, fakebattler=false)
    warden_pbInitEffects(batonpass, fakebattler=false)
    @effects[:Ethereal] = (self.ability == :ORN_ETHEREAL)
    @effects[:Teleface] = (self.ability == :ORN_TELEFACE && self.species==:ORN_EISCUE && self.form==0)
  end

  def pbSuccessCheck(basemove,user,target,flags,accuracy=true)
    return true if user.ability == :ORN_SHARPSHOOTER && !basemove.contactMove?
    return warden_pbSuccessCheck(basemove,user,target,flags,accuracy)
  end

  def pbAbilitiesOnSwitchIn(onactive)
    return if @hp <= 0
    # Dishearten
    warden_pbAbilitiesOnSwitchIn(onactive)
    # Gen 9 Mod - Hadron Engine
    if self.ability == :ORN_HADRONENGINE && onactive
      if @battle.FE == :FROZENDIMENSION
        @battle.pbDisplay(_INTL("The frozen dimension remains unchanged."))
      else
        @battle.pbAnimation(:ELECTRICTERRAIN,self,nil)
        @battle.setField(:ELECTERRAIN,duration)
        @battle.pbDisplay(_INTL("{2} turned the ground into Electric Terrain, energizing its futuristic engine!", pbThis))
      end
    end
    # Gen 9 Mod - Added Costar
    if self.ability == (:ORN_COSTAR) && onactive
      worked = false
      for i in 1...pbPartner.stages.length # skips HP
        if pbPartner.stages[i] != 0
          self.stages[i] = pbPartner.stages[i]
          worked = true
        end
      end
      # Gen 9 Mod - Critical increase should also be copied by Costar
      @effects[:FocusEnergy] = pbPartner.effects[:FocusEnergy]
      if worked
        @battle.pbCommonAnimation("Costar", self, pbPartner)
        @battle.pbDisplay(_INTL("{1}'s {2} copied {3}'s stat changes!", pbThis, getAbilityName(self.ability), pbPartner.pbThis(true)))
      end
    end
    # Gen 9 Mod - Added Wind Rider
    if self.ability == (:ORN_WINDRIDER) && onactive && pbOwnSide.effects[:Tailwind] > 0
      self.pbIncreaseStatBasic(PBStats::ATTACK, 1)
      @battle.pbCommonAnimation("StatUp", self, nil)
      @battle.pbDisplay(_INTL("{1}'s Wind Rider raised its Attack!", pbThis))
    end

    if self.ability == :ORN_DISHEARTEN && onactive
      for i in 0...4
        next if !pbIsOpposing?(i) || @battle.battlers[i].isFainted?
        @battle.battlers[i].pbReduceSpecialAttackStatStageDishearten(self)
      end
    elsif self.ability == :ORN_DISARRAY && onactive
      if @battle.trickroom == 0
        @battle.trickroom = 5
        if [:CHESS, :NEWWORLD, :PSYTERRAIN].include?(@battle.FE) || self.hasWorkingItem(:AMPLIFIELDROCK) || (Rejuv && @battle.FE == :STARLIGHT)
          @battle.trickroom = 8
        end
        if @battle.FE == :DIMENSIONAL
          rnd = @battle.pbRandom(6)
          @battle.trickroom = 3 + rnd
        end
        @battle.pbDisplay(_INTL("{1} twisted the dimensions!", self.pbThis))
      else
        @battle.trickroom = 0
        @battle.pbDisplay(_INTL("The twisted dimensions returned to normal!", self.pbThis))
      end
      for i in @battle.battlers
        if i.hasWorkingItem(:ROOMSERVICE)
          if i.pbReduceStat(PBStats::SPEED, 1, abilitymessage: false, statdropper: i)
            if i.ability == :CONTRARY && !i.moldbroken
              @battle.pbDisplay(_INTL("The Room Service raised #{i.pbThis}'s Speed!"))
            else
              @battle.pbDisplay(_INTL("The Room Service lowered #{i.pbThis}'s Speed!"))
            end
            i.pbDisposeItem(false)
          end
        end
      end
    elsif self.ability == :TELEFACE && self.form == 1 && self.species == :ORN_EISCUE && onactive
      if @battle.state.effects[:ELECTERRAIN] > 0 || @battle.FE == :ELECTERRAIN
        self.pbRegenTele
        @battle.pbDisplay(_INTL("{1} transformed!",self.pbThis))
      end
    end
  end

  def pbEffectsOnDealingDamage(move, user, target, damage, innards)
    return if target.nil?
    return if move.basedamage == 0
    if target.damagestate.calcdamage > 0
      if !target.damagestate.substitute && !move.zmove
        if target.ability == :ORN_VITALITY
          if target.pbCanIncreaseStatStage?(PBStats::SPDEF)
            target.pbIncreaseStatBasic(PBStats::SPDEF, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s {2} raised its Special Defense!", target.pbThis, getAbilityName(target.ability)))
          end
        elsif move.contactMove? && PBStuff::BITEMOVE.include?(move)
          if user.ability == :ORN_LEECHINGFANGS
            changehp=(target.totalhp/8).floor # Changed by DemICE 06-Oct-2023 Reworking Leeching Fangs to absorb 1/8 of opponent's total hp.
            changehp*=1.3 if user.hasActiveItem?(:BIGROOT)
            if target.ability == :LIQUIDOOZE
              changehp*=2 if (@battle.FE == :WASTELAND || @battle.FE == :MURKWATERSURFACE || @battle.FE == :CORRUPTED)
              user.pbReduceHP(changehp, true)
              @battle.pbDisplay(_INTL("{1} sucked up the liquid ooze!", user.pbThis))
            else
              user.pbRecoverHP(changehp, true)
              @battle.pbDisplay(_INTL("{1} drained HP with {2}!",user.pbThis,user.abilityName))
            end
          end
        elsif target.ability == :ORN_HIVEBODY && move.contactMove?
          chance = 50
          if @battle.pbRandom(100) >= chance
            user.effects[:MultiTurn] = 5 + @battle.pbRandom(2)
            user.effects[:MultiTurn] = 8 if target.hasWorkingItem(:GRIPCLAW)
            user.effects[:MultiTurnAttack] = :INFESTATION
            user.effects[:MultiTurnUser] = target.index
            @battle.pbDisplay(_INTL("{1} has been infested!", user.pbThis))
          end
        elsif target.ability == :ORN_MAELSTROM && move.contactMove?
          chance = 50
          if @battle.pbRandom(100) >= chance
            user.effects[:MultiTurn] = 5 + @battle.pbRandom(2)
            user.effects[:MultiTurn] = 8 if target.hasWorkingItem(:GRIPCLAW)
            user.effects[:MultiTurnAttack] = :WHIRLPOOL
            user.effects[:MultiTurnUser] = target.index
            @battle.pbDisplay(_INTL("{1} became trapped in the vortex!", user.pbThis))
          end
        elsif target.ability == :ORN_SCORCHSCALE && move.priority > 0
          user.pbBurn(target) if user.pbCanBurn?(false) && @battle.FE != :FROZENDIMENSION
          @battle.pbDisplay(_INTL("{1}'s {2} burned {3}!", target.pbThis, getAbilityName(target.ability), user.pbThis(true)))
        end
      end
    end
    if !target.damagestate.substitute
      # Gen 9 Mod - Added Toxic Debris.
      if target.ability == (:ORN_TOXICDEBRIS) && target.pbOpposingSide.effects[:ToxicSpikes] < 2 && move.pbIsPhysical?(movetypes) && !(@battle.FE == :WATERS || @battle.FE == :MURKWATERS)
         target.pbOpposingSide.effects[:ToxicSpikes] += 1
        if !@battle.pbIsOpposing?(target.index)
           @battle.pbDisplay(_INTL("Poison spikes were scattered all around the foe's team's feet!"))
        else
           @battle.pbDisplay(_INTL("Poison spikes were scattered all around your team's feet!"))
        end
      end
	end
	warden_pbEffectsOnDealingDamage(move, user, target, damage, innards)
  end

  def pbCanReduceStatStage?(stat, showMessages = false, selfreduce = false)
    return false if isFainted? && !(Rejuv && isbossmon && @shieldCount > 0)
    if !selfreduce
     abilityname = getAbilityName(self.ability)
     if stat == PBStats::DEFENSE && self.ability == :ORN_UNBREAKABLE && !self.moldbroken
        @battle.pbDisplay(_INTL("{1}'s {2} prevents Defense loss!", pbThis, abilityname)) if showMessages
        return false
      elsif stat == PBStats::SPATK && self.ability == :ORN_INTUITION && !self.moldbroken
        @battle.pbDisplay(_INTL("{1}'s {2} prevents Special Attack loss!", pbThis, abilityname)) if showMessages
        return false
      elsif [PBStats::DEFENSE,PBStats::SPDEF].include?(stat) && self.ability == :ORN_IMPENETRABLE && !self.moldbroken
        @battle.pbDisplay(_INTL("{1}'s {2} prevents Defense loss!", pbThis, abilityname)) if showMessages && stat == PBStats::DEFENSE
        @battle.pbDisplay(_INTL("{1}'s {2} prevents Special Defense loss!", pbThis, abilityname)) if showMessages && stat == PBStats::SPDEF
        return false
      elsif ([self.ability,pbPartner.ability].include?(:ORN_NEBULACLOUD) && hasType?(:COSMIC) && !self.moldbroken)
        cloud_user = (pbPartner.ability == :ORN_NEBULACLOUD) ? pbPartner.pbThis : pbThis
        @battle.pbDisplay(_INTL("{1}'s {2} prevents Stat loss!", cloud_user, abilityname)) if showMessages
        return false
      else
        return warden_pbCanReduceStatStage?(stat, showMessages, selfreduce)
      end
    else
      return warden_pbCanReduceStatStage?(stat, showMessages, selfreduce)
    end
  end
  
  def pbProcessMoveAgainstTarget(basemove,user,target,numhits,flags={totaldamage: 0},nocheck=false,alltargets=nil,showanimation=true)
    if target
      aboveHalfHp = target.hp > (target.totalhp / 2.0).floor
      fainted = target.isFainted?
      if !fainted && aboveHalfHp && target.hp <= (target.totalhp / 2.0).floor && damage > 0
        if target.ability == :ORN_FORTIFICATION
          if !pbTooHigh?(PBStats::DEFENSE)
            target.pbIncreaseStatBasic(PBStats::DEFENSE, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s Fortifiction boosted its Defense!", target.pbThis))
          end
          if !pbTooHigh?(PBStats::SPDEF)
            target.pbIncreaseStatBasic(PBStats::SPDEF, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s Fortifiction boosted its Special Defense!", target.pbThis))
          end
        elsif target.ability == :ORN_TERMINATOR
          if !pbTooHigh?(PBStats::ATTACK)
            target.pbIncreaseStatBasic(PBStats::ATTACK, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s Terminator boosted its Attack!", target.pbThis))
          end
        elsif target.ability == :ORN_VENGEFUL
          if !pbTooHigh?(PBStats::ATTACK)
            target.pbIncreaseStatBasic(PBStats::ATTACK, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s Vengeful boosted its Attack!", target.pbThis))
          end
          if !pbTooHigh?(PBStats::SPEED)
            target.pbIncreaseStatBasic(PBStats::SPEED, 1)
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s Vengeful boosted its Speed!", target.pbThis))
          end
        end
        # Gen 9 Mod - Anger Shell
        if target.ability == :ORN_ANGERSHELL
          statup = false
          for stat in [PBStats::ATTACK, PBStats::SPATK, PBStats::SPEED]
            if !pbTooHigh?(stat)
              statgain = 1
              target.pbIncreaseStatBasic(stat, statgain)
              statup = true
            end
          end
          statdown = false
          for stat in [PBStats::DEFENSE, PBStats::SPDEF]
            if !pbTooLow?(stat)
              statloss = 1
              target.pbReduceStatBasic(stat, statloss)
              statdown = true
            end
          end
          @battle.pbDisplay(_INTL("{1}'s Anger Shell was activated!", target.pbThis)) if statup || statdown
          if statup
            @battle.pbCommonAnimation("StatUp", target, nil)
            @battle.pbDisplay(_INTL("{1}'s Special Attack, Attack and Speed rose!", target.pbThis))
          end
          if statdown
            @battle.pbCommonAnimation("StatDown", target, nil)
            @battle.pbDisplay(_INTL("{1}'s Defense and Special Defense fell!", target.pbThis))
          end
        end

      end
    end
    if user.ability == :ORN_REAPER && target.isFainted?
      user.pbRecoverHP(user.totalhp / 5)
      @battle.pbCommonAnimation("StatUp", target, nil)
      @battle.pbDisplay(_INTL("{1} restored health by defeating the foe!", user.pbThis))
    end
	if target.isFainted?
	  if user.ability == :ORN_CHARISMA && user.hp>0 && target.hp<=0
        if !user.pbTooHigh?(PBStats::SPATK)
          @battle.pbCommonAnimation("StatUp",self,nil)
          user.pbIncreaseStatBasic(PBStats::SPATK,1)
          @battle.pbDisplay(_INTL("{1}'s {2} raised its Special Attack!",user.pbThis,$cache.abil[user.ability].name))
        end
      end
    end
	return warden_pbProcessMoveAgainstTarget(basemove,user,target,numhits,flags,nocheck,alltargets,showanimation)
  end

  def pbCanStatus?(showMessages,ignorestatus=false)
    failure = :none
    failure = :ORN_NEBULACLOUD if ((@ability == :ORN_NEBULACLOUD || pbPartner.ability == :ORN_NEBULACLOUD)) && hasType?(:COSMIC) && !moldbroken
    if failure != :none
      if showMessages
        case failure
          when :ORN_NEBULACLOUD then @battle.pbDisplay(_INTL("{1} is protected by Nebula Cloud!", pbThis))
        end
      end
      return false
    else
      return warden_pbCanStatus?(showMessages, ignorestatus)
    end
  end

  def pbCheckForm(basemove = nil)
    transformed = false
    if (self.pokemon && self.pokemon.species == :ORN_TOGEDEMARU) && !self.isFainted?
      if self.ability == :ORN_DESTRUCTIVECORE && @hp<=((@totalhp/2.0).floor)
        if self.form == 0
          self.form = 1; transformed=true
        end
      end
    end
    if transformed
    end
    warden_pbCheckForm(basemove = nil)
  end

  def pbCheckFormRoundEnd
    # Warden Mons
    if self.species == :ORN_WISHIWASHI && !self.isFainted?
      if self.ability == :ORN_DARKSWARM && !@effects[:Transform]
        schoolHP = (self.totalhp / 4.0).floor
        if (self.hp > schoolHP && self.level > 19)
          if self.form != 1
            self.form = 1
            pbUpdate(true)
            @battle.scene.pbChangePokemon(self, @pokemon)
            @battle.pbDisplay(_INTL("{1} formed a swarm!", pbThis))
          end
        else
          if self.form != 0
            self.form = 0
            pbUpdate(true)
            @battle.scene.pbChangePokemon(self, @pokemon)
            @battle.pbDisplay(_INTL("{1} stopped swarming!", pbThis))
          end
        end
      end
    end
    if self.species == :ORN_UNOWN && !self.isFainted?
      if self.ability == :ORN_SYMPHONY && !@effects[:Transform]
        schoolHP = (self.totalhp / 4.0).floor
        if (self.hp > schoolHP && self.level > 19)
          if self.form != 1
            self.form = 1
            pbUpdate(true)
            @battle.scene.pbChangePokemon(self, @pokemon)
            @battle.pbDisplay(_INTL("{1} formed a symphony!", pbThis))
          end
        else
          if self.form != 0
            self.form = 0
            pbUpdate(true)
            @battle.scene.pbChangePokemon(self, @pokemon)
            @battle.pbDisplay(_INTL("{1} stopped coordinating!", pbThis))
          end
        end
      end
    end
    warden_pbCheckFormRoundEnd
  end
  
  def pbCompatibleZMoveFromMove?(move,moveindex = false)
    pkmn=self
    return true if pkmn.item == :WARDENIUMZ
    return warden_pbCompatibleZMoveFromMove?(move,moveindex = false)
  end
  
  # New Definitions
  def pbReduceSpecialAttackStatStageDishearten(opponent)
    # Ways intimidate doesn't work
    return false if isFainted? && !(Rejuv && isbossmon && @shieldCount > 0)
    return false if @effects[:Substitute] > 0

    if [:CLEARBODY, :WHITESMOKE, :HYPERCUTTER, :FULLMETALBODY].include?(self.ability) || (Gen > 7 && [:INNERFOCUS, :OBLIVIOUS, :OWNTEMPO, :SCRAPPY].include?(self.ability))
      abilityname = getAbilityName(self.ability)
      oppabilityname = getAbilityName(opponent.ability)
      @battle.pbDisplay(_INTL("{1}'s {2} prevented {3}'s {4} from working!", pbThis, abilityname, opponent.pbThis(true), oppabilityname))
      if hasWorkingItem(:ADRENALINEORB) && pbCanIncreaseStatStage?(PBStats::SPEED, false) && self.stages[PBStats::SPATK] > -6
        triggerAdrenalineOrb
      end
      return false
    end
    if pbOwnSide.effects[:Mist] > 0
      @battle.pbDisplay(_INTL("{1} is protected by Mist!", pbThis))
      if hasWorkingItem(:ADRENALINEORB) && pbCanIncreaseStatStage?(PBStats::SPEED, false) && self.stages[PBStats::SPATK] > -6
        triggerAdrenalineOrb
      end
      return false
    end
    # Gen 9 Mod - Clear Amulet prevents stat drop from intimidate
    if hasWorkingItem(:CLEARAMULET)
      itemname = getItemName(self.item)
      oppabilityname = getAbilityName(opponent.ability)
      @battle.pbDisplay(_INTL("{1}'s {2} prevented {3}'s {4} from working!", pbThis, itemname, opponent.pbThis(true), oppabilityname))
      return false
    end
    # Gen 9 Mod - Guard Dog raises attack on Intimidate
    if (self.ability == :GUARDDOG)
      @battle.pbDisplay(_INTL("{1} got angry!",pbThis))
      pbIncreaseStat(PBStats::SPATK, 1)
      if hasWorkingItem(:ADRENALINEORB) && pbCanIncreaseStatStage?(PBStats::SPEED, false) && self.stages[PBStats::SPATK] > -6
        triggerAdrenalineOrb
      end
      return false
    end

    # reduce stat only if you can
    if @battle.FE == :CROWD && pbCanReduceStatStage?(PBStats::DEFENSE, false)
      pbReduceStat(PBStats::DEFENSE, 1, statmessage: false, statdropper: opponent, defiant_proc: false)
      oppabilityname = getAbilityName(opponent.ability)
      @battle.pbDisplay(_INTL("{1}'s {2} cuts {3}'s Defense!", opponent.pbThis, oppabilityname, pbThis(true))) if self.ability != :CONTRARY
      @battle.pbDisplay(_INTL("{1}'s {2} boosts {3}'s Defense!", opponent.pbThis, oppabilityname, pbThis(true))) if self.ability == :CONTRARY
      # Defiant/Competitive
      if self.ability == :DEFIANT
        increment = 2
        increment = 3 if @battle.FE == :BACKALLEY
        pbIncreaseStat(PBStats::SPATK, increment, statmessage: false)
        if @battle.FE == :BACKALLEY
          @battle.pbDisplay(_INTL("Defiant dramatically raised {1}'s Special Attck!", pbThis))
        else
          @battle.pbDisplay(_INTL("Defiant sharply raised {1}'s Special Attck!", pbThis))
        end
      end
      if self.ability == :COMPETITIVE && !(Rejuv && @battle.FE == :CHESS)
        increment = 2
        increment = 3 if @battle.FE == :CITY
        pbIncreaseStat(PBStats::ATTACK, increment, statmessage: false)
        if @battle.FE == :CITY
          @battle.pbDisplay(_INTL("Competitive dramatically raised {1}'s Attack!", pbThis))
        else
          @battle.pbDisplay(_INTL("Competitive sharply raised {1}'s Attack!", pbThis))
        end
      end
    end
    if pbReduceStat(PBStats::SPATK, 1, statmessage: false, statdropper: opponent, defiant_proc: false)
      # Battle message
      oppabilityname = getAbilityName(opponent.ability)
      @battle.pbDisplay(_INTL("{1}'s {2} cuts {3}'s Special Attck!", opponent.pbThis, oppabilityname, pbThis(true))) if !(self.ability == :CONTRARY)
      @battle.pbDisplay(_INTL("{1}'s {2} boosts {3}'s Special Attck!", opponent.pbThis, oppabilityname, pbThis(true))) if (self.ability == :CONTRARY)

      if self.ability == :RATTLED && Gen > 7
        pbIncreaseStat(PBStats::SPEED, 1, statmessage: false)
        @battle.pbDisplay(_INTL("{1}'s Rattled raised its Speed!", pbThis))
      end

      # Defiant/Competitive
      if self.ability == :DEFIANT
        increment = 2
        increment = 3 if @battle.FE == :BACKALLEY
        pbIncreaseStat(PBStats::SPATK, increment, statmessage: false)
        if @battle.FE == :BACKALLEY
          @battle.pbDisplay(_INTL("Defiant dramatically raised {1}'s Special Attck!", pbThis))
        else
          @battle.pbDisplay(_INTL("Defiant sharply raised {1}'s Special Attck!", pbThis))
        end
      end
      if self.ability == :COMPETITIVE && !(Rejuv && @battle.FE == :CHESS)
        increment = 2
        increment = 3 if @battle.FE == :CITY
        pbIncreaseStat(PBStats::ATTACK, increment, statmessage: false)
        if @battle.FE == :CITY
          @battle.pbDisplay(_INTL("Competitive dramatically raised {1}'s Attack!", pbThis))
        else
          @battle.pbDisplay(_INTL("Competitive sharply raised {1}'s Attack!", pbThis))
        end
      end

      # Item triggers
      if hasWorkingItem(:ADRENALINEORB) && pbCanIncreaseStatStage?(PBStats::SPEED, false)
        triggerAdrenalineOrb
      end
      if hasWorkingItem(:WHITEHERB)
        reducedstats = false
        for i in 1..7
          if self.stages[i] < 0
            self.stages[i] = 0
            reducedstats = true
          end
        end
        if reducedstats
          itemname = self.item.nil? ? "" : getItemName(self.item)
          @battle.pbDisplay(_INTL("{1}'s {2} restored its status!", pbThis, itemname))
          pbDisposeItem(false)
        end
      end

      return true
    end
    return false
  end

  def pbRegenTele
    self.form=0
    @effects[:Teleface] = true
    pbUpdate(true)
    @battle.scene.pbChangePokemon(self,@pokemon)
  end

  def pbResetForm
    return if !@pokemon
    if !@effects[:Transform]
      if (@pokemon.species == :AEGISLASH && self.form < 2) || [:CASTFORM, :CHERRIM, :WISHIWASHI, :DITTO, :MEW, :MORPEKO, :CRAMORANT, :ORN_WISHIWASHI, :ORN_UNOWN].include?(@pokemon.species) 
      elsif [:DARMANITAN, :MINIOR, :ORN_TOGEDEMARU].include?(@pokemon.species)
        self.form=@startform
      end
    end
    pbUpdate(true)
  end
end

# Superclass for moves which apply an effect to every Pokemon on the field.
class PokeBattle_AllTargetMove < PokeBattle_Move
  def priorityBlockedForAllTargetMoves?(attacker)
    # Priority blocking abilities by the opponent prevent certain moves from going through on ALL Pokemon if used via Prankster
    @battle.battlers.each do |battler|
      if battler != attacker && battler != attacker.pbPartner
        prior_block = ([:ORN_NOBILITY,:QUEENLYMAJESTY,:DAZZLING].include?(battler.ability) || (@battle.FE == :STARLIGHT && battler.ability == :MIRRORARMOR)) ? true : false
        if !battler.moldbroken && prior_block
          if priorityCheck(attacker) > 0 && @battle.choices[attacker.index][2] == self # && !flags[:instructed]
            @battle.pbDisplay(_INTL("{1} cannot use {2}!", attacker.pbThis, self.name))
            return true
          end
        end
      end
    end
    return false
  end
end

class PokeBattle_Battler
  # Gen 9 Mod - Changed definition of pbIncreaseStatBasic to include new 'mirrorable' param, which is required for Opportunist and Mirror Herb.
  def pbIncreaseStatBasic(stat,increment, mirrorable:true)
    increment *= 2 if (self.ability == :SIMPLE) && !(self.moldbroken)
    initial = @stages[stat]
    @stages[stat] += increment
    @stages[stat] = 6 if @stages[stat] > 6
    @effects[:Jealousy] = true
    @statsRaisedSinceLastCheck[stat] += @stages[stat] - initial if mirrorable
  end

  # Gen 9 Mod - Changed definition of pbIncreaseStat to include new 'mirrorable' param, which is required for Opportunist and Mirror Herb.
  # changed from: def pbIncreaseStat(stat,increment,showMessages,attacker=nil,upanim=true)
  def pbIncreaseStat(stat, increment, abilitymessage:true, statmessage:true, ignoreContrary: false, statsource: nil, mirrorable:true)
    # Contrary handling
    if self.ability == :CONTRARY && !self.moldbroken && !ignoreContrary
      @statrepeat = true
      return pbReduceStat(stat, increment, abilitymessage: abilitymessage, statmessage: statmessage, ignoreContrary: true, statdropper: statsource, mirrorable: mirrorable)
    end

    # Increase stat only if you can
    if pbCanIncreaseStatStage?(stat, abilitymessage)
      pbIncreaseStatBasic(stat, increment, mirrorable: mirrorable)

      # Animation
      if !@statupanimplayed
        @battle.pbCommonAnimation("StatUp", self, nil)
        @statupanimplayed = true
      end

      # Battle message
      arrStatTexts = [
        _INTL("{1}'s {2} rose!", pbThis, pbGetStatName(stat)),
        _INTL("{1}'s {2} rose sharply!", pbThis, pbGetStatName(stat)),
        _INTL("{1}'s {2} rose drastically!", pbThis, pbGetStatName(stat)),
        _INTL("{1}'s {2} went way up!", pbThis, pbGetStatName(stat))
      ]
      increment *= 2 if self.ability == :SIMPLE && !self.moldbroken
      if increment > 3
        @battle.pbDisplay(arrStatTexts[3]) if statmessage
      elsif increment == 3
        @battle.pbDisplay(arrStatTexts[2]) if statmessage
      elsif increment == 2
        @battle.pbDisplay(arrStatTexts[1]) if statmessage
      else
        @battle.pbDisplay(arrStatTexts[0]) if statmessage
      end
      @battle.reduceField if stat == PBStats::EVASION && @battle.ProgressiveFieldCheck(PBFields::CONCERT, 2, 4)
      return true
    end
    return false
  end


  # Warden Ability Redirect
  def pbChangeTarget(basemove,userandtarget,targets)
    priority=@battle.pbPriority
    changeeffect=0
    user=userandtarget[0]
    target=userandtarget[1]
    targetchoices=pbTarget(basemove)
    if (basemove.function==0x179) || user.ability == (:STALWART) || user.ability == (:PROPELLERTAIL)
      return true
    end
    # LightningRod here, considers Hidden Power as Normal
    if targets.length==1 && basemove.pbType(user) == :ELECTRIC && target.ability != (:LIGHTNINGROD)
      for i in priority # use Pokémon earliest in priority
        next if i.index==user.index || i.isFainted?
        if i.ability == :LIGHTNINGROD && !i.moldbroken
          target=i # X's LightningRod took the attack!
          changeeffect=1
          break
        end
      end
    end
    # Storm Drain here, considers Hidden Power as Normal
    if targets.length==1 && basemove.type == :WATER && target.ability != (:STORMDRAIN)
      for i in priority # use Pokémon earliest in priority
        next if !pbIsOpposing?(i.index) || i.isFainted?
        if i.ability == :STORMDRAIN && !i.moldbroken
          target=i # X's Storm Drain took the attack!
          changeeffect=2
          break
        end
      end
    end
    # Cacophony here, considers Hidden Power as Normal
    if targets.length==1 && basemove.type == :SOUND && target.ability != (:ORN_CACOPHONY)
      for i in priority # use Pokémon earliest in priority
        next if !pbIsOpposing?(i.index) || i.isFainted?
        if i.ability == :ORN_CACOPHONY && !i.moldbroken
          target=i # X's Storm Drain took the attack!
          changeeffect=4
          break
        end
      end
    end
    # Change target to user of Follow Me (overrides Magic Coat
    # because check for Magic Coat below uses this target)
    if targetchoices==:SingleNonUser ||
      targetchoices==:SingleOpposing ||
      targetchoices==:RandomOpposing ||
      targetchoices==:OppositeOpposing
      for i in priority # use Pokémon latest in priority
        next if !pbIsOpposing?(i.index) || i.isFainted?
        if i.effects[:FollowMe] || i.effects[:RagePowder]
          unless (i.effects[:RagePowder] && (self.ability == :OVERCOAT || self.hasType?(:GRASS) || self.hasWorkingItem(:SAFETYGOGGLES)))# change target to this
            target=i
            changeeffect = 0
          end
        end
      end
    end
    # TODO: Pressure here is incorrect if Magic Coat redirects target
    if target.ability == (:PRESSURE)
      pbReducePP(basemove) # Reduce PP
      if @battle.FE == :DIMENSIONAL || @battle.FE == :DEEPEARTH
        pbReducePP(basemove)
      end
    end
    # Change user to user of Snatch
    if !basemove.zmove && basemove.canSnatch?
      for i in priority
        if i.effects[:Snatch]
          @battle.pbDisplay(_INTL("{1} Snatched {2}'s move!",i.pbThis,user.pbThis(true)))
          i.effects[:Snatch]=false
          target=user
          user=i
          # Snatch's PP is reduced if old user has Pressure
          userchoice=@battle.choices[user.index][1]
          if target.ability == (:PRESSURE) && userchoice>=0
            pressuremove=user.moves[userchoice]
            pbSetPP(pressuremove,pressuremove.pp-1) if pressuremove.pp>0
            if @battle.FE == :DIMENSIONAL || @battle.FE == :DEEPEARTH
              pressuremove=user.moves[userchoice]
              pbSetPP(pressuremove,pressuremove.pp-1) if pressuremove.pp>0
            end
          end
        end
      end
    end
    userandtarget[0]=user
    userandtarget[1]=target
    if target.ability == (:SOUNDPROOF) && basemove.isSoundBased? &&
       basemove.function!=0x19 &&   # Heal Bell handled elsewhere
       basemove.function!=0xE5 &&   # Perish Song handled elsewhere
       !(target.moldbroken)
      @battle.pbDisplay(_INTL("{1}'s {2} blocks {3}!",target.pbThis,
         getAbilityName(target.ability),basemove.name))
      return false
    end
    if !basemove.zmove && basemove.canMagicCoat? && target.effects[:MagicCoat]
      # switch user and target
      changeeffect=3
      target.effects[:MagicCoat]=false
      user, target = target, user

      # Magic Coat's PP is reduced if old user has Pressure
      userchoice=@battle.choices[user.index][1]
      if target.ability == (:PRESSURE) && userchoice>=0
        pressuremove=user.moves[userchoice]
        pbSetPP(pressuremove,pressuremove.pp-1) if pressuremove.pp>0
        if @battle.FE == :DIMENSIONAL || @battle.FE == :DEEPEARTH
          pressuremove=user.moves[userchoice]
          pbSetPP(pressuremove,pressuremove.pp-1) if pressuremove.pp>0
        end
      end
    end
    if !basemove.zmove && !(user.effects[:MagicBounced]) && basemove.canMagicCoat? && target.ability == (:MAGICBOUNCE) && !(target.moldbroken) &&
      !(basemove.function==0x103) && !(basemove.function==0x104) && !(basemove.function==0x105) && !(basemove.function==0x141) &&
      !PBStuff::TWOTURNMOVE.include?(target.effects[:TwoTurnAttack]) && changeeffect != 3
      target.effects[:MagicBounced]=true
      target.effects[:BouncedMove]=basemove
    end
    if changeeffect==1
      @battle.pbDisplay(_INTL("{1}'s Lightningrod took the move!",target.pbThis))
    elsif changeeffect==2
      @battle.pbDisplay(_INTL("{1}'s Storm Drain took the move!",target.pbThis))
    elsif changeeffect==3
      # Target refers to the move's old user
      @battle.pbDisplay(_INTL("{1}'s {2} was bounced back by Magic Coat!",user.pbThis,basemove.name))
    elsif changeeffect==4
      @battle.pbDisplay(_INTL("{1}'s Cacophony took the move!", target.pbThis))
    end
    userandtarget[0]=user
    userandtarget[1]=target
    if basemove.zmove
      targets[0]=target
    end
    return true
  end

  # Gen 9 Mod - Method to check for Opportunist and Mirror Herb triggers
  def opportunistCheck
    return if isFainted?
    return if self.ability != :ORN_OPPORTUNIST && !hasWorkingItem(:MIRRORHERB)
    for i in @battle.battlers
      next if i.isFainted? || !pbIsOpposing?(i.index)
      hash = i.statsRaisedSinceLastCheck
      if self.ability == :ORN_OPPORTUNIST && hash.keys.any? {|stat| hash[stat]>0 && pbCanIncreaseStatStage?(stat)}
        @battle.pbDisplay(_INTL("{1} seized the opportunity to boost its own stats!",pbThis))
        for stat in hash.keys
          pbIncreaseStat(stat,hash[stat], abilitymessage:false, mirrorable:false)
        end
      end
      if hasWorkingItem(:MIRRORHERB) && hash.keys.any? {|stat| hash[stat] > 0 && pbCanIncreaseStatStage?(stat)}
        @battle.pbDisplay(_INTL("{1} used its {2} to mirror its opponent's stat boosts!",pbThis, getItemName(self.item)))
        for stat in hash.keys
          pbIncreaseStat(stat, hash[stat], abilitymessage:false, mirrorable:false)
        end
        pbDisposeItem(false)
      end
    end
  end
end

class PokeBattle_Battle
################################################################################
# Battle core.
################################################################################
  def pbStartBattle(canlose=false)
    if !@fullparty1 && @party1.length>MAXPARTYSIZE
      raise ArgumentError.new(_INTL("Party 1 has more than {1} Pokémon.",MAXPARTYSIZE))
    end
    if !@fullparty2 && @party2.length>MAXPARTYSIZE
      raise ArgumentError.new(_INTL("Party 2 has more than {1} Pokémon.",MAXPARTYSIZE))
    end
    #========================
    # Initialize AI in battle 
    #========================
    if !isOnline?
      @ai = PokeBattle_AI.new(self) 
      $ai_log_data = [PokeBattle_AI_Info.new,PokeBattle_AI_Info.new,PokeBattle_AI_Info.new,PokeBattle_AI_Info.new]
    end
    if !@opponent
      #========================
      # Initialize wild Pokémon
      #========================
      if @party2.length==1
        wildpoke=@party2[0]
        @battlers[1].pbInitialize(wildpoke,0,false)
        @peer.pbOnEnteringBattle(self,wildpoke)
        $Trainer.pokedex.setSeen(wildpoke)
        @scene.pbStartBattle(self)
        pbDisplayPaused(_INTL("A wild {1} appeared!",wildpoke.name)) if !$game_switches[:Boss_Battle]
        if $game_switches[:Boss_Battle]
          if wildpoke.name == "Kyogre"
            pbDisplayPaused(_INTL("The Ancient Leviathan {1} attacked!",wildpoke.name)) 
          elsif wildpoke.name == "Giratina"
            pbDisplayPaused(_INTL("The Renegade {1} attacked!",wildpoke.name)) 
          elsif wildpoke.name == "Regirock"
            pbDisplayPaused(_INTL("The Guardian Soldier {1} attacked!",wildpoke.name)) 
          elsif wildpoke.name == "Gardevoir"
            pbDisplayPaused(_INTL("The Angel of Death {1} attacked!",wildpoke.name))
          elsif wildpoke.name == "Hippowdon"
            pbDisplayPaused(_INTL("{1} is waiting...",wildpoke.name))
          else
            pbDisplayPaused(_INTL("{1} attacked!",wildpoke.name))
          end
        elsif (PBStuff::LEGENDARYLIST).include?(wildpoke) && !$game_switches[:Boss_Battle]
          if wildpoke.name == "Arceus"
            pbDisplayPaused(_INTL("{1} accepts your challenge!",wildpoke.name))            
          else
            pbDisplayPaused(_INTL("{1} appeared!",wildpoke.name))
          end
        end
      elsif @party2.length==2
        @battlers[1].pbInitialize(@party2[0],0,false)
        @battlers[3].pbInitialize(@party2[1],0,false)
        @peer.pbOnEnteringBattle(self,@party2[0])
        @peer.pbOnEnteringBattle(self,@party2[1])
        $Trainer.pokedex.setSeen(@party2[0])
        $Trainer.pokedex.setSeen(@party2[1])
        @scene.pbStartBattle(self)
        pbDisplayPaused(_INTL("A wild {1} and\r\n{2} appeared!",
           @party2[0].name,@party2[1].name))
      else
        raise _INTL("Only one or two wild Pokémon are allowed")
      end
    elsif @doublebattle
      #=======================================
      # Initialize opponents in double battles
      #=======================================
      if @opponent.is_a?(Array)
        if @opponent.length==1
          @opponent=@opponent[0]
        elsif @opponent.length!=2
          raise _INTL("Opponents with zero or more than two people are not allowed")
        end
      end
      if @player.is_a?(Array)
        if @player.length==1
          @player=@player[0]
        elsif @player.length!=2
          raise _INTL("Player trainers with zero or more than two people are not allowed")
        end
      end
      @scene.pbStartBattle(self)
      if @opponent.is_a?(Array)
        pbDisplayPaused(_INTL("{1} and {2} want to battle!",@opponent[0].fullname,@opponent[1].fullname))
        sendout1=pbFindNextUnfainted(@party2,0,pbSecondPartyBegin(1))
        raise _INTL("Opponent 1 has no unfainted Pokémon") if sendout1<0
        sendout2=pbFindNextUnfainted(@party2,pbSecondPartyBegin(1))
        raise _INTL("Opponent 2 has no unfainted Pokémon") if sendout2<0
        @battlers[1].pbInitialize(@party2[sendout1],sendout1,false)
        @battlers[3].pbInitialize(@party2[sendout2],sendout2,false)
        pbDisplayBrief(_INTL("{1} sent\r\nout {2}!",@opponent[0].fullname,getMonName(@battlers[1].species))) 
        pbSendOut(1,@party2[sendout1])
        pbDisplayBrief(_INTL("{1} sent\r\nout {2}!",@opponent[1].fullname,getMonName(@battlers[3].species))) 
        pbSendOut(3,@party2[sendout2])
      else
        pbDisplayPaused(_INTL("{1}\r\nwould like to battle!",@opponent.fullname))
        sendout1=pbFindNextUnfainted(@party2,0)
        sendout2=pbFindNextUnfainted(@party2,sendout1+1)
        if sendout1<0 || sendout2<0
          raise _INTL("Opponent doesn't have two unfainted Pokémon")
        end
        @battlers[1].pbInitialize(@party2[sendout1],sendout1,false) 
        @battlers[3].pbInitialize(@party2[sendout2],sendout2,false)
        pbDisplayBrief(_INTL("{1} sent\r\nout {2} and {3}!", @opponent.fullname,getMonName(@battlers[1].species),getMonName(@battlers[3].species))) 
        pbSendOut(1,@party2[sendout1])
        pbSendOut(3,@party2[sendout2])
      end
    else
      #======================================
      # Initialize opponent in single battles
      #======================================
      sendout=pbFindNextUnfainted(@party2,0)
      raise _INTL("Trainer has no unfainted Pokémon") if sendout<0
      if @opponent.is_a?(Array)
        raise _INTL("Opponent trainer must be only one person in single battles") if @opponent.length!=1
        @opponent=@opponent[0]
      end
      if @player.is_a?(Array)
        raise _INTL("Player trainer must be only one person in single battles") if @player.length!=1
        @player=@player[0]
      end
      trainerpoke=@party2[sendout]
      @scene.pbStartBattle(self)
      pbDisplayPaused(_INTL("{1}\r\nwould like to battle!",@opponent.fullname))

      @battlers[1].pbInitialize(trainerpoke,sendout,false) 
      pbDisplayBrief(_INTL("{1} sent\r\nout {2}!",@opponent.fullname,getMonName(@battlers[1].species)))

      pbSendOut(1,trainerpoke)
    end
    #=====================================
    # Initialize players in double battles
    #=====================================
    if @doublebattle
      if @player.is_a?(Array)
        sendout1=pbFindNextUnfainted(@party1,0,pbSecondPartyBegin(0))
        raise _INTL("Player 1 has no unfainted Pokémon") if sendout1<0
        sendout2=pbFindNextUnfainted(@party1,pbSecondPartyBegin(0))
        raise _INTL("Player 2 has no unfainted Pokémon") if sendout2<0
        @battlers[0].pbInitialize(@party1[sendout1],sendout1,false) 
        @battlers[2].pbInitialize(@party1[sendout2],sendout2,false)
        pbDisplayBrief(_INTL("{1} sent\r\nout {2}! Go! {3}!", @player[1].fullname,@battlers[2].name,@battlers[0].name))
        $Trainer.pokedex.setSeen(@party1[sendout1])
        $Trainer.pokedex.setSeen(@party1[sendout2])
      else
        sendout1=pbFindNextUnfainted(@party1,0)
        sendout2=pbFindNextUnfainted(@party1,sendout1+1)
        @battlers[0].pbInitialize(@party1[sendout1],sendout1,false) 
        @battlers[2].pbInitialize(@party1[sendout2],sendout2,false) unless sendout2==-1
        if sendout2>-1
          pbDisplayPaused(_INTL("Go! {1} and {2}!",@battlers[0].name,@battlers[2].name)) 
        else
          pbDisplayPaused(_INTL("Go! {1}!",@battlers[0].name)) 
        end
      end
      pbSendOut(0,@party1[sendout1])
      pbSendOut(2,@party1[sendout2]) unless sendout2==-1
    else
      #====================================
      # Initialize player in single battles
      #====================================
      sendout=pbFindNextUnfainted(@party1,0)
      if sendout<0
        raise _INTL("Player has no unfainted Pokémon")
      end
      playerpoke=@party1[sendout]
      @battlers[0].pbInitialize(playerpoke,sendout,false) 
      pbDisplayBrief(_INTL("Go! {1}!",@battlers[0].name))
      pbSendOut(0,playerpoke)
    end
    #=======================================================
    # Keep track of who fainted in battle + piece assignment
    #=======================================================
    @fainted_mons = Array.new($Trainer.party.length) {|i| $Trainer.party[i].hp > 0 ? false : true}
    if @doublebattle
      if @player.is_a?(Array)
        pieceAssignment(pbPartySingleOwner(0),true)
        pieceAssignment(pbPartySingleOwner(2),true)
      else
        pieceAssignment(@party1,false)
      end
      if @opponent.is_a?(Array)
        pieceAssignment(pbPartySingleOwner(1),true)
        pieceAssignment(pbPartySingleOwner(3),true)
      else
        pieceAssignment(@party2,false)
      end
    else
      pieceAssignment(@party1,false)
      pieceAssignment(@party2,false)
    end
    
    #==================
    # Initialize battle
    #==================
    if @weather== :SUNNYDAY
      pbCommonAnimation("Sunny")
      pbDisplay(_INTL("The sunlight is strong."))
    elsif @weather== :RAINDANCE
      pbCommonAnimation("Rain")
      pbDisplay(_INTL("It is raining."))
    elsif @weather== :SANDSTORM
      pbCommonAnimation("Sandstorm")
      pbDisplay(_INTL("A sandstorm is raging."))
    elsif @weather== :HAIL
      pbCommonAnimation("Hail")
      pbDisplay(_INTL("Hail is falling."))
    elsif @weather== :STRONGWINDS
      pbCommonAnimation("Wind")
      pbDisplay(_INTL("The wind is strong."))
    elsif @weather== :SHADOWSKY
      pbCommonAnimation("ShadowSky")
      pbDisplay(_INTL("The sky is dark."))
    end
    # Field Effects BEGIN UPDATE
    if @field.introMessage
      fieldmessage = @field.introMessage
      fieldmessage = ["The dawn of a New World shines down upon the broken land."] if pbCheckGlobalAbility(:WORLDOFNIGHTMARES) && @field.effect == :STARLIGHT
      for i in 0...fieldmessage.length do
        pbDisplay(_INTL(fieldmessage[i]))
      end
      @state.effects[:Gravity]=-1 if @field.effect == :DEEPEARTH
      $game_variables[:Cave_Collapse] = 0
    end
    # END OF UPDATE
    priority=pbPriority
    for i in priority # Pre-surge seed check
      seedCheck
    end
    pbOnActiveAll   # Abilities
    for i in priority # Post-surge seed check
      seedCheck
    end

    # Gen 9 Mod - Checks and updates for Opportunist
    priority.each {|i| i.opportunistCheck}
    priority.each {|i| i.statsRaisedSinceLastCheck.clear}

    @turncount=1
    if !isOnline? #for subclassing- online processing continues separately
      loop do   # Now begin the battle loop
        break if @decision>0
        PBDebug.log("************************** Round #{@turncount} *******************************") if $INTERNAL
        if @debug && @turncount>=101
          @decision=pbDecisionOnTime()
          PBDebug.log("***[Undecided after 100 rounds]")
          pbAbort
          break
        end

        PBDebug.logonerr{
          pbCommandPhase
        }
        break if @decision>0

        PBDebug.logonerr{
          @midturn=true
          pbAttackPhase()
          @midturn=false
        }
        break if @decision>0

        PBDebug.logonerr{
          pbEndOfRoundPhase
        }
        break if @decision>0
        @turncount+=1
      end
      return pbEndOfBattle(canlose)
    end
  end

################################################################################
# Attack phase.
################################################################################
  def pbAttackPhase
    @scene.pbBeginAttackPhase
    for i in 0...4
      @successStates[i].clear
      if @choices[i][0]!=1 && @choices[i][0]!=2
        #@battlers[i].effects[:DestinyBond]=false # Effect gets removed on move use, NOT move choice
        @battlers[i].effects[:Grudge]=false
      end
      @battlers[i].turncount+=1 if !@battlers[i].isFainted?
      @battlers[i].turncount+=1 if !@battlers[i].isFainted? && @battlers[i].ability==:SLOWSTART && @field.effect==:ELECTERRAIN
      @battlers[i].effects[:Rage]=false if @choices[i][1].is_a?(Symbol)|| @battlers[i].moves[@choices[i][1]] != :RAGE
      #@battlers[i].pbCustapBerry # Moved to later, timing was incorrect here
    end
    # Prepare for Z Moves
    for i in 0..3
      next if @choices[i][0]!=1
      side=(pbIsOpposing?(i)) ? 1 : 0
      owner=pbGetOwnerIndex(i)
      if @zMove[side][owner]==i
        @choices[i][2].zmove=true
      end
    end
    # Calculate priority at this time
    @usepriority=false
    priority=pbPriority
    # Call at Pokémon
    for i in priority
      if @choices[i.index][0]==4
        pbCall(i.index)
      end
    end
    # Switch out Pokémon
    @switching=true
    switched=[]
    for i in priority
      if @choices[i.index][0]==2
        index=@choices[i.index][1] # party position of Pokémon to switch to
        self.lastMoveUser=i.index
        if !pbOwnedByPlayer?(i.index)
          owner=pbGetOwner(i.index)
          pbDisplayBrief(_INTL("{1} withdrew {2}!",owner.fullname,getMonName(i.species)))
        else
          pbDisplayBrief(_INTL("{1}, that's enough!\r\nCome back!",i.name))
        end
        for j in priority
          next if !i.pbIsOpposing?(j.index)
          # if Pursuit and this target ("i") was chosen
          if pbChoseMoveFunctionCode?(j.index,0x88) && !j.effects[:Pursuit] && (@choices[j.index][3]==-1 || @choices[j.index][3]==i.index)
            newpoke=pbPursuitInterrupt(j,i)
            return if @decision>0
          end
          break if i.isFainted?
        end
        if defined?(newpoke) && !newpoke.nil?
          index=newpoke
        end
        if !pbRecallAndReplace(i.index,index)
          # If a forced switch somehow occurs here in single battles
          # the attack phase now ends
          if !@doublebattle
            @switching=false
            return
          end
        else
          switched.push(i.index)
        end
      end
    end
    if switched.length>0
      for i in priority
        i.pbAbilitiesOnSwitchIn(true) if switched.include?(i.index)
      end
    end
    @switching=false
    # Gen 9 Mod - Checks and updates for Opportunist
    priority.each {|i| i.opportunistCheck}
    priority.each {|i| i.statsRaisedSinceLastCheck.clear}
    for i in 0...4
       if !switched.include?(i)
         @battlers[i].pbCustapBerry
       end
    end
    # Use items
    for i in priority
      if pbIsOpposing?(i.index) && @choices[i.index][0]==3
        pbEnemyUseItem(@choices[i.index][1],i)
        i.itemUsed = true
        i.itemUsed2 = true
      elsif @choices[i.index][0]==3
        # Player use item
        item=@choices[i.index][1]
        if item
          usetype=$cache.items[item].checkFlag?(:noUseInBattle) ? 0 : pbGetPocket(item)
          i.itemUsed = true
          i.itemUsed2 = true
          if !pbIsPokeBall?(item)
            if @choices[i.index][2]>=0 && usetype != 7
              pbUseItemOnPokemon(item,@choices[i.index][2],i,@scene)
            elsif !ItemHandlers.hasUseInBattle(item)
              pbUseItemOnBattler(item,@choices[i.index][2],i,@scene)
            end
          end
        end
      end
    end
    # Mega Evolution
    for i in priority
      next if @choices[i.index][0]!=1
      side=(pbIsOpposing?(i.index)) ? 1 : 0
      owner=pbGetOwnerIndex(i.index)
      if @megaEvolution[side][owner]==i.index
        pbMegaEvolve(i.index)
      end
    end
    # Ultra Burst
    for i in priority
      next if @choices[i.index][0]!=1
      side=(pbIsOpposing?(i.index)) ? 1 : 0
      owner=pbGetOwnerIndex(i.index)
      if @ultraBurst[side][owner]==i.index
        pbUltraBurst(i.index)
      end
    end
    priority=pbPriority(false,true)    #Turn order recalc from Gen VII
    if @state.effects[:WonderRoom] > 0
      for i in @battlers
        i.pbSwapDefenses if !i.wonderroom
      end
    end

    # Gen 9 Mod - Checks and updates for Opportunist
    priority.each {|i| i.opportunistCheck}
    priority.each {|i| i.statsRaisedSinceLastCheck.clear}

    # move animations before main move processing
    for i in priority
      if pbChoseMoveFunctionCode?(i.index,0x115) # Focus Punch
        pbCommonAnimation("FocusPunch",i,nil)
        pbDisplay(_INTL("{1} is tightening its focus!",i.pbThis))
      elsif pbChoseMoveFunctionCode?(i.index,0x15D) # Beak Blast
        pbCommonAnimation("BeakBlast",i,nil)
        i.effects[:BeakBlast]=true
        pbDisplay(_INTL("{1} is heating up!",i.pbThis))
      elsif pbChoseMoveFunctionCode?(i.index,0x16B) # Shell Trap
        pbCommonAnimation("ShellTrap",i,nil)
        i.effects[:ShellTrap]=true
        pbDisplay(_INTL("{1} set a shell trap!",i.pbThis))
      end
    end

    # Use attacks
    for i in priority
      i.pbProcessTurn(@choices[i.index])
      if i.effects[:Round] && @doublebattle
        pbMoveAfter(i, i.pbPartner)
      end

      # Gen 9 Mod - Checks and updates for Opportunist
      priority.each {|i| i.opportunistCheck}
      priority.each {|i| i.statsRaisedSinceLastCheck.clear}

      # Shell Trap
      for ii in 0...4
        if !@battlers[ii].effects[:ShellTrapTarget].nil? && @battlers[ii].effects[:ShellTrapTarget] != -1 &&
           !@battlers[ii].effects[:ShellTrap] 
          if pbChoseMoveFunctionCode?(ii,0x16B)
            pbMoveAfter(i, @battlers[ii])
          else # Via seed
            target=@battlers[ii].effects[:ShellTrapTarget]
            @battlers[ii].pbUseMoveSimple(:SHELLTRAP,-1,target,false)
            @battlers[ii].effects[:ShellTrapTarget]=-1
          end
        end
      end

      return if @decision>0
    end
  end

################################################################################
# End of round.
################################################################################
  def pbEndOfRoundPhase
    for i in 0...4
      if @battlers[i].effects[:ShellTrap] && !pbChoseMoveFunctionCode?(i,0x16B)
        pbDisplay(_INTL("{1}'s Shell Trap didn't work.",@battlers[i].name))
      end
    end
    for i in 0...4
      @battlers[i].forcedSwitchEarlier                  =false
      next if @battlers[i].hp <= 0
      @battlers[i].damagestate.reset
      @battlers[i].midwayThroughMove                    =false
      @battlers[i].forcedSwitchEarlier                  =false
      @battlers[i].effects[:Protect]          =false
      @battlers[i].effects[:Obstruct]         =false
      @battlers[i].effects[:KingsShield]      =false
      @battlers[i].effects[:ProtectNegation]  =false
      @battlers[i].effects[:Endure]           =false
      @battlers[i].effects[:HyperBeam]-=1     if @battlers[i].effects[:HyperBeam]>0
      @battlers[i].effects[:SpikyShield]      =false
      @battlers[i].effects[:BanefulBunker]    =false
      @battlers[i].effects[:BeakBlast]        =false
      @battlers[i].effects[:ClangedScales]    =false
      @battlers[i].effects[:ShellTrap]        =false
      if (@field.effect==:BURNING || @field.effect==:VOLCANIC || @field.effect==:INFERNAL) && @battlers[i].effects[:BurnUp] # Burning/Volcanic Field
        @battlers[i].type1= @battlers[i].pokemon.type1
        @battlers[i].type2= @battlers[i].pokemon.type2
        @battlers[i].effects[:BurnUp]         =false
      end
      @battlers[i].effects[:Powder]           =false
      @battlers[i].effects[:MeFirst]          =false
      @battlers[i].effects[:BurningJealousy]  =false
      @battlers[i].effects[:LashOut]          =false
      @battlers[i].effects[:Quickdrawsnipe]   =false
      if @battlers[i].effects[:ThroatChop]>0
        @battlers[i].effects[:ThroatChop]-=1
      end
      @battlers[i].itemUsed                    =false
    end
    @state.effects[:IonDeluge]       =false
    for i in 0...2
      sides[i].resetProtect
    end
    @usepriority=false  # recalculate priority
    priority=pbPriority
    if @trickroom > 0
      @trickroom=@trickroom-1 if @field.effect != :FROZENDIMENSION
      if @trickroom == 0
        pbDisplay("The twisted dimensions returned to normal!")
      end
    end
    if @state.effects[:WonderRoom] > 0
      @state.effects[:WonderRoom] -= 1 if @field.effect != :FROZENDIMENSION
      if @state.effects[:WonderRoom] == 0
        for i in @battlers
          if i.wonderroom
           i.pbSwapDefenses
          end
        end
        pbDisplay("Wonder Room wore off, and the Defense and Sp. Def stats returned to normal!")
      end
    end
    priority=pbPriority
    # Field Effects
    endmessage=false
    for i in priority
      next if i.isFainted?
      if i.species == :VESPIQUEN && i.crested
        mon = i
        if mon.effects[:VespiCrest] == 0 
           if (mon.totalhp != mon.hp)
            pbDisplay(_INTL("Vespiquen's swarm patched up her injuries!",i.pbThis)) if endmessage == false
            endmessage=true
            hpgain=(mon.totalhp/16).floor
            hpgain=mon.pbRecoverHP(hpgain,true)
           end
        end
      end
    end
    for i in priority
      next if i.isFainted?
      case @field.effect
        when :ELECTERRAIN # Electric Terrain
          next if i.hp<=0
          if i.ability == :VOLTABSORB && i.effects[:HealBlock]==0 && Rejuv
            hpgain=(i.totalhp/16.0).floor
            hpgain=i.pbRecoverHP(hpgain,true)
            pbDisplay(_INTL("{1} absorbed stray electricity!",i.pbThis)) if hpgain>0
          end
        when :GRASSY # Grassy Field
          next if i.hp<=0
          if !i.isAirborne? && i.effects[:HealBlock]==0 && i.totalhp != i.hp
            pbDisplay(_INTL("The grassy terrain healed the Pokémon on the field.",i.pbThis)) if !endmessage
            endmessage=true
            hpgain=(i.totalhp/16.0).floor
            hpgain=i.pbRecoverHP(hpgain,true)
          end
          if i.ability == :SAPSIPPER && i.effects[:HealBlock]==0
            hpgain=(i.totalhp/16.0).floor
            hpgain=i.pbRecoverHP(hpgain,true)
            pbDisplay(_INTL("{1} drank tree sap to recover!",i.pbThis)) if hpgain>0
          end
        when :BURNING, :VOLCANIC, :INFERNAL # Burning Field
          next if i.hp<=0
          if !i.isAirborne?
            if (i.ability == :FLASHFIRE)
              if !i.effects[:FlashFire]
                i.effects[:FlashFire]=true
                pbDisplay(_INTL("{1}'s {2} raised its Fire power!", i.pbThis,getAbilityName(i.ability)))
              end
            end
            if i.burningFieldPassiveDamage?
              eff=PBTypes.twoTypeEff(:FIRE,i.type1,i.type2)
              if eff>0
                @scene.pbDamageAnimation(i,0)
                if (i.ability == :LEAFGUARD) || (i.ability == :ICEBODY) || (i.ability == :FLUFFY) || (i.ability == :GRASSPELT)
                  eff = eff*2
                end
                eff = eff*2 if (i.effects[:TarShot])
                pbDisplay(_INTL("The Pokémon were burned by the field!",i.pbThis)) if !endmessage
                endmessage=true
                i.pbReduceHP([(i.totalhp*eff/32).floor,1].max)
                if i.hp<=0
                  return if !i.pbFaint
                end
              end
            end
          end
        when :CORROSIVE # Corrosive Field
          next if i.hp<=0
          if i.ability == :GRASSPELT
            @scene.pbDamageAnimation(i,0)
            i.pbReduceHP((i.totalhp/8.0).floor)
            pbDisplay(_INTL("{1}'s Pelt was corroded!",i.pbThis))
            if i.hp<=0
              return if !i.pbFaint
            end
          end
          if (i.ability == :POISONHEAL || (i.species == :ZANGOOSE && i.crested)) && !i.isAirborne? && i.effects[:HealBlock]==0 && i.hp<i.totalhp
            pbCommonAnimation("Poison",i,nil)
            i.pbRecoverHP((i.totalhp/8.0).floor,true)
            pbDisplay(_INTL("{1} was healed by poison!",i.pbThis))
          end
        when :CORROSIVEMIST # Corrosive Mist Field
          if i.pbCanPoison?(false) && !@battle.pbCheckGlobalAbility(:NEUTRALIZINGGAS)
            pbDisplay(_INTL("The Pokémon were poisoned by the corrosive mist!",i.pbThis))   if !endmessage
            endmessage=true
            i.pbPoison(i)
          end
          if (i.ability == :POISONHEAL || (i.species == :ZANGOOSE && i.crested)) && i.effects[:HealBlock]==0 && i.hp<i.totalhp
            pbCommonAnimation("Poison",i,nil)
            i.pbRecoverHP((i.totalhp/8.0).floor,true)
            pbDisplay(_INTL("{1} was healed by poison!",i.pbThis))
          end
        when :FOREST # Forest Field
          next if i.hp<=0
          if i.ability == :SAPSIPPER && i.effects[:HealBlock]==0
            hpgain=(i.totalhp/16.0).floor
            hpgain=i.pbRecoverHP(hpgain,true)
            pbDisplay(_INTL("{1} drank tree sap to recover!",i.pbThis)) if hpgain>0
          end
        when :VOLCANICTOP
          eruptionChecker if @state.effects[:HarshSunlight]
          # eruption check - insane, too much, but makes typh op, so i no question
          next if i.hp<=0
          if @eruption
            if i.hasType?(:FIRE) ||
               i.ability == (:MAGMAARMOR) || i.ability == (:FLASHFIRE) ||
               i.ability == (:FLAREBOOST) || i.ability == (:BLAZE) ||
               i.ability == (:FLAMEBODY) || i.ability == (:SOLIDROCK) ||
               i.ability == (:STURDY) || i.ability == (:BATTLEARMOR) ||
               i.ability == (:SHELLARMOR) || i.ability == (:WATERBUBBLE) ||
               i.ability == (:MAGICGUARD) || i.ability == (:WONDERGUARD) ||
               i.ability == (:PRISMARMOR) || i.effects[:AquaRing] ||
               i.pbOwnSide.effects[:WideGuard] || (i.pbOwnSide.effects[:AreniteWall]>0)
              pbDisplay(_INTL("{1} is immune to the eruption!",i.pbThis))
            else
              atype=getConst(PBTypes,:FIRE) || 0
              eff=PBTypes.twoTypeEff(atype,i.type1,i.type2)
              eff /= 2 if (i.ability == (:THICKFAT))
              eff *= 2 if (i.effects[:TarShot])
              @scene.pbDamageAnimation(i,0)
              i.pbReduceHP([(i.totalhp*eff/16).floor,1].max)
              pbDisplay(_INTL("{1} is hurt by the eruption!",i.pbThis))
              if i.hp<=0
                return if !i.pbFaint
              end
            end
            if i.ability == (:MAGMAARMOR)
              boost = false
              if !i.pbTooHigh?(PBStats::DEFENSE)
                i.pbIncreaseStatBasic(PBStats::DEFENSE,1)
                pbCommonAnimation("StatUp",i,nil)
                boost=true
              end
              if !i.pbTooHigh?(PBStats::SPDEF)
                i.pbIncreaseStatBasic(PBStats::SPDEF,1)
                pbCommonAnimation("StatUp",i,nil)
                boost=true
              end
              if boost
                pbDisplay(_INTL("{1}'s Magma Armor raised its defenses!",i.pbThis))
              end
            end
            if i.ability == (:FLAREBOOST)
              if !i.pbTooHigh?(PBStats::SPATK)
                i.pbIncreaseStatBasic(PBStats::SPATK,1)
                pbCommonAnimation("StatUp",i,nil)
                pbDisplay(_INTL("{1}'s Flare Boost raised its Sp. Attack!",i.pbThis))
              end
            end
            if i.ability == (:FLASHFIRE)
              if !i.effects[:FlashFire]
                i.effects[:FlashFire]=true
                pbDisplay(_INTL("{1}'s {2} raised its Fire power!",
                i.pbThis,getAbilityName(i.ability)))
              end
            end
            if i.ability == (:BLAZE)
              if !i.effects[:Blazed]
                i.effects[:Blazed]=true
                pbDisplay(_INTL("{1}'s {2} raised its Fire power!",
                i.pbThis,getAbilityName(i.ability)))
              end
            end
            if i.status==:SLEEP && i.ability != :SOUNDPROOF
              i.pbCureStatus
              pbDisplay(_INTL("{1} woke up due to the eruption!",i.pbThis))
            end
            if i.effects[:LeechSeed]>=0
              i.effects[:LeechSeed] = -1
              pbDisplay(_INTL("{1}'s Leech Seed burned away in the eruption!",i.pbThis))
            end
          end
          # eruption check - insane, too much, but makes typh op, so i no question
        when :SHORTCIRCUIT # Shortcircuit Field
          next if i.hp<=0
          if i.ability == :VOLTABSORB && i.effects[:HealBlock]==0
            hpgain=(i.totalhp/16.0).floor
            hpgain=i.pbRecoverHP(hpgain,true)
            pbDisplay(_INTL("{1} absorbed stray electricity!",i.pbThis)) if hpgain>0
          end
        when :WASTELAND # Wasteland
          if (i.ability == :POISONHEAL || (i.species == :ZANGOOSE && i.crested)) && !i.isAirborne? && i.effects[:HealBlock]==0 && i.hp<i.totalhp
            pbCommonAnimation("Poison",i,nil)
            i.pbRecoverHP((i.totalhp/8.0).floor,true)
            pbDisplay(_INTL("{1} was healed by poison!",i.pbThis))
          end
        when :WATERSURFACE # Water Surface
          next if i.hp<=0
          if (i.ability == :WATERABSORB || i.ability == :DRYSKIN) && i.effects[:HealBlock]==0 && !i.isAirborne?
            hpgain=(i.totalhp/16.0).floor
            hpgain=i.pbRecoverHP(hpgain,true)
            pbDisplay(_INTL("{1} absorbed some of the water!",i.pbThis)) if hpgain>0
          end
          if i.effects[:TarShot] == true
            i.effects[:TarShot]=false
            pbDisplay(_INTL("The tar washed of {1} in the water!",i.pbThis))
          end
        when :UNDERWATER
          next if i.hp<=0
          if (i.ability == :WATERABSORB || i.ability == :DRYSKIN) && i.effects[:HealBlock]==0
            hpgain=(i.totalhp/16.0).floor
            hpgain=i.pbRecoverHP(hpgain,true)
            pbDisplay(_INTL("{1} absorbed some of the water!",i.pbThis)) if hpgain>0
          end
          if i.underwaterFieldPassiveDamamge?
            eff=PBTypes.twoTypeEff(:WATER,i.type1,i.type2)
            if eff>4
              @scene.pbDamageAnimation(i,0)
              if i.ability == :FLAMEBODY || i.ability == :MAGMAARMOR
                eff = eff*2
              end
              i.pbReduceHP([(i.totalhp*eff/32).floor,1].max)
              pbDisplay(_INTL("{1} struggled in the water!",i.pbThis))
              if i.hp<=0
                return if !i.pbFaint
              end
            end
          end
        when :MURKWATERSURFACE # Murkwater Surface
          if i.murkyWaterSurfacePassiveDamage?
            eff=PBTypes.twoTypeEff(:POISON,i.type1,i.type2)
            if i.ability == :FLAMEBODY || i.ability == :MAGMAARMOR || i.ability == :DRYSKIN || i.ability == :WATERABSORB
              eff = eff*2
            end
            if !$cache.moves[i.effects[:TwoTurnAttack]].nil? && 
              $cache.moves[i.effects[:TwoTurnAttack]].function==0xCB # Dive
              @scene.pbDamageAnimation(i,0)
              i.pbReduceHP([(i.totalhp*eff/8).floor,1].max)
              pbDisplay(_INTL("{1} suffocated underneath the toxic water!",i.pbThis))
            elsif !i.isAirborne?
              @scene.pbDamageAnimation(i,0)
              i.pbReduceHP([(i.totalhp*eff/32).floor,1].max)
              pbDisplay(_INTL("{1} was hurt by the toxic water!",i.pbThis))
            end
          end
          if i.isFainted?
            return if !i.pbFaint
          end
          if i.hasType?(:POISON) && (i.ability == :DRYSKIN || i.ability == :WATERABSORB) || (i.ability == :POISONHEAL || (i.species == :ZANGOOSE && i.crested))  && !i.isAirborne? && i.effects[:HealBlock]==0 && i.hp<i.totalhp
            pbCommonAnimation("Poison",i,nil)
            i.pbRecoverHP((i.totalhp/8.0).floor,true)
            pbDisplay(_INTL("{1} was healed by the poisoned water!",i.pbThis))
          end
        when :DIMENSIONAL # Dimension Field (Rejuv)
          if i.effects[:HealBlock]!=0
            @scene.pbDamageAnimation(i,0)
            i.pbReduceHP((i.totalhp/16).floor)
            pbDisplay(_INTL("{1} was damaged by the Heal Block!",i.pbThis))
            if i.hp<=0
              return if !i.pbFaint
            end
          end
        when :CORRUPTED # Corrupted Cave Field (Rejuv)
          next if i.hp<=0
          if i.ability == :GRASSPELT || i.ability == :LEAFGUARD || i.ability == :FLOWERVEIL
            @scene.pbDamageAnimation(i,0)
            i.pbReduceHP((i.totalhp/8).floor)
            pbDisplay(_INTL("{1}'s foliage caused harm!",i.pbThis))
            if i.hp<=0
              return if !i.pbFaint
            end
          end 
          if i.ability == (:POISONHEAL) && !i.isAirborne? && i.effects[:HealBlock]==0 && i.hp<i.totalhp
            pbCommonAnimation("Poison",i,nil)
            i.pbRecoverHP((i.totalhp/8).floor,true)
            pbDisplay(_INTL("{1} was healed in the corruption!",i.pbThis))
          end
          if !i.isAirborne? && !i.hasType?(:POISON) && i.ability != :WONDERSKIN && i.ability != :IMMUNITY && i.ability != :PASTELVEIL
            if i.pbCanPoison?(false)
              pbDisplay(_INTL("{1} was poisoned!",i.pbThis)) if endmessage == false
              endmessage=true
              i.pbPoison(i)
            end
          end
        when :BEWITCHED #Bewitched Woods (Rejuv)
          next if i.hp<=0
          if !i.isAirborne? && i.hasType(:GRASS) && i.effects[:HealBlock]==0 && i.totalhp != i.hp
            pbDisplay(_INTL("The woods healed the grass Pokemon on the field.",i.pbThis)) if !endmessage
            endmessage=true
            hpgain=(i.totalhp/16.0).floor
            hpgain=i.pbRecoverHP(hpgain,true)
          end
          if i.ability(:NATURALCURE) || (i.ability(:TRACE) &&
            i.effects[:TracedAbility]==:NATURALCURE)
            i.status=nil
          end
        when :INFERNAL #Infernal Field (Rejuv)
          next if i.hp<=0
          if i.effects[:Torment] == true
            @scene.pbDamageAnimation(i,0)
            i.pbReduceHP((i.totalhp/8).floor)
            pbDisplay(_INTL("{1} was damaged by Torment!",i.pbThis))
          end
      end
      if @state.effects[:ELECTERRAIN] > 0
        next if i.hp<=0
        if i.ability == :VOLTABSORB && i.effects[:HealBlock]==0
          hpgain=(i.totalhp/16.0).floor
          hpgain=i.pbRecoverHP(hpgain,true)
          pbDisplay(_INTL("{1} absorbed stray electricity!",i.pbThis)) if hpgain>0
        end
      end
      if @state.effects[:GRASSY] > 0
        next if i.hp<=0
        if !i.isAirborne? && i.effects[:HealBlock]==0 && i.totalhp != i.hp
          pbDisplay(_INTL("The grassy terrain healed the Pokémon on the field.",i.pbThis)) if !endmessage
          endmessage=true
          hpgain=(i.totalhp/16.0).floor
          hpgain=i.pbRecoverHP(hpgain,true)
        end
        if i.ability == :SAPSIPPER && i.effects[:HealBlock]==0
          hpgain=(i.totalhp/16.0).floor
          hpgain=i.pbRecoverHP(hpgain,true)
          pbDisplay(_INTL("{1} drank tree sap to recover!",i.pbThis)) if hpgain>0
        end
      end
    end
    # eruption check 2 (having the hazard removal in the main loop above causes the messaging to malfunction)
    if @field.effect == :VOLCANICTOP
      if @eruption
        hazardsOnSide = false
        for i in priority
          if i.pbOwnSide.effects[:Spikes]>0
            i.pbOwnSide.effects[:Spikes]=0
            hazardsOnSide = true
          end
          if i.pbOwnSide.effects[:ToxicSpikes]>0
            i.pbOwnSide.effects[:ToxicSpikes]=0
            hazardsOnSide = true
          end
          if i.pbOwnSide.effects[:StealthRock]
            i.pbOwnSide.effects[:StealthRock]=false
            hazardsOnSide = true
          end
          if i.pbOwnSide.effects[:StickyWeb]
            i.pbOwnSide.effects[:StickyWeb]=false
            hazardsOnSide = true
          end
        end
        if hazardsOnSide
          pbDisplay(_INTL("The eruption removed all hazards from the field!"))
        end
      end
    end
    # End Field stuff
    # Weather
    # Unsure what this is really doing, cass thinks it's probably nothing. But just in case ?? ~a
    #if @field.effect != :UNDERWATER
    #  @field.counter = 0 if @weather != :HAIL && @field.effect == :MOUNTAIN
    #end
    for i in priority
      if i.ability == :TEMPEST
        weathers=rand(5)
        case weathers
         when 0
            if @weather== :SUNNYDAY
              rainbowhold=8
            end
            @weather=:RAINDANCE
            @weatherduration=8
            pbCommonAnimation("Rain",nil,nil)
            pbDisplay(_INTL("Storm-9 created a downpour!"))
            if rainbowhold != 0
              fieldbefore = @field.effect
              setField(:RAINBOW,rainbowhold)
              if fieldbefore != :RAINBOW
                pbDisplay(_INTL("The weather created a rainbow!"))
              else
                pbDisplay(_INTL("The weather refreshed the rainbow!"))
              end
            end
         when 1
            @weather=:HAIL
            @weatherduration=8
            pbCommonAnimation("Hail",nil,nil)
            pbDisplay(_INTL("Storm-9 brought hailfall!"))
            for facemon in @battlers
              if facemon.species==:EISCUE && facemon.form==1 # Eiscue
                facemon.pbRegenFace
                pbDisplayPaused(_INTL("{1} transformed!",facemon.name))
              end
            end
         when 2
            @weather=:SANDSTORM
            @weatherduration=8
            pbCommonAnimation("Sandstorm",nil,nil)
            pbDisplay(_INTL("Storm-9 whipped up a duststorm!"))
         when 3
            @weather=:STRONGWINDS
            @weatherduration=8
            pbCommonAnimation("Wind",nil,nil)
            pbDisplay(_INTL("Storm-9 whipped up terrible winds!"))
         when 4
            @weather=:SHADOWSKY
            @weatherduration=8
            pbCommonAnimation("ShadowSky",nil,nil)
            pbDisplay(_INTL("Storm-9 shrouded the sky in a dark aura..."))
         end
       end
    end
    case @weather
      when :SUNNYDAY
        @weatherduration=@weatherduration-1 if @weatherduration>0
        if @weatherduration==0
          pbDisplay(_INTL("The sunlight faded."))
          pbDisplay(_INTL("The starry sky shone through!")) if @field.effect == :STARLIGHT
          @weather=0
        elsif @field.effect == :DIMENSIONAL
          pbDisplay(_INTL("The sunlight cannot pierce the darkness."))
          @weather=0
        else
          pbCommonAnimation("Sunny")
          if @field.effect == :DARKCRYSTALCAVERN #Dark Crystal Cavern
            duration = @weatherduration + 1
            setField(:CRYSTALCAVERN,duration)
            @field.duration_condition = proc {|battle| battle.weather == :SUNNYDAY}
            @field.permanent_condition = proc {|battle| battle.FE != :CRYSTALCAVERN}
            pbDisplay(_INTL("The sun lit up the crystal cavern!"))
          end
          if pbWeather == :SUNNYDAY
            for i in priority
              next if i.isFainted?
              if i.ability == :SOLARPOWER && @field.effect != :FROZENDIMENSION
                pbDisplay(_INTL("{1} was hurt by the sunlight!",i.pbThis))
                @scene.pbDamageAnimation(i,0)
                i.pbReduceHP((i.totalhp/8.0).floor)
                if i.isFainted?
                  return if !i.pbFaint
                end
              end
              if Rejuv && @field.effect == :DESERT && (i.hastype?(:GRASS) || i.hasType(:WATER))
                pbDisplay(_INTL("{1} was hurt by the sunlight!",i.pbThis))
                @scene.pbDamageAnimation(i,0)
                i.pbReduceHP((i.totalhp/8.0).floor)
                if i.isFainted?
                  return if !i.pbFaint
                end
              end
            end
          end
        end
      when :RAINDANCE
        @weatherduration=@weatherduration-1 if @weatherduration>0
        if @weatherduration==0
          pbDisplay(_INTL("The rain stopped."))
          pbDisplay(_INTL("The starry sky shone through!")) if @field.effect == :STARLIGHT
          @weather=0
        elsif @field.effect == :DIMENSIONAL && !pbCheckGlobalAbility(:TEMPEST)
          pbDisplay(_INTL("The dark dimension swallowed the rain."))
          @weather=0
        elsif @field.effect == :INFERNAL && !pbCheckGlobalAbility(:TEMPEST)
          pbDisplay(_INTL("The rain evaporated."))
          @weather=0
        else
          pbCommonAnimation("Rain")
          if @field.effect == :BURNING
            breakField
            pbDisplay(_INTL("The rain snuffed out the flame!"));
          end
          if @field.effect == :VOLCANIC
            setField(:CAVE)
            pbDisplay(_INTL("The rain snuffed out the flame!"));
          end
        end
      when :SANDSTORM
        @weatherduration=@weatherduration-1 if @weatherduration>0
        if @weatherduration==0
          pbDisplay(_INTL("The sandstorm subsided."))
          pbDisplay(_INTL("The starry sky shone through!")) if @field.effect == :STARLIGHT
          @weather=0
        elsif @field.effect == :DIMENSIONAL && !pbCheckGlobalAbility(:TEMPEST)
          pbDisplay(_INTL("The dark dimension swallowed the sand."))
          @weather=0
        else
          pbCommonAnimation("Sandstorm")
          if @field.effect == :BURNING
            breakField
            pbDisplay(_INTL("The sand snuffed out the flame!"));
          end
          if @field.effect == :VOLCANIC
            setField(:CAVE)
            pbDisplay(_INTL("The sand snuffed out the flame!"));
          end
          if @field.effect == :RAINBOW
            breakField if @field.duration == 0
            endTempField if @field.duration > 0
            pbDisplay(_INTL("The weather blocked out the rainbow!"));
          end
          if pbWeather== :SANDSTORM
            endmessage=false
            for i in priority
              next if i.isFainted?
              if !i.hasType?(:GROUND) && !i.hasType?(:ROCK) && !i.hasType?(:STEEL) && !(i.ability == :SANDVEIL  || i.ability == :SANDRUSH ||
                i.ability == :SANDFORCE || i.ability == :MAGICGUARD || i.ability == :TEMPEST || (i.ability == :WONDERGUARD && @field.effect == :COLOSSEUM) || i.ability == :OVERCOAT) &&
              !(i.item == :SAFETYGOGGLES) && ($cache.moves[i.effects[:TwoTurnAttack]].nil? || ![0xCA,0xCB].include?($cache.moves[i.effects[:TwoTurnAttack]].function)) # Dig, Dive
                pbDisplay(_INTL("The Pokémon were buffeted by the sandstorm!",i.pbThis)) if !endmessage
                endmessage=true
                @scene.pbDamageAnimation(i,0)
                if Rejuv && @field.effect == :DESERT
                  i.pbReduceHP((i.totalhp/8.0).floor)
                else
                  i.pbReduceHP((i.totalhp/16.0).floor)
                end
                if i.isFainted?
                  return if !i.pbFaint
                end
              end
            end
          end
        end
      when :HAIL
        @weatherduration=@weatherduration-1 if @weatherduration>0
        if @weatherduration==0
          pbDisplay(_INTL("The hail stopped."))
          pbDisplay(_INTL("The starry sky shone through!")) if @field.effect == :STARLIGHT
          @weather=0
        elsif (@field.effect == :SUPERHEATED || @field.effect == :VOLCANIC || @field.effect == :VOLCANICTOP || @field.effect == :INFERNAL || (@field.effect == :DRAGONSDEN && Rejuv)) && !pbCheckGlobalAbility(:TEMPEST)
          pbDisplay(_INTL("The hail melted away."))
          @weather=0
        elsif @field.effect == :DIMENSIONAL && !pbCheckGlobalAbility(:TEMPEST)
          pbDisplay(_INTL("The dark dimension swallowed the hail."))
          @weather=0
        else
          pbCommonAnimation("Hail")
          if @field.effect == :RAINBOW
            breakField if @field.duration == 0
            endTempField if @field.duration > 0
            pbDisplay(_INTL("The weather blocked out the rainbow!"));
          end
          if pbWeather== :HAIL
            endmessage=false
            for i in priority
              next if i.isFainted?
              if !i.hasType?(:ICE) && i.ability != :TEMPEST && i.ability != :ICEBODY && i.ability != :SNOWCLOAK && i.ability != :MAGICGUARD && !(i.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM) && i.ability != :OVERCOAT &&
                !(i.item == :SAFETYGOGGLES) && ($cache.moves[i.effects[:TwoTurnAttack]].nil? || ![0xCA,0xCB].include?($cache.moves[i.effects[:TwoTurnAttack]].function)) # Dig, Dive
                pbDisplay(_INTL("The Pokémon were buffeted by the hail!",i.pbThis)) if !endmessage
                endmessage=true
                @scene.pbDamageAnimation(i,0)
                if @field.effect == :FROZENDIMENSION
                  i.pbReduceHP((i.totalhp/8.0).floor)
                else
                  i.pbReduceHP((i.totalhp/16.0).floor)
                end
                if i.isFainted?
                  return if !i.pbFaint
                end
              end
            end
            if @field.effect  == :MOUNTAIN
              @field.counter+=1
              if @field.counter == 3
                setField(:SNOWYMOUNTAIN)
                pbDisplay(_INTL("The mountain was covered in snow!"))
              end
            end
          end
        end
      when :STRONGWINDS
        @weatherduration=@weatherduration-1 if @weatherduration>0
        if @weatherduration==0
          pbDisplay(_INTL("The strong wind petered out."))
          @weather=0
        else
          pbCommonAnimation("Wind")
        end
      when :SHADOWSKY
        @weatherduration=@weatherduration-1 if @weatherduration>0
        if @weatherduration==0
          pbDisplay(_INTL("The shadow sky faded."))
          pbDisplay(_INTL("The starry sky shone through!")) if @field.effect == :STARLIGHT
          @weather=0
        else
          pbCommonAnimation("ShadowSky")
          if @weather == :SHADOWSKY
            for i in priority
              next if i.isFainted?
              if !i.isShadow? && i.ability != :TEMPEST
                pbDisplay(_INTL("{1} was hurt by the shadow sky!",i.pbThis))
                @scene.pbDamageAnimation(i,0)
                if @field.effect == :DIMENSIONAL || @field.effect == :FROZENDIMENSION
                  i.pbReduceHP((i.totalhp/8.0).floor)
                else
                  i.pbReduceHP((i.totalhp/16.0).floor)
                end
                if i.isFainted?
                  return if !i.pbFaint
                end
              end
            end
          end
        end
    end
    # Temporal Shift
    for i in priority
      next if i.isFainted?
      if i.hasWorkingAbility(:TEMPORALSHIFT)
        for j in priority
          next if j.isFainted?
          if !(i==j || i.pbPartner==j || j.pbHasType?(:NORMAL)) && j.effects[:FutureSight]==0
            j.effects[:FutureSight]=3 
            j.effects[:FutureSightMove]=:HEX
            j.effects[:FutureSightUser]=i.index
            j.effects[:FutureSightPokemonIndex]=i.pokemonIndex
            pbDisplay(_INTL("{1} casts a hex!",i.pbThis))
            break
          end
        end
      end
    end
    # Future Sight/Doom Desire
    for i in battlers   # not priority
      next if i.effects[:FutureSight]<=0
      i.effects[:FutureSight]-=1
      next if i.isFainted? || i.effects[:FutureSight]!=0
      moveuser=nil
      #check if battler on the field
      move, moveuser, disabled_items = i.pbFutureSightUserPlusMove
      type = move.type
      pbDisplay(_INTL("{1} took the {2} attack!",i.pbThis,move.name))
      typemod = move.pbTypeModifier(type,moveuser,i)
      twoturninvul = PBStuff::TWOTURNMOVE.include?(i.effects[:TwoTurnAttack])
      if (i.isFainted? || move.pbAccuracyCheck(moveuser,i) && !(i.ability == :WONDERGUARD && typemod<=4)) && !twoturninvul
        i.damagestate.reset
        damage = nil
        if i.effects[:FutureSightMove] == :FUTURESIGHT && !(i.hasType?(:DARK))
          moveuser.hp != 0 ? pbAnimation(:FUTUREDUMMY,moveuser,i) : pbAnimation(:FUTUREDUMMY,i,i)
        elsif i.effects[:FutureSightMove] == :DOOMDESIRE
          moveuser.hp != 0 ? pbAnimation(:DOOMDUMMY,moveuser,i) : pbAnimation(:DOOMDUMMY,i,i)
        elsif i.effects[:FutureSightMove] == :HEX && !(i.hasType?(:NORMAL))
          moveuser.hp != 0 ? pbAnimation(:HEXDUMMY,moveuser,i) : pbAnimation(:HEXDUMMY,i,i)
        end
        move.pbReduceHPDamage(damage,moveuser,i)
        move.pbEffectMessages(moveuser,i)
      elsif i.ability == :WONDERGUARD && typemod<=4 && !twoturninvul
        pbDisplay(_INTL("{1} avoided damage with Wonder Guard!",i.pbThis))
      else
        pbDisplay(_INTL("But it failed!"))
      end
      i.effects[:FutureSight]=0
      i.effects[:FutureSightMove]=0
      i.effects[:FutureSightUser]=-1
      i.effects[:FutureSightPokemonIndex]=-1
      if !disabled_items.empty?
        moveuser.item = disabled_items[:item]
        moveuser.ability = disabled_items[:ability]
      end
      if i.isFainted?
        return if !i.pbFaint
        next
      end
    end
    for i in priority
      next if !i.isbossmon
      next if i.isFainted?
      if i.chargeAttack
        chargeAttack = i.chargeAttack
        if self.turncount % chargeAttack[:turns] ==0 
          if i.chargeTurns? == false && self.turncount % chargeAttack[:turns] ==0 
            for m in @party1
              m.status = :FAINTED
              m.hp = 0
            end
            for j in priority
              next if j.isFainted?
              next if j.isbossmon
              pbDisplay(_INTL("{1} unleashed it's power!",i.pbThis))
              pbAnimation(:EXPLOSION,i,i)
              j.pbReduceHP(j.hp,true)
              j.pbFaint if j.isFainted?
            end
            @decision=2
            return 
          end
        else
          if chargeAttack[:intermediateattack]
            newmove = PokeBattle_BossMove.new(self,i,chargeAttack[:intermediateattack])
            i.pbUseMoveSimpleBoss(newmove,-1)
          end
        end
      end
    end
    for i in priority
      next if i.isFainted?
      # Meganium + Meganium Crest
      if (i.species == :MEGANIUM && i.crested) ||
        (i.pbPartner.species == :MEGANIUM && i.pbPartner.crested && i.pbPartner.isFainted?)
          hpgain=i.pbRecoverHP((i.totalhp/16).floor,true)
          pbDisplay(_INTL("The Meganium Crest restored {1}'s HP a little!",i.pbThis(true))) if hpgain>0       
      end
      # Rain Dish
      if (i.ability == :RAINDISH && (pbWeather== :RAINDANCE && !i.hasWorkingItem(:UTILITYUMBRELLA)))&& i.effects[:HealBlock]==0
        hpgain=i.pbRecoverHP((i.totalhp/16.0).floor,true)
        pbDisplay(_INTL("{1}'s Rain Dish restored its HP a little!",i.pbThis)) if hpgain>0
      end

      # Dry Skin
      if (i.ability == :DRYSKIN)
        if (pbWeather== :RAINDANCE && !i.hasWorkingItem(:UTILITYUMBRELLA)) && i.effects[:HealBlock]==0
          hpgain=i.pbRecoverHP((i.totalhp/8.0).floor,true)
          pbDisplay(_INTL("{1}'s Dry Skin was healed by the rain!",i.pbThis)) if hpgain>0
        elsif (pbWeather== :SUNNYDAY && !i.hasWorkingItem(:UTILITYUMBRELLA))
          @scene.pbDamageAnimation(i,0)
          hploss=i.pbReduceHP((i.totalhp/8.0).floor)
          pbDisplay(_INTL("{1}'s Dry Skin was hurt by the sunlight!",i.pbThis)) if hploss>0
        elsif (@field.effect == :CORROSIVEMIST || @field.effect == :CORRUPTED) && !i.hasType?(:STEEL)
          if !i.hasType?(:POISON)
            @scene.pbDamageAnimation(i,0)
            hploss=i.pbReduceHP((i.totalhp/8.0).floor)
            pbDisplay(_INTL("{1}'s Dry Skin absorbed the poison!",i.pbThis)) if hploss>0
          elsif i.effects[:HealBlock]==0
            hpgain=i.pbRecoverHP((i.totalhp/8.0).floor,true)
            pbDisplay(_INTL("{1}'s Dry Skin was healed by the poison!",i.pbThis)) if hpgain>0
          end
        elsif @field.effect == :DESERT
          @scene.pbDamageAnimation(i,0)
          hploss=i.pbReduceHP((i.totalhp/8.0).floor)
          pbDisplay(_INTL("{1}'s Dry Skin was hurt by the desert air!",i.pbThis)) if hploss>0
        elsif @field.effect == :MISTY || @battle.state.effects[:MISTY] > 0
          hpgain=0
          if i.effects[:HealBlock]==0
            hpgain=(i.totalhp/16.0).floor
            hpgain=i.pbRecoverHP(hpgain,true)
          end
          pbDisplay(_INTL("{1}'s Dry Skin was healed by the mist!",i.pbThis)) if hpgain>0
        elsif @field.effect == :SWAMP  # Swamp Field
          hpgain=0
          if i.effects[:HealBlock]==0
            hpgain=(i.totalhp/16.0).floor
            hpgain=i.pbRecoverHP(hpgain,true)
          end
          pbDisplay(_INTL("{1}'s Dry Skin was healed by the murk!",i.pbThis)) if hpgain>0
        end
      end
      # Ice Body
      if i.ability == :ICEBODY && (pbWeather== :HAIL || @field.effect == :ICY || @field.effect == :SNOWYMOUNTAIN || @field.effect == :FROZENDIMENSION) && i.effects[:HealBlock]==0
        hpgain=i.pbRecoverHP((i.totalhp/16.0).floor,true)
        pbDisplay(_INTL("{1}'s Ice Body restored its HP a little!",i.pbThis)) if hpgain>0
      end
      if i.isFainted?
        return if !i.pbFaint
        next
      end
    end
    # Wish
    for i in priority
      if i.effects[:Wish]>0
        i.effects[:Wish]-=1
        if i.effects[:Wish]==0
          next if i.isFainted?
          hpgain=i.pbRecoverHP(i.effects[:WishAmount],true)
          if hpgain>0
            wishmaker=pbThisEx(i.index,i.effects[:WishMaker])
            pbDisplay(_INTL("{1}'s wish came true!",wishmaker))
          end
        end
      end
    end
    # Fire Pledge + Grass Pledge combination damage - should go here
    for i in priority
      next if i.isFainted?
      # Shed Skin
      if i.ability == :SHEDSKIN
        if (pbRandom(10)<3 || @field.effect == :DRAGONSDEN) && !i.status.nil?
          pbDisplay(_INTL("{1}'s Shed Skin cured its {2} problem!",i.pbThis,i.status.downcase))
          i.status=nil
          i.statusCount=0
          if @field.effect == :DRAGONSDEN
            pbDisplay(_INTL("{1}'s scaled sheen glimmers brightly!",i.pbThis))
            if i.effects[:HealBlock]==0
              hpgain=(i.totalhp/4.0).floor
              hpgain=i.pbRecoverHP(hpgain,true)
            end
            animDDShedSkin = true 
            if !i.pbTooHigh?(PBStats::SPEED)
              i.pbIncreaseStatBasic(PBStats::SPEED,1)
              pbCommonAnimation("StatUp",i,nil)
              animDDShedSkin = false
            end
            if !i.pbTooHigh?(PBStats::SPATK)
              i.pbIncreaseStatBasic(PBStats::SPATK,1)
              pbCommonAnimation("StatUp",i,nil) if animDDShedSkin
            end
            animDDShedSkin = true 
            if !i.pbTooLow?(PBStats::DEFENSE)
              i.pbReduceStat(PBStats::DEFENSE,1)
              pbCommonAnimation("StatDown",i,nil)
              animDDShedSkin = false
            end
            if !i.pbTooLow?(PBStats::SPDEF)
              i.pbReduceStat(PBStats::SPDEF,1)
              pbCommonAnimation("StatDown",i,nil) if animDDShedSkin
            end
          end
        end
      end
      # Hydration
      if i.ability == :HYDRATION && ((pbWeather== :RAINDANCE && !i.hasWorkingItem(:UTILITYUMBRELLA)) || @field.effect == :WATERSURFACE || @field.effect == :UNDERWATER)
        if !i.status.nil?
          pbDisplay(_INTL("{1}'s Hydration cured its {2} problem!",i.pbThis,i.status.downcase))
          i.status=nil
          i.statusCount=0
        end
        if @field.effect == :CLOUDS && pbWeather==:RAINDANCE && i.hp!=i.totalhp
          i.pbRecoverHP((i.totalhp/16.0).floor,true)
          pbDisplay(_INTL("{1}'s Hydration restored its health!",i.pbThis))
        end
      end
      if i.ability == :WATERVEIL && (@field.effect == :WATERSURFACE || @field.effect == :UNDERWATER)
        if !i.status.nil?
          pbDisplay(_INTL("{1}'s Water Veil cured its {2} problem!",i.pbThis,i.status.downcase))
          i.status=nil
          i.statusCount=0
        end
      end
      # Healer
      if i.ability == :HEALER
        partner=i.pbPartner
        if pbRandom(10)<3 && partner.hp >0 && !partner.status.nil?
          pbDisplay(_INTL("{1}'s Healer cured its partner's {2} problem!",i.pbThis,i.status.downcase))
          partner.status=nil
          partner.statusCount=0
        end
      end
    end
    # Held berries/Leftovers/Black Sludge
    for i in priority
      next if i.isFainted?
      i.pbBerryCureCheck(true)
      if i.isFainted?
        return if !i.pbFaint
        next
      end
    end
    # Aqua Ring
    for i in priority
      next if i.hp<=0
      if i.effects[:AquaRing]
        if @field.effect == :CORROSIVEMIST && !i.hasType?(:STEEL) && !i.hasType?(:POISON)
          @scene.pbDamageAnimation(i,0)
          i.pbReduceHP((i.totalhp/16.0).floor)
          pbDisplay(_INTL("{1}'s Aqua Ring absorbed poison!",i.pbThis))
          if i.hp<=0
            return if !i.pbFaint
          end
        elsif i.effects[:HealBlock]==0
          hpgain=(i.totalhp/16.0).floor
          if Rejuv && @battle.FE == :GRASSY
            hpgain=(hpgain*1.6).floor if i.hasWorkingItem(:BIGROOT)
          else
            hpgain=(hpgain*1.3).floor if i.hasWorkingItem(:BIGROOT)
          end
          hpgain=(hpgain*2).floor if [:MISTY,:SWAMP,:WATERSURFACE,:UNDERWATER].include?(@field.effect)
          hpgain=i.pbRecoverHP(hpgain,true)
          pbDisplay(_INTL("{1}'s Aqua Ring restored its HP a little!",i.pbThis)) if hpgain>0
        end
      end
    end
    # Ingrain
    for i in priority
      next if i.hp<=0
      if i.effects[:Ingrain]
        if (@field.effect == :SWAMP || @field.effect == :CORROSIVE || @field.effect == :CORRUPTED) && (!i.hasType?(:STEEL) && !i.hasType?(:POISON))
          @scene.pbDamageAnimation(i,0)
          i.pbReduceHP((i.totalhp/16.0).floor)
          pbDisplay(_INTL("{1} absorbed foul nutrients with its roots!",i.pbThis))
          if i.hp<=0
            return if !i.pbFaint
          end
        else
          if @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN,3,5)
            hpgain=(i.totalhp/4.0).floor
          elsif (@field.effect == :FOREST || @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN,2,5) || (Rejuv && @field.effect == :GRASSY) || @state.effects[:GRASSY] > 0)
            hpgain=(i.totalhp/8.0).floor
          elsif i.effects[:HealBlock]==0
            hpgain=(i.totalhp/16.0).floor
          end
          if i.effects[:HealBlock]==0
            if Rejuv && @battle.FE == :GRASSY
              hpgain=(hpgain*1.6).floor if i.hasWorkingItem(:BIGROOT)
            else
              hpgain=(hpgain*1.3).floor if i.hasWorkingItem(:BIGROOT)
            end
            hpgain=i.pbRecoverHP(hpgain,true)
            pbDisplay(_INTL("{1} absorbed nutrients with its roots!",i.pbThis)) if hpgain>0
          end
        end
      end
    end
    # Leech Seed
    for i in priority
      if i.ability == :LIQUIDOOZE && i.effects[:LeechSeed]>=0
        recipient=@battlers[i.effects[:LeechSeed]]
        if recipient && !recipient.isFainted?
          hploss=(i.totalhp/8.0).floor
          hploss= hploss * 2 if @field.effect == :WASTELAND
          pbCommonAnimation("LeechSeed",recipient,i)
          i.pbReduceHP(hploss,true)
          hploss= hploss * 2 if @field.effect == :MURKWATERSURFACE || @field.effect == :CORRUPTED || @field.effect == :WASTELAND
          if Rejuv && @battle.FE == :GRASSY
            hploss=(hploss*1.6).floor if recipient.hasWorkingItem(:BIGROOT)
          else
            hploss=(hploss*1.3).floor if recipient.hasWorkingItem(:BIGROOT)
          end
          recipient.pbReduceHP(hploss,true)
          pbDisplay(_INTL("{1} sucked up the liquid ooze!",recipient.pbThis))
          if i.isFainted?
            return if !i.pbFaint
          end
          if recipient.isFainted?
            return if !recipient.pbFaint
          end
          next
        end
      end
      next if i.isFainted?
      if i.effects[:LeechSeed]>=0
        recipient=@battlers[i.effects[:LeechSeed]]
        if recipient && !recipient.isFainted? && i.ability != :MAGICGUARD && !(i.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)# if recipient exists
          pbCommonAnimation("LeechSeed",recipient,i)
          hploss=i.pbReduceHP((i.totalhp/8.0).floor,true)
          hploss= hploss * 2 if @field.effect == :WASTELAND
          if recipient.effects[:HealBlock]==0
            if Rejuv && @battle.FE == :GRASSY
              hploss=(hploss*1.3).floor
              hploss=(hploss*1.6).floor if recipient.hasWorkingItem(:BIGROOT)
            else
              hploss=(hploss*1.3).floor if recipient.hasWorkingItem(:BIGROOT)
            end
            recipient.pbRecoverHP(hploss,true)
            pbDisplay(_INTL("{1}'s health was sapped by Leech Seed!",i.pbThis))
          end
          if i.isFainted?
            return if !i.pbFaint
          end
          if recipient.isFainted?
            return if !recipient.pbFaint
          end
        end
      end
    end

    for i in priority
      next if i.isFainted?
      # Petrification
      if i.status== :PETRIFIED && (i.effects[:Petrification]>=0) 
        recipient=@battlers[i.effects[:Petrification]]
        if recipient && !recipient.isFainted?  && i.ability != :MAGICGUARD && !(i.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM) # if recipient exists
          pbCommonAnimation("Petrification",recipient,i)
          hploss=i.pbReduceHP((i.totalhp/8).floor,true)
          if Rejuv && @battle.FE == :GRASSY
            hploss=(hploss*1.6).floor if recipient.hasWorkingItem(:BIGROOT)
          else
            hploss=(hploss*1.3).floor if recipient.hasWorkingItem(:BIGROOT)
          end
          recipient.pbRecoverHP(hploss,true)
          pbDisplay(_INTL("{1}'s health was drained by {2}!",i.pbThis,recipient.pbThis))
          if i.isFainted?          
            return if !i.pbFaint
          end
          if recipient.isFainted?
            return if !recipient.pbFaint
          end
        end
      end
      # Poison/Bad poison
      if i.status== :POISON && i.ability != :MAGICGUARD && !(i.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM) && !(i.ability == :GUTS && @battle.FE == :CROWD)
        if (i.ability == :POISONHEAL || (i.species == :ZANGOOSE && i.crested))
          if i.effects[:HealBlock]==0
            if i.hp<i.totalhp
              pbCommonAnimation("Poison",i,nil)
              i.pbRecoverHP((i.totalhp/8.0).floor,true)
              pbDisplay(_INTL("{1} is healed by poison!",i.pbThis))
            end
            if i.statusCount>0
              i.effects[:Toxic]+=1
              i.effects[:Toxic]=[15,i.effects[:Toxic]].min
            end
          end
        else
          i.pbContinueStatus
          if i.statusCount==0
            i.pbReduceHP((i.totalhp/8.0).floor)
          else
            i.effects[:Toxic]+=1
            i.effects[:Toxic]=[15,i.effects[:Toxic]].min
            i.pbReduceHP((i.totalhp/16.0).floor*i.effects[:Toxic])
          end
        end
      end
      # Burn
      if i.status== :BURN && i.ability != :MAGICGUARD && !(i.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
        i.pbContinueStatus
        if !(i.ability == :GUTS && @battle.FE == :CROWD)
          if i.ability == :HEATPROOF || @field.effect == :ICY
            i.pbReduceHP((i.totalhp/32.0).floor)
          else
            i.pbReduceHP((i.totalhp/16.0).floor)
          end
        end
      end
      # Nightmare
      if i.effects[:Nightmare] && i.ability != :MAGICGUARD && !(i.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM) && @field.effect != :RAINBOW
        if (i.status== :SLEEP || @battle.FE == :INFERNAL || i.pbOpposing1.ability == :WORLDOFNIGHTMARES || i.pbOpposing2.ability == :WORLDOFNIGHTMARES)
          pbCommonAnimation("Nightmare",i,nil)
          pbDisplay(_INTL("{1} is locked in a nightmare!",i.pbThis))
          hploss = (i.totalhp/4.0).floor
          hploss = (i.totalhp/3.0).floor if @field.effect == :HAUNTED ||@field.effect == :DARKNESS3
          i.pbReduceHP(hploss,true)
        else
          i.effects[:Nightmare]=false
        end
      end
      if i.isFainted?
        return if !i.pbFaint
        next
      end
    end
     # Curse
    for i in priority
      next if i.isFainted?
      next if !i.effects[:Curse]
      if @field.effect == :HOLY 
        i.effects[:Curse] = false
        pbDisplay(_INTL("{1}'s curse was lifted!",i.pbThis))
      end
      if i.ability != :MAGICGUARD && !(i.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
        pbCommonAnimation("Curse",i,nil)
        pbDisplay(_INTL("{1} is afflicted by the curse!",i.pbThis))
        i.pbReduceHP((i.totalhp/4.0).floor,true)
      end
      if i.isFainted?
        return if !i.pbFaint
        next
      end
    end
    # Multi-turn attacks (Bind/Clamp/Fire Spin/Magma Storm/Sand Tomb/Whirlpool/Wrap)
    for i in priority
      next if i.isFainted?
      i.pbBerryCureCheck
      if i.effects[:MultiTurn]>0
        i.effects[:MultiTurn]-=1
        movename=getMoveName(i.effects[:MultiTurnAttack])
        if i.effects[:MultiTurn]==0
          pbDisplay(_INTL("{1} was freed from {2}!",i.pbThis,movename))
          i.effects[:BindingBand] = false
        elsif !(i.ability == :MAGICGUARD) && !(i.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
          pbDisplay(_INTL("{1} is hurt by {2}!",i.pbThis,movename))
          if (i.effects[:MultiTurnAttack] == :BIND)
            pbCommonAnimation("Bind",i,nil)
          elsif (i.effects[:MultiTurnAttack] == :CLAMP)
            pbCommonAnimation("Clamp",i,nil)
          elsif (i.effects[:MultiTurnAttack] == :FIRESPIN)
            pbCommonAnimation("FireSpin",i,nil)
          elsif (i.effects[:MultiTurnAttack] == :MAGMASTORM)
            pbCommonAnimation("Magma Storm",i,nil)
          elsif (i.effects[:MultiTurnAttack] == :SANDTOMB) || (i.effects[:MultiTurnAttack] == :DESERTSMARK)
            pbCommonAnimation("SandTomb",i,nil)
          elsif (i.effects[:MultiTurnAttack] == :WRAP)
            pbCommonAnimation("Wrap",i,nil)
          elsif (i.effects[:MultiTurnAttack] == :INFESTATION)
            pbCommonAnimation("Infestation",i,nil)
          elsif (i.effects[:MultiTurnAttack] == :WHIRLPOOL)
            pbCommonAnimation("Whirlpool",i,nil)
          else
            pbCommonAnimation("Wrap",i,nil)
          end
          @scene.pbDamageAnimation(i,0)
          if i.effects[:BindingBand]
            i.pbReduceHP((i.totalhp/6.0).floor)
          elsif (i.effects[:MultiTurnAttack] == :MAGMASTORM) && @field.effect == :DRAGONSDEN
            i.pbReduceHP((i.totalhp/6.0).floor)
          elsif (i.effects[:MultiTurnAttack] == :SANDTOMB) && @field.effect == :DESERT
            i.pbReduceHP((i.totalhp/6.0).floor)
          elsif (i.effects[:MultiTurnAttack] == :WHIRLPOOL) && (@field.effect == :WATERSURFACE || @field.effect == :UNDERWATER)
            i.pbReduceHP((i.totalhp/6.0).floor)
          elsif (i.effects[:MultiTurnAttack] == :INFESTATION) && @field.effect == :FOREST
            i.pbReduceHP((i.totalhp/6.0).floor)
          elsif (i.effects[:MultiTurnAttack] == :FIRESPIN) && (@field.effect == :BURNING || @field.effect == :HAUNTED)
            i.pbReduceHP((i.totalhp/6.0).floor)
          elsif (i.effects[:MultiTurnAttack] == :INFESTATION) && @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN,3,5)
            case @field.counter
              when 2 then i.pbReduceHP((i.totalhp/6.0).floor)
              when 3 then i.pbReduceHP((i.totalhp/4.0).floor)
              when 4 then i.pbReduceHP((i.totalhp/3.0).floor)
            end
          elsif (i.effects[:MultiTurnAttack] == :THUNDERCAGE) && (@field.effect == :ELECTERRAIN)
            i.pbReduceHP((i.totalhp/6.0).floor)
          elsif (i.effects[:MultiTurnAttack] == :SNAPTRAP) && (@field.effect == :GRASSY)
            i.pbReduceHP((i.totalhp/6.0).floor)
          else
            i.pbReduceHP((i.totalhp/8.0).floor)
          end
          if (i.effects[:MultiTurnAttack] == :SANDTOMB) && @field.effect == :ASHENBEACH
            i.pbReduceStat(PBStats::ACCURACY,1,abilitymessage:true)
          end
        end
      end
      if i.hp<=0
        return if !i.pbFaint
        next
      end
    end
    # Taunt
    for i in priority
      next if i.isFainted?
      next if i.effects[:Taunt] == 0
      i.effects[:Taunt]-=1
      if i.effects[:Taunt]==0
        pbDisplay(_INTL("{1} recovered from the taunting!",i.pbThis))
      end
    end
    # Encore
    for i in priority
      next if i.isFainted?
      next if i.effects[:Encore] == 0
      if i.moves[i.effects[:EncoreIndex]].move!=i.effects[:EncoreMove]
        i.effects[:Encore]=0
        i.effects[:EncoreIndex]=0
        i.effects[:EncoreMove]=0
      else
        i.effects[:Encore]-=1
        if i.effects[:Encore]==0 || i.moves[i.effects[:EncoreIndex]].pp==0
          i.effects[:Encore]=0
          pbDisplay(_INTL("{1}'s encore ended!",i.pbThis))
        end
      end
    end
    # Disable/Cursed Body
    for i in priority
      next if i.isFainted?
      next if i.effects[:Disable]==0
      i.effects[:Disable]-=1
      if i.effects[:Disable]==0
        i.effects[:DisableMove]=0
        pbDisplay(_INTL("{1} is disabled no more!",i.pbThis))
      end
    end
    # Magnet Rise
    for i in priority
      next if i.isFainted?
      if i.effects[:MagnetRise]>0
        i.effects[:MagnetRise]-=1
        if i.effects[:MagnetRise]==0
          pbDisplay(_INTL("{1} stopped levitating.",i.pbThis))
        end
      end
    end
    # Telekinesis
    for i in priority
      next if i.isFainted?
      if i.effects[:Telekinesis]>0
        i.effects[:Telekinesis]-=1
        if i.effects[:Telekinesis]==0
          pbDisplay(_INTL("{1} stopped levitating.",i.pbThis))
        end
      end
    end
    # Heal Block
    for i in priority
      next if i.isFainted?
      if i.effects[:HealBlock]>0
        i.effects[:HealBlock]-=1
        if i.effects[:HealBlock]==0
          pbDisplay(_INTL("The heal block on {1} ended.",i.pbThis))
        end
      end
    end
    # Embargo
    for i in priority
      next if i.isFainted?
      if i.effects[:Embargo]>0
        i.effects[:Embargo]-=1
        if i.effects[:Embargo]==0
          pbDisplay(_INTL("The embargo on {1} was lifted.",i.pbThis(true)))
        end
      end
    end
    # Yawn
    for i in priority
      next if i.isFainted?
      if i.effects[:Yawn]>0
        i.effects[:Yawn]-=1
        if i.effects[:Yawn]==0 && i.pbCanSleepYawn?
          i.pbSleep
          pbDisplay(_INTL("{1} fell asleep!",i.pbThis))
          i.pbBerryCureCheck
        end
      end
    end
    # Perish Song
    perishSongUsers=[]
    for i in priority
      next if i.isFainted?
      if i.effects[:PerishSong]>0
        if (i.isbossmon && i.immunities[:moves].include?(:PERISHSONG))
          pbDisplay(_INTL("{1} grew resistant to the Perish Song!",i.pbThis))
          i.effects[:PerishSong]=0
          next
        end
        i.effects[:PerishSong]-=1
        pbDisplay(_INTL("{1}'s Perish count fell to {2}!",i.pbThis,i.effects[:PerishSong]))
        if i.effects[:PerishSong]==0
          i.immunities[:moves].push(:PERISHSONG) if i.isbossmon
          perishSongUsers.push(i.effects[:PerishSongUser])
          i.pbReduceHP(i.hp,true)
        end
      end
      if i.isFainted?
        return if !i.pbFaint
      end
    end
    if perishSongUsers.length>0
      # If all remaining Pokemon fainted by a Perish Song triggered by a single side
      if (perishSongUsers.find_all{|item| pbIsOpposing?(item) }.length==perishSongUsers.length) ||
         (perishSongUsers.find_all{|item| !pbIsOpposing?(item) }.length==perishSongUsers.length)
        pbJudgeCheckpoint(@battlers[perishSongUsers[0]])
      end
    end
    if @decision>0
      pbGainEXP
      return
    end
    texts = ["Your","The opposing"]
    # Reflect
    for i in 0...2
      next if sides[i].effects[:Reflect] == 0
      sides[i].effects[:Reflect]-=1
      pbDisplay(_INTL("#{texts[i]} team's Reflect faded!")) if sides[i].effects[:Reflect]==0
    end
    # Light Screen
    for i in 0...2
      next if sides[i].effects[:LightScreen] == 0
      sides[i].effects[:LightScreen]-=1
      pbDisplay(_INTL("#{texts[i]} team's Light Screen faded!")) if sides[i].effects[:LightScreen]==0
    end
    # Aurora Veil
    for i in 0...2
      next if sides[i].effects[:AuroraVeil] == 0
      sides[i].effects[:AuroraVeil]-=1
      pbDisplay(_INTL("#{texts[i]} team's Aurora Veil faded!")) if sides[i].effects[:AuroraVeil]==0
    end
    for i in 0...2
      next if sides[i].effects[:AreniteWall] == 0
      sides[i].effects[:AreniteWall]-=1
      pbDisplay(_INTL("#{texts[i]} team's Arenite Wall faded!")) if sides[i].effects[:AreniteWall]==0
    end
    # Safeguard
    for i in 0...2
      next if sides[i].effects[:Safeguard] == 0
      sides[i].effects[:Safeguard]-=1
      pbDisplay(_INTL("#{texts[i]} team is no longer protected by Safeguard!")) if sides[i].effects[:Safeguard]==0
    end
    # Mist
    for i in 0...2
      next if sides[i].effects[:Mist] == 0
      sides[i].effects[:Mist]-=1
      pbDisplay(_INTL("#{texts[i]} team's Mist faded!")) if sides[i].effects[:Mist]==0
    end
    # Tailwind
    for i in 0...2
      next if sides[i].effects[:Tailwind] == 0
      sides[i].effects[:Tailwind]-=1
      pbDisplay(_INTL("#{texts[i]} team's tailwind stopped blowing!")) if sides[i].effects[:Tailwind]==0
    end
    # Lucky Chant
    for i in 0...2
      next if sides[i].effects[:LuckyChant] == 0
      sides[i].effects[:LuckyChant]-=1
      pbDisplay(_INTL("#{texts[i]} team's Lucky Chant faded!")) if sides[i].effects[:LuckyChant]==0
    end
    # Mud Sport
    if @state.effects[:MudSport]>0
      @state.effects[:MudSport]-=1
      if @state.effects[:MudSport]==0
        if Rejuv && @field.backup == :ELECTERRAIN && @field.effect != :ELECTERRAIN
          breakField
          pbDisplay(_INTL("The field electrified again!"))
        else
          pbDisplay(_INTL("The effects of Mud Sport faded."))
        end
      end
    end
    # Water Sport
    if @state.effects[:WaterSport]>0
      @state.effects[:WaterSport]-=1
      pbDisplay(_INTL("The effects of Water Sport faded.")) if @state.effects[:WaterSport]==0
    end
    # Gravity
    if @state.effects[:Gravity]>0
      @state.effects[:Gravity]-=1 if @field.effect != :FROZENDIMENSION
      if @state.effects[:Gravity]==0
        if @field.backup == :NEWWORLD && @field.effect != :NEWWORLD
          breakField
          pbDisplay(_INTL("The world broke apart again!"))
          noWeather
        else
          pbDisplay(_INTL("Gravity returned to normal."))
        end
      end
    end

    # Terrain
    if @field.duration>0
      @field.checkPermCondition(self)
    end
    if @field.duration>0
      @field.duration-=1
      @field.duration = 0 if @field.duration_condition && !@field.duration_condition.call(self)
      if @field.duration==0
        endTempField
        pbDisplay(_INTL("The terrain returned to normal."))
        noWeather
      end
    end
    # Terrain overlays
    if @state.effects[:ELECTERRAIN]>0
      @state.effects[:ELECTERRAIN]-=1
      pbDisplay(_INTL("The surging electricity dissipated.")) if @state.effects[:ELECTERRAIN]==0
    end
    if @state.effects[:GRASSY]>0
      @state.effects[:GRASSY]-=1
      pbDisplay(_INTL("The surrounding grass withered.")) if @state.effects[:GRASSY]==0
    end
    if @state.effects[:MISTY]>0
      @state.effects[:MISTY]-=1
      pbDisplay(_INTL("The surrounding mist dispersed.")) if @state.effects[:MISTY]==0
    end
    if @state.effects[:PSYTERRAIN]>0
      @state.effects[:PSYTERRAIN]-=1
      pbDisplay(_INTL("The psychic energy left as mysteriously as it came.")) if @state.effects[:PSYTERRAIN]==0
    end
    if @state.effects[:RAINBOW]>0
      @state.effects[:RAINBOW]-=1
      pbDisplay(_INTL("The rainbow disappeared.")) if @state.effects[:RAINBOW]==0
    end
    # Trick Room - should go here
    # Wonder Room - should go here
    # Magic Room
    if @state.effects[:MagicRoom]>0
      @state.effects[:MagicRoom]-=1 if @field.effect != :FROZENDIMENSION
      pbDisplay(_INTL("The area returned to normal.")) if @state.effects[:MagicRoom]==0
    end
    # Fairy Lock
    if @state.effects[:FairyLock]>0
      @state.effects[:FairyLock]-=1
      # Fairy Lock seems to have no end-of-effect text so I've added some.
      pbDisplay(_INTL("The Fairy Lock was released.")) if @state.effects[:FairyLock]==0
    end
    # Uproar
    for i in priority
      next if i.isFainted?
      if i.effects[:Uproar]>0
        for j in priority
          if !j.isFainted? && j.status== :SLEEP && !j.ability == (:SOUNDPROOF)
            j.effects[:Nightmare]=false
            j.status=nil
            j.statusCount=0
            pbDisplay(_INTL("{1} woke up in the uproar!",j.pbThis))
          end
        end
        i.effects[:Uproar]-=1
        if i.effects[:Uproar]==0
          pbDisplay(_INTL("{1} calmed down.",i.pbThis))
        else
          pbDisplay(_INTL("{1} is making an uproar!",i.pbThis))
        end
      end
    end

    # Slow Start's end message
    for i in priority
      next if i.isFainted?
      if i.ability==:SLOWSTART && i.turncount==4 && !@battle.FE == :DEEPEARTH
        pbDisplay(_INTL("{1} finally got its act together!",i.pbThis))
      end
    end

    #Wasteland hazard interaction
    if @field.effect == :WASTELAND
      for i in priority
        is_fainted_before = i.isFainted?
        partner_fainted_before = @doublebattle && i.pbPartner.isFainted?
        # Stealth Rock
        if i.pbOwnSide.effects[:StealthRock]
          pbDisplay(_INTL("The waste swallowed up the pointed stones!"))
          i.pbOwnSide.effects[:StealthRock]=false
          pbDisplay(_INTL("...Rocks spewed out from the ground below!"))
          for mon in [i, i.pbPartner]
            next if mon.isFainted? || PBStuff::TWOTURNMOVE.include?(mon.effects[:TwoTurnAttack])
            eff=PBTypes.twoTypeEff(:ROCK,mon.type1,mon.type2)
            next if eff <=0
            @scene.pbDamageAnimation(mon,0)
            mon.pbReduceHP([(mon.totalhp*eff/16).floor,1].max)
          end
        end

        # Spikes
        if i.pbOwnSide.effects[:Spikes]>0
          pbDisplay(_INTL("The waste swallowed up the spikes!"))
          i.pbOwnSide.effects[:Spikes]=0
          pbDisplay(_INTL("...Stalagmites burst up from the ground!"))
          for mon in [i, i.pbPartner]
            if !mon.isFainted? && !mon.isAirborne? && !PBStuff::TWOTURNMOVE.include?(mon.effects[:TwoTurnAttack]) # Dig, Dive, etc
              @scene.pbDamageAnimation(mon,0)
              mon.pbReduceHP([(mon.totalhp/3.0).floor,1].max)
            end
          end
        end

        # Toxic Spikes
        if i.pbOwnSide.effects[:ToxicSpikes]>0
          pbDisplay(_INTL("The waste swallowed up the toxic spikes!"))
          i.pbOwnSide.effects[:ToxicSpikes]=0
          pbDisplay(_INTL("...Poison needles shot up from the ground!"))
          for mon in [i, i.pbPartner]
            next if mon.isFainted? || mon.isAirborne? || mon.hasType?(:STEEL) || mon.hasType?(:POISON)
            next if PBStuff::TWOTURNMOVE.include?(mon.effects[:TwoTurnAttack])
            @scene.pbDamageAnimation(mon,0)
            mon.pbReduceHP([(mon.totalhp/8.0).floor,1].max)
            if mon.status.nil? && mon.pbCanPoison?(false)
              mon.status=:POISON
              mon.statusCount=1
              mon.effects[:Toxic]=0
              pbCommonAnimation("Poison",mon,nil)
            end
          end
        end

        # Sticky Web
        if i.pbOwnSide.effects[:StickyWeb]
          pbDisplay(_INTL("The waste swallowed up the sticky web!"))
          i.pbOwnSide.effects[:StickyWeb]=false
          pbDisplay(_INTL("...Sticky string shot out of the ground!"))
          for mon in [i, i.pbPartner]
            next if mon.isFainted? && !PBStuff::TWOTURNMOVE.include?(mon.effects[:TwoTurnAttack])
            if mon.ability == :CONTRARY && !mon.pbTooHigh?(PBStats::SPEED)
              mon.pbIncreaseStatBasic(PBStats::SPEED,4)
                pbCommonAnimation("StatUp",mon,nil)
                pbDisplay(_INTL("{1}'s Speed went way up!",mon.pbThis))
            elsif !mon.pbTooLow?(PBStats::SPEED)
              mon.pbReduceStatBasic(PBStats::SPEED,4)
              pbCommonAnimation("StatDown",mon,nil)
              pbDisplay(_INTL("{1}'s Speed was severely lowered!",mon.pbThis))
            end
          end
        end

        # Fainting
        if @doublebattle && !partner_fainted_before
          partner=i.pbPartner
          if partner && partner.hp<=0
            partner.pbFaint
          end
        end
        if i.hp<=0 && !is_fainted_before
          return if !i.pbFaint
          next
        end
      end
    end
    # End Wasteland hazards
    for i in priority
      next if i.isFainted?
      # Mimicry
      if i.ability == :MIMICRY
        protype = -1
        case @field.effect
          when :CRYSTALCAVERN
            protype = @field.getRoll
          when :NEWWORLD
            protype = @battle.getRandomType
          else
            protype = @field.mimicry if @field.mimicry
        end
        prot1 = i.type1
        prot2 = i.type2
        camotype = protype
        if !camotype.nil? && (!i.hasType?(camotype) || (defined?(prot2) && prot1 != prot2))
          i.type1=camotype
          i.type2=camotype
          pbDisplay(_INTL("{1} had its type changed to {2}!",i.pbThis,camotype.capitalize))
        end
      end
      # Speed Boost
      # A Pokémon's turncount is 0 if it became active after the beginning of a round
      if i.turncount>0 && (i.ability == :SPEEDBOOST || (@field.effect == :ELECTERRAIN && i.ability == :MOTORDRIVE) || 
        ([:VOLCANIC,:VOLCANICTOP,:WATERSURFACE,:UNDERWATER,:INFERNAL].include?(@field.effect) && i.ability == :STEAMENGINE))
        if !i.pbTooHigh?(PBStats::SPEED)
          i.pbIncreaseStatBasic(PBStats::SPEED,1)
          pbCommonAnimation("StatUp",i,nil)
          pbDisplay(_INTL("{1}'s {2} raised its Speed!",i.pbThis, getAbilityName(i.ability)))
        end
      end
      if i.ability == :ACCUMULATION && i.turncount>0 && i.lastMoveUsed!=:SPITUP && i.lastMoveUsed!=:SWALLOW
        if i.effects[:Stockpile] <3
          i.effects[:Stockpile] +=1
          i.pbIncreaseStatBasic(PBStats::DEFENSE,1)
          i.effects[:StockpileDef] +=1
          i.pbIncreaseStatBasic(PBStats::SPDEF,1)
          i.effects[:StockpileSpDef] +=1
          pbDisplay(_INTL("{1} stockpiled with Accumulation!",i.pbThis))
        end
      end
      if @field.effect == :SWAMP && ![:WHITESMOKE,:CLEARBODY,:QUICKFEET,:SWIFTSWIM,:PROPELLERTAIL].include?(i.ability)
        if !i.isAirborne?
          if !i.pbTooLow?(PBStats::SPEED)
            contcheck = i.ability == :CONTRARY
            candrop = i.pbCanReduceStatStage?(PBStats::SPEED)
            canraise = i.pbCanIncreaseStatStage?(PBStats::SPEED) if contcheck
            statdrop = 1
            statdrop = 2 if i.effects[:MultiTurn]>0
            i.pbReduceStat(PBStats::SPEED,1, statmessage: false)
            pbDisplay(_INTL("{1}'s Speed sank...",i.pbThis)) if !contcheck && candrop
            pbDisplay(_INTL("{1}'s Speed rose!",i.pbThis)) if contcheck && canraise
          end
        end
      end
      if (@field.effect == :DESERT || @field.effect == :HAUNTED) && i.ability == :WANDERINGSPIRIT
        if !i.pbTooLow?(PBStats::SPEED)
          i.pbReduceStat(PBStats::SPEED,1, statmessage: false)
          pbDisplay(_INTL("{1}'s Wandering Spirit lowered its Speed!",i.pbThis))
        end
      end
      #sleepyswamp #sleepydimension #spookydreams #fairyringsleep
      if i.status== :SLEEP && !(i.ability == :MAGICGUARD)
        if @field.effect == :SWAMP # Swamp Field
          if i.effects[:MultiTurn]>0
            hploss=i.pbReduceHP((i.totalhp/8.0).floor,true)
          else
            hploss=i.pbReduceHP((i.totalhp/16.0).floor,true)
          end
          pbDisplay(_INTL("{1}'s strength is sapped by the swamp!",i.pbThis)) if hploss>0
        elsif @field.effect == :DIMENSIONAL #Dimensional Field (Rejuv)
          hploss=i.pbReduceHP((i.totalhp/16.0).floor,true)
          pbDisplay(_INTL("{1}'s dream is corrupted by the dimension!",i.pbThis)) if hploss>0
        elsif @field.effect == :HAUNTED && !(i.hasType?(:GHOST)) #Haunted Field (Rejuv)
          hploss=i.pbReduceHP((i.totalhp/16.0).floor,true)
          pbDisplay(_INTL("{1}'s dream is corrupted by the evil spirits!",i.pbThis)) if hploss>0
        elsif @field.effect == :BEWITCHED #Bewitched Woods (Rejuv)
          hploss=i.pbReduceHP((i.totalhp/16.0).floor,true)
          pbDisplay(_INTL("{1}'s dream is corrupted by the evil in the woods!",i.pbThis)) if hploss>0
        end
      end
      if i.hp<=0
        return if !i.pbFaint
        next
      end
      #sleepyrainbow
      if i.status== :SLEEP
        if @field.effect == :RAINBOW && i.effects[:HealBlock]==0#Rainbow Field
        hpgain=(i.totalhp/16.0).floor
        hpgain=i.pbRecoverHP(hpgain,true)
        pbDisplay(_INTL("{1} recovered health in its peaceful sleep!",i.pbThis))
        end
      end
      #sleepycorro
      if i.status== :SLEEP && i.ability != :MAGICGUARD && !(i.ability == :POISONHEAL || (i.species == :ZANGOOSE && i.crested)) && i.ability != :TOXICBOOST &&
      i.ability != :WONDERGUARD && !i.isAirborne? && !i.hasType?(:STEEL) && !i.hasType?(:POISON) && @field.effect == :CORROSIVE
        hploss=i.pbReduceHP((i.totalhp/16.0).floor,true)
        pbDisplay(_INTL("{1}'s is seared by the corrosion!",i.pbThis)) if hploss>0
      end
      if i.hp<=0
        return if !i.pbFaint
        next
      end
    # Water Compaction on Water-based Fields
    if i.ability == :WATERCOMPACTION
      if [:SWAMP,:WATERSURFACE,:UNDERWATER,:MURKWATERSURFACE].include?(@field.effect)
        if !i.pbTooHigh?(PBStats::DEFENSE)
          i.pbIncreaseStatBasic(PBStats::DEFENSE,2)
          pbCommonAnimation("StatUp",i,nil)
          pbDisplay(_INTL("{1}'s Water Compaction sharply raised its defense!", i.pbThis))
         end
       end
     end
     if i.effects[:Octolock]>=0
      locklowered = false
      if !i.pbTooLow?(PBStats::DEFENSE)
        contcheck = (i.ability == :CONTRARY)
        i.pbReduceStat(PBStats::DEFENSE,1,abilitymessage:false)
        locklowered = true if !contcheck
      end
      if !i.pbTooLow?(PBStats::SPDEF)
        contcheck = (i.ability == :CONTRARY)
        i.pbReduceStat(PBStats::SPDEF,1,abilitymessage:false)
        locklowered = true if !contcheck
      end
      if locklowered
        pbCommonAnimation("StatDown",i,nil)
        pbDisplay(_INTL("The Octolock lowered {1}'s defenses!",i.pbThis))
      end
    end
    # Bad Dreams
    if (i.status== :SLEEP || (i.ability == :COMATOSE && @battle.FE != :ELECTERRAIN)) && i.ability != :MAGICGUARD && !(i.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM) && @field.effect != :RAINBOW
      if i.pbOpposing1.ability == (:BADDREAMS) || i.pbOpposing2.ability == (:BADDREAMS)
        hpdrain=(i.totalhp/8.0).floor
        hpdrain=(i.totalhp/6.0).floor if @battle.FE == :DARKNESS2
        hpdrain=(i.totalhp/4.0).floor if @battle.FE == :INFERNAL || @battle.FE == :DARKNESS3
        hploss=i.pbReduceHP(hpdrain,true)
        pbDisplay(_INTL("{1} is having a bad dream!",i.pbThis)) if hploss>0
      end
    end
    if i.isFainted?
      return if !i.pbFaint
      next
    end
    # World of Nightmares
    if i.pbOpposing1.ability == :WORLDOFNIGHTMARES || i.pbOpposing2.ability == :WORLDOFNIGHTMARES
      nightmarechip=[64,i.turncount].min
      nightmarechip*2 if @battle.FE == :NEWWORLD
      hploss=i.pbReduceHP(((i.totalhp/32).floor)*nightmarechip,true)
      pbDisplay(_INTL("{1}'s nightmares are becoming a reality!",i.pbThis)) if hploss>0
    end
    if i.isFainted?
      return if !i.pbFaint
      next
    end
    # Harvest
    if i.ability == :HARVEST && i.item.nil? && i.pokemon.itemRecycle #if an item was recycled, check
      if pbIsBerry?(i.pokemon.itemRecycle) && (pbRandom(100)>50 || (pbWeather== :SUNNYDAY && !i.hasWorkingItem(:UTILITYUMBRELLA)) ||
         @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN,2,5) || (Rejuv && @battle.FE == :GRASSY))
        i.item=i.pokemon.itemRecycle
        i.pokemon.itemInitial=i.pokemon.itemRecycle
        i.pokemon.itemRecycle=nil
        firstberryletter=getItemName(i.item).split(//).first
        if firstberryletter=="A" || firstberryletter=="E" || firstberryletter=="I" ||
          firstberryletter=="O" || firstberryletter=="U"
              pbDisplay(_INTL("{1} harvested an {2}!",i.pbThis,getItemName(i.item)))
        else
          pbDisplay(_INTL("{1} harvested a {2}!",i.pbThis,getItemName(i.item)))
        end
        i.pbBerryCureCheck(true)
      end
    end
    # Ball Fetch
    puts i.effects[:BallFetch]
    if i.ability == :BALLFETCH && !i.effects[:BallFetch].nil? && i.item.nil?
      pokeball=i.effects[:BallFetch]
      i.item=pokeball
      i.pokemon.itemInitial=pokeball
      PBDebug.log("[Ability triggered] #{i.pbThis}'s Ball Fetch found #{getItemName(pokeball)}")
      pbDisplay(_INTL("{1} fetched a {2}!",i.pbThis,getItemName(pokeball)))
    end
    # Moody
    if i.ability == :CLOUDNINE && @field.effect == :RAINBOW
      failsafe=0
      randoms=[]
      loop do
        failsafe+=1
        break if failsafe==1000
        randomnumber=1+pbRandom(7)
        if !i.pbTooHigh?(randomnumber)
          randoms.push(randomnumber)
          break
        end
      end
      if failsafe!=1000
       i.stages[randoms[0]]+=1
       i.stages[randoms[0]]=6 if i.stages[randoms[0]]>6
       pbCommonAnimation("StatUp",i,nil)
       pbDisplay(_INTL("{1}'s Cloud Nine raised its {2}!",i.pbThis,i.pbGetStatName(randoms[0])))
      end
    end
    if i.ability == :MOODY
      randomup=[]
      randomdown=[]
      failsafe1=0
      failsafe2=0
      loop do
        failsafe1+=1
        break if failsafe1==1000
        randomnumber=1+pbRandom(5)
        if !i.pbTooHigh?(randomnumber)
          randomup.push(randomnumber)
          break
        end
      end
      loop do
        failsafe2+=1
        break if failsafe2==1000
        randomnumber=1+pbRandom(5)
        if !i.pbTooLow?(randomnumber) && randomnumber!=randomup[0]
          randomdown.push(randomnumber)
          break
        end
      end
       if failsafe1!=1000
         i.stages[randomup[0]]+=2
         i.stages[randomup[0]]=6 if i.stages[randomup[0]]>6
         pbCommonAnimation("StatUp",i,nil)
         pbDisplay(_INTL("{1}'s Moody sharply raised its {2}!",i.pbThis,i.pbGetStatName(randomup[0])))
       end
       if failsafe2!=1000
         i.stages[randomdown[0]]-=1
         pbCommonAnimation("StatDown",i,nil)
         pbDisplay(_INTL("{1}'s Moody lowered its {2}!",i.pbThis,i.pbGetStatName(randomdown[0])))
       end
     end
    end
    # Gen 9 Mod - Checks and updates for Opportunist
    priority.each {|i| i.opportunistCheck}
    priority.each {|i| i.statsRaisedSinceLastCheck.clear}
    for i in priority
      next if i.isFainted?
      next if !i.itemWorks?
      # Toxic Orb
      if i.item == :TOXICORB && i.status.nil? && i.pbCanPoison?(false,true)
        i.status=:POISON
        i.statusCount=1
        i.effects[:Toxic]=0
        pbCommonAnimation("Poison",i,nil)
        pbDisplay(_INTL("{1} was poisoned by its {2}!",i.pbThis,getItemName(i.item)))
      end
      # Flame Orb
      if i.item == :FLAMEORB && i.status.nil? && i.pbCanBurn?(false,true)
        i.status=:BURN
        i.statusCount=0
        pbCommonAnimation("Burn",i,nil)
        pbDisplay(_INTL("{1} was burned by its {2}!",i.pbThis,getItemName(i.item)))
      end
      # Sticky Barb
      if i.item == :STICKYBARB && i.ability != :MAGICGUARD && !(pkmn.ability == :WONDERGUARD && @battle.FE == :COLOSSEUM)
        pbDisplay(_INTL("{1} is hurt by its {2}!",i.pbThis,getItemName(i.item)))
        @scene.pbDamageAnimation(i,0)
        i.pbReduceHP((i.totalhp/8.0).floor)
      end
      if i.isFainted?
        return if !i.pbFaint
        next
      end
    end
    #Emergency exit caused by passive end of turn damage
    for i in priority
      if i.userSwitch
        i.userSwitch = false
        pbDisplay(_INTL("{1} went back to {2}!",i.pbThis,pbGetOwner(i.index).name))
        newpoke=0
        newpoke=pbSwitchInBetween(i.index,true,false)
        pbMessagesOnReplace(i.index,newpoke)
        i.vanished=false
        i.pbResetForm
        pbReplace(i.index,newpoke,false)
        pbOnActiveOne(i)
        i.pbAbilitiesOnSwitchIn(true)
      end
    end
    # Hunger Switch
    for i in priority
      next if i.isFainted?
      if i.ability == :HUNGERSWITCH && (i.species == :MORPEKO) && @battle.FE != :FROZENDIMENSION
        i.form=(i.form==0) ? 1 : 0
        i.pbUpdate(true)
        scene.pbChangePokemon(i,i.pokemon)
        pbDisplay(_INTL("{1} transformed!",i.pbThis))
      end
    end
    # Form checks
    for i in 0...4
      next if @battlers[i].isFainted?
      @battlers[i].pbCheckForm
      @battlers[i].pbCheckFormRoundEnd
    end
    pbGainEXP

    # Checks if a pokemon on either side has fainted on this turn
    # for retaliate
    player   = priority[0]
    opponent = priority[1]
    player.pbOwnSide.effects[:Retaliate] = player.isFainted? || (@doublebattle && player.pbPartner.isFainted?)
    opponent.pbOwnSide.effects[:Retaliate] = opponent.isFainted? || (@doublebattle && opponent.pbPartner.isFainted?)
    @state.effects[:sosBuffer]=2 if @state.effects[:sosBuffer]==0 && (opponent.issossmon && opponent.isFainted? || (@doublebattle && opponent.pbPartner.issossmon && opponent.pbPartner.isFainted?))
    # sosBuffer
    if @state.effects[:sosBuffer]>0
      @state.effects[:sosBuffer]-=1
    end
    pbBossSOS(priority) if Rejuv && @state.effects[:sosBuffer]==0    
    pbSwitch
    return if @decision>0
    for i in priority
      next if i.isFainted?
      i.pbAbilitiesOnSwitchIn(false)
    end
    for i in 0...4
      if @battlers[i].turncount>0 && @battlers[i].ability == :TRUANT
        @battlers[i].effects[:Truant]=!@battlers[i].effects[:Truant]
      end
      if @battlers[i].effects[:LockOn]>0   # Also Mind Reader
        @battlers[i].effects[:LockOn]-=1
        @battlers[i].effects[:LockOnPos]=-1 if @battlers[i].effects[:LockOn]==0
      end
      @battlers[i].effects[:Roost]=false
      @battlers[i].effects[:Flinch]=false
      @battlers[i].effects[:FollowMe]=false
      @battlers[i].effects[:RagePowder]=false
      @battlers[i].effects[:HelpingHand]=false
      @battlers[i].effects[:MagicCoat]=false
      @battlers[i].effects[:Snatch]=false
      @battlers[i].effects[:Electrify]=false
      @battlers[i].effects[:Charge]-=1 if @battlers[i].effects[:Charge]>0
      @battlers[i].lastHPLost=0
      @battlers[i].lastAttacker=-1
      @battlers[i].effects[:Counter]=-1
      @battlers[i].effects[:CounterTarget]=-1
      @battlers[i].effects[:MirrorCoat]=-1
      @battlers[i].effects[:MirrorCoatTarget]=-1
    end
    # Gen 9 Mod - Checks and updates for Opportunist
    priority.each {|i| i.opportunistCheck}
    priority.each {|i| i.statsRaisedSinceLastCheck.clear}
    # invalidate stored priority
    @usepriority=false
    @eruption= false
  end

  def pbPriority(ignorequickclaw = true,megacalc = false)
    return @priority if @usepriority && !megacalc # use stored priority if round isn't over yet (best ged rid of this in gen 8)
    @priority.clear
    priorityarray = []
    quickclawarray = [0,0,0,0]
    # -Move priority take precedence(stored as priorityarray[i][0])
    # -Then Items  (stored as priorityarray[i][1])
    # -Then speed (stored as priorityarray[i][2]) (trick room is applied by just making speed negative.)
    # -The last element is just the battler index (which is otherwise lost when sorting)
    for i in 0..3
      priorityarray[i] = [0,0,0,i] #initializes the array and stores the battler index

      # Move priority
      pri = 0
      if (@choices[i][0] == 2 || @battle.switchedOut[i]) # If switching or has switched
        pri = 12
      end
      if @choices[i][0] == 3 #Used item
        pri = 11
      end
      if @choices[i][0] == 1 # Is a move
        pri = @choices[i][2].priority if !@choices[i][2].zmove  #Base move priority
        pri -= 1 if @battle.FE == :DEEPEARTH && @choices[i][2].move == :COREENFORCER
        pri += 1 if [:ORN_POUNCE,:ORN_LEADERSHIP].include?(battlers[i].ability) && battlers[i].turncount == 1
        pri += 1 if @field.effect == :CHESS && @battlers[i].pokemon && @battlers[i].pokemon.piece == :KING
        pri += 1 if @battlers[i].ability == :PRANKSTER && @choices[i][2].basedamage==0 && @battlers[i].effects[:TwoTurnAttack] == 0 # Is status move
        pri += 1 if @battlers[i].ability == :GALEWINGS && @choices[i][2].type==:FLYING && ((@battlers[i].hp == @battlers[i].totalhp) || ((@field.effect == :MOUNTAIN || @field.effect == :SNOWYMOUNTAIN) && @weather == :STRONGWINDS))
        pri += 1 if @choices[i][2].move == :GRASSYGLIDE && (@field.effect == :GRASSY || @battle.state.effects[:GRASSY] > 0)
        pri += 1 if @choices[i][2].move == :QUASH && @field.effect == :DIMENSIONAL
        pri += 1 if @choices[i][2].basedamage != 0 && @battlers[i].species == :FERALIGATR && @battlers[i].crested && @battlers[i].turncount == 0 # Feraligatr Crest
        pri += 3 if @battlers[i].ability == :TRIAGE && (PBStuff::HEALFUNCTIONS).include?(@choices[i][2].function)
      end
      priorityarray[i][0]=pri

      #Item/stall priority (all items overwrite stall priority)
      priorityarray[i][1] = -1 if @battlers[i].ability == :STALL 
      if !ignorequickclaw && @choices[i][0] == 1 # Is a move
        if (@battlers[i].ability == :QUICKDRAW && (pbRandom(100)<30))
          priorityarray[i][1] = 1
          quickclawarray[i] = :QUICKDRAW
        elsif (@battlers[i].itemWorks? && @battlers[i].item == :QUICKCLAW && (pbRandom(100)<20))
          priorityarray[i][1] = 1
          quickclawarray[i] = :QUICKCLAW
        elsif @battlers[i].custap
          priorityarray[i][1] = 1
          quickclawarray[i] = :CUSTAPBERRY
        end
      end
      priorityarray[i][1] = -2 if (@battlers[i].itemWorks? && (@battlers[i].item == :LAGGINGTAIL || @battlers[i].item == :FULLINCENSE))

      #speed priority
      priorityarray[i][2] = @battlers[i].pbSpeed if @trickroom == 0
      priorityarray[i][2] = -@battlers[i].pbSpeed if @trickroom > 0
      
    end
    priorityarray.sort!

    #Speed ties. Only works correctly if two pokemon speed tie
    speedtie = []
    for i in 0..2
      for j in (i+1)..3
        if priorityarray[i][0]==priorityarray[j][0] && priorityarray[i][1]==priorityarray[j][1] && priorityarray[i][2]==priorityarray[j][2]
          if pbRandom(2)==1 
            priorityarray[i],priorityarray[j] = priorityarray[j],priorityarray[i]
          end
        end
      end
    end
    priorityarray.reverse!

    # Quick claw battle message
    for i in 0..3
      @priority[i] = @battlers[priorityarray[i][3]]
      if (@battlers[i].ability == :QUICKDRAW) && quickclawarray[priorityarray[i][3]]==:QUICKDRAW
        if priorityarray[i][1] == 1 && !ignorequickclaw
          @battlers[i].effects[:Quickdrawsnipe] if @battle.FE == :COLOSSEUM
          pbDisplayBrief(_INTL("{1}'s Quick Draw let it move first!",@priority[i].pbThis))
        end
      elsif (@battlers[i].itemWorks? && @battlers[i].item == :QUICKCLAW) && quickclawarray[priorityarray[i][3]]==:QUICKCLAW
        pbDisplayBrief(_INTL("{1}'s Quick Claw let it move first!",@priority[i].pbThis)) if priorityarray[i][1] == 1 && !ignorequickclaw
      end
    end

    @usepriority=true
    return @priority
  end
end

class PBStuff
  ZMOVES = [
    :BREAKNECKBLITZ, :ALLOUTPUMMELING, :SUPERSONICSKYSTRIKE, :ACIDDOWNPOUR, :TECTONICRAGE, :CONTINENTALCRUSH,
    :SAVAGESPINOUT, :NEVERENDINGNIGHTMARE, :CORKSCREWCRASH, :INFERNOOVERDRIVE, :HYDROVORTEX, :BLOOMDOOM,
    :GIGAVOLTHAVOC, :SHATTEREDPSYCHE, :SUBZEROSLAMMER, :DEVASTATINGDRAKE, :BLACKHOLEECLIPSE, :TWINKLETACKLE,
    :STOKEDSPARKSURFER, :SINISTERARROWRAID, :MALICIOUSMOONSAULT, :OCEANICOPERETTA, :EXTREMEEVOBOOST, :CATASTROPIKA,
    :PULVERIZINGPANCAKE, :GENESISSUPERNOVA, :GUARDIANOFALOLA, :SOULSTEALING7STARSTRIKE, :CLANGOROUSSOULBLAZE,
    :SPLINTEREDSTORMSHARDS, :LETSSNUGGLEFOREVER,:SEARINGSUNRAZESMASH, :MENACINGMOONRAZEMAELSTROM, :LIGHTTHATBURNSTHESKY,
    :UNLEASHEDPOWER, :BLINDINGSPEED, :ELYSIANSHIELD, :CHTHONICMALADY, :DOMAINSHIFT,

    :ORN_ASTRALSTARSTORM,:ORN_ARCLIGHTBARRAGE,:ORN_ACOUSTICOVERLOAD,:ORN_ORIGINALGENESIS,:ORN_ORIGINALGENESIS1,:ORN_ORIGINALGENESIS2,:ORN_ORIGINALGENESIS3,
  ]

  TYPETOZCRYSTAL = {
    :NORMAL   => :NORMALIUMZ, :FIGHTING => :FIGHTINIUMZ,
    :FLYING   => :FLYINIUMZ,  :POISON   => :POISONIUMZ, 
    :GROUND   => :GROUNDIUMZ, :ROCK     => :ROCKIUMZ,
    :BUG      => :BUGINIUMZ,  :GHOST    => :GHOSTIUMZ,
    :STEEL    => :STEELIUMZ,  :FIRE     => :FIRIUMZ, 
    :WATER    => :WATERIUMZ,  :GRASS    => :GRASSIUMZ, 
    :ELECTRIC => :ELECTRIUMZ, :PSYCHIC  => :PSYCHIUMZ,
    :ICE      => :ICIUMZ,     :DRAGON   => :DRAGONIUMZ, 
    :DARK     => :DARKINIUMZ, :FAIRY    => :FAIRIUMZ,
    :COSMIC   => :COSMICIUMZ, :LIGHT    => :LIGHTIUMZ,
    :SOUND    => :SOUNDIUMZ,  :QMARKS   => :WARDENIUMZ,
  }

  CRYSTALTOZMOVE = {
    :NORMALIUMZ => :BREAKNECKBLITZ,           :FIGHTINIUMZ => :ALLOUTPUMMELING,
    :FLYINIUMZ => :SUPERSONICSKYSTRIKE,       :POISONIUMZ => :ACIDDOWNPOUR,
    :GROUNDIUMZ => :TECTONICRAGE,             :ROCKIUMZ => :CONTINENTALCRUSH,
    :BUGINIUMZ => :SAVAGESPINOUT,             :GHOSTIUMZ => :NEVERENDINGNIGHTMARE,
    :STEELIUMZ => :CORKSCREWCRASH,            :FIRIUMZ => :INFERNOOVERDRIVE,
    :WATERIUMZ => :HYDROVORTEX,               :GRASSIUMZ => :BLOOMDOOM,
    :ELECTRIUMZ => :GIGAVOLTHAVOC,            :PSYCHIUMZ => :SHATTEREDPSYCHE,
    :ICIUMZ => :SUBZEROSLAMMER,               :DRAGONIUMZ => :DEVASTATINGDRAKE,
    :DARKINIUMZ => :BLACKHOLEECLIPSE,         :FAIRIUMZ => :TWINKLETACKLE,
    :ALORAICHIUMZ => :STOKEDSPARKSURFER,      :DECIDIUMZ => :SINISTERARROWRAID,
    :INCINIUMZ => :MALICIOUSMOONSAULT,        :PRIMARIUMZ => :OCEANICOPERETTA,
    :EEVIUMZ => :EXTREMEEVOBOOST,             :PIKANIUMZ => :CATASTROPIKA,
    :SNORLIUMZ => :PULVERIZINGPANCAKE,        :MEWNIUMZ => :GENESISSUPERNOVA,
    :TAPUNIUMZ => :GUARDIANOFALOLA,           :MARSHADIUMZ => :SOULSTEALING7STARSTRIKE,
    :KOMMONIUMZ => :CLANGOROUSSOULBLAZE,      :LYCANIUMZ => :SPLINTEREDSTORMSHARDS,
    :MIMIKIUMZ => :LETSSNUGGLEFOREVER,        :SOLGANIUMZ => :SEARINGSUNRAZESMASH,
    :LUNALIUMZ => :MENACINGMOONRAZEMAELSTROM, :ULTRANECROZIUMZ => :LIGHTTHATBURNSTHESKY,
    :COSMICIUMZ => :ORN_ASTRALSTARSTORM,      :LIGHTIUMZ => :ORN_ARCLIGHTBARRAGE,
    :SOUNDIUMZ => :ORN_ACOUSTICOVERLOAD,      :WARDENIUMZ      => :ORN_ORIGINALGENESIS,
  }

  WARDEN_MEGASTONE = {:ORN_GENGAR => [:ORN_GENGARITE], :ORN_DODRIO => [:ORN_DODRINITE], :ORN_ARBOK => [:ORN_ARBOKINITE], :ORN_STARMIE => [:ORN_STARMITE], :ORN_STEELIX => [:ORN_STEELIXITE], :ORN_XATU => [:ORN_XATUNITE], :ORN_SEISMITOAD => [:ORN_SEISMITOADITE], :ORN_GOLURK => [:ORN_GOLITE], :ORN_GYARADOS => [:ORN_GYARADOSITE], :ORN_AVALUGG => [:ORN_AVALUGGITE], :ORN_RAPIDASH => [:ORN_RAPIDASHINITE], :ORN_AERODACTYL => [:ORN_AERODACTYLITE], :ORN_GIGALITH => [:ORN_GIGANITE], :ORN_GLISCOR => [:ORN_GLISCITE], :ORN_SUDOWOODO => [:ORN_SUDOWOODITE], :ORN_NOCTOWL => [:ORN_NOCTOWLITE], :ORN_ELECTRODE => [:ORN_ELECTRONITE], :ORN_BEEDRILL => [:ORN_BEEDRILLITE], :ORN_MACHAMP => [:ORN_MACHAMPITE], :ORN_VENUSAUR => [:ORN_VENUSAURITE], :ORN_SHARPEDO => [:ORN_SHARPEDONITE], :ORN_CHANDELURE => [:ORN_CHANDELITE], :ORN_GLALIE => [:ORN_GLALITITE], :ORN_FROSLASS => [:ORN_FROSLASSITE], :ORN_INFERNAPE => [:ORN_INFERNAPINITE], :ORN_SABLEYE => [:ORN_SABLENITE], :ORN_BEARTIC => [:ORN_BEARTICITE], :ORN_SCEPTILE => [:ORN_SCEPTILITE], :ORN_TYRANITAR => [:ORN_TYRANITARITE], :ORN_HIPPOWDON => [:ORN_HIPPOWDONITE], :ORN_AMPHAROS => [:ORN_AMPHAROSITE], :ORN_ALTARIA => [:ORN_ALTARIANITE], :ORN_HERACROSS => [:ORN_HERACRONITE], :ORN_SAWSBUCK => [:ORN_SAWSBUCKITE], :ORN_AGGRON => [:ORN_AGGRONITE], :ORN_SLOWKING => [:ORN_SLOWKINGITE], :ORN_CORVIKNIGHT => [:ORN_CORVINITE], :ORN_KINGDRA => [:ORN_KINGDRANITE], :ORN_BUTTERFREE => [:ORN_BUTTERFRITE], :ORN_FURRET => [:ORN_FURRETITE], :ORN_GARDEVOIR => [:ORN_GARDEVOIRITE], :ORN_GALLADE => [:ORN_GALLADITE], :ORN_DUGTRIO => [:ORN_DUGTRIOITE], :ORN_MELOETTA => [:ORN_MELOETTITE], :ORN_ABSOL => [:ORN_ABSOLITE], :ORN_METAGROSS => [:ORN_METAGROSSITE], :ORN_MEDICHAM => [:ORN_MEDICHAMITE], :ORN_PIDGEOT => [:ORN_PIDGEOTITE], :ORN_BLISSEY => [:ORN_BLISSITE], :ORN_TENTACRUEL => [:ORN_TENTACRUELITE], :ORN_TSAREENA => [:ORN_TSAREENITEX, :ORN_TSAREENITEY], :ORN_BEHEEYEM => [:ORN_BEHEEYEMITE], :ORN_SANDACONDA => [:ORN_SANDACONITE], :ORN_RAICHU => [:ORN_RAICHUNITE], :ORN_COFAGRIGUS => [:ORN_COFAGRINITE], :ORN_SWAMPERT => [:ORN_SWAMPERTITE], :ORN_GOTHITELLE => [:ORN_GOTHITELLITE], :ORN_CHARIZARD => [:ORN_CHARIZARDITE], :ORN_WIGGLYTUFF => [:ORN_WIGGNITE], :ORN_MANECTRIC => [:ORN_MANECTITE], :ORN_MAMOSWINE => [:ORN_MAMOSWINITE], :ORN_TORTERRA => [:ORN_TORTERRANITE], :ORN_LOPUNNY => [:ORN_LOPUNNITE], :ORN_GOTHITELLE2 => [:ORN_GOTHITELLITE2], :ORN_DONPHAN => [:ORN_DONPHANITE], :ORN_GARCHOMP => [:ORN_GARCHOMPITE], :ORN_NINETALES => [:ORN_NINETALITE], :ORN_TOXTRICITY => [:ORN_TOXTRICITE], :ORN_DUGTRIO2 => [:ORN_DUGTRIOITE2], :ORN_LUVDISC => [:ORN_LUVDISCITE], :ORN_ABSOL2 => [:ORN_ABSOLITE2], :ORN_ABOMASNOW => [:ORN_ABOMASITE], :ORN_SABLEYE2 => [:ORN_SABLENITE2], :ORN_GARBODOR => [:ORN_GARBODINITE], :ORN_ALTARIA2 => [:ORN_ALTARIANITE2], :ORN_SWAMPERT2 => [:ORN_SWAMPERTITE2], :ORN_MASQUERAIN2 => [:ORN_MASQUERITE2], :ORN_BARBARACLE => [:ORN_BARBARACLITE], :ORN_FALINKS => [:ORN_FALINKITE], :ORN_MISMAGIUS => [:ORN_MISMAGITE], :ORN_COALOSSAL => [:ORN_COALOSSALITE], :ORN_GIGALITH2 => [:ORN_GIGANITE2], :ORN_DRAGONITE => [:ORN_DRAGITE], :ORN_DRAGAPULT => [:ORN_DRAGAPULTITE], :ORN_BANETTE => [:ORN_BANETTITE], :ORN_HOUNDOOM => [:ORN_HOUNDOOMINITE], :ORN_EMPOLEON => [:ORN_EMPOLEONITE], :ORN_JUMPLUFF2 => [:ORN_JUMPINITE2], :ORN_EXPLOUD => [:ORN_EXPLOUDINITE], :ORN_CENTISKORCH => [:ORN_CENTISKORITE], :ORN_SALAMENCE => [:ORN_SALAMENCITE], :ORN_GRAPPLOCT => [:ORN_GRAPPLOCTITE], :ORN_HATTERENE => [:ORN_HATTERENITE], :ORN_CHIMECHO => [:ORN_CHIMECHITE], :ORN_GRIMMSNARL2 => [:ORN_GRIMMSNARLITE2], :ORN_WYRDEER2 => [:ORN_WYRDEERITE2], :ORN_URSALUNA => [:ORN_URSALUNITE], :ORN_EMOLGA => [:ORN_EMOLGITE], :ORN_VESPIQUEN => [:ORN_VESPIQUENITE], :ORN_BLAZIKEN => [:ORN_BLAZIKENITE], :ORN_GARGANACL => [:ORN_GARGANACLITE], :ORN_WOBBUFFET => [:ORN_WOBBNITE], :ORN_PLUSLE => [:ORN_PLUSITE], :ORN_MINUN => [:ORN_MINUNITE], :ORN_BLASTOISE => [:ORN_BLASTOISINITE], :ORN_CACTURNE2 => [:ORN_CACTURNITE2], :ORN_URSALUNA2 => [:ORN_URSALUNITE2], :ORN_DREDNAW => [:ORN_DREDNITE], :ORN_MELMETAL => [:ORN_MELMETALITE], :ORN_WHIMSICOTT2 => [:ORN_WHIMSICOTTITE2], :ORN_CHARIZARD2 => [:ORN_CHARIZARDITE2]}
  WARDEN_MEGASTONE.default = []
end
