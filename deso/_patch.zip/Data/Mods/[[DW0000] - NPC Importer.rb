module Event_Import
  MapIDList = [442]  
  
  NewEvents = {
    #Orion Ticket Event
    442 => [{:x => 28,:y => 17, :Name => "Ticket Giver", :Pages => [
      {:Conditions => {:Switch1 => {:isChecked => true,:ID => 758}, :Switch2 => {:isChecked => false,:ID => 1},
       :Variable => {:isChecked => false,:ID => 1, :Value => 0}, :SelfSwitch => {:isChecked => false,:ID => "A"}},
       :Graphic => {:TileID => 0,:Name => "!OI _ Growlithe.png",:Hue => 0,:CharSheetColumn => 2,:CharSheetRow => 0,:Opacity => 255, :BlendType => 0,},
       :MoveType => 0, :MoveSpeed => 3, :MoveFrequency => 3, :Moving => true, :Stopped => true, :Fixed => false, :Passthrough => false, :AlwaysOnTop => false, :Trigger => 0,
       :List => [{:Command => 355,:Indent => 0, :Parameters => ["give_ORN_pass"]}]
       },
    ]}],
  }
  
end

def give_ORN_pass
  Kernel.pbMessage("There's a weird dog pokemon you can't help but pet... He offers you a Ticket!")
  Kernel.pbMessage("But you already have one, so you just pet the dog again.") if $PokemonBag.pbQuantity(:ORN_DRIFBLIMPPASS)==1
  Kernel.pbReceiveItem(:ORN_DRIFBLIMPPASS) if $PokemonBag.pbQuantity(:ORN_DRIFBLIMPPASS)==0
end

class Game_Map
  def importNewEvents()
    eventList = Event_Import::NewEvents
    #Event Start
      idoffset = 1
      for events in eventList[@map_id]
          newEvent = RPG::Event.new(events[:x], events[:y])
          newEvent.id = @map.events.keys.size + idoffset
          idoffset+=1
          newEvent.name = events[:Name]      
          #Event Pages Start
            newEventPages = Array.new(events[:Pages].length) {RPG::Event::Page.new}
            for page in 0...newEventPages.length
              
              #Event Conditions Start
                newConditions = RPG::Event::Page::Condition.new
                newConditions.switch1_valid = events[:Pages][page][:Conditions][:Switch1][:isChecked]
                newConditions.switch2_valid = events[:Pages][page][:Conditions][:Switch2][:isChecked]
                newConditions.variable_valid = events[:Pages][page][:Conditions][:Variable][:isChecked]
                newConditions.self_switch_valid = events[:Pages][page][:Conditions][:SelfSwitch][:isChecked]
                newConditions.switch1_id = events[:Pages][page][:Conditions][:Switch1][:ID]
                newConditions.switch2_id = events[:Pages][page][:Conditions][:Switch2][:ID]
                newConditions.variable_id = events[:Pages][page][:Conditions][:Variable][:ID]
                newConditions.variable_value = events[:Pages][page][:Conditions][:Variable][:Value]
                newConditions.self_switch_ch = events[:Pages][page][:Conditions][:SelfSwitch][:Char]
              #Event Conditions End
              newEventPages[page].condition = newConditions
      
              #Event Graphic Start
                newGraphic = RPG::Event::Page::Graphic.new
                newGraphic.tile_id = events[:Pages][page][:Graphic][:TileID]
                newGraphic.character_name = events[:Pages][page][:Graphic][:Name]
                newGraphic.character_hue = events[:Pages][page][:Graphic][:Hue]
                newGraphic.direction = events[:Pages][page][:Graphic][:CharSheetColumn]
                newGraphic.pattern = events[:Pages][page][:Graphic][:CharSheetRow]
                newGraphic.opacity = events[:Pages][page][:Graphic][:Opacity]
                newGraphic.blend_type = events[:Pages][page][:Graphic][:BlendType]
              #Event Graphic End
              newEventPages[page].graphic = newGraphic

              newEventPages[page].move_type = events[:Pages][page][:MoveType]
              newEventPages[page].move_speed = events[:Pages][page][:MoveSpeed]
              newEventPages[page].move_frequency = events[:Pages][page][:MoveFrequency]
              newEventPages[page].walk_anime = events[:Pages][page][:Moving]
              newEventPages[page].step_anime = events[:Pages][page][:Stopped]
              newEventPages[page].direction_fix = events[:Pages][page][:Fixed]
              newEventPages[page].through = events[:Pages][page][:Passthrough]
              newEventPages[page].always_on_top = events[:Pages][page][:AlwaysOnTop]
              newEventPages[page].trigger = events[:Pages][page][:Trigger]
              newEventPages[page].move_route = RPG::MoveRoute.new
      
              #Event Commands Start
                eventCommands = Array.new(events[:Pages][page][:List].length + 1) {RPG::EventCommand.new}
                for line in 0...eventCommands.length - 1
                  eventCommands[line].code = events[:Pages][page][:List][line][:Command]
                  eventCommands[line].indent = events[:Pages][page][:List][line][:Indent]
                  eventCommands[line].parameters = events[:Pages][page][:List][line][:Parameters]
                  #Kernel.pbMessage("#{events[:Pages][page][:List][line][:Parameters]}")
                end

              #Event Commands End
              newEventPages[page].list = eventCommands
            end
          #Event Pages End
          newEvent.pages = newEventPages
          @events[newEvent.id] = Game_Event.new(@map_id, newEvent, self)
      end
    #Event End
  end

  def setup(map_id,fromLoad=false,mapdata=nil)
    @map_id = map_id
    # Use previous map if available
    if $previous_map && $previous_map_id && $previous_map_id==map_id
      @map=$previous_map
    else
      @map = $cache.map_load(map_id)
    end
    $previous_map = $previous_map_id = nil
    # Setup data from tileset
    tileset = $cache.RXtilesets[@map.tileset_id]
    @tileset_name = tileset.tileset_name
    @autotile_names = tileset.autotile_names
    if tileset.panorama_name != ""
      @panorama_name = tileset.panorama_name
      @panorama_hue = tileset.panorama_hue
    end
    @battleback_name = tileset.battleback_name
    @passages = tileset.passages
    @priorities = tileset.priorities
    @terrain_tags = tileset.terrain_tags
    # Setup map data
    @outdoor = $cache.mapdata[@map_id].Outdoor rescue false
    @has_connections = $MapFactory.getNewMapConnections if map_id != STARTINGMAP && !fromLoad
    self.display_x = 0
    self.display_y = 0
    @need_refresh = false
    Events.onMapCreate.trigger(self,map_id, @map, tileset) if !fromLoad
    # Setup events
    @events = {}
    for i in @map.events.keys
      @events[i] = Game_Event.new(@map_id, @map.events[i],self)
    end
    @common_events = {}
    for i in 1...$cache.RXevents.size
      common_event = Game_CommonEvent.new(i)
      if common_event.interpreter != nil
        @common_events[i] = common_event
      end
    end
    if Event_Import::MapIDList.include?(@map_id)
      importNewEvents()
    end
    # Setup fog and scrolling
    @scroll_direction = 2
    @scroll_rest = 0
    @scroll_speed = 4
    if @fog_name != ""
      @fog_name = tileset.fog_name
      @fog_hue = tileset.fog_hue
      @fog_opacity = tileset.fog_opacity
      @fog_blend_type = tileset.fog_blend_type
      @fog_zoom = tileset.fog_zoom
      @fog_sx = tileset.fog_sx
      @fog_sy = tileset.fog_sy
      @fog_ox = 0
      @fog_oy = 0
      @fog_tone = Tone.new(0, 0, 0, 0)
      @fog_tone_target = Tone.new(0, 0, 0, 0)
      @fog_tone_duration = 0
      @fog_opacity_duration = 0
      @fog_opacity_target = 0
    end
  end
end
